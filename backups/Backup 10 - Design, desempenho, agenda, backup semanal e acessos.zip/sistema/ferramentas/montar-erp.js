// Gera sistema/app/index.html a partir do ERP original (#Sistemas/2 - ERP/ERP.html).
// O visual, as telas e os cálculos ficam exatamente iguais; só muda:
//  - de onde vêm os dados (erp-dados.js lê do Supabase no lugar do Apps Script);
//  - Chart.js servido do próprio site (sem CDN);
//  - login por e-mail;
//  - cada linha das tabelas ganha data-gx (tabela:id) para o botão ✎ Editar.
// Uso: node sistema/ferramentas/montar-erp.js
'use strict';
const fs = require('fs');
const path = require('path');
const raiz = path.join(__dirname, '..', '..');
const origem = path.join(raiz, '#Sistemas', '2 - ERP', 'ERP.html');
const destino = path.join(raiz, 'sistema', 'app', 'index.html');
let s = fs.readFileSync(origem, 'utf8');
let trocas = 0;

function trocar(de, para, vezes) {
  const n = s.split(de).length - 1;
  if (vezes !== undefined ? n !== vezes : n < 1) throw new Error('Trecho esperado ' + (vezes ?? '≥1') + 'x, achei ' + n + 'x: ' + de.slice(0, 80));
  s = s.split(de).join(para); trocas += n;
}
// troca a próxima ocorrência de `alvo` depois de `ancora`
function depoisDe(ancora, alvo, novo) {
  const i = s.indexOf(ancora);
  if (i < 0 || s.indexOf(ancora, i + 1) >= 0) throw new Error('Âncora ausente ou repetida: ' + ancora);
  const j = s.indexOf(alvo, i);
  if (j < 0 || j - i > 1500) throw new Error('Alvo longe/ausente após: ' + ancora);
  s = s.slice(0, j) + novo + s.slice(j + alvo.length); trocas++;
}

// 1. Scripts: Chart.js local + ponte Supabase antes de tudo; editor no fim.
trocar('<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js" defer></script>',
  '<script src="vendor/chart.umd.js" defer></script>\n' +
  '<script src="vendor/supabase.js"></script>\n<script src="config.js"></script>\n<script src="erp-dados.js"></script>\n' +
  '<link rel="stylesheet" href="editor.css">\n<link rel="stylesheet" href="erp-telas.css">\n' +
  '<script src="editor.js" defer></script>\n<script src="erp-telas.js" defer></script>\n' +
  '<link rel="stylesheet" href="gs.css">\n<script src="importador.js" defer></script>\n<script src="gestao-embutida.js" defer></script>', 1);

// 2. URL "do script": fica só como marcador; nenhuma chamada sai para o Google.
s = s.replace(/const DEFAULT_URL = 'https:\/\/script\.google\.com\/macros\/s\/[^']+\/exec';/,
  () => { trocas++; return "const DEFAULT_URL = 'https://script.google.com/macros/s/supabase/exec'; // interceptado por erp-dados.js"; });
trocar("const url = localStorage.getItem(LS_KEY) || DEFAULT_URL;", "const url = DEFAULT_URL;");
trocar("const url=localStorage.getItem(LS_KEY)||DEFAULT_URL;", "const url=DEFAULT_URL;");
trocar("const _u = localStorage.getItem(LS_KEY) || DEFAULT_URL;", "const _u = DEFAULT_URL;");

// 3. Login por e-mail.
trocar('<label class="ac-login-label" id="ac-login-email-label">Login</label>', '<label class="ac-login-label" id="ac-login-email-label">E-mail</label>', 1);
trocar('autocomplete="username" placeholder="seu login de acesso"', 'autocomplete="username" inputmode="email" placeholder="seu e-mail"', 1);
trocar("_acMostrarMsg('Entre em contato com o escritório para redefinir sua senha.', 'warn');",
  "if (window.ERP_ESQUECI_SENHA) window.ERP_ESQUECI_SENHA(); else _acMostrarMsg('Entre em contato com o escritório para redefinir sua senha.', 'warn');", 1);

// 4. Linhas editáveis: data-gx em cada <tr> das tabelas principais.
const TPL = (v) => '<tr data-gx="${_gx(' + v + ')}">';
depoisDe("const el=$('tblExecRanking');", 'return`<tr>', 'return`' + TPL('r'));
depoisDe("$('tblProcBody').innerHTML=", 'return`<tr>', 'return`' + TPL('p'));
depoisDe("$('tblParcBody').innerHTML=", 'map(p=>`<tr>', 'map(p=>`' + TPL('p'));
depoisDe("const el=$('tblParcPagoBody');", 'map(p=>`<tr>', 'map(p=>`' + TPL('p'));
depoisDe("const el=$('tblParcVencBody');", 'map(p=>`<tr>', 'map(p=>`' + TPL('p'));
depoisDe("$('tblAcordosBody').innerHTML=", 'return`<tr>', 'return`' + TPL('a'));
depoisDe("const el=$('tblAcordosVencBody');", 'return`<tr>', 'return`' + TPL('a'));
depoisDe("$('tblAcordosPgBody').innerHTML=", 'map(a=>`<tr>', 'map(a=>`' + TPL('a'));
// financeiro (linhas montadas por concatenação, variável f)
s = s.replace(/map\(f=>'<tr>/g, () => { trocas++; return "map(f=>'<tr data-gx=\"'+_gx(f)+'\">"; });
s = s.replace(/map\(function\(f\)\{return '<tr>/g, () => { trocas++; return "map(function(f){return '<tr data-gx=\"'+_gx(f)+'\">"; });
s = s.replace(/return '<tr><td>'\+_faSelo\(f\.grupo/g, () => { trocas++; return "return '<tr data-gx=\"'+_gx(f)+'\"><td>'+_faSelo(f.grupo"; });
s = s.replace(/return '<tr><td><span class="tag tn">'\+\(f\.grupo/g, () => { trocas++; return "return '<tr data-gx=\"'+_gx(f)+'\"><td><span class=\"tag tn\">'+(f.grupo"; });

// análise de honorários (jurídico e contabilidade) e sócios da contabilidade
s = s.replace(/return '<tr><td class="mono" title="'\+\(pg\?/g, () => { trocas++; return "return '<tr data-gx=\"'+_gx(f)+'\"><td class=\"mono\" title=\"'+(pg?"; });
s = s.replace(/var pago=f\.pagamento==='SIM';\n(\s*)return '<tr><td class="mono">'/g, (m, e) => { trocas++; return "var pago=f.pagamento==='SIM';\n" + e + "return '<tr data-gx=\"'+_gx(f)+'\"><td class=\"mono\">'"; });

// 4b. E-mail: o rascunho no Gmail (Apps Script) virou "abrir e-mail já preenchido".
s = s.split("Rascunho criado no Gmail").join('E-mail aberto no seu programa de e-mail');
s = s.split('✉ Salvar rascunho (Gmail)').join('✉ Abrir e-mail');
s = s.split("'⏳ Salvando rascunho…'").join("'⏳ Abrindo e-mail…'");
s = s.split("'\\u23f3 Salvando rascunho\\u2026'").join("'\\u23f3 Abrindo e-mail\\u2026'");

// 5. Dados pessoais dos advogados (CPF, endereço) saem do HTML público e vão para o banco
//    (tabela configuracoes, só a equipe lê). O SQL para colar no Supabase é gerado em
//    sistema/banco/dados-recibos.sql; o erp-dados.js carrega depois do login.
const mEmit = s.match(/var RECIBO_EMITENTES = (\{[\s\S]*?\n\});/);
if (!mEmit) throw new Error('Bloco RECIBO_EMITENTES não encontrado');
const emitentes = require('vm').runInNewContext('(' + mEmit[1] + ')');
s = s.replace(mEmit[0], 'var RECIBO_EMITENTES = {}; // preenchido após o login por erp-dados.js (tabela configuracoes)'); trocas++;
const json = JSON.stringify(emitentes).replace(/'/g, "''");
fs.writeFileSync(path.join(raiz, 'sistema', 'banco', 'dados-recibos.sql'),
  '-- Dados dos advogados usados nos recibos (gerado por ferramentas/montar-erp.js).\n' +
  '-- Cole no SQL Editor do Supabase e clique em Run. Pode rodar de novo sem problema.\n' +
  '-- Cria a tabela (se ainda não existir) com as regras de acesso: só a equipe lê, só o admin altera.\n' +
  'create table if not exists public.configuracoes (\n  chave text primary key,\n  valor jsonb not null,\n  atualizado_em timestamptz not null default now()\n);\n' +
  'alter table public.configuracoes enable row level security;\n' +
  'revoke all on public.configuracoes from anon;\n' +
  'grant select, insert, update, delete on public.configuracoes to authenticated;\n' +
  'drop policy if exists configuracoes_ver on public.configuracoes;\n' +
  'create policy configuracoes_ver on public.configuracoes for select to authenticated using (public.eh_equipe());\n' +
  'drop policy if exists configuracoes_admin on public.configuracoes;\n' +
  'create policy configuracoes_admin on public.configuracoes for all to authenticated\n  using (public.eh_admin()) with check (public.eh_admin());\n\n' +
  "insert into public.configuracoes (chave, valor) values ('recibo_emitentes', '" + json + "'::jsonb)\n" +
  'on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();\n');

// 6. Em atraso com a regra do Gestão: todos os meses (não só o período escolhido),
//    mantendo os recortes de pessoa, tipo e grupo; e a lista "⚠ Em atraso" logo abaixo.
function semPeriodo(estado, filtrar, abas) {
  return 'window._semPeriodo(' + estado + ',function(){return ' + filtrar + '(' + abas + ');})';
}
trocar("var vencidos=aReceber.filter(function(f){ var d=_faData(f); return d&&d<hoje; });",
  "var vencidos=" + semPeriodo('_FA', '_faFiltrar', "['A Receber']") + ".filter(function(f){ var d=pDate(f.vencimento); return d&&d<hoje; });", 1);
trocar("var vencidos=aberto.filter(function(f){ var d=_fcData(f); return d&&d<hoje; });",
  "var vencidos=" + semPeriodo('_FC', '_fcFiltrar', '[L.abaAberto]') + ".filter(function(f){ var d=pDate(f.vencimento); return d&&d<hoje; });", 1);
trocar("  +   kC('Vencido',_faFT(vVenc),vencidos.length+' lançamento(s)','cr',vVenc>0?'dr':'')",
  "  +   kC('Em atraso',_faFT(vVenc),vencidos.length+' vencido(s) · todos os meses','cr',vVenc>0?'dr':'')", 2);
// Análise (Jurídico): ordem Recebido mês a mês → tipo de serviço e maiores grupos → comparativo por pessoa → Em atraso
trocar("  +   _faTabelaPessoas(_faPessoas()) + '</div>';",
  "  +   _faTabelaPessoas(_faPessoas()) + '</div>'\n" +
  "  + (vencidos.length?'<div class=\"cc\" style=\"margin-bottom:14px\"><div class=\"cc-hd\"><div><div class=\"cc-t\">⚠ Em atraso</div><div class=\"cc-d\">todos os meses · mesmos recortes de pessoa, tipo e grupo</div></div></div>'+_faTabelaDetalhe(vencidos.slice().sort(function(a,b){return (pDate(a.vencimento)||0)-(pDate(b.vencimento)||0);}))+'</div>':'');", 1);
// Análise (Jurídico): sem a lista de lançamentos (os lançamentos já estão em A Receber / Recebidos)
trocar("  + '<div id=\"faCorpo\"></div>'\n  + '<div class=\"cc\"><div class=\"cc-hd\" style=\"align-items:center\"><div><div class=\"cc-t\">Lançamentos</div>'\n  +   '<div class=\"cc-d\">os filtros do topo já valem para esta lista · clique no cabeçalho para ordenar</div></div>'\n  +   '<span class=\"fa-dica\" id=\"faLqCount\"></span></div>'\n  +   '<div id=\"faLancTbl\"></div></div>';",
  "  + '<div id=\"faCorpo\"></div>';", 1);
trocar("  + '<div class=\"cc\" style=\"margin-bottom:14px\"><div class=\"cc-hd\"><div><div class=\"cc-t\">'+(L.lado==='pagar'?'Pago':'Recebido')+' mês a mês</div>'",
  "  + (vencidos.length?'<div class=\"cc\" style=\"margin-bottom:14px\"><div class=\"cc-hd\"><div><div class=\"cc-t\">⚠ Em atraso</div><div class=\"cc-d\">todos os meses · mesmos recortes</div></div></div>'+_fcTabelaDetalhe(vencidos)+'</div>':'')\n"
  + "  + '<div class=\"cc\" style=\"margin-bottom:14px\"><div class=\"cc-hd\"><div><div class=\"cc-t\">'+(L.lado==='pagar'?'Pago':'Recebido')+' mês a mês</div>'", 1);

// 7. Acordos e parcelamentos são dívidas do CLIENTE com terceiros; honorários são o financeiro
//    do ESCRITÓRIO. Nunca na mesma lista: _getVencRows ganha o escopo ('financeiro' | 'cliente').
trocar('function _getVencRows(dias){',
  "function _getVencRows(dias,escopo){\n  var _r=_getVencRowsTodos(dias);\n  if(!escopo) return _r;\n" +
  "  return _r.filter(function(r){ return escopo==='financeiro' ? r.tipo==='Honorário' : r.tipo!=='Honorário'; });\n}\n" +
  'function _getVencRowsTodos(dias){', 1);
trocar('_getVencRows(7)', "_getVencRows(7,'cliente')", 2);
trocar('_getVencRows(30)', "_getVencRows(30,'cliente')", 2);
trocar("kC('Acordos c/ Terceiros a Pagar',", "kC('Acordos dos clientes c/ terceiros',", 1);
// 8. Design: um só jeito de escrever dinheiro (R$ colado ao número por espaço que não quebra),
//    formato curto único "R$ 1,85 mi" / "R$ 691 mil", títulos de seção padronizados.
trocar("const fS = v => { v=Number(v)||0; if(v>=1e6)return'R$'+(v/1e6).toFixed(1).replace('.',',')+'M'; if(v>=1e3)return'R$'+(v/1e3).toFixed(0)+'k'; return'R$'+v.toFixed(0); };",
  "const fS = v => _moedaCurta(v);\n" +
  "function _moedaCurta(v){ v=Number(v)||0; var neg=v<0, a=Math.abs(v), t;\n" +
  "  if(a>=1e6) t=(a/1e6).toLocaleString('pt-BR',{maximumFractionDigits:2})+'\\u00A0mi';\n" +
  "  else if(a>=1e4) t=Math.round(a/1e3).toLocaleString('pt-BR')+'\\u00A0mil';\n" +
  "  else t=a.toLocaleString('pt-BR',{maximumFractionDigits:0});\n" +
  "  return (neg?'−':'')+'R$\\u00A0'+t; }", 1);
trocar("const fF = v => 'R$ '+(Number(v)||0)", "const fF = v => 'R$\\u00A0'+(Number(v)||0)", 1);
trocar("  if(a>=1e6) t='R$ '+(a/1e6).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2})+' mi';\n  else       t='R$ '+a.toLocaleString('pt-BR',{maximumFractionDigits:0});\n  return (neg?'−':'')+t;",
  "  return _moedaCurta(neg?-a:a);", 1);
trocar("callback:v=>{const n=Number(v)||0;if(n>=1e6)return'R$'+(n/1e6).toFixed(1)+'M';if(n>=1e3)return'R$'+(n/1e3).toFixed(0)+'k';return'R$'+n.toFixed(0);}", "callback:v=>_moedaCurta(v)", 1);
s = s.replace(/'R\$ ?'\+/g, () => { trocas++; return "'R$\\u00A0'+"; });
trocar('style="font-family:var(--font-d);font-size:14px;font-weight:700;color:var(--ac-gold);margin-bottom:12px;letter-spacing:.01em"', 'class="gx-sec-tit"', 5);

// 9. CRM antigo (da planilha, sem tela desde a v41): saem os estilos e a janela de histórico do lead.
//    O CRM novo é outro módulo (telas-crm.js), com classes próprias "cr-".
function removerBloco(inicio, fim) {
  const i = s.indexOf(inicio); if (i < 0 || s.indexOf(inicio, i + 1) >= 0) throw new Error('Bloco ausente ou repetido: ' + inicio);
  const j = s.indexOf(fim, i); if (j < 0) throw new Error('Fim do bloco ausente: ' + fim);
  s = s.slice(0, i) + s.slice(j + fim.length); trocas++;
}
removerBloco('.crm-funnel{display:grid', '.crm-tl-nota-input:focus{border-color:var(--gold);outline:none;background:var(--white)}\n');
removerBloco('/* ── CRM v2', '.crm-base-item:last-child{border-bottom:none}\n');
{ const k = s.indexOf('MODAL — TIMELINE / HISTÓRICO DO LEAD'); const i = s.lastIndexOf('<!--', k);
  const j = s.indexOf('</div>\n</div>\n', s.indexOf('<div class="m-overlay" id="mo-crm-timeline">'));
  if (k < 0 || i < 0 || j < 0) throw new Error('Janela do CRM antigo não encontrada');
  s = s.slice(0, i) + s.slice(j + '</div>\n</div>\n'.length); trocas++; }

// 10. CAPAG "Omisso" com selo vermelho (antes caía em texto cinza)
trocar("    if(m[v])return`<span class=\"capag ${m[v]}\">${v}</span>`;\n    return`<span style=\"font-size:10px;color:var(--text3)\">${v}</span>`;",
  "    if(m[v])return`<span class=\"capag ${m[v]}\">${v}</span>`;\n    if(/omisso/i.test(v))return`<span class=\"capag capag-O\">Omisso</span>`;\n    return`<span style=\"font-size:10px;color:var(--text3)\">${v}</span>`;", 1);
trocar("    [/omisso|—|^$/,'#F3F4F6','var(--gray)','#E5E7EB']", "    [/omisso/i,'#DC2626','#FFFFFF','#B91C1C'],\n    [/—|^$/,'#F3F4F6','var(--gray)','#E5E7EB']", 1);

// 11. Painel Executivo: passivo por grupo em barras horizontais com o valor na frente (como no Gestão)
//     e a legenda da rosca à direita, com % e valor.
trocar("  mCh('cResGrupos',bCfg(labGr,valGr,null,isHoriz));",
  "  { const _n=Math.min(labGr.length,15), _cfg=bCfg(labGr.slice(0,_n),valGr.slice(0,_n),null,true);\n" +
  "    _cfg.options.gxValores=true; _cfg.options.layout={padding:{right:84}};\n" +
  "    _cfg.options.scales.x.display=false; _cfg.options.scales.y.grid={display:false}; _cfg.options.scales.y.ticks=Object.assign({},_cfg.options.scales.y.ticks,{autoSkip:false,callback:function(v){var t=String(this.getLabelForValue(v)||'');return t.length>30?t.slice(0,29)+'…':t;}});\n" +
  "    const _box=$('cResGrupos').parentElement; if(_box) _box.style.height=Math.max(150,_n*30+30)+'px';\n" +
  "    const _d=$('resGrupoTitle').nextElementSibling; if(_d) _d.textContent='Soma de todos os órgãos tributários'+(labGr.length>15?' · 15 maiores de '+labGr.length:'');\n" +
  "    mCh('cResGrupos',_cfg); }", 1);
trocar("      plugins:{legend:{display:true,position:'bottom',labels:{color:'#4B5563',font:{size:11},padding:14,boxWidth:10,usePointStyle:true,pointStyle:'circle'}},",
  "      plugins:{legend:{display:true,position:window.innerWidth>760?'right':'bottom',labels:{color:'#1F2937',font:{size:12},padding:12,boxWidth:10,usePointStyle:true,pointStyle:'circle',\n" +
  "        generateLabels:function(ch){var tot=data.reduce(function(a,b){return a+(Number(b)||0);},0)||1;\n" +
  "          return Chart.overrides.doughnut.plugins.legend.labels.generateLabels(ch).map(function(it){var v=Number(data[it.index])||0;\n" +
  "            it.text=it.text+'  '+(v/tot*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%  ·  '+fS(v);return it;});}}},", 1);

// 12. "Demanda" passa a se chamar "Serviço pontual" na tela (o valor gravado continua o mesmo)
trocar('<option value="Demanda">Demanda</option>', '<option value="Demanda">Serviço pontual</option>', 1);

s = s.replace(/<title>[^<]*<\/title>/, '<title>ERP — Araújo &amp; Castro</title>');
// 14. Imagens: saem do HTML (eram base64) e viram arquivos em img/, guardados pelo navegador.
{
  const IMG = path.join(raiz, 'sistema', 'app', 'img'); fs.mkdirSync(IMG, { recursive: true });
  const salvar = (nome, b64) => { const buf = Buffer.from(b64, 'base64'); fs.writeFileSync(path.join(IMG, nome), buf);
    return 'img/' + nome + '?v=' + require('crypto').createHash('sha1').update(buf).digest('hex').slice(0, 8); };
  const logo = s.match(/(<div class="ac-login-logo"[^>]*>\s*<img src=")data:image\/png;base64,([A-Za-z0-9+/=]+)"/);
  if (!logo) throw new Error('logo do login não encontrada');
  s = s.replace(logo[0], logo[1] + salvar('logo-login.png', logo[2]) + '"'); trocas++;
  const rec = s.match(/var RECIBO_HEADER_B64 = "([A-Za-z0-9+/=]+)";/);
  if (!rec) throw new Error('cabeçalho do recibo não encontrado');
  // o recibo abre em janela nova (about:blank): o endereço precisa ser completo
  s = s.replace(rec[0], "var RECIBO_HEADER_URL = new URL('" + salvar('recibo-cabecalho.png', rec[1]) + "', location.href).href;"); trocas++;
  trocar(`'<div class="rh"><img src="data:image/png;base64,'+RECIBO_HEADER_B64+'"></div>'`, `'<div class="rh"><img src="'+RECIBO_HEADER_URL+'"></div>'`, 1);
}

// 13. Cores de tokens.css (fonte única) depois do CSS do ERP; modo escuro lembrado neste aparelho.
trocar('\n</head>\n', '\n<link rel="stylesheet" href="tokens.css">\n<link rel="stylesheet" href="tema-escuro.css">\n' +
  '<script>try{if(localStorage.getItem("erp_tema")==="escuro")document.documentElement.setAttribute("data-tema","escuro")}catch(e){}</script>\n</head>\n', 1);
fs.writeFileSync(destino, s);

// ═══════ Gestão embutido: as telas do Gestão rodando dentro do ERP ═══════
// Junta o código do Gestão num bloco isolado (nada vaza para o ERP e vice-versa)
// e gera o CSS do Gestão restrito à classe .gs.
const APP = path.join(raiz, 'sistema', 'app');
const ler = (f) => fs.readFileSync(path.join(APP, f), 'utf8');
function cortar(txt, de, ate, novo) {
  const i = txt.indexOf(de), j = ate ? txt.indexOf(ate, i) : txt.length;
  if (i < 0 || j < 0) throw new Error('Trecho do Gestão não encontrado: ' + de);
  return txt.slice(0, i) + (novo || '') + txt.slice(j);
}
let nuc = ler('nucleo.js');
nuc = nuc.replace(/const sb = CONFIGURADO \? [^\n]+/, 'const sb = window.SB;');
nuc = cortar(nuc, '// ─────────────────────────── login', 'async function carregarCadastros');
nuc = cortar(nuc, '// ─────────────────────────── navegação', null, `// ── navegação dentro do ERP: cada tela desenha no painel que o ERP mostrou ──
const TELAS = {};
async function irPara(tela, alvo) {
  E.perfil = window.ERP_EU || E.perfil;
  E.tela = tela;
  // cada painel tem a sua área; só a do painel aberto se chama "conteudo" (o painel mantém o próprio id)
  if (alvo) {
    let area = alvo.querySelector(':scope > .gs-area');
    if (!area) { area = document.createElement('div'); area.className = 'gs-area'; alvo.appendChild(area); }
    const ant = document.getElementById('conteudo'); if (ant && ant !== area) ant.removeAttribute('id');
    area.id = 'conteudo';
  }
  if (!$('conteudo')) return;
  $('conteudo').innerHTML = '<div class="carregando">Carregando…</div>';
  try { await carregarCadastros(); await TELAS[tela](); }
  catch (e) {
    console.error(e);
    $('conteudo').innerHTML = '<div class="card"><div class="card-bd msg-erro">' + esc(erroAmigavel(e)) + '</div></div>';
  }
}
function recarregar() { invalidarCadastros(); if (window.ERP_RECARREGAR) return window.ERP_RECARREGAR(); return irPara(E.tela); }
`);
let graf = ler('graficos.js').replace("document.addEventListener('DOMContentLoaded', () => document.body.appendChild(dica));",
  "(document.getElementById('gs-raiz') || document.body).appendChild(dica);");
const bundle = "'use strict';\n// GERADO por sistema/ferramentas/montar-erp.js — não edite; edite os arquivos do Gestão.\n(function () {\n" +
  "const _raiz = document.createElement('div'); _raiz.id = 'gs-raiz'; _raiz.className = 'gs';\n" +
  "_raiz.innerHTML = '<div id=\"janelas\"></div><div id=\"aviso\"></div>'; document.body.appendChild(_raiz);\n" +
  [nuc, graf, ler('telas-painel.js'), ler('telas-financeiro.js'), ler('telas-cadastros.js'), ler('telas-admin.js'), ler('telas-tarefas.js'), ler('telas-documentos.js'), ler('telas-cliente360.js'), ler('telas-crm.js'), ler('telas-publicacoes.js'), ler('telas-acordos.js'), ler('telas-alertas.js')].join('\n') +
  "\n// toda gravação confirmada aparece também no rodapé do ERP\nconst _avisoOrig = aviso;\n" +
  "aviso = function (msg, erro) { _avisoOrig(msg, erro); if (!erro && window.ERP_EDITOR && /^✓/.test(msg)) window.ERP_EDITOR.gravou(String(msg).replace(/^✓\\s*/, '')); };\n" +
  "window.GS = { TELAS, E, irPara, carregarCadastros, formLancamento, formCliente, formContrato, formTarefa, tabelaLancamentos, ligarAcoesLancamentos, abrirJanela, fecharJanela, abrirFicha, invalidarCadastros, blocoDocumentos, abrirAlertas, contarAlertas, pode, janelaMeusAvisos, formOportunidade, detalheAcordo };\n})();\n";
fs.writeFileSync(path.join(APP, 'gestao-embutida.js'), bundle);

// CSS do Gestão só dentro de .gs (as telas do Gestão) e #gs-hd (barra superior)
function escopo(sel) {
  sel = sel.trim();
  if (sel === ':root' || sel === 'body') return '.gs';
  if (sel === '*') return '.gs *';
  if (/^#hd\b/.test(sel)) return sel.replace(/^#hd/, '#gs-hd');
  if (/^(nav|\.marca|\.hd-usuario)\b/.test(sel)) return '#gs-hd ' + sel;
  return '.gs ' + sel;
}
function escoparCss(css) {
  let out = '', i = 0;
  while (i < css.length) {
    const ab = css.indexOf('{', i);
    if (ab < 0) break;
    const cab = css.slice(i, ab).replace(/\/\*[\s\S]*?\*\//g, '').trim();
    // acha o fechamento correspondente
    let n = 1, j = ab + 1;
    while (n && j < css.length) { if (css[j] === '{') n++; else if (css[j] === '}') n--; j++; }
    const corpo = css.slice(ab + 1, j - 1);
    if (/^@media/.test(cab)) out += cab + '{' + escoparCss(corpo) + '}\n';
    else if (/^@/.test(cab)) out += cab + '{' + corpo + '}\n';
    else out += cab.split(',').map(escopo).join(',') + '{' + corpo + '}\n';
    i = j;
  }
  return out;
}
const gsCss = '/* GERADO por sistema/ferramentas/montar-erp.js a partir de estilo.css (Gestão) — não edite. */\n' +
  escoparCss(ler('estilo.css')) +
  '/* cores do ERP, tamanhos do Gestão */\n' +
  '.gs{background:none!important;min-height:0!important}\n' +
  '.gs .duas-col>*,.gs .card{min-width:0}\n';
fs.writeFileSync(path.join(APP, 'gs.css'), gsCss);
// modo escuro: gerado do CSS que existe (o claro não muda)
{
  const estilosErp = (s.match(/<style[^>]*>[\s\S]*?<\/style>/g) || []).filter((x) => !/_pdfCss|<\/head>/.test(x)).map((x) => x.replace(/<\/?style[^>]*>/g, ''));
  const escuro = require('./tema-escuro.js').gerar(estilosErp.concat([gsCss, ler('erp-telas.css'), ler('editor.css')]),
    [s, bundle, ler('editor.js'), ler('erp-telas.js')]);
  fs.writeFileSync(path.join(APP, 'tema-escuro.css'), escuro);
  console.log('tema-escuro.css gerado: ' + Math.round(escuro.length / 1024) + ' KB');
}
console.log('gestao-embutida.js e gs.css gerados');

// 15. Carimbo de versão (?v=) nos arquivos do sistema: o navegador guarda por 1 ano (vercel.json)
// e baixa de novo sozinho quando o conteúdo muda. config.js fica sem carimbo (sempre confere).
{
  const crypto = require('crypto');
  const versao = (f) => crypto.createHash('sha1').update(fs.readFileSync(path.join(APP, f))).digest('hex').slice(0, 8);
  let n = 0;
  s = s.replace(/(<(?:script|link)[^>]*?(?:src|href)=")((?:vendor\/)?[\w.-]+\.(?:js|css))(")/g, (m, a, f, z) => {
    if (f === 'config.js' || !fs.existsSync(path.join(APP, f))) return m;
    n++; return a + f + '?v=' + versao(f) + z;
  });
  fs.writeFileSync(destino, s);
  console.log('carimbo de versão em ' + n + ' arquivos');
}
console.log('index.html gerado: ' + trocas + ' ajustes, ' + Math.round(s.length / 1024) + ' KB');
