'use strict';
// ═══════════════════════════════════════════════════════════════════
// Guias (Backup 27) — emissão das guias de PARCELAMENTOS e dos boletos/PIX de ACORDOS,
// pensada para o estagiário: 1) emitir  2) marcar "emitida" (data e quem, com o PDF guardado)
// 3) mandar ao cliente por e-mail (a guia vai anexa)  4) conferir o pagamento (✓ Pago).
// Quadro "Guias para emitir" no alto de Parcelamentos e de Acordos + janela de emissão,
// usada também nos cartões das parcelas do detalhamento.
// ═══════════════════════════════════════════════════════════════════
const GUIA_DIAS = 15;   // o quadro mostra o que vence até 15 dias à frente (e tudo o que já venceu sem pagamento)
const ABAS_GUIA = [['emitir', 'A emitir'], ['emitidas', 'Emitidas — falta enviar'], ['vencidas', 'Vencidas sem pagamento']];   // Backup 49: abas sem ícone
const _guiaAba = { parcelas: 'emitir', acordos: 'emitir' };
// Backup 28: quadro minimizável (lembra por navegador) e envio de várias guias da mesma empresa num e-mail/WhatsApp
const _guiaMin = {};
try { Object.assign(_guiaMin, JSON.parse(localStorage.getItem('erp_guias_min') || '{}')); } catch (e) { /* sem armazenamento: começa aberto */ }
const emitida = (x) => !!x.emitida_em || /sim|emitid/i.test(x.emissao || '');

async function dadosGuias(tabela) {
  const lim = somarDias(hojeISO(), GUIA_DIAS);
  let L;
  if (tabela === 'parcelas') {
    L = (await buscarTodos(() => sb.from('parcelas').select('id, numero, vencimento, pago, emissao, emitida_em, emitida_por, guia_doc, reenvio_em, reenvio_venc, reenvio_valor, reenvios, parcelamentos(id, empresa, natureza, local, numero, total_parcelas, valor_ultima_parcela, grupo_id, emitimos_guia, cnpj)')
      .eq('pago', false).lte('vencimento', lim).order('vencimento').order('id')).catch(() => []))
      .filter((x) => x.parcelamentos && x.parcelamentos.emitimos_guia !== false)
      .map((x) => { const p = x.parcelamentos;
        return Object.assign(x, { quem: p.empresa, detalhe: [p.natureza, p.local, p.numero ? 'nº ' + p.numero : ''].filter(Boolean).join(' · '),
          parcela: (x.numero || '?') + (p.total_parcelas ? '/' + p.total_parcelas : ''), valor: Number(p.valor_ultima_parcela) || 0, grupo_id: p.grupo_id,
          cliente_id: (E.clientes.find((c) => (soDigitos(p.cnpj) && soDigitos(c.cpf_cnpj) === soDigitos(p.cnpj)) || c.nome === p.empresa) || {}).id || null }); });
  } else {
    L = (await buscarTodos(() => sb.from('acordos').select('id, parcela, total_parcelas, vencimento, valor, pago, emissao, emitida_em, emitida_por, guia_doc, reenvio_em, reenvio_venc, reenvio_valor, reenvios, devedor, credor, processo, grupo_id, pix, pix_codigo, banco, forma_pagamento')
      .eq('pago', false).lte('vencimento', lim).order('vencimento').order('id')).catch(() => []))
      .map((x) => Object.assign(x, { quem: x.devedor, detalhe: 'deve a ' + (x.credor || '—') + (x.processo ? ' · ' + x.processo : ''),
        parcela: (x.parcela || '?') + (x.total_parcelas ? '/' + x.total_parcelas : ''), valor: Number(x.valor) || 0,
        cliente_id: (E.clientes.find((c) => c.grupo_id === x.grupo_id && primeiroNome(c.nome) === primeiroNome(x.devedor)) || {}).id || null }));
  }
  const envios = L.length ? await q(sb.rpc('emissao_emails', { p_tabela: tabela, p_ids: L.map((x) => x.id) })).catch(() => ({})) : {};
  L.forEach((x) => { const v = (envios || {})[x.id];
    // Backup 30: {em, status, para, erro} — status vem da fila (pendente · retido · enviado · erro · cancelado)
    const o = !v ? null : typeof v === 'string' ? { em: v, status: 'enviado' } : v;
    x.email_em = o ? o.em : null; x.email_st = o ? o.status : ''; x.email_para = o ? o.para || '' : ''; x.email_erro = o ? o.erro || '' : ''; });
  return L;
}
// já saiu (ou está saindo) para o cliente: na fila, retido pela pausa ou enviado. Erro/descartado volta para "falta enviar".
const guiaEnviada = (x) => !!x.email_em && !/erro|cancelado|^rascunho$/.test(x.email_st || '');   // Backup 44: rascunho não salvo volta para "falta enviar"
const ST_EMAIL = { pendente: ['aberto', '✉ na fila'], retido: ['hoje', '⏸ retido (pausa)'], enviado: ['pago', '✉ enviado'], erro: ['vencido', '⚠ e-mail falhou'], cancelado: ['neutro', 'e-mail descartado'], rascunho: ['vencido', '📝 rascunho não salvo'], rascunho_salvo: ['pago', '📝 rascunho no Gmail'] };

// quadro no alto de Parcelamentos / Acordos
// Backup 29: "Parcelamentos para emitir" / "Acordos para emitir"; o que já foi ENVIADO ao cliente sai do quadro (evita confusão)
async function cardGuias(tabela, el) {
  if (!el) return;
  if (!E.clientes.length) await carregarCadastros();
  const h = hojeISO(), TODOS = await dadosGuias(tabela), L = TODOS.filter((x) => !guiaEnviada(x)), enviadas = TODOS.filter((x) => guiaEnviada(x) && x.vencimento >= h).length,
    retidas = TODOS.filter((x) => x.email_st === 'retido').length, naFila = TODOS.filter((x) => x.email_st === 'pendente').length;
  // Backup 33: cada parcela em UMA aba só — a emitir / emitida (falta enviar) / VENCIDA sem pagamento (mesmo já enviada: fica até o ✓ Pago, com o reenvio)
  const grupos = { emitir: L.filter((x) => !emitida(x) && x.vencimento >= h), emitidas: L.filter((x) => emitida(x) && x.vencimento >= h), vencidas: TODOS.filter((x) => x.vencimento < h) };
  const aba = _guiaAba[tabela], lista = grupos[aba], nome = tabela === 'parcelas' ? 'guia' : 'boleto/PIX';
  const dias = (v) => { const d = Math.round((new Date(v + 'T12:00:00') - new Date(h + 'T12:00:00')) / 864e5);
    return d < 0 ? '<span class="dias-r">' + (-d) + ' d atraso</span>' : d === 0 ? '<span class="dias-r">vence hoje</span>' : '<span class="' + (d < 3 ? 'dias-a' : d < 10 ? 'dias-b' : 'dias-g') + '">em ' + d + ' d</span>'; };
  const min = !!_guiaMin[tabela];
  el.innerHTML = '<div class="card gd-card' + (min ? ' gd-min' : '') + '"><div class="card-hd">🧾 ' + (tabela === 'parcelas' ? 'Parcelamentos para emitir' : 'Acordos para emitir') +
      (min && grupos.emitir.length ? ' <span class="pill hoje">' + grupos.emitir.length + ' a emitir</span>' : '') +
      '<span class="sub">vencem até ' + dataBR(somarDias(h, GUIA_DIAS)) + ' · emitir → enviar ao cliente → conferir o pagamento' + (enviadas ? ' · ✉ ' + plural(enviadas, 'já enviada ao cliente saiu', 'já enviadas ao cliente saíram') + ' da lista' : '') + '</span>' +
      '<span class="gd-hd-ac">' + (L.length ? '<button type="button" class="btn btn-p btn-mini" data-gd-empresa>✉ Enviar por empresa</button>' : '') +
      '<button type="button" class="btn btn-o btn-mini" data-gd-min aria-expanded="' + (min ? 'false' : 'true') + '">' + (min ? '▸ Mostrar' : '▾ Minimizar') + '</button></span></div>' +
    '<div class="card-bd"' + (min ? ' hidden' : '') + '>' +
    (retidas || naFila ? '<div class="gd-fila">' + (retidas ? '⏸ <b>' + plural(retidas, 'e-mail de guia retido', 'e-mails de guias retidos') + '</b> pela pausa de envio — só sai quando alguém liberar. ' : '') +
      (naFila ? '✉ ' + plural(naFila, 'e-mail na fila', 'e-mails na fila') + ' (sai em até 5 minutos). ' : '') +
      '</div>' : '') +
    '<div class="segmento gd-abas">' + ABAS_GUIA.map(([k, r]) => '<button type="button" data-gd-aba="' + k + '" class="' + (aba === k ? 'ativo' : '') + '">' + r +
        ' <span class="pill ' + (k === 'vencidas' && grupos[k].length ? 'vencido' : k === 'emitir' && grupos[k].length ? 'hoje' : 'neutro') + '">' + grupos[k].length + '</span></button>').join('') + '</div>' +
    (lista.length ? htmlGuiasPorGrupo(tabela, lista, TODOS, nome, dias, h, aba)
      : '<div class="sub" style="padding:8px 2px">' + ({ emitir: 'Nada a emitir agora. 👏', emitidas: 'Nenhuma ' + nome + ' emitida aguardando envio.', vencidas: 'Nenhuma parcela vencida sem pagamento. 👏' })[aba] + '</div>') +
    '</div></div>';
  el.querySelector('[data-gd-min]').onclick = () => { _guiaMin[tabela] = !_guiaMin[tabela]; try { localStorage.setItem('erp_guias_min', JSON.stringify(_guiaMin)); } catch (e) { /* ok */ } cardGuias(tabela, el); };
  const be = el.querySelector('[data-gd-empresa]'); if (be) be.onclick = () => janelaGuiasEmpresa(tabela, L, null, () => cardGuias(tabela, el));
  el.querySelectorAll('[data-gd-grp]').forEach((b) => b.onclick = () => { const k = tabela + '|' + b.dataset.gdGrp; _guiaGrpAberto[k] = !_guiaGrpAberto[k]; cardGuias(tabela, el); });
  el.querySelectorAll('[data-gd-emp]').forEach((b) => b.onclick = () => janelaGuiasEmpresa(tabela, L, b.dataset.gdEmp, () => cardGuias(tabela, el)));
  el.querySelectorAll('[data-gd-aba]').forEach((b) => b.onclick = () => { _guiaAba[tabela] = b.dataset.gdAba; cardGuias(tabela, el); });
  el.querySelectorAll('[data-gd-emitir]').forEach((b) => b.onclick = () => janelaEmissao(tabela, TODOS.find((x) => x.id === b.dataset.gdEmitir), () => cardGuias(tabela, el)));
  el.querySelectorAll('[data-gd-ver]').forEach((b) => b.onclick = () => comBotao(b, async () => { const d = (await q(sb.from('documentos').select('*').eq('id', b.dataset.gdVer)))[0]; if (d) await abrirDocumento(d); }));
  el.querySelectorAll('[data-gd-pago]').forEach((b) => b.onclick = () => { if (window.ERP_EDITOR && window.ERP_EDITOR.baixaRapida) window.ERP_EDITOR.baixaRapida(tabela, b.dataset.gdPago); });
}
// Backup 31: o quadro em blocos — GRUPO (clique abre) › empresa (botão "Emitir" = e-mail com as guias dela) › parcelas
const _guiaGrpAberto = {};
const chaveParcGuia = (tabela, x) => tabela === 'parcelas' ? (x.parcelamentos && x.parcelamentos.id) || x.parcelamento_id || x.id : [x.devedor, x.credor, x.processo].join('|');
function htmlGuiasPorGrupo(tabela, lista, TODOS, nome, dias, h, aba) {
  // Backup 33: tudo em COLUNAS fixas (como tabela) — A data · B parcela · C atraso · D valor · E situação · F ações — nas três abas
  const atr = {}; TODOS.forEach((x) => { if (x.vencimento < h) { const k = chaveParcGuia(tabela, x); atr[k] = (atr[k] || 0) + 1; } });
  const grs = {};
  lista.forEach((x) => { const gid = x.grupo_id || ''; const g = (grs[gid] = grs[gid] || { gid, nome: nomeGrupo(gid) || 'Sem grupo', emps: {} });
    const k = chaveEmpresaGuia(x); (g.emps[k] = g.emps[k] || { k, nome: x.quem || '—', itens: [] }).itens.push(x); });
  const G = Object.values(grs).sort((a, b) => (a.nome === 'Sem grupo') - (b.nome === 'Sem grupo') || a.nome.localeCompare(b.nome, 'pt-BR'));
  const unico = G.length === 1, mostrado = {}, venc = aba === 'vencidas', plN = nome === 'guia' ? 'guias' : 'boletos';
  const pillAtr = (n) => n ? '<span class="pill ' + (n >= 2 ? 'vencido' : 'atr-leve') + '">' + n + ' em atraso' + (n >= 2 ? ' · risco de rescisão' : '') + '</span>' : '';
  return '<div class="gd-grupos gd-tab">' +
    '<div class="gd-row gd-cab" aria-hidden="true"><span>Vencimento</span><span>' + (tabela === 'parcelas' ? 'Grupo / empresa / parcela' : 'Grupo / devedor / parcela') + '</span><span>Atraso</span><span class="gd-dir">Valor</span><span>Situação</span><span></span></div>' +
    G.map((g) => {
      const its = Object.values(g.emps).flatMap((e) => e.itens), aberto = unico || !!_guiaGrpAberto[tabela + '|' + g.gid];
      const nv = its.filter((x) => x.vencimento < h).length, tot = its.reduce((s2, x) => s2 + (Number(x.valor) || 0), 0);
      return '<div class="gd-g' + (aberto ? ' gd-g-aberto' : '') + '"><button type="button" class="gd-row gd-g-hd" data-gd-grp="' + esc(g.gid) + '" aria-expanded="' + aberto + '">' +
          '<span class="gd-g-nome"><span class="gd-g-seta">' + (aberto ? '▾' : '▸') + '</span><b>' + esc(g.nome) + '</b><span class="sub">' + plural(Object.keys(g.emps).length, 'empresa', 'empresas') + ' · ' + plural(its.length, nome, plN) + '</span></span>' +
          '<span>' + (nv ? '<span class="pill atr-leve">' + nv + ' vencida' + (nv > 1 ? 's' : '') + '</span>' : '') + '</span>' +
          '<span class="gd-dir gd-g-tot">' + (tot ? brl(tot) : '') + '</span><span></span><span></span></button>' +
        (aberto ? '<div class="gd-g-corpo">' + Object.values(g.emps).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR')).map((e) =>
          '<div class="gd-row gd-emp-hd"><span class="gd-emp-nome"><b>' + esc(e.nome) + '</b></span><span></span><span class="gd-dir sub">' + (e.itens.length > 1 ? brl(e.itens.reduce((s2, x) => s2 + (Number(x.valor) || 0), 0)) : '') + '</span><span></span>' +
            '<span class="gd-ac">' + (venc ? '' : '<button type="button" class="btn btn-p btn-mini" data-gd-emp="' + esc(e.k) + '" title="Abre o e-mail com ' + (e.itens.length > 1 ? 'as ' + e.itens.length + ' guias' : 'a guia') + ' desta empresa: anexe os PDFs e envie">🧾 Emitir</button>') + '</span></div>' +
            e.itens.map((x) => { const kp = chaveParcGuia(tabela, x), n = atr[kp] && !mostrado[kp] ? atr[kp] : 0; mostrado[kp] = true;   // uma vez por parcelamento
              return '<div class="gd-row gd-it' + (x.vencimento < h ? ' gd-venc' : '') + '">' +
                '<span class="gd-venc-d"><b>' + dataBR(x.vencimento).slice(0, 5) + '</b>' + dias(x.vencimento) + '</span>' +
                '<span class="gd-quem">Parcela ' + esc(x.parcela) + (x.detalhe ? ' · ' + esc(x.detalhe) : '') + '</span>' +
                '<span class="gd-atr">' + pillAtr(n) + '</span>' +
                '<span class="gd-val gd-dir">' + (x.valor ? brl(x.valor) : '—') + (x.reenvio_valor ? '<small title="valor atualizado da guia reenviada">→ ' + brl(x.reenvio_valor) + '</small>' : '') + '</span>' +
                '<span class="gd-st">' + seloEmissao(x, nome) + '</span>' +
                '<span class="gd-ac">' + (venc ? '<button type="button" class="btn btn-o btn-mini" data-gd-emitir="' + x.id + '" title="Reemitir a guia no portal (valor com SELIC) e mandar de novo ao cliente">↻ Reenviar</button>'
                  : emitida(x) ? (x.guia_doc ? '<button type="button" class="btn btn-o btn-mini" data-gd-ver="' + x.guia_doc + '">📄</button>' : '') +
                    '<button type="button" class="btn btn-o btn-mini" data-gd-emitir="' + x.id + '" title="Emissão / enviar esta guia">✎</button>'
                  : '<button type="button" class="btn btn-o btn-mini" data-gd-emitir="' + x.id + '" title="Emitir só esta guia">Só esta</button>') +
                  '<button type="button" class="btn btn-v btn-mini" data-gd-pago="' + x.id + '" title="Conferiu que o cliente pagou">✓ Pago</button></span></div>'; }).join('')).join('') + '</div>' : '') + '</div>';
    }).join('') + '</div>';
}
function seloEmissao(x, nome) {
  return (emitida(x) ? '<span class="pill pago" title="' + esc(x.emitida_por ? 'por ' + x.emitida_por : '') + '">' + (nome === 'guia' ? 'Guia emitida' : 'Boleto emitido') + (x.emitida_em ? ' em ' + dataBR(x.emitida_em) : '') + '</span>'
      : '<span class="pill hoje">' + (nome === 'guia' ? 'Guia a emitir' : 'Boleto a emitir') + '</span>') +
    (x.email_em ? ' <span class="pill ' + (ST_EMAIL[x.email_st] || ST_EMAIL.enviado)[0] + '" title="' + esc((x.email_para ? 'para ' + x.email_para : '') + (x.email_erro ? ' — ' + x.email_erro : '')) + '">' +
      (ST_EMAIL[x.email_st] || ST_EMAIL.enviado)[1] + ' ' + dataLocal(x.email_em) + '</span>' : '') +
    (x.reenvio_em ? ' <span class="pill aberto" title="' + esc('reenviada ' + (x.reenvios > 1 ? x.reenvios + ' vezes' : '1 vez') + (x.reenvio_valor ? ' · valor atualizado ' + brl(x.reenvio_valor) : '')) + '">↻ reenviada ' + dataLocal(x.reenvio_em) +
      (x.reenvio_venc ? ' · vence ' + dataBR(x.reenvio_venc).slice(0, 5) : '') + '</span>' : '');
}
// data local (fuso do navegador) de um carimbo de hora do banco — "2026-10-01T02:10Z" em Brasília ainda é 30/09
function dataLocal(ts) { if (!ts) return ''; const d = new Date(ts); return isNaN(d) ? dataBR(String(ts).slice(0, 10)) : d.toLocaleDateString('pt-BR'); }
// arquivo escolhido na tela → {arquivo, mime, b64} (vai só dentro do e-mail; não é guardado no sistema)
function lerArquivoB64(f) {
  return new Promise((ok, erro) => { const r = new FileReader(); r.onload = () => ok({ arquivo: f.name, mime: f.type || 'application/pdf', b64: String(r.result).split(',')[1] || '' }); r.onerror = () => erro(new Error('Não consegui ler ' + f.name)); r.readAsDataURL(f); });
}
const LIMITE_ANEXOS = 15 * 1024 * 1024;

// e-mail cadastrado para receber as guias (contato marcado "Parcelamentos"/"Acordos", setor, geral ou cadastro)
async function preencherDestino(campo, cli, grp, tabela) {
  let para = '';
  if (cli || grp) para = await q(sb.rpc('guia_destino', { p_cliente: cli || null, p_grupo: grp || null, p_tabela: tabela })).catch(() => '') || '';
  if (!campo.isConnected) return;
  if (!campo.value) campo.value = para;
  campo.placeholder = para ? '' : 'sem e-mail cadastrado — digite aqui (ex.: financeiro@empresa.com.br)';
  const cx = campo.closest('.campo'); if (cx) cx.classList.toggle('ge-sem-email', !para);
}
let _emailTeste;
async function emailDeTeste() {
  if (_emailTeste === undefined) _emailTeste = ((await q(sb.from('configuracoes').select('valor').eq('chave', 'email_redirecionar')).catch(() => []))[0] || {}).valor || '';
  return typeof _emailTeste === 'string' ? _emailTeste : '';
}
async function copiarTexto(txt) {
  try { await navigator.clipboard.writeText(txt); }
  catch (e) { const a = document.createElement('textarea'); a.value = txt; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); }
}
// Backup 42: depois de pôr o e-mail na fila, manda na hora (enviarEmailAgora) e mostra o que aconteceu de verdade
async function avisoEnvio(prefixo, r) {
  const s = r && r.status === 'rascunho' ? await salvarRascunhoAgora(r.ref) : await enviarEmailAgora(r && r.ref, r && r.para);
  aviso(prefixo + (s.ok ? '✓ ' : '⚠ ') + s.msg, !s.ok);
  return s;
}

// janela de emissão: marcar como emitida e, se quiser, mandar ao cliente com o PDF (o PDF vai só no e-mail)
async function janelaEmissao(tabela, x, depois) {
  if (!x) return;
  if (!E.clientes.length) await carregarCadastros();
  if (x.vencimento < hojeISO() && !x.pago) return janelaReenvio(tabela, x, depois);   // Backup 33: parcela vencida = reenviar a guia atualizada
  const nome = tabela === 'parcelas' ? 'guia' : 'boleto / PIX', ja = emitida(x);
  const j = abrirJanela({ titulo: '🧾 ' + (ja ? 'Emissão' : 'Emitir ' + nome) + ' — ' + (x.quem || ''), larga: true,
    corpo: '<div class="gd-jan-hd"><div><b>' + esc(x.quem || '—') + '</b><div class="sub">Parcela ' + esc(x.parcela || '') + (x.detalhe ? ' · ' + esc(x.detalhe) : '') + '</div></div>' +
        '<div class="gd-jan-v"><span>Vencimento</span><b>' + dataBR(x.vencimento) + '</b></div>' +
        '<div class="gd-jan-v ge-it-v"><span>Valor da guia</span><span class="ge-vbox"><span class="ge-rs">R$</span><input id="gd-valor" data-mascara="nenhuma" inputmode="decimal" value="' + (x.valor ? valorParaCampo(x.valor) : '') + '" placeholder="0,00" aria-label="Valor da guia"></span></div></div>' +
      (ja ? '<div class="dica" style="margin:10px 0">' + (tabela === 'parcelas' ? 'Guia emitida' : 'Boleto emitido') + (x.emitida_em ? ' em <b>' + dataBR(x.emitida_em) + '</b>' : '') + (x.emitida_por ? ' por <b>' + esc(x.emitida_por) + '</b>' : '') +
          (x.email_em ? ' · e-mail ao cliente em <b>' + dataLocal(x.email_em) + '</b>' + (x.email_st && x.email_st !== 'enviado' ? ' (' + (ST_EMAIL[x.email_st] || ['', x.email_st])[1] + ')' : '') : ' · ainda não enviada ao cliente') + '.</div>' : '') +
      (tabela === 'acordos' && (x.pix || x.banco) ? '<div class="dica" style="margin:10px 0">Dados do credor: ' + [x.pix ? 'PIX <b>' + esc(x.pix) + '</b>' : '', x.banco ? esc(x.banco) : ''].filter(Boolean).join(' · ') + '</div>' : '') +
      '<ol class="passos gd-passos"><li>Emita a ' + nome + ' no site do órgão/credor.</li><li>Anexe o PDF aqui e marque "enviar ao cliente".</li>' +
        '<li>O PDF vai <b>só no e-mail</b> — não fica guardado no sistema.</li></ol>' +
      '<div class="grade"><div class="inteiro"><label class="ge-drop"><input type="file" id="gd-arq" accept=".pdf,image/*" hidden><span id="gd-arq-n">📎 <b>Anexar o PDF</b> da ' + nome + ' (opcional)</span><small>vai só no e-mail — não fica guardado no sistema</small></label></div>' +
      '<label class="check inteiro"><input type="checkbox" id="gd-enviar"' + (guiaEnviada(x) ? '' : ' checked') + '> ✉ Enviar ao cliente por e-mail agora</label>' +
      '<label class="campo inteiro" id="gd-para-l"><span>✉ Para (e-mail do cliente)</span><input id="gd-para" type="text" autocomplete="off" placeholder="procurando o e-mail cadastrado…"></label></div>',
    rodape: (ja ? '<button class="btn btn-x" type="button" id="gd-desfazer">Desmarcar emissão</button>' : '<span></span>') +
      '<div class="acoes"><button class="btn btn-o" type="button" data-cancelar>Cancelar</button><button class="btn btn-p" type="button" id="gd-ok">' + (ja ? 'Salvar' : '✓ Marcar como emitida') + '</button></div>' });
  j.querySelector('[data-cancelar]').onclick = () => fecharJanela(j);
  // Backup 30: o mesmo destinatário do "Enviar por empresa" — já vem preenchido; se não houver, digite aqui
  const cPara = j.querySelector('#gd-para'), cEnv = j.querySelector('#gd-enviar');
  const verPara = () => { j.querySelector('#gd-para-l').hidden = !cEnv.checked;
    j.querySelector('#gd-ok').textContent = cEnv.checked ? '✉ ' + (ja ? 'Salvar e enviar e-mail' : 'Marcar emitida e enviar e-mail') : (ja ? 'Salvar' : '✓ Marcar como emitida'); };
  cEnv.addEventListener('change', verPara); verPara();
  j.querySelector('#gd-arq').onchange = (ev) => { const f = ev.target.files[0]; j.querySelector('#gd-arq-n').innerHTML = f ? '📄 <b>' + esc(f.name) + '</b> · ' + Math.max(1, Math.round(f.size / 1024)) + ' KB (clique para trocar)' : '📎 <b>Anexar o PDF</b>'; };
  const cVal = j.querySelector('#gd-valor'); cVal.addEventListener('blur', () => { const v = lerValor(cVal.value); cVal.value = v ? valorParaCampo(v) : ''; });
  preencherDestino(cPara, x.cliente_id, x.grupo_id, tabela);
  const fim = async (msg) => { aviso(msg); fecharJanela(j); if (depois) await depois(); if (window.ERP_RECARREGAR) window.ERP_RECARREGAR(); };
  j.querySelector('#gd-ok').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const arq = j.querySelector('#gd-arq').files[0], enviar = j.querySelector('#gd-enviar').checked, v = lerValor(j.querySelector('#gd-valor').value) || x.valor || 0;
    if (enviar) {
      if (arq && arq.size > LIMITE_ANEXOS) throw new Error('O PDF passa de 15 MB.');
      if (!cPara.value.trim()) throw new Error('Digite o e-mail do cliente no campo "Para" (ou desmarque "Enviar ao cliente").');
      const r = await q(sb.rpc('enviar_guias_email', { p_cliente: x.cliente_id || null, p_grupo: x.grupo_id || null,
        p_itens: [{ tabela, id: x.id, descricao: descricaoGuia(tabela, x), vencimento: x.vencimento, valor: v }],
        p_assunto: (tabela === 'parcelas' ? 'Guia de parcelamento' : 'Boleto de acordo') + ' — ' + (x.quem || ''), p_texto: textoGuias(tabela, x.quem || '', [x]).email,
        p_docs: x.guia_doc ? [x.guia_doc] : [], p_para: cPara.value.trim(), p_arquivos: arq ? [await lerArquivoB64(arq)] : [] }));
      await avisoEnvio((tabela === 'parcelas' ? 'Guia emitida' : 'Boleto emitido') + '. ', r); fecharJanela(j); if (depois) await depois(); if (window.ERP_RECARREGAR) window.ERP_RECARREGAR(); return;
    }
    await q(sb.rpc('registrar_emissao', { p_tabela: tabela, p_id: x.id, p_emitida: true, p_doc: null, p_enviar: false }));
    await fim('✓ ' + (tabela === 'parcelas' ? 'Guia emitida' : 'Boleto emitido') + ' em ' + dataBR(hojeISO()) + '. Ela fica em "Emitidas — falta enviar" até o e-mail sair.');
  });
  const d = j.querySelector('#gd-desfazer');
  if (d) d.onclick = (ev) => comBotao(ev.currentTarget, async () => {
    if (!await confirmarB('Desmarcar a emissão desta parcela?')) return;
    await q(sb.rpc('registrar_emissao', { p_tabela: tabela, p_id: x.id, p_emitida: false, p_doc: null, p_enviar: false }));
    await fim('Emissão desmarcada.');
  });
}
// Backup 33: parcela VENCIDA sem pagamento — reemitir no portal (o órgão já calcula os juros/SELIC) e mandar de novo ao cliente.
// A parcela continua a mesma (mesmo número); guardamos o novo vencimento, o valor atualizado e quantas vezes foi reenviada.
function fimDoMesGuia(iso) { const d = new Date(iso.slice(0, 7) + '-01T12:00:00'); d.setMonth(d.getMonth() + 1); d.setDate(0); return d.toISOString().slice(0, 10); }
async function janelaReenvio(tabela, x, depois) {
  const nome = tabela === 'parcelas' ? 'guia' : 'boleto / PIX', h = hojeISO();
  const j = abrirJanela({ titulo: '↻ Reenviar ' + nome + ' vencida — ' + (x.quem || ''), larga: true,
    corpo: '<div class="gd-jan-hd"><div><b>' + esc(x.quem || '—') + '</b><div class="sub">Parcela ' + esc(x.parcela || '') + (x.detalhe ? ' · ' + esc(x.detalhe) : '') + '</div></div>' +
        '<div class="gd-jan-v"><span>Venceu em</span><b class="dias-r">' + dataBR(x.vencimento) + '</b></div>' +
        '<div class="gd-jan-v"><span>Valor original</span><b>' + (x.valor ? brl(x.valor) : '—') + '</b></div></div>' +
      (x.reenvio_em ? '<div class="dica" style="margin:10px 0">Já reenviada ' + (x.reenvios > 1 ? x.reenvios + ' vezes' : '1 vez') + ' — a última em <b>' + dataLocal(x.reenvio_em) + '</b>' +
        (x.reenvio_venc ? ', com vencimento em <b>' + dataBR(x.reenvio_venc) + '</b>' : '') + (x.reenvio_valor ? ' e valor de <b>' + brl(x.reenvio_valor) + '</b>' : '') + '.</div>' : '') +
      '<ol class="passos gd-passos"><li>Emita a ' + nome + ' <b>de novo</b> no portal (e-CAC, Regularize, SIARE, banco do credor…): ' + (tabela === 'parcelas' ? 'a guia nova já vem com os <b>juros (SELIC)</b> do atraso.' : 'peça o valor atualizado ao credor.') + '</li>' +
        '<li>Copie aqui o <b>novo vencimento</b> e o <b>valor atualizado</b> da guia nova e anexe o PDF.</li><li>O cliente recebe o e-mail avisando que é a mesma parcela, agora atualizada.</li></ol>' +
      '<div class="grade"><div class="campo"><span>Novo vencimento</span><input type="date" id="rv-venc" value="' + (x.reenvio_venc && x.reenvio_venc >= h ? x.reenvio_venc: fimDoMesGuia(h)) + '"></div>' +
        '<div class="campo ge-it-v"><span>Valor atualizado (com juros)</span><span class="ge-vbox"><span class="ge-rs">R$</span><input id="rv-valor" data-mascara="nenhuma" inputmode="decimal" value="' + valorParaCampo(x.reenvio_valor || x.valor || '') + '" placeholder="0,00"></span></div>' +
        '<div class="inteiro"><label class="ge-drop"><input type="file" id="rv-arq" accept=".pdf,image/*" hidden><span id="rv-arq-n">📎 <b>Anexar o PDF</b> da ' + nome + ' nova</span><small>vai só no e-mail — não fica guardado no sistema</small></label></div>' +
        '<label class="campo inteiro"><span>✉ Para (e-mail do cliente)</span><input id="rv-para" type="text" autocomplete="off" placeholder="procurando o e-mail cadastrado…"></label></div>',
    rodape: '<span class="sub">A parcela continua em "Vencidas" até você marcar ✓ Pago.</span><div class="acoes"><button class="btn btn-o" type="button" data-cancelar>Cancelar</button><button class="btn btn-p" type="button" id="rv-ok">↻ Reenviar ao cliente</button></div>' });
  j.querySelector('[data-cancelar]').onclick = () => fecharJanela(j);
  const cPara = j.querySelector('#rv-para'), cVal = j.querySelector('#rv-valor');
  cVal.addEventListener('blur', () => { const v = lerValor(cVal.value); cVal.value = v ? valorParaCampo(v) : ''; });
  j.querySelector('#rv-arq').onchange = (ev) => { const f = ev.target.files[0]; j.querySelector('#rv-arq-n').innerHTML = f ? '📄 <b>' + esc(f.name) + '</b> · ' + Math.max(1, Math.round(f.size / 1024)) + ' KB (clique para trocar)' : '📎 <b>Anexar o PDF</b>'; };
  preencherDestino(cPara, x.cliente_id, x.grupo_id, tabela);
  j.querySelector('#rv-ok').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const venc = j.querySelector('#rv-venc').value, v = lerValor(cVal.value), arq = j.querySelector('#rv-arq').files[0];
    if (!venc || venc < h) throw new Error('Informe o novo vencimento (hoje ou depois).');
    if (!(v > 0)) throw new Error('Informe o valor atualizado da guia nova.');
    if (!cPara.value.trim()) throw new Error('Digite o e-mail do cliente no campo "Para".');
    if (arq && arq.size > LIMITE_ANEXOS) throw new Error('O PDF passa de 15 MB.');
    const desc = 'Guia ATUALIZADA da parcela vencida em ' + dataBR(x.vencimento) + ' — ' + descricaoGuia(tabela, Object.assign({}, x, { vencimento: venc }));
    const texto = 'Prezados,\n\nA parcela ' + parcDe(x) + (tabela === 'parcelas' ? ' do parcelamento' : ' do acordo') + ' em nome de ' + (x.quem || '') + ', que venceu em ' + dataBR(x.vencimento) + ', ainda consta em aberto.\n' +
      'Segue ' + (tabela === 'parcelas' ? 'a guia atualizada (já com os juros do atraso)' : 'o boleto atualizado') + ', com vencimento em ' + dataBR(venc) + ', no valor de ' + brl(v) + '.\n' +
      'Se o pagamento já foi feito, por favor desconsidere e nos envie o comprovante.\n\nOs arquivos seguem anexos.';
    const r = await q(sb.rpc('enviar_guias_email', { p_cliente: x.cliente_id || null, p_grupo: x.grupo_id || null,
      p_itens: [{ tabela, id: x.id, descricao: desc, vencimento: venc, valor: v, reenvio: true }],
      p_assunto: (tabela === 'parcelas' ? 'Guia atualizada (parcela em atraso)' : 'Boleto atualizado (parcela em atraso)') + ' — ' + (x.quem || ''), p_texto: texto,
      p_docs: [], p_para: cPara.value.trim(), p_arquivos: arq ? [await lerArquivoB64(arq)] : [] }));
    await avisoEnvio('↻ ' + (tabela === 'parcelas' ? 'Guia' : 'Boleto') + ' reenviado. ', r); fecharJanela(j);
    if (depois) await depois(); if (window.ERP_RECARREGAR) window.ERP_RECARREGAR();
  });
  return j;
}
// para os cartões do ERP (detalhamento do parcelamento/acordo): busca a parcela e abre a janela
async function emitirParcela(tabela, id, depois) {
  const L = await dadosGuias(tabela);
  let x = L.find((y) => y.id === id);
  if (!x) {   // vence depois de 15 dias: busca direto
    if (tabela === 'parcelas') {
      const r = (await q(sb.from('parcelas').select('id, numero, vencimento, pago, emissao, emitida_em, emitida_por, guia_doc, parcelamentos(empresa, natureza, local, numero, total_parcelas, valor_ultima_parcela, grupo_id)').eq('id', id)))[0];
      if (r) { const p = r.parcelamentos || {}; x = Object.assign(r, { quem: p.empresa, detalhe: [p.natureza, p.local].filter(Boolean).join(' · '), parcela: (r.numero || '?') + (p.total_parcelas ? '/' + p.total_parcelas : ''), valor: Number(p.valor_ultima_parcela) || 0, grupo_id: p.grupo_id, parcelamentos: p }); }
    } else {
      const r = (await q(sb.from('acordos').select('*').eq('id', id)))[0];
      if (r) x = Object.assign(r, { quem: r.devedor, detalhe: 'deve a ' + (r.credor || '—'), parcela: (r.parcela || '?') + (r.total_parcelas ? '/' + r.total_parcelas : ''), valor: Number(r.valor) || 0 });
    }
  }
  return janelaEmissao(tabela, x, depois);
}

// ═══ Várias guias da MESMA empresa num e-mail só (ou no WhatsApp) — Backup 29: visual novo e o texto das antigas "Notificações" ═══
const chaveEmpresaGuia = (x) => x.cliente_id || 'q:' + normalizar(x.quem || '');
const parcDe = (x) => { const [n, t] = String(x.parcela || '').split('/'); return (n || '?') + (t ? ' de ' + t : ''); };
function descricaoGuia(tabela, x) {
  const venc = x.vencimento < hojeISO() ? '⚠ VENCIDA — ' : '';
  if (tabela === 'parcelas') { const p = x.parcelamentos || {};
    return venc + 'Parcelamento ' + [p.local, p.natureza].filter(Boolean).join(' — ') + (p.numero ? ' · nº ' + p.numero : '') + ' · Parcela ' + parcDe(x); }
  return venc + 'Processo ' + (x.processo || '—') + ' · ' + parcOrd(x) + ' · ' + (x.devedor || '') + ' × ' + (x.credor || '');
}
// Backup 37: "8ª parcela de 40"; saudação pela hora; acordo pago por PIX ou por boleto (campo "Forma de pagamento" do acordo)
const parcOrd = (x) => { const [n, t] = String(x.parcela || '').split('/'); return (/^\d+$/.test(n || '') ? n + 'ª parcela' : 'Parcela ' + (n || '?')) + (t ? ' de ' + t : ''); };
const saudacaoGuia = () => { const hh = new Date().getHours(); return hh < 12 ? 'Bom dia!' : hh < 18 ? 'Boa tarde!' : 'Boa noite!'; };
const ehPixGuia = (tabela, x) => tabela === 'acordos' && x.forma_pagamento === 'pix';
// Backup 52 (C6): o PIX de uma parcela de acordo = o código copia e cola dela (pix_codigo) ou, sem ele, a chave PIX do acordo (qualquer forma de pagamento)
const pixDaParcela = (x) => String((x._pixCodigo != null ? x._pixCodigo : x.pix_codigo) || x.pix || '').trim();
const fechoGuias = (tabela, itens) => tabela === 'parcelas' ? 'Os arquivos seguem anexos. Depois de pagar, por favor nos envie o comprovante.'
  // Backup 42: acordo sem o pedido de comprovante; PIX sem fecho (não tem arquivo)
  : itens.every((x) => ehPixGuia(tabela, x)) ? ''
  : itens.some((x) => ehPixGuia(tabela, x)) ? 'Os boletos seguem anexos (as parcelas por PIX têm a chave acima).'
  : (itens.length > 1 ? 'Os boletos seguem anexos.' : 'O boleto segue anexo.');
// o texto (e-mail e WhatsApp). Parcelamentos: modelo das antigas Notificações. Acordos (Backup 37): objetivo, como o escritório escreve
function textoGuias(tabela, empresa, itens) {
  const vencida = itens.some((x) => x.vencimento < hojeISO());
  const valorDe = (x) => { const v = x._valor != null ? x._valor : x.valor; return v ? brl(v) : '[preencher]'; };
  const tot = itens.reduce((s2, x) => s2 + (Number(x._valor != null ? x._valor : x.valor) || 0), 0), fecho = fechoGuias(tabela, itens);
  if (tabela === 'parcelas') {
    // Backup 42: o texto das antigas Notificações → Parcelamento, palavra por palavra (o mesmo da Planilha da Rotina)
    // Backup 52 (C7): texto genérico — o nome do cliente fica só no assunto (antes: "guias dos parcelamentos da Fulano")
    const intro = 'Prezados,\n\nSeguem as guias dos parcelamentos com vencimento neste mês. Antes de pagar, confirme se a guia já não foi paga, para evitar duplicidade.';
    const blocos = itens.map((x) => { const p = x.parcelamentos || {}, [n, tt] = String(x.parcela || '').split('/'), v = x._venc || x.vencimento || '';
      return (x.vencimento < hojeISO() ? '⚠︎ GUIA VENCIDA\n' : '') + 'Parcelamento ' + (p.local || p.natureza || '') + ' — Natureza: ' + (p.natureza || '—') +
        '\nNº do Parcelamento: ' + (p.numero || '—') + '\nParcela: ' + (n || '?') + ' de ' + (tt || p.total_parcelas || '?') + ' | Vencimento: ' + (v ? v.slice(5, 7) + '/' + v.slice(0, 4) : '—') +
        '\nNº da Guia: ' + (n || '—') + '\nValor: ' + valorDe(x); });
    return { intro, fecho, email: intro + '\n\n' + fecho, zap: intro + '\n\n' + blocos.join('\n\n') + (itens.length > 1 ? '\n\n*Total: ' + brl(tot) + '*' : '') + '\n\n' + fecho };
  }
  // Backup 52 (C6/C7): texto genérico (sem "da Fulano") e o PIX da parcela — o código copia e cola dela ou, sem ele, a chave PIX do acordo
  const intro = saudacaoGuia() + '\n\nSeguem as parcelas de acordo com vencimento neste mês ou em atraso.';
  const blocos = itens.map((x) => { const pix = pixDaParcela(x);
    return (x.vencimento < hojeISO() ? '⚠ PARCELA EM ATRASO\n' : '') + '*Acordo para pagamento*\nProcesso: ' + (x.processo || '—') + ' | Parcela: ' + parcOrd(x) +
      '\nPartes: ' + (x.devedor || '—') + ' × ' + (x.credor || '—') + '\nVencimento: ' + dataBR(x._venc || x.vencimento) + '\nValor: ' + valorDe(x) +
      (pix ? '\nPIX: ' + pix + (x.banco && !x._pixCodigo && !x.pix_codigo ? '\nBanco: ' + x.banco : '') : ehPixGuia(tabela, x) ? '\nPIX: [chave PIX]' : ''); });
  return { intro, fecho, email: intro + (fecho ? '\n\n' + fecho : ''), zap: intro + '\n\n' + blocos.join('\n\n') + (itens.length > 1 ? '\n\nTotal: ' + brl(tot) : '') + (fecho ? '\n\n' + fecho : '') };
}
async function janelaGuiasEmpresa(tabela, L, chaveIni, depois) {
  if (!E.clientes.length) await carregarCadastros();
  L = (L || []).filter((x) => !x.pago && !x.email_em);
  const emp = {};
  L.forEach((x) => { const k = chaveEmpresaGuia(x); (emp[k] = emp[k] || { k, nome: x.quem || '—', cli: x.cliente_id, grupo: x.grupo_id, itens: [] }).itens.push(x); });
  // Backup 30: empresas organizadas por GRUPO (igual ao Painel Executivo); sem grupo vai por último
  Object.values(emp).forEach((e) => { const c = E.clientes.find((y) => y.id === e.cli) || {}; e.gid = e.grupo || c.grupo_id || ''; e.gnome = nomeGrupo(e.gid) || ''; });
  const lista = Object.values(emp).sort((a, b) => (!a.gnome) - (!b.gnome) || a.gnome.localeCompare(b.gnome, 'pt-BR') || a.nome.localeCompare(b.nome, 'pt-BR'));
  if (!lista.length) return aviso('Nenhuma parcela em aberto para enviar.', true);
  const nome = tabela === 'parcelas' ? 'guias' : 'boletos';
  let atualK = chaveIni && emp[chaveIni] ? chaveIni : lista[0].k, arquivos = [];
  const soRascunho = tabela === 'acordos';
  const j = abrirJanela({ titulo: tabela === 'parcelas' ? '✉ Enviar guias por empresa' : '✉ Enviar parcelas de acordo por empresa', larga: true,
    corpo: '<div class="ge"><aside class="ge-emps" id="ge-emps"></aside><section class="ge-msg" id="ge-msg"></section></div>',
    rodape: '<span class="ge-tot" id="ge-tot"></span><div class="acoes ge-acoes"><button class="btn btn-o" type="button" data-cancelar>Cancelar</button>' +
      // Backup 45: em Acordos o e-mail é só "Rascunho no Gmail" (sem prévia, sem WhatsApp, sem "Enviar e-mail")
      (soRascunho ? '<button type="button" class="btn btn-o" id="ge-copiar" title="Copia o texto">📋 Copiar texto</button>' +
        '<button type="button" class="btn btn-p" id="ge-rascunho" title="Guarda o e-mail pronto (com os anexos) na pasta Rascunhos do seu Gmail, já com o e-mail do cliente — confira e envie de lá">📝 Rascunho no Gmail</button></div>'
      : '<button type="button" class="btn btn-o" id="ge-previa" title="Ver o e-mail exatamente como o cliente vai receber">👁 Prévia do e-mail</button>' +
      '<button type="button" class="btn btn-o" id="ge-copiar" title="Copia o texto para você colar no WhatsApp">📋 Copiar texto</button>' +
      '<button type="button" class="btn btn-v" id="ge-zap">💬 WhatsApp</button>' +
      '<button type="button" class="btn btn-o" id="ge-rascunho" title="Guarda o e-mail pronto (com os anexos) na pasta Rascunhos do seu Gmail, para você conferir e enviar de lá">📝 Rascunho no Gmail</button>' +
      '<button class="btn btn-p" type="button" id="ge-enviar">✉ Enviar e-mail</button></div>') });
  j.querySelector('.janela').classList.add('ge-janela');
  const $j = (sel) => j.querySelector(sel);
  const pixItem = (i) => tabela === 'acordos' && pixDaParcela(i) ? { pix: pixDaParcela(i), banco: (i._pixCodigo || i.pix_codigo) ? '' : i.banco || '', pix_codigo: !!(i._pixCodigo || i.pix_codigo) } : {};
  const atual = () => emp[atualK];
  const pintarEmps = () => {
    const grs = []; lista.forEach((e) => { const g = grs[grs.length - 1]; if (g && g.k === e.gid) g.emps.push(e); else grs.push({ k: e.gid, nome: e.gnome || 'Sem grupo', emps: [e] }); });
    $j('#ge-emps').innerHTML = '<div class="ge-emps-tit">Grupos <span class="sub">' + grs.length + ' · ' + plural(lista.length, 'empresa', 'empresas') + '</span></div>' +
      grs.map((g) => '<div class="ge-grp"><div class="ge-grp-hd"><b>' + esc(g.nome) + '</b><span class="sub">' + plural(g.emps.length, 'empresa', 'empresas') + '</span></div>' +
        g.emps.map((e) => '<button type="button" class="ge-emp' + (e.k === atualK ? ' ativo' : '') + '" data-ge-emp="' + esc(e.k) + '">' +
          '<b>' + esc(e.nome) + '</b><span class="sub">' + plural(e.itens.length, nome.slice(0, -1), nome) + ' · ' + brl(e.itens.reduce((s2, x) => s2 + (Number(x.valor) || 0), 0)) + '</span>' +
          (e.itens.some((x) => x.vencimento < hojeISO()) ? '<span class="pill vencido">vencida</span>' : '') + '</button>').join('') + '</div>').join('');
  };
  const pintarMsg = () => {
    const e = atual(), c = E.clientes.find((y) => y.id === e.cli) || {}, t = textoGuias(tabela, e.nome, e.itens);
    arquivos = [];
    $j('#ge-msg').innerHTML =
      '<div class="ge-cab"><div><div class="ge-emp-nome">' + esc(e.nome) + '</div><div class="sub">' + esc([mascaraDoc(c.cpf_cnpj), e.gnome].filter(Boolean).join(' · ')) + '</div></div></div>' +
      '<div class="ge-dest"><label class="campo"><span>✉ E-mail (para)</span><input id="ge-para" type="text" autocomplete="off" placeholder="procurando o e-mail cadastrado…"><small class="sub" id="ge-teste"></small></label>' +
        (soRascunho ? '' : '<label class="campo"><span>💬 WhatsApp</span><input id="ge-tel" data-mascara="tel" inputmode="tel" value="' + esc(c.telefone || '') + '" placeholder="(37) 9 9999-9999"></label>') +
        '<label class="campo ge-ass"><span>Assunto</span><input id="ge-assunto" value="' + esc((tabela === 'parcelas' ? 'Guias de parcelamento' : e.itens.every((x) => ehPixGuia(tabela, x)) ? 'Parcela de acordo' : 'Boletos de acordo') + ' — ' + e.nome) + '"></label></div>' +
      '<div class="ge-papel"><textarea id="ge-texto" rows="5">' + esc(t.intro) + '</textarea>' +
        '<div class="ge-itens">' + e.itens.map((x) => { const p = x.parcelamentos || {};
          return '<label class="ge-it' + (tabela === 'acordos' ? ' ge-it-ac' : '') + (x.vencimento < hojeISO() ? ' ge-venc' : '') + '" data-ge="' + x.id + '"><input type="checkbox" checked aria-label="Incluir">' +
            '<span class="ge-it-txt">' + (x.vencimento < hojeISO() ? '<span class="ge-alerta">⚠ ' + (tabela === 'parcelas' ? 'GUIA VENCIDA' : 'PARCELA VENCIDA') + '</span>' : '') +
              '<b>' + esc(tabela === 'parcelas' ? 'Parcelamento ' + [p.local, p.natureza].filter(Boolean).join(' — ') : 'Processo ' + (x.processo || '—') + ' · ' + parcOrd(x)) + '</b>' +
              (ehPixGuia(tabela, x) ? ' <span class="ge-forma">PIX</span>' : tabela === 'acordos' ? ' <span class="ge-forma ge-forma-b">boleto</span>' : '') +
              '<span>' + (tabela === 'parcelas' ? (p.numero ? 'Nº do parcelamento: <b>' + esc(p.numero) + '</b> · Parcela <b>' + esc(parcDe(x)) + '</b> · ' : 'Parcela <b>' + esc(parcDe(x)) + '</b> · ') : 'Partes: <b>' + esc(x.devedor || '—') + ' × ' + esc(x.credor || '—') + '</b> · ') +
              'Vencimento <b>' + dataBR(x.vencimento) + '</b>' + '</span></span>' +
            (tabela === 'parcelas' && x.vencimento < hojeISO() ? '<span class="ge-it-v ge-it-d"><small>Novo vencimento</small><input type="date" class="ge-novo-venc" value="' + fimDoMesGuia(hojeISO()) + '" aria-label="Novo vencimento da guia atualizada"></span>' : '') +
            (tabela === 'acordos' ? '<span class="ge-it-v ge-it-pix"><small>Código PIX (copia e cola)</small><input class="ge-pix" data-mascara="nenhuma" value="' + esc(x.pix_codigo || '') + '" placeholder="' + esc(x.pix ? 'vazio = chave ' + x.pix : 'cole o código desta parcela') + '" aria-label="Código PIX (copia e cola)"></span>' : '') +
            '<span class="ge-it-v"><small>' + (tabela === 'acordos' ? 'Valor da parcela' : x.vencimento < hojeISO() ? 'Valor atualizado' : 'Valor da guia') + '</small><span class="ge-vbox"><span class="ge-rs">R$</span><input class="ge-valor" data-mascara="nenhuma" inputmode="decimal" value="' + (x.valor ? valorParaCampo(x.valor) : '') + '" placeholder="0,00" aria-label="Valor"></span></span></label>'; }).join('') + '</div>' +
        '<div class="ge-fecho">' + esc(t.fecho) + '</div></div>' +
      '<div class="ge-anexos"' + (e.itens.every((x) => ehPixGuia(tabela, x)) ? ' hidden' : '') + '><label class="ge-drop"><input type="file" id="ge-arqs" accept=".pdf,image/*" multiple hidden><span>📎 <b>Anexar os PDFs</b> ' + (tabela === 'acordos' ? 'dos boletos' : 'das guias') + '</span><small>vão só no e-mail — não ficam guardados no sistema</small></label><div class="ge-chips" id="ge-chips"></div></div>';
    $j('#ge-arqs').onchange = () => { arquivos = arquivos.concat([...$j('#ge-arqs').files]); $j('#ge-arqs').value = ''; pintarChips(); };
    j.querySelectorAll('.ge-it input').forEach((i) => i.addEventListener('input', total));
    j.querySelectorAll('.ge-it input[type=checkbox]').forEach((i) => i.addEventListener('change', total));
    j.querySelectorAll('.ge-valor').forEach((i) => i.addEventListener('blur', () => { const v = lerValor(i.value); i.value = v ? valorParaCampo(v) : ''; total(); }));
    preencherDestino($j('#ge-para'), e.cli, e.grupo, tabela);
    emailDeTeste().then((m) => { const x = $j('#ge-teste'); if (x && m) x.textContent = 'Modo teste: por enquanto todo e-mail chega só em ' + m + '.'; });
    pintarChips(); total();
  };
  const pintarChips = () => { $j('#ge-chips').innerHTML = arquivos.map((f, k) => '<span class="ge-chip">📄 ' + esc(f.name) + ' <small>' + Math.max(1, Math.round(f.size / 1024)) + ' KB</small><button type="button" data-tira="' + k + '" aria-label="Tirar">×</button></span>').join('');
    j.querySelectorAll('[data-tira]').forEach((b) => b.onclick = () => { arquivos.splice(+b.dataset.tira, 1); pintarChips(); }); };
  const marcados = () => [...j.querySelectorAll('.ge-it')].filter((l) => l.querySelector('input[type=checkbox]').checked).map((l) => {
    const x = atual().itens.find((y) => y.id === l.dataset.ge), v = lerValor(l.querySelector('.ge-valor').value);
    const dv = l.querySelector(".ge-novo-venc");   // Backup 34: parcela vencida → reemissão com novo vencimento e valor atualizado
    const px = l.querySelector('.ge-pix');   // Backup 52: código PIX desta parcela
    return Object.assign({}, x, { _valor: isNaN(v) ? 0 : v, _venc: dv ? dv.value : null }, px ? { _pixCodigo: px.value.trim() } : {});
  });
  const total = () => { const m = marcados(); $j('#ge-tot').innerHTML = m.length ? plural(m.length, 'parcela', 'parcelas') + ' · total <b>' + brl(m.reduce((s2, x) => s2 + x._valor, 0)) + '</b>' : 'Nenhuma parcela marcada'; };
  $j('#ge-emps').onclick = (ev) => { const b = ev.target.closest('[data-ge-emp]'); if (!b) return; atualK = b.dataset.geEmp; pintarEmps(); pintarMsg(); };
  pintarEmps(); pintarMsg();
  j.querySelector('[data-cancelar]').onclick = () => fecharJanela(j);
  // Backup 52 (C6): o código PIX digitado fica gravado na parcela (acordos.pix_codigo)
  const gravarPix = async (its) => { if (tabela !== 'acordos') return;
    // Backup 53: grava as parcelas alteradas ao mesmo tempo (antes, uma depois da outra)
    await Promise.all(its.filter((i) => i._pixCodigo != null && i._pixCodigo !== (i.pix_codigo || '')).map(async (i) => {
      await q(sb.from('acordos').update({ pix_codigo: i._pixCodigo }).eq('id', i.id));
      const o = atual().itens.find((y) => y.id === i.id); if (o) o.pix_codigo = i._pixCodigo; })); };
  if ($j('#ge-zap')) $j('#ge-zap').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const its = marcados(); if (!its.length) throw new Error('Marque ao menos uma parcela.');
    await gravarPix(its);
    const t = textoGuias(tabela, atual().nome, its), txt = $j('#ge-texto').value.trim() + t.zap.slice(t.intro.length);
    if (arquivos.length && navigator.canShare && navigator.canShare({ files: arquivos })) { await navigator.share({ text: txt, files: arquivos }); return; }
    const tel = soDigitos($j('#ge-tel').value);
    window.open('https://wa.me/' + (tel ? (tel.length <= 11 ? '55' : '') + tel : '') + '?text=' + encodeURIComponent(txt), '_blank', 'noopener');
    if (arquivos.length) aviso('No computador o WhatsApp não recebe anexo por link: arraste os PDFs para a conversa que abriu.');
  });
  $j('#ge-copiar').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const its = marcados(); if (!its.length) throw new Error('Marque ao menos uma parcela.');
    await gravarPix(its);
    const t = textoGuias(tabela, atual().nome, its), txt = $j('#ge-texto').value.trim() + t.zap.slice(t.intro.length);
    await copiarTexto(txt); aviso('✓ Texto copiado — é só colar no WhatsApp.');
  });
  if ($j('#ge-previa')) $j('#ge-previa').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const its = marcados(), e = atual(); if (!its.length) throw new Error('Marque ao menos uma parcela.');
    const html = await q(sb.rpc('previa_guias_email', { p_cliente: e.cli || null,
      p_itens: its.map((i) => Object.assign({ tabela, id: i.id, descricao: descricaoGuia(tabela, i), vencimento: i._venc || i.vencimento, valor: i._valor }, pixItem(i))),
      p_assunto: $j('#ge-assunto').value.trim(), p_texto: $j('#ge-texto').value.trim() + '\n\n' + fechoGuias(tabela, its) }));
    const pj = abrirJanela({ titulo: '👁 ' + ($j('#ge-assunto').value.trim() || 'Prévia do e-mail'), larga: true, corpo: '<iframe class="ge-previa" title="Prévia do e-mail" sandbox></iframe>' });
    pj.querySelector('.ge-previa').srcdoc = html;
  });
  const mandar = (rascunho) => async () => {
    const its = marcados(), e = atual(); if (!its.length) throw new Error('Marque ao menos uma parcela.');
    if (!$j('#ge-para').value.trim()) throw new Error('Digite o e-mail do cliente no campo "Para".');
    if (its.some((i) => !(i._valor > 0))) throw new Error('Confira o valor de todas as parcelas marcadas.');
    if (its.some((i) => i._venc !== null && i._venc !== undefined && (!i._venc || i._venc < hojeISO()))) throw new Error('Confira o novo vencimento da guia atualizada (hoje ou depois).');
    if (arquivos.reduce((s2, f) => s2 + f.size, 0) > LIMITE_ANEXOS) throw new Error('Os PDFs somam mais de 15 MB: envie em dois e-mails.');
    const [, arqs] = await Promise.all([gravarPix(its), Promise.all(arquivos.map(lerArquivoB64))]);   // Backup 53: em paralelo
    const r = await q(sb.rpc(rascunho ? 'salvar_guias_rascunho' : 'enviar_guias_email', { p_cliente: e.cli || null, p_grupo: e.grupo || null,
      p_itens: its.map((i) => Object.assign(i._venc
        ? { tabela, id: i.id, descricao: descricaoGuia(tabela, i).replace(/^⚠ VENCIDA — /, '↻ Guia atualizada — ') + ' (vencia em ' + dataBR(i.vencimento) + ')', vencimento: i._venc, valor: i._valor, reenvio: true }
        : { tabela, id: i.id, descricao: descricaoGuia(tabela, i), vencimento: i.vencimento, valor: i._valor }, pixItem(i))),
      p_assunto: $j('#ge-assunto').value.trim(), p_texto: $j('#ge-texto').value.trim() + '\n\n' + fechoGuias(tabela, its), p_docs: its.map((i) => i.guia_doc).filter(Boolean),
      p_para: $j('#ge-para').value.trim() || null, p_arquivos: arqs }));
    // Backup 53 (lentidão do e-mail do acordo): a janela fecha assim que o e-mail fica pronto no banco; o Gmail e a tela atualizam por trás
    fecharJanela(j); aviso(rascunho ? '📝 Guardando o rascunho no seu Gmail…' : '✉ Enviando o e-mail…');
    Promise.all([avisoEnvio(plural(r.itens, 'parcela', 'parcelas') + (r.anexos ? ' e ' + plural(r.anexos, 'anexo', 'anexos') : '') + ': ', r).catch((er) => aviso('⚠ ' + erroAmigavel(er), true)),
      depois ? Promise.resolve(depois()).catch(() => {}) : null])
      .then(() => { if (window.ERP_RECARREGAR) window.ERP_RECARREGAR(); });
  };
  if ($j('#ge-enviar')) $j('#ge-enviar').onclick = (ev) => comBotao(ev.currentTarget, mandar(false));
  $j('#ge-rascunho').onclick = (ev) => comBotao(ev.currentTarget, mandar(true));
  return j;
}
// Backup 35: Acordos → aba "A pagar": marcar as parcelas e "✉ Enviar por empresa" (mesma janela/e-mail das guias)
async function enviarAcordosSelecionados(ids, depois) {
  if (!ids || !ids.length) return aviso('Marque ao menos uma parcela.', true);
  if (!E.clientes.length) await carregarCadastros();
  const L = (await q(sb.from('acordos').select('id, parcela, total_parcelas, vencimento, valor, pago, emissao, emitida_em, emitida_por, guia_doc, devedor, credor, processo, grupo_id, pix, pix_codigo, banco, forma_pagamento').in('id', ids)))
    .filter((x) => !x.pago)
    .map((x) => Object.assign(x, { quem: x.devedor, detalhe: 'deve a ' + (x.credor || '—') + (x.processo ? ' · ' + x.processo : ''), email_em: null,
      parcela: (x.parcela || '?') + (x.total_parcelas ? '/' + x.total_parcelas : ''), valor: Number(x.valor) || 0,
      cliente_id: (E.clientes.find((c) => c.grupo_id === x.grupo_id && primeiroNome(c.nome) === primeiroNome(x.devedor)) || {}).id || null }));
  return janelaGuiasEmpresa('acordos', L, null, depois);
}

// ═══ Backup 53: alterar o ACORDO INTEIRO (todas as parcelas, ou só as em aberto) — devedor, credor, processo, forma de pagamento, PIX, banco,
// valor da parcela e dia do vencimento. Para mudar UMA parcela só, clique na parcela.
async function editarAcordo(ids, depois) {
  const L = await q(sb.from('acordos').select('id, parcela, total_parcelas, vencimento, valor, pago, devedor, credor, processo, forma_pagamento, pix, banco').in('id', ids || []));
  if (!L.length) return aviso('Acordo não encontrado.', true);
  const a = L.find((x) => !x.pago) || L[0], abertas = L.filter((x) => !x.pago);
  const j = abrirJanela({ titulo: '✎ Alterar o acordo inteiro', larga: true,
    corpo: '<form class="grade" id="f-acordo-todo">' +
      '<div class="inteiro dica">Muda de uma vez <b>' + plural(L.length, 'parcela', 'parcelas') + '</b> deste acordo (' + plural(abertas.length, 'em aberto', 'em aberto') + '). ' +
        'Campo em branco = não muda. Para mudar uma parcela só, feche e clique na parcela.</div>' +
      campo('Devedor', '<input name="devedor" value="' + esc(a.devedor || '') + '">') + campo('Credor', '<input name="credor" value="' + esc(a.credor || '') + '">') +
      campo('Processo', '<input name="processo" value="' + esc(a.processo || '') + '">') +
      campo('Forma de pagamento', '<select name="forma_pagamento"><option value="">— não muda —</option><option value="boleto"' + (a.forma_pagamento === 'boleto' ? ' selected' : '') + '>Boleto</option><option value="pix"' + (a.forma_pagamento === 'pix' ? ' selected' : '') + '>PIX</option></select>') +
      campo('Chave PIX', '<input name="pix" value="' + esc(a.pix || '') + '">') + campo('Banco', '<input name="banco" value="' + esc(a.banco || '') + '">') +
      campo('Novo valor da parcela (só as em aberto)', '<input name="valor" data-mascara="brl" inputmode="decimal" placeholder="em branco = não muda">') +
      campo('Novo dia do vencimento (só as em aberto)', '<input name="dia" type="number" min="1" max="31" placeholder="ex.: 10">') +
      campo('Aplicar em', '<select name="alcance"><option value="abertas">Só nas parcelas em aberto (' + abertas.length + ')</option><option value="todas">Em todas as parcelas (' + L.length + ')</option></select>', 'inteiro') + '</form>',
    rodape: '<span></span><div class="acoes"><button class="btn btn-o" type="button" data-cancelar>Cancelar</button><button class="btn btn-p" type="button" id="ac-todo-ok">Salvar no acordo inteiro</button></div>' });
  const f = j.querySelector('#f-acordo-todo');
  j.querySelector('[data-cancelar]').onclick = () => fecharJanela(j);
  j.querySelector('#ac-todo-ok').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const alvo = f.alcance.value === 'todas' ? L : abertas;
    if (!alvo.length) throw new Error('Este acordo não tem parcela em aberto. Escolha "Em todas as parcelas".');
    const d = {}; ['devedor', 'credor', 'processo', 'pix', 'banco'].forEach((k) => { const v = f[k].value.trim(); if (v !== String(a[k] || '')) d[k] = v || null; });
    if (f.forma_pagamento.value) d.forma_pagamento = f.forma_pagamento.value;
    if (Object.keys(d).length) await q(sb.from('acordos').update(d).in('id', alvo.map((x) => x.id)));
    const v = lerValor(f.valor.value), dia = Math.min(31, Math.max(0, Number(f.dia.value) || 0));
    if (v > 0) await q(sb.from('acordos').update({ valor: v }).in('id', abertas.map((x) => x.id)));
    if (dia) await Promise.all(abertas.filter((x) => x.vencimento).map((x) => { const [y, m] = x.vencimento.split('-').map(Number), ult = new Date(y, m, 0).getDate();
      return q(sb.from('acordos').update({ vencimento: y + '-' + String(m).padStart(2, '0') + '-' + String(Math.min(dia, ult)).padStart(2, '0') }).eq('id', x.id)); }));
    if (!Object.keys(d).length && !(v > 0) && !dia) throw new Error('Nada mudou.');
    aviso('✓ Acordo alterado (' + plural(alvo.length, 'parcela', 'parcelas') + ').'); fecharJanela(j);
    if (depois) await depois(); else if (window.ERP_RECARREGAR) window.ERP_RECARREGAR();
  });
  return j;
}

// ═══ Backup 37: "🧾 Gerar guias\" — abre o envio por empresa (a tela que expande com vencimento e valor atualizado) já com as parcelas a emitir:
// em atraso + as que vencem neste mês. alcance: {} = tudo · {grupo_id} · {empresa} · {itens: ids de parcelamento ou chaves de acordo}.
// proximas: true → se o parcelamento/acordo não tem nada a emitir agora, entra a PRÓXIMA parcela (mesmo futura).
const chaveAcordoGuia = (a) => [a.grupo_id || '', a.devedor || '', a.credor || '', a.processo || ''].join('|');
async function gerarGuias(tabela, alcance, depois) {
  alcance = alcance || {};
  if (!E.clientes.length) await carregarCadastros();
  const h = hojeISO(), fim = fimDoMesGuia(h), parc = tabela === 'parcelas';
  const cliDe = (doc, nome, grp) => (E.clientes.find((c) => (soDigitos(doc) && soDigitos(c.cpf_cnpj) === soDigitos(doc)) || (grp ? c.grupo_id === grp && primeiroNome(c.nome) === primeiroNome(nome) : c.nome === nome)) || {}).id || null;
  let base;
  if (parc) {
    base = (await buscarTodos(() => { let c = sb.from('parcelas').select('id, parcelamento_id, numero, vencimento, pago, emissao, emitida_em, guia_doc, valor, parcelamentos!inner(id, empresa, natureza, local, numero, total_parcelas, valor_ultima_parcela, grupo_id, cnpj, emitimos_guia)').eq('pago', false);
      if (alcance.grupo_id) c = c.eq('parcelamentos.grupo_id', alcance.grupo_id);
      if (alcance.empresa) c = c.eq('parcelamentos.empresa', alcance.empresa);
      if (alcance.itens) c = c.in('parcelamento_id', alcance.itens);
      if (alcance.ids) c = c.in('id', alcance.ids);
      return c.order('vencimento').order('id'); })).filter((x) => x.parcelamentos && (alcance.ids || x.parcelamentos.emitimos_guia !== false));
    base.forEach((x) => { const p = x.parcelamentos;
      Object.assign(x, { _k: p.id, quem: p.empresa, grupo_id: p.grupo_id, email_em: null, parcela: (x.numero || '?') + (p.total_parcelas ? '/' + p.total_parcelas : ''),
        valor: Number(x.valor) > 0 ? Number(x.valor) : Number(p.valor_ultima_parcela) || 0, detalhe: [p.natureza, p.local].filter(Boolean).join(' · '), cliente_id: cliDe(p.cnpj, p.empresa) }); });
  } else {
    base = (await buscarTodos(() => { let c = sb.from('acordos').select('id, parcela, total_parcelas, vencimento, valor, pago, emissao, emitida_em, emitida_por, guia_doc, devedor, credor, processo, grupo_id, pix, pix_codigo, banco, forma_pagamento').eq('pago', false);
      if (alcance.grupo_id) c = c.eq('grupo_id', alcance.grupo_id);
      if (alcance.empresa) c = c.eq('devedor', alcance.empresa);
      return c.order('vencimento').order('id'); }));
    if (alcance.itens) base = base.filter((a) => alcance.itens.includes(chaveAcordoGuia(a)) || alcance.itens.includes([a.processo || '', a.devedor || '', a.credor || ''].join('|')));
    base.forEach((x) => Object.assign(x, { _k: chaveAcordoGuia(x), quem: x.devedor, email_em: null, detalhe: 'deve a ' + (x.credor || '—') + (x.processo ? ' · ' + x.processo : ''),
      parcela: (x.parcela || '?') + (x.total_parcelas ? '/' + x.total_parcelas : ''), valor: Number(x.valor) || 0, cliente_id: cliDe('', x.devedor, x.grupo_id) }));
  }
  let L = alcance.ids ? base : base.filter((x) => x.vencimento && x.vencimento <= fim);   // parcelas escolhidas: vale até a futura
  if (alcance.proximas) { const tem = new Set(L.map((x) => x._k)), prox = {};
    base.forEach((x) => { if (!tem.has(x._k) && !prox[x._k]) prox[x._k] = x; });
    L = L.concat(Object.values(prox)); }
  if (!L.length) {
    if (base.length && !alcance.proximas && await confirmarB('Nada em atraso nem vencendo neste mês.\n\nEmitir a PRÓXIMA parcela ' + (parc ? 'de cada parcelamento' : 'de cada acordo') + ' deste recorte?'))
      return gerarGuias(tabela, Object.assign({}, alcance, { proximas: true }), depois);
    return aviso(base.length ? 'Nenhuma guia escolhida.' : 'Nenhuma parcela em aberto neste recorte' + (parc ? ' (que o escritório emita).' : '.'), !base.length);
  }
  return janelaGuiasEmpresa(tabela, L, null, depois);
}

// ═══ Backup 54: "+ Lançar → Acordo inteiro" — cadastra TODAS as parcelas de um acordo de uma vez (antes: uma parcela por vez) ═══
function formAcordoNovo(depois) {
  const grupos = (E.grupos || []).slice().sort((a, b) => String(a.nome).localeCompare(String(b.nome), 'pt-BR'));
  const j = abrirJanela({ titulo: '+ Novo acordo (todas as parcelas)', larga: true,
    corpo: '<form class="grade" id="f-acordo-novo">' +
      campo('Grupo', '<select name="grupo_id"><option value="">— escolha —</option>' + grupos.map((g) => '<option value="' + g.id + '">' + esc(g.nome) + '</option>').join('') + '</select>') +
      campo('Responsável', selectPessoa('responsavel', (E.perfil && E.perfil.nome) || '', '— escolha —')) +
      campo('Devedor (nosso cliente) <span class="obrig">*</span>', '<input name="devedor" maxlength="200">') +
      campo('Credor <span class="obrig">*</span>', '<input name="credor" maxlength="200">') +
      campo('Processo / identificação <span class="obrig">*</span>', '<input name="processo" maxlength="80" placeholder="nº do processo ou do acordo">') +
      campo('Forma de pagamento', '<select name="forma_pagamento"><option value="boleto">Boleto</option><option value="pix">PIX</option></select>') +
      campo('Nº de parcelas <span class="obrig">*</span>', '<input name="n" type="number" min="1" max="240" value="1">') +
      campo('Valor de cada parcela (R$) <span class="obrig">*</span>', '<input name="valor" data-mascara="brl" inputmode="decimal" placeholder="0,00">') +
      campo('1º vencimento <span class="obrig">*</span>', '<input name="venc" type="date" value="' + somarDias(hojeISO(), 30) + '">') +
      campo('Chave PIX', '<input name="pix" maxlength="200">') +
      '<div class="dica inteiro" id="acn-previa">Preencha para ver as parcelas.</div></form>',
    rodape: '<span></span><div class="acoes"><button class="btn btn-o" type="button" data-cancelar>Cancelar</button><button class="btn btn-p" type="button" id="acn-ok">Lançar o acordo</button></div>' });
  const f = j.querySelector('#f-acordo-novo');
  const venc = (k) => { const [y, m, d] = f.venc.value.split('-').map(Number), x = new Date(y, m - 1 + k, 1), ult = new Date(x.getFullYear(), x.getMonth() + 1, 0).getDate();
    return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(Math.min(d, ult)).padStart(2, '0'); };
  const previa = () => { const n = Math.max(1, Math.min(240, Number(f.n.value) || 1)), v = lerValor(f.valor.value);
    j.querySelector('#acn-previa').innerHTML = v > 0 && f.venc.value ? plural(n, 'parcela', 'parcelas') + ' de <b class="mono">' + brl(v) + '</b> (total ' + brl(v * n) + '), de ' + dataBR(venc(0)) + ' a ' + dataBR(venc(n - 1)) + ', todo mês.' : 'Preencha para ver as parcelas.'; };
  ['input', 'change'].forEach((x) => f.addEventListener(x, previa));
  j.querySelector('[data-cancelar]').onclick = () => fecharJanela(j);
  j.querySelector('#acn-ok').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const n = Number(f.n.value) || 0, v = lerValor(f.valor.value);
    if (!f.devedor.value.trim() || !f.credor.value.trim() || !f.processo.value.trim()) throw new Error('Preencha devedor, credor e processo.');
    if (!(n >= 1 && n <= 240)) throw new Error('Nº de parcelas entre 1 e 240.');
    if (!(v > 0)) throw new Error('Informe o valor da parcela (ex.: 1.500,00).');
    if (!f.venc.value) throw new Error('Informe o 1º vencimento.');
    const base = { grupo_id: f.grupo_id.value || null, responsavel: f.responsavel.value || '', devedor: f.devedor.value.trim(), credor: f.credor.value.trim(), processo: f.processo.value.trim(),
      forma_pagamento: f.forma_pagamento.value, pix: f.pix.value.trim(), total_parcelas: String(n), valor: v };
    await q(sb.from('acordos').insert(Array.from({ length: n }, (_, k) => Object.assign({}, base, { parcela: String(k + 1), vencimento: venc(k) }))));
    aviso('✓ Acordo lançado: ' + plural(n, 'parcela', 'parcelas') + '.'); fecharJanela(j);
    if (depois) await depois(); else if (window.ERP_RECARREGAR) window.ERP_RECARREGAR();
  });
  return j;
}

// ═══ Backup 85 (PA5/AC4/RO3): a janela "Emitir" do ambiente — todas as guias da MESMA empresa a emitir, em passos
// 1. Anexar a guia (PDF) por linha → o sistema lê valor e vencimento e mostra se mudou · 2. Conferir · 3. Salvar no rascunho do Gmail
// ou Enviar (conforme Administração → E-mails). "Só marcar como emitida" não manda e-mail (tem Desfazer).
// itens: [{ id, desc, valor, venc, numero }] (todas da mesma tabela: 'parcelas' | 'acordos'); ctx: { nome, doc, cli, grupo, depois, extra }
async function janelaEmitirGuias(tabela, itens, ctx) {
  ctx = ctx || {};
  if (!itens || !itens.length) return aviso('Nada para emitir.', true);
  const acordo = tabela === 'acordos', modo = ((await modoEnvioGuias().catch(() => ({}))) || {})[acordo ? 'acordo' : 'parcelamento'] || 'rascunho';
  const lidos = {}, arquivos = {};
  const hoje = hojeISO(), h = new Date().getHours(), oi = h < 12 ? 'Bom dia!' : h < 18 ? 'Boa tarde!' : 'Boa noite!';
  const texto = oi + '\n\n' + (acordo ? 'Segue a parcela do acordo para pagamento.' : 'Seguem as guias dos parcelamentos com vencimento neste mês ou em atraso. Antes de pagar, confirme se a guia já não foi paga, para evitar duplicidade.') + '\n\n' +
    itens.map((x) => '• ' + x.desc + ' — ' + brl(x.valor) + ' — vence ' + dataBR(x.venc) + (x.pix ? '\n  PIX: ' + x.pix : '')).join('\n') + '\n\nQualquer dúvida, é só responder este e-mail.\n\nEquipe Araújo & Castro';
  const j = abrirJanela({ larga: true, kick: acordo ? 'Emitir boleto/PIX do acordo' : 'Emitir guias do parcelamento', titulo: ctx.nome || 'Cliente', sub: esc(ctx.doc || '') + (ctx.doc ? ' · ' : '') + '<span id="eg-sub-email">procurando o e-mail…</span>',
    corpo: '<div class="b-passos3"><span class="b-on">1. Anexar a guia (PDF)</span><span>2. Conferir</span><span>3. ' + (modo === 'rascunho' ? 'Salvar no rascunho do Gmail' : 'Enviar') + '</span></div>' +
      '<div class="b-rola b-eg-rola"><table class="b-tab b-tab-eg"><thead><tr><th>Parcela</th><th class="b-dir">Valor</th><th class="b-cen">Vencimento</th><th>Guia (PDF)</th><th>Conferência</th></tr></thead><tbody>' +
      itens.map((x) => '<tr data-eg="' + esc(x.id) + '"><td>' + esc(x.desc) + (x.venc < hoje ? '<span class="b-sub b-pz-r">vencida · <button type="button" class="b-link" data-eg-reenv="' + esc(x.id) + '" title="A janela do ERP para reenviar a guia vencida com novo vencimento e valor atualizado">reenviar atualizada</button></span>' : '') + '</td><td class="b-dir b-val">' + brl(x.valor) + '</td><td class="b-cen b-data">' + dataBR(x.venc) + '</td>' +
        '<td><label class="btn btn-o btn-mini b-eg-anexar">' + iconeB('documento') + 'Anexar<input type="file" accept="application/pdf" hidden data-eg-pdf="' + esc(x.id) + '"></label></td>' +
        '<td class="b-eg-conf" data-eg-conf="' + esc(x.id) + '"><span class="traco">aguardando o PDF</span></td></tr>').join('') + '</tbody></table></div>' +
      '<div class="grade" style="margin-top:12px">' + campo('Para', '<input id="eg-para" type="email" placeholder="e-mail do cliente">', 'inteiro') +
        campo('Texto do e-mail', '<textarea id="eg-texto" rows="8">' + esc(texto) + '</textarea>', 'inteiro') + '</div>' +
      '<div class="dica">Como está configurado: <b>' + (modo === 'rascunho' ? 'o e-mail vai para o RASCUNHO do Gmail' : 'o e-mail é ENVIADO direto') + '</b> com as guias anexadas. Troque em Administração → E-mails.</div>' + (ctx.extra || ''),
    rodape: '<button type="button" class="btn btn-o" data-cancelar>Cancelar</button><div class="acoes"><button type="button" class="btn btn-o" id="eg-so">Só marcar como emitida</button>' +
      '<button type="button" class="btn btn-p" id="eg-ok">' + iconeB(modo === 'rascunho' ? 'documento' : 'enviar') + (modo === 'rascunho' ? 'Salvar no rascunho' : 'Enviar agora') + '</button></div>' });
  j.classList.add('janela-emitir');
  const $j = (s) => j.querySelector(s);
  $j('[data-cancelar]').onclick = () => fecharJanela(j);
  preencherDestino($j('#eg-para'), ctx.cli, ctx.grupo, tabela).then(() => { const e = $j('#eg-para') && $j('#eg-para').value; const s = $j('#eg-sub-email'); if (s) s.innerHTML = e ? 'e-mail: ' + esc(e) : '<b class="b-vermelho">sem e-mail cadastrado</b>'; }).catch(() => {});
  const conferir = (x, pdf, nome) => {
    lidos[x.id] = pdf;
    const dif = pdf && pdf.valor != null && Math.abs(pdf.valor - (Number(x.valor) || 0)) > 0.01, vdif = pdf && pdf.venc && pdf.venc !== x.venc;
    $j('[data-eg-conf="' + x.id + '"]').innerHTML = '<span class="' + (dif || vdif ? 'b-pz-a' : 'b-ok-txt') + '">' + (pdf && pdf.valor != null ? brl(pdf.valor) : 'valor não lido') + ' · ' + (pdf && pdf.venc ? dataBR(pdf.venc) : 'vencimento não lido') + '</span>' +
      (dif ? '<small class="b-pz-sub">valor diferente da parcela (juros/atualização?) — o novo valor fica gravado</small>' : '') + (vdif ? '<small class="b-pz-sub">vencimento do PDF diferente da parcela</small>' : '') + '<small class="b-pz-sub">' + esc(nome) + '</small>';
    const pas = j.querySelectorAll('.b-passos3 span'); if (pas[1]) pas[1].classList.add('b-on');
  };
  j.addEventListener('click', (ev) => { const r = ev.target.closest('[data-eg-reenv]'); if (!r) return; fecharJanela(j); emitirParcela(tabela, r.dataset.egReenv); });   // PA6 (do ERP)
  j.addEventListener('change', async (ev) => {
    const inp = ev.target.closest('[data-eg-pdf]'); if (!inp || !inp.files[0]) return;
    const f = inp.files[0], x = itens.find((y) => String(y.id) === inp.dataset.egPdf); if (!x) return;
    arquivos[x.id] = f;
    $j('[data-eg-conf="' + x.id + '"]').innerHTML = '<span class="traco">lendo o PDF…</span>';
    const pdf = await lerPdfGuia(f).catch(() => null);
    conferir(x, pdf || { valor: null, venc: null }, f.name);
  });
  const marcar = async () => {
    for (const x of itens) {
      await q(sb.rpc('registrar_emissao', { p_tabela: tabela, p_id: x.id, p_emitida: true, p_doc: null, p_enviar: false }));
      const v = lidos[x.id] && lidos[x.id].valor; if (!acordo && v > 0) await q(sb.rpc('lancar_valor_parcela', { p_id: x.id, p_valor: v })).catch(() => null);
    }
    if (window.ERP_EDITOR && window.ERP_EDITOR.marcarSujo && !acordo) itens.forEach((x) => { if (x.parcelamento_id) window.ERP_EDITOR.marcarSujo('parcelas', x.parcelamento_id); });
  };
  const desmarcar = async () => { for (const x of itens) await q(sb.rpc('registrar_emissao', { p_tabela: tabela, p_id: x.id, p_emitida: false, p_doc: null, p_enviar: false })); };
  const fim = async () => { fecharJanela(j); if (ctx.depois) await Promise.resolve(ctx.depois()).catch(() => {}); if (window.ERP_RECARREGAR) window.ERP_RECARREGAR(); };
  $j('#eg-so').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    await marcar(); feitoDesfazer(plural(itens.length, 'guia marcada', 'guias marcadas') + ' como emitida' + (itens.length > 1 ? 's' : '') + '.', desmarcar, ctx.depois); await fim(); });
  $j('#eg-ok').onclick = (ev) => comBotao(ev.currentTarget, async () => {
    const para = $j('#eg-para').value.trim(), falta = itens.filter((x) => !arquivos[x.id]);
    if (!para && modo !== 'rascunho') throw new Error('Este cliente não tem e-mail cadastrado. Digite no campo "Para" ou use "Salvar no rascunho".');
    if (falta.length && !(await confirmarB({ titulo: 'Faltam ' + plural(falta.length, 'guia', 'guias') + ' sem PDF', sub: 'O e-mail sai só com as que têm PDF.', ok: 'Continuar mesmo assim',
      resumo: falta.map((x) => '<span>' + esc(x.desc) + '</span>').join('') }))) return;
    const fs = Object.values(arquivos);
    if (fs.reduce((s2, f) => s2 + f.size, 0) > LIMITE_ANEXOS) throw new Error('Os PDFs somam mais de 15 MB: envie em dois e-mails.');
    const arqs = await Promise.all(fs.map(lerArquivoB64));
    const r = await q(sb.rpc(modo === 'rascunho' ? 'salvar_guias_rascunho' : 'enviar_guias_email', { p_cliente: ctx.cli || null, p_grupo: ctx.grupo || null,
      p_itens: itens.map((x) => ({ tabela, id: x.id, descricao: x.desc, vencimento: (lidos[x.id] && lidos[x.id].venc) || x.venc, valor: (lidos[x.id] && lidos[x.id].valor) || x.valor || null })),
      p_assunto: (acordo ? 'Acordo — ' : 'Guias de Parcelamento — ') + (ctx.nome || ''), p_texto: $j('#eg-texto').value.trim(), p_docs: [], p_para: para || null, p_arquivos: arqs }));
    await marcar();
    fecharJanela(j); aviso(modo === 'rascunho' ? 'Guardando o rascunho no seu Gmail…' : 'Enviando o e-mail…');
    Promise.all([avisoEnvio(plural(itens.length, 'guia', 'guias') + (arqs.length ? ' e ' + plural(arqs.length, 'anexo', 'anexos') : '') + ': ', r).catch((er) => aviso(erroAmigavel(er), true)),
      ctx.depois ? Promise.resolve(ctx.depois()).catch(() => {}) : null]).then(() => { if (window.ERP_RECARREGAR) window.ERP_RECARREGAR(); });
  });
  return j;
}
// acha o cliente (cadastro) de uma empresa pelo CNPJ ou pelo nome — para o e-mail e o rascunho
function clienteDaEmpresa(nome, doc) {
  const so = (s) => String(s || '').replace(/\D/g, ''), d = so(doc), n = normalizar(nome || '');
  return (E.clientes || []).find((c) => d && so(c.cpf_cnpj) === d) || (E.clientes || []).find((c) => n && normalizar(c.nome) === n) || null;
}
