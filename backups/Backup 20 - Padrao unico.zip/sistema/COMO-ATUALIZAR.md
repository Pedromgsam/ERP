# Como atualizar o sistema (passo a passo)

Toda mudança chega como uma **pull request** no GitHub. Siga sempre esta ordem.

## 1. Publicar as telas
1. No GitHub, abra a pull request → botão verde **Merge pull request** → **Confirm merge**.
2. Espere uns 2 minutos (a Vercel publica sozinha).

Faça o Merge **antes** do SQL: só depois do Merge o arquivo do banco fica completo na página principal do GitHub.

## 2. Banco de dados (só quando a pull request pedir)
1. Abra o **Supabase** → seu projeto → **SQL Editor** (ícone `>_` no menu da esquerda) → **New query**.
2. No GitHub, na página principal do repositório, abra o arquivo indicado (ex.: `sistema/banco/estrutura.sql`)
   e clique no botão **Raw** (acima do código, à direita). Abre uma página só com o texto.
3. Nessa página: **Ctrl+A** (seleciona tudo) e **Ctrl+C** (copia).
   Não selecione com o mouse: o GitHub não mostra o arquivo inteiro na tela e o final fica de fora.
4. Volte ao Supabase, clique na área de texto, **Ctrl+A** (apaga o que houver) e **Ctrl+V**.
5. **Confira o fim**: role até o final do editor. O número da última linha tem que ser igual ao que a
   pull request informa. Se for menor, faltou texto: repita o passo 2.
6. Clique em **Run**. Se aparecer um aviso sobre "destructive operations", clique em **Run this query**.
7. O certo é aparecer **"Success. No rows returned"** embaixo.

Os arquivos podem ser rodados quantas vezes quiser: não apagam nada.
Se aparecer **ERROR** em vermelho: tire um print e mande antes de continuar.
Enquanto o SQL não for rodado, o ERP mostra um aviso amarelo dizendo o que falta — o resto funciona.

## 2b. Funções do Supabase — e-mails, publicações, cartão CNPJ, agenda, backup e PGFN
Os avisos por e-mail, a busca de publicações, o cartão CNPJ, a agenda do Google, o backup semanal e a consulta da PGFN
rodam em seis "funções" dentro do Supabase.

**Atenção ao nome:** tem que ser exatamente `erp-emails`, `erp-publicacoes`, `erp-cnpj`, `erp-agenda`, `erp-backup` e `erp-pgfn`,
tudo em minúsculas e com hífen.
Se o nome for outro (ex.: "ERP-email"), o ERP não encontra a função. Para conferir, vá em Administração → ✉ E-mail →
**🩺 Verificar funções**. A tela mostra ✅ ou ❌ para cada uma e diz o que corrigir.
Isso é feito **uma vez**; depois só muda se uma pull request pedir.

**Ligar o agendador (para rodar sozinho de manhã):**
1. Supabase → **Database** → **Extensions**.
2. Procure **pg_cron** e ligue (Enable). Procure **pg_net** e ligue.
3. Rode de novo o `sistema/banco/estrutura.sql` (passo 2). Ele cria os horários automáticos.

**Publicar as cinco funções** (para atualizar uma função que já existe: abra a função → **Code** → cole o texto novo → **Deploy**):
1. Supabase → **Edge Functions** → **Deploy a new function** → **Via Editor**.
2. Nome: **erp-emails**. Apague o exemplo que aparece.
3. No GitHub, abra `supabase/functions/erp-emails/index.ts` → **Raw** → **Ctrl+A**, **Ctrl+C**.
4. Volte ao Supabase, **Ctrl+V** no editor e clique em **Deploy function**.
5. Na página da função, abra **Details** (ou **Settings**) e **desligue "Verify JWT"** (Enforce JWT verification) → salve.
   A função confere sozinha quem chamou.
6. Repita os passos 1 a 5 com o nome **erp-publicacoes** e o arquivo `supabase/functions/erp-publicacoes/index.ts`.
7. Repita os passos 1 a 5 com o nome **erp-cnpj** e o arquivo `supabase/functions/erp-cnpj/index.ts`.
8. Repita os passos 1 a 5 com o nome **erp-agenda** e o arquivo `supabase/functions/erp-agenda/index.ts`.
9. Repita os passos 1 a 5 com o nome **erp-backup** e o arquivo `supabase/functions/erp-backup/index.ts`.
10. Repita os passos 1 a 5 com o nome **erp-pgfn** e o arquivo `supabase/functions/erp-pgfn/index.ts`
    (Backup 14). Ela **não gasta nada** enquanto a chave do SERPRO não for salva (veja a seção PGFN abaixo).

**Configurar dentro do ERP:**
- **E-mail:** Administração → **✉ E-mail** → escolha "Gmail do escritório", informe o e-mail e a **senha de app**
  (a própria tela mostra onde gerar) → **Salvar** → **Enviar e-mail de teste**.
- **Publicações:** Jurídico → **Publicações** → **OABs monitoradas** → inclua cada OAB (número e UF) e o nome do
  advogado → **Buscar agora**.
- **Cartão CNPJ:** **Alertas** → cartão **Cartão CNPJ (6h)** → escolha a API (a BrasilAPI é grátis e sem chave) →
  **Salvar API** → **↻ Atualizar agora**. Depois disso, ela roda sozinha todo dia às 6h. O resultado fica no mesmo
  cartão, com as alterações, os erros e o histórico.
- **Salário mínimo:** Contratos → **Salário mínimo** → quando sair o valor do ano novo, cadastre. As mensalidades em aberto
  se ajustam sozinhas.
- **Google Agenda (cada pessoa, uma vez):** Tarefas → **📅 Google Agenda** → **Copiar link** → no Google Agenda,
  em **Outras agendas** → **+** → **Do URL** → cole → **Adicionar agenda**. Aparecem os prazos fatais e as audiências.
- **Backup semanal:** Administração → **Backup** → **↻ Fazer backup agora** (confere que funciona). Depois ele roda
  sozinho todo domingo às 3h e guarda as 8 últimas cópias.
- **Automações:** Tarefas → **⚡ Automações** (ou Administração → ⚡ Automações). Cada automação tem uma chave de
  liga/desliga que salva na hora. Os **e-mails ao cliente** começam desligados: ligue os que quiser (usam o Gmail
  configurado em Administração → E-mail e vão para o contato financeiro do cliente).
- **Modo escuro:** botão **◐** na barra de cima (fica lembrado em cada computador).
- **Funções de cada pessoa:** Administração → Usuários → botão **Funções** ao lado de cada pessoa da equipe.
  Ali também se escolhe **"Clientes que vê"** (Só Jurídico / Só Contabilidade / Os dois) e o nível **Rascunho**
  (a pessoa preenche, mas só vale depois de aprovado — modelo pronto "Estagiário (rascunho)").
- **Área de cada cliente:** no cadastro do cliente, campo **Área do cliente** (Jurídico / Contabilidade / os dois).
  Na primeira vez que o SQL do Backup 12 roda, o sistema sugere a área sozinho; confira em Clientes → filtro de áreas.
- **Aprovações (rascunhos):** faixa no Início ou menu **⋯ → 📝 Aprovações**. Mostra *antes → depois*; **✓ Aprovar** ou **Recusar**.
- **Recebimentos:** todo botão de baixa pergunta a **data** (já vem com hoje). Nos acordos, pergunta também se o
  **comprovante foi anexado ao processo** e, se sim, o **ID** do documento.
- **Seu nome na barra:** ⋯ → **👤 Meu nome** (o login continua pelo e-mail). O administrador também muda em Administração → Usuários.
- **Avisos (🔔):** funcionam como caixa de mensagens. **✓ Lido** tira da lista. Se o assunto não for resolvido, ele volta na próxima leva:
  urgentes no dia seguinte, os demais na semana seguinte. Ao abrir o sistema, um cartão no canto mostra os avisos novos.
- **Cobranças, avisos e recibos** (antiga "Notificações"): botão **✉** no alto de Financeiro, Parcelamentos e Acordos, ou ⋯ → Cobranças.
  **✉ Enviar e-mail** pergunta se vai **pelo e-mail do escritório** (com a marca) ou pelo seu programa de e-mail.
- **E-mails automáticos ao cliente:** agora vêm **ligados** e só saem para quem tem e-mail cadastrado. Cobranças vão ao contato
  **financeiro** (quem recebe boletos primeiro); acordos, ao contato **jurídico**. Preencha a chave PIX e a assinatura em
  Administração → E-mail → **Dados para pagamento** e confira os modelos no botão **Ver modelo**.
- **Demonstração:** Administração → Importar → **🧪 Carregar demonstração** cria clientes e lançamentos fictícios ("DEMO ·"),
  ligados entre si, inclusive um rascunho de estagiário para aprovar. **Apagar demonstração** remove tudo, sem tocar no que é seu.
- **Êxito:** no contrato, informe o % e *como foi combinado*. Quando o êxito acontecer, abra o contrato →
  **🏆 Registrar êxito** → informe o valor X (ex.: quanto a dívida reduziu). O sistema lança % × X em Honorários Jurídico.

## 2c. Ler de novo uma planilha (substituir o que foi importado)
Use quando uma planilha foi lida errado (ex.: Contabilidade ou Acordos).
1. Antes, faça um backup: Administração → **Backup** → Excel.
2. Administração → **Importar** → escolha o arquivo (ex.: `12 - Contabilidade.xlsx` ou `4 - Acordos.xlsx`).
3. Marque **Substituir** → confirme. O sistema apaga **só o que veio de importação** daquele tipo (o que você lançou
   à mão fica) e lê a planilha de novo.
4. O nome do arquivo ajuda o sistema a saber o tipo: mantenha "Acordos" ou "Contabilidade" no nome.

## 3. Conferir
1. Abra o ERP e aperte **Ctrl+Shift+R** (recarrega sem cache).
2. Entre com seu e-mail e senha.
3. Se aparecer um aviso amarelo embaixo, ele diz o que falta. Se algo estiver estranho, mande um print.

## Não gostei: como voltar para a versão anterior

Há três "voltas", conforme o que você quer desfazer.

### A. Voltar as TELAS (o mais comum) — pela Vercel, 1 minuto
Cada publicação fica guardada na Vercel. Para voltar:
1. Entre em **vercel.com** → projeto **erp** → aba **Deployments**.
2. Ache a publicação anterior (a lista mostra data e hora; a atual está no topo com a etiqueta **Current**).
3. Clique nos **três pontinhos (⋯)** dessa publicação anterior → **Instant Rollback** (ou **Promote**) → confirme.
4. Em segundos o site volta a ser o anterior. Os **dados não mudam**: tudo o que foi lançado continua no banco.

Enquanto estiver "voltado", novas pull requests que você juntar **não** vão ao ar sozinhas.
Quando quiser seguir em frente, faça o mesmo na publicação mais nova (⋯ → Promote) ou me peça.

### B. Voltar de vez (desfazer a mudança no GitHub)
1. No GitHub, abra a pull request já juntada (aba **Pull requests** → **Closed**).
2. Clique em **Revert** (no fim da página). O GitHub cria uma nova pull request que desfaz a anterior.
3. Clique em **Merge pull request** nela. Em 2 minutos a Vercel publica a versão anterior.

### C. Voltar os DADOS (se algo foi gravado errado)
- Um registro só: abra o registro (✎) → **🕘 Ver alterações** mostra quem mudou o quê e o valor anterior;
  corrija à mão.
- Muitos registros: use o arquivo de **Backup** (Administração → Backup). Faça backup **antes** de
  importações grandes. Para restaurar a partir de um backup, me chame: eu preparo a restauração com você.

### O Gestão antigo saiu do site (Backup 13)
O `gestao.html` foi apagado do site, com sua autorização. Todas as telas dele já estão dentro do ERP.
Se precisar dele de volta, basta voltar a publicação na Vercel (passo A acima) ou pedir.


## Backup 14 — o que mudou e onde clicar
- **Usuários novos:** Administração → **👤 Usuários** → cartão **Acessos combinados** → **Criar conta** em cada pessoa
  (Emanuelle, Adriana, João Vitor, Éder). Escolha uma senha provisória e passe para a pessoa. A função já vem certa
  (Éder = Adm. da Contabilidade, só clientes da contabilidade; João Vitor = estagiário em rascunho, Jurídico e Contabilidade).
- **E-mails por cliente:** Administração → **📨 E-mails aos clientes**. Cada cliente tem um perfil:
  *Padrão* · *Só no vencimento* · *Não enviar financeiro* · *Personalizado*. Muda na própria linha, ou marque vários e use
  "Aplicar aos marcados". Também aparece no cadastro do cliente ("E-mails de cobrança").
- **Conciliar extrato (OFX):** Financeiro → Jurídico (ou Contabilidade) → botão **🏦 Conciliar extrato** no topo → escolha o
  arquivo .ofx exportado do Sicoob → confira os três grupos (identificados, em dúvida, não identificados) → **Registrar pagamentos marcados**.
- **Evolução do cliente:** ficha do cliente → aba **📈 Evolução** (passivo, CAPAG e processos: "devia X, hoje deve Y").
  A primeira foto é tirada ao rodar o SQL; o comparativo aparece a partir do mês seguinte.
- **Editar em tabela:** Clientes → **✎ Editar em tabela** (passivo, CEAT e CAPAG de vários clientes; aceita colar do Excel).
  Estagiário: cada linha vira uma proposta em Aprovações.
- *(Processos em tela nova: desfeito no Backup 15 — voltou a tela do Backup 13.)*

## Backup 15 — o que mudou e onde clicar
- **Início:** a fila mostra 5 tarefas (▾ Ver todas para abrir o resto). Botões **Lista · Mês · Semana · Dia** trocam
  para calendário; a escolha fica guardada e abre igual no próximo acesso. Honorário atrasado saiu da fila.
  **Mural** (logo abaixo): destaques do dia (avisos, prazos fatais, tarefas atrasadas, publicações novas) e recados —
  escreva e clique **Publicar**. Só o administrador marca 📌 fixo. O botão dos atrasados voltou a ser **✓ Recebido**.
- **Pop-up dos honorários** (clicar nos cartões do Início): mais largo, sem Descrição, pílulas do mesmo tamanho,
  sem "Recebido" no "Recebido no mês" e sem "emitir guia" no "A receber".
- **Painel Executivo:** sem a faixa de título; "Atualizado" e **▣ entidades ◉ grupos** ficam na linha do filtro, à esquerda.
  Cartões de grupo do mesmo tamanho e com as letras padronizadas.
- **Processos, Parcelamentos e Acordos:** voltaram à versão do Backup 13.
- **Financeiro → Jurídico:** novo campo **Área do serviço** (Tributário, Imobiliário, Empresarial, Sucessões, Família,
  Criminal, Trabalhista, Contratual, Cobrança, Consultoria) no lançamento e no contrato; o gráfico "por tipo de serviço"
  usa esse campo. A mensalidade de consultoria continua sendo gerada igual. Clicar numa linha abre a **visualização**
  (✎ Editar e ✓ Recebido ficam lá dentro).
- **Contrato:** botão **+ Novo cliente** ao lado do campo Cliente (cadastra sem sair do contrato).
- **Clientes:** "Jur + Cont" virou **Jurídico + Contábil**.
- **CRM:** abas **Em andamento · Ganhos (contrato assinado) · Perdidos (não fechou)** — o funil mostra só as vigentes.
  Cartões maiores e do mesmo tamanho. Clicar abre o **Resumo** (só leitura); para mudar, **Editar**.
  *Ganhou* = o cliente fechou (vira contrato). *Perdeu* = não fechou (registre o motivo).
- **Documentos:** filtro por **grupo** e atalhos por tipo (Procuração, Contrato… com a quantidade).
- **Tarefas:** abas **Em aberto · ✓ Concluídas · 🗑 Excluídas**. "Excluir" manda para Excluídas (dá para **↩ Restaurar**);
  só o administrador usa **Excluir de vez**.
- **Alertas:** dentro do relatório de um alerta, **📋 Virar tarefa** → escolha quem faz (você ou o estagiário), o prazo e se
  cada linha vira subtarefa (com prazo) ou item do checklist. O cartão PGFN fica escondido até o SERPRO ser contratado.
- **Prompts prontos** para as próximas rodadas (e-mails de honorários/parcelamentos/acordos/recibos, CRM, Tarefas):
  `sistema/PROMPTS-BACKUP-15.md`.

## Backup 16 — o que mudou e onde clicar
- **Início (a "home" do escritório):** logo abaixo do mural, o **🏠 Resumo do escritório** (processos, publicações, parcelamentos, acordos,
  CRM, tarefas e documentos — clique no número para abrir). A fila mostra só tarefas; **"Emitir guias de parcelamentos"** virou
  **🔔 Lembrete** (card Lembretes, abaixo da fila): abra a linha e marque **✓ Guia emitida** em cada parcela. Em **+ Lembrete** você cria
  avisos que não são tarefa (ex.: "renovar certificado digital", todo ano).
- **Painel Executivo → Empresas do grupo:** grupo, empresa e sócio em CAIXA ALTA, uma letra só, selo do grupo mais estreito,
  CAPAG em selo quadrado e Situação em pílula do mesmo tamanho.
- **Processos → Análise da carteira:** "Processos" mostra *X em andamento · Y arquivados/extintos*; o card "Arquivados / extintos" saiu;
  o mesmo processo do sócio e da PJ conta uma vez só; "Valor em disputa" mostra *com valor · sem valor informado*.
- **Publicações:** **⚙ Monitoramento (OABs e clientes)** → além das OABs, escolha **clientes** (o Diário busca pelo nome da empresa).
  **🩺 Testar conexão com o CNJ** explica o problema se houver. **🌐 Buscar pelo navegador** busca do seu computador (use se o servidor não conseguir).
- **Acordos:** mostra só os acordos com parcela pendente (caixa **Mostrar concluídos** no topo traz todos). A tabela **Acordos em andamento**
  (devedor, credor, descrição, total, pago, falta, parcela e inadimplência) abre ao clicar, com **✓ Lançar pagamento** em cada parcela.
  Saiu o gráfico "Valor em atraso por devedor". O "Progresso por acordo" continua até você aprovar a tabela nova.
- **Financeiro:** a 2ª linha de cada honorário mostra *Área do serviço — contrato* (sem contrato, só a área). Saíram os gráficos das abas
  A receber / Recebidos / Prejuízo / Despesas (a análise fica na aba Análise) e o "Despesas por categoria" do caixa da Contabilidade.
  **✎ Editar em tabela** (botão no topo do Financeiro): completa vários lançamentos na tela ou por planilha (⬇ Baixar → ajustar no Excel → ⬆ Enviar).
- **CRM:** funil em duas linhas; etapas novas **Contrato fechado** (o cliente disse sim: cria cadastro, contrato e a tarefa "Enviar contrato
  para assinatura") → **Aguardando assinatura** → **Contrato assinado** (vai para a aba). **Lead perdido** pede o motivo numa lista.
  **⚡ Cadastro rápido**, atalhos no cartão (💬 WhatsApp, ✉ e-mail, 📞 registrar ligação), **✉ Follow-up** na ficha, **⚙ Etapas** (prazo de cada
  etapa: passou do prazo, vira tarefa), painel do mês (novas, conversão, valor por área, quem mais indica), modelos de proposta novos e
  proposta com visual da marca (**👁 Ver como fica** em Modelos de proposta). Na ficha do cliente: **🤝 Indicação** cria prospecto indicado por ele.
- **Central de e-mails ao cliente:** **⋯ → ✉ Central de e-mails ao cliente** (ou ✉ Cobrar/Notificar em cada tela). Abas *A enviar hoje*
  (clique na linha = prévia; **Enviar agora**, **Pular este**, **Enviar selecionados**), *Enviados* e *Com erro* (**Tentar de novo**).
  **⚙ Automático e horário**: liga/desliga honorários, parcelamentos, acordos e recibos, horário do envio e os dias do 1º/2º/3º aviso.
  **✎ Modelos**: texto de cada e-mail (também em Administração → E-mails aos clientes). O **recibo** sai sozinho ao marcar **Recebido**, com o PDF anexo.
  A tela antiga continua em **⋯ → Tela antiga de cobranças** até você aprovar a nova. Na ficha do cliente, aba **✉ E-mails** mostra o histórico.
- **Tarefas:** barra de **criação rápida** no topo ("Protocolar defesa amanhã @Emanuelle !alta #trabalhista" + Enter); vista **Minha semana**
  (arraste para remarcar); prazo fatal com **contagem de dias úteis**; **⏭ Pular esta vez** nas recorrentes; **Relatório** com mês,
  por cliente e **Carga da semana** (horas estimadas × disponíveis; o admin ajusta as horas); modelos de fluxo novos (Abertura de empresa,
  Inventário, Defesa trabalhista); resumo do dia por e-mail às **8h** (cada um liga/desliga em ⋯ → Meus avisos por e-mail);
  excluídas há mais de 90 dias somem da aba (ficam no histórico).
- **Geradores de documentos:** **⋯ → 📄 Geradores de documentos** (ou **📄 Gerar** na ficha do cliente / **📄 Gerar documento** em Documentos):
  Contrato e Procuração, **Petição** (nova), Solicitação de Documentos, Proposta e Modelos de E-mail. Cada um abre numa aba, exige login,
  **Preencher com o cliente** puxa nome, CPF/CNPJ, endereço e sócios, e **📁 Guardar em Documentos** salva na pasta do cliente.
  As contas bancárias/PIX dos advogados saíram do arquivo público: rode **uma vez** o `sistema/banco/dados-recibos.sql` (mesmo jeito do estrutura.sql).
- **PGFN grátis (dados abertos):** **Alertas → Rotinas → PGFN — dados abertos (grátis)** → siga os 3 passos da janela (baixar o arquivo
  público da PGFN, descompactar, escolher os .csv). Atualiza PGFN e PGFN negociada de cada cliente e a aba PGFN da ficha. A PGFN publica
  esses dados a cada trimestre.

## PGFN — dívida ativa pela API do SERPRO (paga)
1. Contrate na Loja SERPRO a API **Consulta Dívida Ativa** (cobrança por consulta; confira a tabela antes).
2. Na área do cliente SERPRO copie a **Consumer Key** e a **Consumer Secret**.
3. Peça ao Claude para reexibir o cartão PGFN em Alertas (escondido desde o Backup 15 a seu pedido). Depois: **Alertas** → cartão **PGFN — dívida ativa** → cole as duas chaves → escolha a frequência
   (todo dia, toda segunda ou todo dia 1º) → marque **Rotina ligada** → **Salvar** → **↻ Consultar agora**.
4. O resultado atualiza os campos PGFN (em cobrança) e PGFN negociada (parcelada) e aparece na ficha do cliente → aba **PGFN**.

## Backup 17 — o que mudou e onde clicar
- **Início:** o Resumo mostra só o que pede ação (sem Processos): Publicações novas, Parcelamentos e Acordos (em atraso, com
  "vencem hoje" e "nos próximos 5 dias" embaixo, no mesmo cartão), CRM, Tarefas do escritório (em aberto + atrasadas, hoje e
  próximos 5 dias no mesmo cartão) e Documentos que vencem em 15 dias. O Início também busca publicações pelo navegador 1× por dia.
- **Painel Executivo → Empresas do grupo:** mesmo visual da tabela de Processos (letra normal, selo cinza do grupo), empresa e sócio em
  negrito, Situação sem a bolinha.
- **Processos:** legendas em duas linhas (em andamento / arquivados-extintos; com valor / sem valor informado).
- **Acordos → Acordos em andamento:** lista nova (quem deve a quem, barra do que já foi pago, próxima parcela e situação); clique no
  acordo para ver as parcelas em cartões com **✓ Lançar pagamento**.
- **Financeiro → ✎ Editar em tabela:** a janela ocupa a largura toda da tela.
- **CRM:** 8 quadros do mesmo tamanho (4 + 4) com a etapa nova **Follow-up da proposta**; Contrato assinado e Lead perdido saíram do
  "Em andamento" (solte o cartão na faixa verde/cinza embaixo). Quadro vazio desenhado.
- **E-mails:** a Central mostra a coluna **E-mail de destino** (endereço + de qual contato veio). A janela **✉ Enviar e-mail ao cliente**
  e o editor de **✎ Modelos** mostram ao lado **como o cliente recebe** (o mesmo layout com a marca).
- **Publicações:** partes em linhas (**Autor:** / **Réu:**). O "Testar conexão" explica quando a função não responde; a função nova
  (erp-publicacoes) não trava mais quando o CNJ não responde. **Publicar a função erp-publicacoes de novo.**
- **PGFN:** Alertas → Rotinas → PGFN — dados abertos aceita também o CSV exportado do site **Dívida Aberta** (mais atual).
- **Contratos:** a ficha (clique no contrato) mostra tipo, área, vigência, **reajuste** (só consultoria em salários mínimos é reajustada),
  próximo vencimento e atraso, e o card **📝 Aditivos** (**+ Novo aditivo**: valor — consultoria muda a mensalidade a partir de uma
  competência; pontual lança o valor a mais em parcelas —, escopo, prazo ou outro).

## Backup 18 — Design (só visual; sem SQL e sem funções novas)
Depois do Merge, aperte **Ctrl+Shift+R** no ERP para baixar o visual novo.
- **Cores mais sóbrias** em todas as telas: fundo cinza neutro, cartões brancos com borda fina e sombra quase invisível,
  selos (pílulas) menores e em tons suaves. Nenhum botão ou texto mudou de nome.
- **Cartões:** um desenho só (Início, Painel, Processos, Financeiro, Acordos, CRM…): título pequeno em caixa alta cinza com um
  **pontinho de cor** (verde, âmbar, vermelho…), número grande embaixo. A faixa grossa colorida à esquerda saiu; ela só aparece,
  fina, onde quer dizer algo (atraso, crítico, recado fixado).
- **Tabelas:** cabeçalho claro (saiu o azul-marinho pesado), linhas separadas por um fio leve, números alinhados à direita.
- **Barra superior:** lisa, sem brilho; os botões ◐, 🔔, ⋯ e Sair sem contorno. Menus com cantos e sombra iguais aos cartões.
- **Títulos das telas** sem caixa em volta, maiores; janelas com cabeçalho branco e botões no rodapé, à direita.
- **Gráficos:** cores vindas da paleta do sistema (rampa azul nas barras; rosca com cores contidas), grade bem leve, sem animação
  ao redesenhar.
- **Modo escuro (◐):** agora **preto de verdade**, com cinzas neutros (sem azulado) e cartões em cinza bem escuro.

Para quem mexe no código: as cores continuam **só** em `sistema/app/tokens.css` (paleta, `--chart-*` dos gráficos, escala de
espaçamento `--sp-*` e de letras `--fs-*`, raios `--card-r`/`--r-ctl`/`--r-pill`). O desenho único fica em `sistema/app/design.css`
(última camada, só `var(--…)`).

## Backup 19 — mais enxuto (tem SQL novo)
Ordem: **1) Merge  2) SQL no Supabase (`sistema/banco/estrutura.sql`)  3) Ctrl+Shift+R**. Nenhuma função do Supabase mudou.
- **E-mails PAUSADOS:** depois do SQL, **nenhum e-mail sai do sistema** até você liberar. Os e-mails novos ficam em
  **Central de e-mails → Retidos (pausa)** (dá para enviar um a um ou descartar). Para ligar de novo: Central de e-mails →
  botão **▶ Liberar o envio** (só administrador). O e-mail de teste da Configuração sai sempre.
- **Central de e-mails = tudo de e-mail num lugar:** abas **Enviar e acompanhar**, **Quem recebe (por cliente)**, **Configuração do envio**,
  **Meus avisos por e-mail** e **Cobranças (tela antiga)**. Em Administração ficou só o atalho "✉ E-mails → Central".
- **Início:** o **Mural** mostra só o que é **seu** (ex.: "8 tarefas suas atrasadas") e junta os **Lembretes** e as **guias de
  parcelamento a emitir** (clique no destaque para abrir a lista; **+ Lembrete** fica no Mural). O **Resumo do escritório** mostra a
  equipe toda e ocupa a linha inteira. Os **avisos** (sino) não repetem mais o que já está no Início (tarefas atrasadas, honorários e
  acordos em atraso, documentos vencendo): ficam só as novidades (prazo chegando, vence hoje, menções, certidões). Textos sem "(s)".
- **Painel Executivo → Empresas do grupo:** ordenada por grupo, grupo em texto simples, nomes em CAIXA ALTA sem negrito,
  CAPAG A/B/C/D e "Omisso", situação "Ativa/Baixada".
- **Jurídico:** abas **Processos · Parcelamentos · Publicações** no topo das três telas.
- **Parcelamentos:** tabela **por grupo** (clique no grupo para ver por órgão), concluídos ocultos (**Mostrar concluídos** junto da
  tabela), "Risco de rescisão" com a **Natureza**, clique no parcelamento em "Progresso" para ver as parcelas e dar **✓ Baixa**,
  colunas **Atraso** (vencidos) e **Dias** (a vencer) no lugar de "Status".
- **Acordos:** "Mostrar concluídos" junto da tabela; sai a coluna "Situação/Vencido" dos vencidos.
- **Financeiro:** "Recebido mês a mês" com as cores de antes; "Comparativo por pessoa" com Total; "Em atraso" com vencimento e atraso em dias.
- **Clientes:** nomes em CAIXA ALTA, sem negrito. **Alertas:** mais limpo (o que está em dia fica recolhido).
- **Tabelas:** cabeçalho azul-marinho de novo; sem a bolinha antes do título dos cartões.
- **Usuários:** a conta nova já nasce liberada (não precisa clicar no link de confirmação). Para quem já foi criado: Administração →
  Usuários → **✓ Liberar entrada**.

## Backup 20 — tudo no mesmo padrão (tem SQL novo)
Ordem: **1) Merge  2) SQL no Supabase (`sistema/banco/estrutura.sql`)  3) Ctrl+Shift+R**. Nenhuma função do Supabase mudou.
- **Início:** saíram "+ Receita / + Despesa / + Contrato" (use **+ Lançar**). O **Recado** acabou: virou **📌 Lembretes**, sempre à vista
  no topo. Lembrete pode ser **sem prazo** (fica até "Feito"), **📌 fixo no topo** e ter **cor de destaque**. Os recados que estavam no
  mural foram copiados para os lembretes pelo SQL. Honorários **Jurídico** e **Contabilidade** com o mês no título, na ordem
  recebido (verde) · a receber · a pagar · em atraso (vermelho). "Atrasados" com um alerta vermelho discreto e baixa em lote.
- **ⓘ ao lado de Avisos, Tarefas, Minha fila e Lembretes:** pare o mouse em cima para ver a diferença entre eles.
- **Tabelas de pagamento (Início, Financeiro):** Quem · Grupo · Descrição · Valor · Vencimento · Atraso (em vermelho) · ações.
  **Baixa em lote:** marque as caixinhas → "✓ Dar baixa nos marcados". **PIX copia e cola:** botão **PIX** na linha (valor já
  preenchido); o e-mail de cobrança também leva o código. Para funcionar, preencha a **chave PIX, o titular e a cidade** em
  Central de e-mails → Configuração do envio → Dados para pagamento.
- **Painel → Empresas do grupo e Processos:** iguais a Clientes — agrupados por grupo (com a contagem), **▸** abre o detalhe,
  filtros no mesmo desenho (fundo azul no escolhido). Negociado aparece como "18k neg.". Os filtros antigos saíram.
- **Processos, Acordos, Parcelamentos e Financeiro:** sem o cartão de título. Os alertas (vencidos) e os botões (Cobrar/Notificar,
  Recibo, Conciliar, Editar em tabela) foram para a direita das abas ou do quadro "Situação".
- **Acordos:** já pago em verde, em atraso em vermelho; coluna do acordo mais larga; o acordo aberto vira um cartão; o gráfico
  gigante "Saldo por devedor" virou uma lista com barrinhas e total.
- **Financeiro:** sem "Ano passado", sem o campo mm/aaaa e sem CSV nos filtros; Recebidos e Prejuízo sem os cartões repetidos;
  "Em atraso" com ▲ vermelho e no padrão novo.
- **Clientes/Contratos:** tabelas com cantos arredondados; pílulas no desenho do Painel; "Sim" neutro (nem verde nem vermelho).
- **Saiu:** a tela antiga de Cobranças (o 🧾 Recibo continua funcionando).
