-- ═══════════════════════════════════════════════════════════════════
-- ERP Araújo & Castro — estrutura do banco de dados (Supabase / PostgreSQL)
-- ═══════════════════════════════════════════════════════════════════
--
-- Como usar: no painel do Supabase, abra "SQL Editor", cole este arquivo
-- inteiro e clique em "Run". Pode rodar de novo sem perder dados: tudo
-- aqui é "crie se não existir" ou "substitua a regra".
--
-- Quem pode o quê (fase 1 — uso interno do escritório):
--   admin   → tudo, inclusive liberar usuários e excluir clientes/contratos
--   equipe  → cadastra, edita e dá baixa; não exclui cliente nem contrato
--   inativo → não vê nada (é o estado de todo usuário novo, até o admin liberar)
-- O primeiro usuário criado no projeto vira admin automaticamente.
--
-- A regra de acesso fica NO BANCO (Row Level Security), não na tela: mesmo
-- quem tiver a chave pública do projeto não lê nada sem login liberado.
-- ═══════════════════════════════════════════════════════════════════

-- ─────────────────────────── USUÁRIOS ───────────────────────────────
create table if not exists public.perfis (
  id        uuid primary key references auth.users(id) on delete cascade,
  nome      text not null default '',
  email     text not null default '',
  papel     text not null default 'inativo' check (papel in ('admin','equipe','inativo')),
  criado_em timestamptz not null default now()
);

-- Papel de quem está logado. security definer: lê perfis sem passar pela
-- própria regra de perfis (senão a regra chamaria a si mesma).
create or replace function public.papel_atual() returns text
language sql stable security definer set search_path = public as $$
  select coalesce((select papel from public.perfis where id = auth.uid()), 'inativo');
$$;
create or replace function public.eh_equipe() returns boolean
language sql stable as $$ select public.papel_atual() in ('admin','equipe'); $$;
create or replace function public.eh_admin() returns boolean
language sql stable as $$ select public.papel_atual() = 'admin'; $$;

-- Todo usuário criado em Authentication ganha um perfil. O primeiro vira
-- admin; os demais entram inativos até o admin liberar na tela Usuários.
create or replace function public.criar_perfil() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.perfis (id, email, nome, papel)
  values (new.id, coalesce(new.email,''),
          coalesce(new.raw_user_meta_data->>'nome', split_part(coalesce(new.email,''),'@',1)),
          case when exists (select 1 from public.perfis) then 'inativo' else 'admin' end)
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists ao_criar_usuario on auth.users;
create trigger ao_criar_usuario after insert on auth.users
  for each row execute function public.criar_perfil();

-- Ninguém tira o último admin (evita o escritório ficar trancado para fora).
create or replace function public.proteger_ultimo_admin() returns trigger
language plpgsql as $$
begin
  if old.papel = 'admin' and new.papel <> 'admin'
     and (select count(*) from public.perfis where papel = 'admin') <= 1 then
    raise exception 'É preciso manter pelo menos um administrador.';
  end if;
  return new;
end $$;
drop trigger if exists proteger_admin on public.perfis;
create trigger proteger_admin before update on public.perfis
  for each row execute function public.proteger_ultimo_admin();

-- ─────────────────────────── CADASTROS ──────────────────────────────
-- Grupo = carteira do cliente (ex.: um grupo econômico com várias empresas).
create table if not exists public.grupos (
  id        uuid primary key default gen_random_uuid(),
  nome      text not null check (btrim(nome) <> ''),
  criado_em timestamptz not null default now()
);
create unique index if not exists grupos_nome_unico on public.grupos (lower(btrim(nome)));

create table if not exists public.clientes (
  id            uuid primary key default gen_random_uuid(),
  grupo_id      uuid references public.grupos(id) on delete set null,
  nome          text not null check (btrim(nome) <> ''),
  cpf_cnpj      text not null default '',
  tipo          text not null default 'Consultoria' check (tipo in ('Consultoria','Demanda','Inativo')),
  responsavel   text not null default '',
  email         text not null default '',
  telefone      text not null default '',
  endereco      text not null default '',
  cidade        text not null default '',
  estado        text not null default '',
  obs           text not null default '',
  criado_por    uuid default auth.uid(),
  criado_em     timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists clientes_grupo on public.clientes (grupo_id);

create table if not exists public.contratos (
  id                  uuid primary key default gen_random_uuid(),
  cliente_id          uuid not null references public.clientes(id) on delete restrict,
  descricao           text not null check (btrim(descricao) <> ''),
  data_contrato       date not null default current_date,
  valor_total         numeric(14,2) not null default 0 check (valor_total >= 0),
  num_parcelas        int not null default 1 check (num_parcelas between 1 and 120),
  primeiro_vencimento date,
  percentual_exito    numeric(5,2) check (percentual_exito between 0 and 100),
  status              text not null default 'Ativo' check (status in ('Ativo','Encerrado','Cancelado')),
  obs                 text not null default '',
  criado_por          uuid default auth.uid(),
  criado_em           timestamptz not null default now(),
  atualizado_em       timestamptz not null default now()
);
create index if not exists contratos_cliente on public.contratos (cliente_id);

-- ─────────────────────────── FINANCEIRO ─────────────────────────────
create table if not exists public.lancamentos (
  id              uuid primary key default gen_random_uuid(),
  tipo            text not null check (tipo in ('receita','despesa')),
  descricao       text not null check (btrim(descricao) <> ''),
  categoria       text not null default '',
  cliente_id      uuid references public.clientes(id) on delete set null,
  contrato_id     uuid references public.contratos(id) on delete cascade,
  parcela         int,
  total_parcelas  int,
  vencimento      date not null,
  valor           numeric(14,2) not null check (valor > 0),
  pago            boolean not null default false,
  data_pagamento  date,
  forma_pagamento text not null default '',
  obs             text not null default '',
  criado_por      uuid default auth.uid(),
  criado_em       timestamptz not null default now(),
  atualizado_em   timestamptz not null default now()
);
create index if not exists lanc_venc     on public.lancamentos (vencimento);
create index if not exists lanc_cliente  on public.lancamentos (cliente_id);
create index if not exists lanc_contrato on public.lancamentos (contrato_id);

-- Pago sem data → hoje. Desmarcou pago → apaga a data. Sempre coerente.
create or replace function public.ajustar_pagamento() returns trigger
language plpgsql as $$
begin
  if new.pago and new.data_pagamento is null then new.data_pagamento := current_date; end if;
  if not new.pago then new.data_pagamento := null; end if;
  return new;
end $$;
drop trigger if exists ajustar_pagamento on public.lancamentos;
create trigger ajustar_pagamento before insert or update on public.lancamentos
  for each row execute function public.ajustar_pagamento();

-- Contrato novo com valor e 1º vencimento → cria as parcelas a receber.
-- Centavos que sobram da divisão vão para a última parcela.
create or replace function public.gerar_parcelas_contrato() returns trigger
language plpgsql as $$
declare
  i int; base numeric(14,2); v numeric(14,2);
begin
  if new.valor_total > 0 and new.primeiro_vencimento is not null then
    base := trunc(new.valor_total / new.num_parcelas, 2);
    for i in 1..new.num_parcelas loop
      v := case when i = new.num_parcelas
                then new.valor_total - base * (new.num_parcelas - 1) else base end;
      insert into public.lancamentos
        (tipo, descricao, categoria, cliente_id, contrato_id, parcela, total_parcelas, vencimento, valor)
      values
        ('receita', new.descricao || case when new.num_parcelas > 1
                                          then ' — parcela ' || i || '/' || new.num_parcelas else '' end,
         'Honorários', new.cliente_id, new.id, i, new.num_parcelas,
         (new.primeiro_vencimento + make_interval(months => i - 1))::date, v);
    end loop;
  end if;
  return new;
end $$;
drop trigger if exists gerar_parcelas on public.contratos;
create trigger gerar_parcelas after insert on public.contratos
  for each row execute function public.gerar_parcelas_contrato();

-- ─────────────────────── DATA DE ALTERAÇÃO ──────────────────────────
create or replace function public.marcar_atualizacao() returns trigger
language plpgsql as $$ begin new.atualizado_em := now(); return new; end $$;
drop trigger if exists atualizado_clientes on public.clientes;
create trigger atualizado_clientes before update on public.clientes
  for each row execute function public.marcar_atualizacao();
drop trigger if exists atualizado_contratos on public.contratos;
create trigger atualizado_contratos before update on public.contratos
  for each row execute function public.marcar_atualizacao();
drop trigger if exists atualizado_lancamentos on public.lancamentos;
create trigger atualizado_lancamentos before update on public.lancamentos
  for each row execute function public.marcar_atualizacao();

-- ─────────────────────────── HISTÓRICO ──────────────────────────────
-- Toda inclusão, alteração e exclusão fica registrada: quem, quando e o
-- quê. Só o admin consulta; ninguém edita.
create table if not exists public.historico (
  id          bigserial primary key,
  tabela      text not null,
  registro_id uuid,
  acao        text not null,
  usuario     uuid,
  quando      timestamptz not null default now(),
  antes       jsonb,
  depois      jsonb
);
create or replace function public.registrar_historico() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  -- alteração que não muda nada (ex.: reimportar a mesma planilha) não polui o histórico
  if tg_op = 'UPDATE' and (to_jsonb(old) - 'atualizado_em') = (to_jsonb(new) - 'atualizado_em') then
    return null;
  end if;
  insert into public.historico (tabela, registro_id, acao, usuario, antes, depois)
  values (tg_table_name,
          coalesce((case when tg_op = 'DELETE' then old.id else new.id end), null),
          tg_op, auth.uid(),
          case when tg_op <> 'INSERT' then to_jsonb(old) end,
          case when tg_op <> 'DELETE' then to_jsonb(new) end);
  return null;
end $$;
drop trigger if exists hist_clientes on public.clientes;
create trigger hist_clientes after insert or update or delete on public.clientes
  for each row execute function public.registrar_historico();
drop trigger if exists hist_contratos on public.contratos;
create trigger hist_contratos after insert or update or delete on public.contratos
  for each row execute function public.registrar_historico();
drop trigger if exists hist_lancamentos on public.lancamentos;
create trigger hist_lancamentos after insert or update or delete on public.lancamentos
  for each row execute function public.registrar_historico();
drop trigger if exists hist_perfis on public.perfis;
create trigger hist_perfis after update or delete on public.perfis
  for each row execute function public.registrar_historico();

-- ──────────────────────── REGRAS DE ACESSO ──────────────────────────
alter table public.perfis      enable row level security;
alter table public.grupos      enable row level security;
alter table public.clientes    enable row level security;
alter table public.contratos   enable row level security;
alter table public.lancamentos enable row level security;
alter table public.historico   enable row level security;

-- Sem login: nada.
revoke all on public.perfis, public.grupos, public.clientes, public.contratos,
              public.lancamentos, public.historico from anon;
grant select, insert, update, delete on public.grupos, public.clientes,
              public.contratos, public.lancamentos to authenticated;
grant select, update on public.perfis to authenticated;
grant select on public.historico to authenticated;
revoke insert, delete on public.perfis from authenticated;
revoke insert, update, delete on public.historico from authenticated;

-- perfis: cada um vê o próprio; admin vê e altera todos.
drop policy if exists perfis_ver on public.perfis;
create policy perfis_ver on public.perfis for select to authenticated
  using (id = auth.uid() or public.eh_admin());
drop policy if exists perfis_alterar on public.perfis;
create policy perfis_alterar on public.perfis for update to authenticated
  using (public.eh_admin()) with check (public.eh_admin());

-- grupos, clientes, contratos, lançamentos: equipe lê e grava.
do $$
declare t text;
begin
  foreach t in array array['grupos','clientes','contratos','lancamentos'] loop
    execute format('drop policy if exists %1$s_ver on public.%1$s', t);
    execute format('create policy %1$s_ver on public.%1$s for select to authenticated using (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_incluir on public.%1$s', t);
    execute format('create policy %1$s_incluir on public.%1$s for insert to authenticated with check (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_alterar on public.%1$s', t);
    execute format('create policy %1$s_alterar on public.%1$s for update to authenticated using (public.eh_equipe()) with check (public.eh_equipe())', t);
  end loop;
end $$;

-- Excluir: lançamento e grupo → equipe; cliente e contrato → só admin.
drop policy if exists lancamentos_excluir on public.lancamentos;
create policy lancamentos_excluir on public.lancamentos for delete to authenticated using (public.eh_equipe());
drop policy if exists grupos_excluir on public.grupos;
create policy grupos_excluir on public.grupos for delete to authenticated using (public.eh_equipe());
drop policy if exists clientes_excluir on public.clientes;
create policy clientes_excluir on public.clientes for delete to authenticated using (public.eh_admin());
drop policy if exists contratos_excluir on public.contratos;
create policy contratos_excluir on public.contratos for delete to authenticated using (public.eh_admin());

-- histórico: só admin lê.
drop policy if exists historico_ver on public.historico;
create policy historico_ver on public.historico for select to authenticated using (public.eh_admin());

-- ═══════════════════════════════════════════════════════════════════
-- v2 (2026-09-26) — campos do ERP antigo: cadastro completo dos clientes,
-- financeiro do escritório e da contabilidade, e chave de importação
-- (reimportar a mesma planilha atualiza em vez de duplicar).
-- ═══════════════════════════════════════════════════════════════════
alter table public.clientes add column if not exists socio_admin        text not null default '';
alter table public.clientes add column if not exists rfb                numeric(16,2);
alter table public.clientes add column if not exists rfb_negociada      numeric(16,2);
alter table public.clientes add column if not exists pgfn               numeric(16,2);
alter table public.clientes add column if not exists pgfn_negociada     numeric(16,2);
alter table public.clientes add column if not exists sefaz_mg           numeric(16,2);
alter table public.clientes add column if not exists age_mg             numeric(16,2);
alter table public.clientes add column if not exists age_mg_negociada   numeric(16,2);
alter table public.clientes add column if not exists ceat_trt3          int;
alter table public.clientes add column if not exists em_operacao        boolean;
alter table public.clientes add column if not exists procuracao         boolean;
alter table public.clientes add column if not exists certificado        boolean;
alter table public.clientes add column if not exists cadastro_regular   boolean;
alter table public.clientes add column if not exists capag              text not null default '';
alter table public.clientes add column if not exists regime_tributario  text not null default '';
alter table public.clientes add column if not exists situacao_cadastral text not null default '';
alter table public.clientes add column if not exists tipo_societario    text not null default '';
alter table public.clientes add column if not exists historico_cadastral text not null default '';
alter table public.clientes add column if not exists origem             text not null default '';
alter table public.clientes add column if not exists data_migracao      date;
alter table public.clientes add column if not exists chave_importacao   text;
create unique index if not exists clientes_chave_importacao on public.clientes (chave_importacao);

-- empresa: 'escritorio' (Honorários Jurídico) ou 'contabilidade'
alter table public.lancamentos add column if not exists empresa      text not null default 'escritorio';
alter table public.lancamentos drop constraint if exists lancamentos_empresa_check;
alter table public.lancamentos add constraint lancamentos_empresa_check check (empresa in ('escritorio','contabilidade'));
alter table public.lancamentos add column if not exists grupo_id     uuid references public.grupos(id) on delete set null;
alter table public.lancamentos add column if not exists favorecido   text not null default '';  -- fornecedor, em despesas
alter table public.lancamentos add column if not exists responsavel  text not null default '';  -- advogado/pessoa
alter table public.lancamentos add column if not exists referencia   text not null default '';  -- ex.: 0,7 salário
alter table public.lancamentos add column if not exists cobranca     text not null default '';  -- ex.: Cobrado, Emitir guia
alter table public.lancamentos add column if not exists conta        text not null default '';  -- banco
alter table public.lancamentos add column if not exists chave_pix    text not null default '';
alter table public.lancamentos add column if not exists perda        boolean not null default false; -- prejuízo
alter table public.lancamentos add column if not exists chave_importacao text;
create unique index if not exists lancamentos_chave_importacao on public.lancamentos (chave_importacao);
create index if not exists lanc_empresa on public.lancamentos (empresa, vencimento);
create index if not exists lanc_pagamento on public.lancamentos (data_pagamento);
create index if not exists lanc_grupo on public.lancamentos (grupo_id);

-- ═══════════════════════════════════════════════════════════════════
-- v3 (2026-09-27) — demais módulos do ERP: processos, parcelamentos
-- (com as parcelas), acordos e tarefas; e o acesso de CLIENTE (portal).
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.processos (
  id                   uuid primary key default gen_random_uuid(),
  grupo_id             uuid references public.grupos(id) on delete set null,
  carteira             text not null default 'Ativo' check (carteira in ('Ativo','Prospecção')),
  advogado             text not null default '',
  numero               text not null check (btrim(numero) <> ''),
  competencia          text not null default '',
  natureza             text not null default '',
  autor                text not null default '',
  reu                  text not null default '',
  data_distribuicao    date,
  valor                numeric(16,2),
  atualizacao          date,
  procuracao           boolean,
  outro_advogado       boolean,
  status               text not null default '',
  data_arq_provisorio  date,
  prescricao           text not null default '',
  obs                  text not null default '',
  chave_importacao     text unique,
  criado_por           uuid default auth.uid(),
  criado_em            timestamptz not null default now(),
  atualizado_em        timestamptz not null default now()
);
create index if not exists processos_grupo on public.processos (grupo_id);

create table if not exists public.parcelamentos (
  id                   uuid primary key default gen_random_uuid(),
  grupo_id             uuid references public.grupos(id) on delete set null,
  aba                  text not null default '',          -- nome da aba na planilha (ex.: grupo)
  empresa              text not null check (btrim(empresa) <> ''),
  cnpj                 text not null default '',
  local                text not null default '',          -- eCAC, Regularize, Siare…
  natureza             text not null default '',          -- Simples Nacional, INSS, ICMS…
  numero               text not null default '',
  total_parcelas       int,
  valor_ultima_parcela numeric(16,2),
  valor_residual       numeric(16,2),
  obs                  text not null default '',
  chave_importacao     text unique,
  criado_por           uuid default auth.uid(),
  criado_em            timestamptz not null default now(),
  atualizado_em        timestamptz not null default now()
);
create index if not exists parcelamentos_grupo on public.parcelamentos (grupo_id);

create table if not exists public.parcelas (
  id               uuid primary key default gen_random_uuid(),
  parcelamento_id  uuid not null references public.parcelamentos(id) on delete cascade,
  numero           text not null default '',
  vencimento       date,
  emissao          text not null default '',             -- ex.: SIM / guia emitida
  pago             boolean not null default false,
  chave_importacao text unique,
  criado_em        timestamptz not null default now(),
  atualizado_em    timestamptz not null default now()
);
create index if not exists parcelas_parc on public.parcelas (parcelamento_id, vencimento);

create table if not exists public.acordos (
  id               uuid primary key default gen_random_uuid(),
  grupo_id         uuid references public.grupos(id) on delete set null,
  aba              text not null default '',
  responsavel      text not null default '',
  processo         text not null check (btrim(processo) <> ''),
  devedor          text not null default '',
  credor           text not null default '',
  parcela          text not null default '',
  total_parcelas   text not null default '',
  valor            numeric(16,2),
  vencimento       date,
  situacao         text not null default '',
  emissao          text not null default '',
  pago             boolean not null default false,
  data_pagamento   date,
  pix              text not null default '',
  banco            text not null default '',
  obs              text not null default '',
  chave_importacao text unique,
  criado_por       uuid default auth.uid(),
  criado_em        timestamptz not null default now(),
  atualizado_em    timestamptz not null default now()
);
create index if not exists acordos_grupo on public.acordos (grupo_id, vencimento);

create table if not exists public.tarefas (
  id                    uuid primary key default gen_random_uuid(),
  grupo_id              uuid references public.grupos(id) on delete set null,
  titulo                text not null check (btrim(titulo) <> ''),
  processos_vinculados  text not null default '',
  prioridade            text not null default 'media',
  responsavel           text not null default '',
  status                text not null default 'pendente',
  inicio                date,
  prazo                 date,
  obs                   text not null default '',
  chave_importacao      text unique,
  criado_por            uuid default auth.uid(),
  criado_em             timestamptz not null default now(),
  atualizado_em         timestamptz not null default now()
);

-- datas de alteração e histórico dos módulos novos
do $$
declare t text;
begin
  foreach t in array array['processos','parcelamentos','parcelas','acordos','tarefas'] loop
    execute format('drop trigger if exists atualizado_%1$s on public.%1$s', t);
    execute format('create trigger atualizado_%1$s before update on public.%1$s for each row execute function public.marcar_atualizacao()', t);
    execute format('drop trigger if exists hist_%1$s on public.%1$s', t);
    execute format('create trigger hist_%1$s after insert or update or delete on public.%1$s for each row execute function public.registrar_historico()', t);
  end loop;
end $$;

-- ─────────────────────── acesso de CLIENTE (portal) ─────────────────
-- Cliente vê só os grupos liberados para ele, e só pelo portal_dados()
-- (que tira observações internas e dados bancários). Nada de financeiro.
alter table public.perfis drop constraint if exists perfis_papel_check;
alter table public.perfis add constraint perfis_papel_check check (papel in ('admin','equipe','cliente','inativo'));
create table if not exists public.perfil_grupos (
  perfil_id uuid not null references public.perfis(id) on delete cascade,
  grupo_id  uuid not null references public.grupos(id) on delete cascade,
  primary key (perfil_id, grupo_id)
);

-- regras de acesso dos módulos novos: equipe lê e grava; admin exclui
alter table public.processos     enable row level security;
alter table public.parcelamentos enable row level security;
alter table public.parcelas      enable row level security;
alter table public.acordos       enable row level security;
alter table public.tarefas       enable row level security;
alter table public.perfil_grupos enable row level security;
revoke all on public.processos, public.parcelamentos, public.parcelas, public.acordos,
              public.tarefas, public.perfil_grupos from anon;
grant select, insert, update, delete on public.processos, public.parcelamentos, public.parcelas,
              public.acordos, public.tarefas, public.perfil_grupos to authenticated;
do $$
declare t text;
begin
  foreach t in array array['processos','parcelamentos','parcelas','acordos','tarefas'] loop
    execute format('drop policy if exists %1$s_ver on public.%1$s', t);
    execute format('create policy %1$s_ver on public.%1$s for select to authenticated using (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_incluir on public.%1$s', t);
    execute format('create policy %1$s_incluir on public.%1$s for insert to authenticated with check (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_alterar on public.%1$s', t);
    execute format('create policy %1$s_alterar on public.%1$s for update to authenticated using (public.eh_equipe()) with check (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_excluir on public.%1$s', t);
    execute format('create policy %1$s_excluir on public.%1$s for delete to authenticated using (%2$s)', t,
                   case when t in ('parcelas','tarefas') then 'public.eh_equipe()' else 'public.eh_admin()' end);
  end loop;
end $$;
drop policy if exists perfil_grupos_ver on public.perfil_grupos;
create policy perfil_grupos_ver on public.perfil_grupos for select to authenticated
  using (perfil_id = auth.uid() or public.eh_admin());
drop policy if exists perfil_grupos_admin on public.perfil_grupos;
create policy perfil_grupos_admin on public.perfil_grupos for all to authenticated
  using (public.eh_admin()) with check (public.eh_admin());
-- grupos: o cliente enxerga o nome dos grupos dele
drop policy if exists grupos_ver_cliente on public.grupos;
create policy grupos_ver_cliente on public.grupos for select to authenticated
  using (id in (select grupo_id from public.perfil_grupos where perfil_id = auth.uid()));

-- Dados do portal: só para papel 'cliente', só dos grupos dele, sem campos internos.
create or replace function public.portal_dados() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare meus uuid[];
begin
  if public.papel_atual() <> 'cliente' then
    raise exception 'Acesso restrito ao portal do cliente.';
  end if;
  select coalesce(array_agg(grupo_id), '{}') into meus from public.perfil_grupos where perfil_id = auth.uid();
  return jsonb_build_object(
    'grupos', (select coalesce(jsonb_agg(nome order by nome), '[]') from public.grupos where id = any(meus)),
    'clientes', (select coalesce(jsonb_agg(to_jsonb(c) - 'obs' - 'historico_cadastral' - 'criado_por' - 'chave_importacao'
                  || jsonb_build_object('grupo_nome', g.nome)), '[]')
                 from public.clientes c join public.grupos g on g.id = c.grupo_id where c.grupo_id = any(meus)),
    'processos', (select coalesce(jsonb_agg(to_jsonb(p) - 'obs' - 'criado_por' - 'chave_importacao'
                  || jsonb_build_object('grupo_nome', g.nome)), '[]')
                  from public.processos p join public.grupos g on g.id = p.grupo_id where p.grupo_id = any(meus)),
    'parcelamentos', (select coalesce(jsonb_agg(to_jsonb(pa) - 'obs' - 'criado_por' - 'chave_importacao'
                  || jsonb_build_object('grupo_nome', g.nome, 'parcelas',
                       (select coalesce(jsonb_agg(to_jsonb(x) - 'chave_importacao' order by x.vencimento), '[]')
                        from public.parcelas x where x.parcelamento_id = pa.id))), '[]')
                  from public.parcelamentos pa join public.grupos g on g.id = pa.grupo_id where pa.grupo_id = any(meus)),
    'acordos', (select coalesce(jsonb_agg(to_jsonb(a) - 'obs' - 'pix' - 'banco' - 'criado_por' - 'chave_importacao'
                  || jsonb_build_object('grupo_nome', g.nome)), '[]')
                from public.acordos a join public.grupos g on g.id = a.grupo_id where a.grupo_id = any(meus))
  );
end $$;
revoke all on function public.portal_dados() from anon;
grant execute on function public.portal_dados() to authenticated;

-- ─────────────────────────── v3: configurações ───────────────────────────
-- Dados que o ERP usa mas que não podem ficar no HTML público (ex.: CPF e
-- endereço dos advogados nos recibos). Só a equipe lê; só o admin altera.
create table if not exists public.configuracoes (
  chave         text primary key,
  valor         jsonb not null,
  atualizado_em timestamptz not null default now()
);
alter table public.configuracoes enable row level security;
revoke all on public.configuracoes from anon;
grant select, insert, update, delete on public.configuracoes to authenticated;
drop policy if exists configuracoes_ver on public.configuracoes;
create policy configuracoes_ver on public.configuracoes for select to authenticated using (public.eh_equipe());
drop policy if exists configuracoes_admin on public.configuracoes;
create policy configuracoes_admin on public.configuracoes for all to authenticated
  using (public.eh_admin()) with check (public.eh_admin());

-- ─────────────────────────── v4: contratos no ERP ───────────────────────────
-- Parcelas geradas pelo contrato já nascem com o grupo do cliente e o
-- responsável, para aparecerem certinhas em Honorários Jurídico.
alter table public.contratos add column if not exists responsavel text not null default '';
create or replace function public.gerar_parcelas_contrato() returns trigger
language plpgsql as $$
declare
  i int; base numeric(14,2); v numeric(14,2); g uuid;
begin
  if new.valor_total > 0 and new.primeiro_vencimento is not null then
    select grupo_id into g from public.clientes where id = new.cliente_id;
    base := trunc(new.valor_total / new.num_parcelas, 2);
    for i in 1..new.num_parcelas loop
      v := case when i = new.num_parcelas
                then new.valor_total - base * (new.num_parcelas - 1) else base end;
      insert into public.lancamentos
        (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia,
         parcela, total_parcelas, vencimento, valor)
      values
        ('escritorio', 'receita', new.descricao || case when new.num_parcelas > 1
                                          then ' — parcela ' || i || '/' || new.num_parcelas else '' end,
         'Honorários', new.cliente_id, new.id, g, new.responsavel,
         case when new.num_parcelas > 1 then i || '/' || new.num_parcelas else '' end,
         i, new.num_parcelas, (new.primeiro_vencimento + make_interval(months => i - 1))::date, v);
    end loop;
  end if;
  return new;
end $$;

-- ─────────────────── v5: comissão é redutor de receita ───────────────────
-- Comissão/desconto não é despesa: é um ajuste que diminui a receita
-- (em vez de receber 5.000, o escritório recebe 3.500). Fica como receita
-- com "redutor" marcado e entra nas somas com sinal negativo.
alter table public.lancamentos add column if not exists redutor boolean not null default false;
-- deduções que vieram das abas de receita (valor negativo na planilha) viraram "despesa com grupo e sem fornecedor"
update public.lancamentos set tipo = 'receita', redutor = true
 where tipo = 'despesa' and redutor = false and grupo_id is not null and favorecido = '';

-- ═══════════════════════════════════════════════════════════════════
-- v6 (2026-09-27) — Fase 1: ficha 360° do cliente · Fase 2: documentos ·
-- Fase 3: tarefas completas (fluxos, subtarefas, prazos, modelos, feriados).
-- ═══════════════════════════════════════════════════════════════════

-- ── Fase 1: ficha 360° ──
create table if not exists public.contatos (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  nome text not null default '', cargo text not null default '',
  finalidade text not null default 'geral',      -- geral, financeiro, marketing, juridico, socio, contador, cobranca
  email text not null default '', telefone text not null default '', whatsapp boolean not null default false,
  recebe_boletos boolean not null default false, recebe_notificacoes boolean not null default false,
  preferencia text not null default '', obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists contatos_cliente on public.contatos (cliente_id);
create table if not exists public.enderecos (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  tipo text not null default 'sede',              -- sede, correspondencia, cobranca, filial, residencial
  logradouro text not null default '', numero text not null default '', complemento text not null default '',
  bairro text not null default '', cidade text not null default '', uf text not null default '', cep text not null default '',
  principal boolean not null default false, obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists enderecos_cliente on public.enderecos (cliente_id);
create table if not exists public.contas_bancarias (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  banco text not null default '', agencia text not null default '', conta text not null default '', tipo_conta text not null default '',
  pix text not null default '', titular text not null default '', documento_titular text not null default '',
  uso text not null default '',                   -- recebimento, pagamento, restituicao
  principal boolean not null default false, obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists contas_bancarias_cliente on public.contas_bancarias (cliente_id);
create table if not exists public.vinculos_societarios (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  nome text not null default '', cpf_cnpj text not null default '', qualificacao text not null default '',
  participacao numeric(7,4), email text not null default '', telefone text not null default '', obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists vinculos_cliente on public.vinculos_societarios (cliente_id);
create table if not exists public.etiquetas (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (btrim(nome) <> ''), cor text not null default '#2E5EAA',
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create unique index if not exists etiquetas_nome on public.etiquetas (lower(btrim(nome)));
create table if not exists public.cliente_etiquetas (
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  etiqueta_id uuid not null references public.etiquetas(id) on delete cascade,
  primary key (cliente_id, etiqueta_id)
);
-- linha do tempo: ligações, e-mails, reuniões, WhatsApp, anotações (também usada pelo CRM)
create table if not exists public.interacoes (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid references public.clientes(id) on delete cascade,
  tipo text not null default 'anotacao',          -- ligacao, email, reuniao, whatsapp, anotacao
  quando timestamptz not null default now(), resumo text not null check (btrim(resumo) <> ''),
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists interacoes_cliente on public.interacoes (cliente_id, quando desc);
create table if not exists public.certidoes (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  orgao text not null default '',                 -- RFB/PGFN, Estadual MG, Municipal, Trabalhista, FGTS
  situacao text not null default '',              -- negativa, positiva com efeito de negativa, positiva
  emissao date, validade date, obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists certidoes_cliente on public.certidoes (cliente_id, validade);

-- ── Fase 2: documentos (arquivo no Storage privado "documentos") ──
create table if not exists public.documentos (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid references public.clientes(id) on delete set null,
  grupo_id uuid references public.grupos(id) on delete set null,
  contrato_id uuid references public.contratos(id) on delete set null,
  lancamento_id uuid references public.lancamentos(id) on delete set null,
  processo_id uuid references public.processos(id) on delete set null,
  tarefa_id uuid references public.tarefas(id) on delete set null,
  tipo text not null default 'outro',             -- contrato, procuracao, pessoal, certidao, guia, comprovante, peticao, proposta, outro
  nome text not null check (btrim(nome) <> ''),
  caminho text not null,                          -- caminho do arquivo no bucket
  tamanho bigint, mime text not null default '',
  versao int not null default 1, documento_pai_id uuid references public.documentos(id) on delete set null,
  validade date, etiquetas text not null default '', obs text not null default '',
  liberado_cliente boolean not null default false, arquivado boolean not null default false,
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists documentos_cliente on public.documentos (cliente_id);
create index if not exists documentos_contrato on public.documentos (contrato_id);
create index if not exists documentos_lancamento on public.documentos (lancamento_id);

-- ── Fase 3: tarefas completas ──
create table if not exists public.modelos_fluxo (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (btrim(nome) <> ''), descricao text not null default '',
  itens jsonb not null default '[]',              -- [{titulo, dias (antes do fatal, úteis), responsavel, checklist:[...], subtarefas:[...]}]
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create table if not exists public.fluxos (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (btrim(nome) <> ''),
  cliente_id uuid references public.clientes(id) on delete set null,
  grupo_id uuid references public.grupos(id) on delete set null,
  modelo_id uuid references public.modelos_fluxo(id) on delete set null,
  responsavel text not null default '', status text not null default 'ativo',   -- ativo, concluido, cancelado
  inicio date, prazo_fatal date, obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
alter table public.tarefas add column if not exists tarefa_pai_id uuid references public.tarefas(id) on delete cascade;
alter table public.tarefas add column if not exists fluxo_id uuid references public.fluxos(id) on delete cascade;
alter table public.tarefas add column if not exists cliente_id uuid references public.clientes(id) on delete set null;
alter table public.tarefas add column if not exists contrato_id uuid references public.contratos(id) on delete set null;
alter table public.tarefas add column if not exists descricao text not null default '';
alter table public.tarefas add column if not exists participantes text not null default '';
alter table public.tarefas add column if not exists etiquetas text not null default '';
alter table public.tarefas add column if not exists prazo_fatal date;
alter table public.tarefas add column if not exists estimativa_horas numeric(6,1);
alter table public.tarefas add column if not exists checklist jsonb not null default '[]';
alter table public.tarefas add column if not exists depende_de uuid references public.tarefas(id) on delete set null;
alter table public.tarefas add column if not exists recorrencia text not null default '';   -- '', semanal, mensal, anual
alter table public.tarefas add column if not exists ordem int not null default 0;
alter table public.tarefas add column if not exists concluida_em timestamptz;
alter table public.tarefas add column if not exists concluida_por uuid;
create index if not exists tarefas_pai on public.tarefas (tarefa_pai_id);
create index if not exists tarefas_fluxo on public.tarefas (fluxo_id);
create index if not exists tarefas_prazo on public.tarefas (prazo);
create table if not exists public.comentarios (
  id uuid primary key default gen_random_uuid(),
  tarefa_id uuid not null references public.tarefas(id) on delete cascade,
  texto text not null check (btrim(texto) <> ''),
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists comentarios_tarefa on public.comentarios (tarefa_id, criado_em);
create table if not exists public.feriados (
  data date not null, nome text not null default '', abrangencia text not null default 'nacional',   -- nacional, estadual, municipal, tribunal
  local text not null default '', primary key (data, abrangencia, local)
);
-- notificações dentro do sistema (sino): tarefa atribuída, menção etc.
create table if not exists public.notificacoes (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.perfis(id) on delete cascade,
  tipo text not null default '', titulo text not null default '', detalhe text not null default '',
  link text not null default '', lida boolean not null default false, criado_em timestamptz not null default now()
);
create index if not exists notificacoes_usuario on public.notificacoes (usuario_id, lida, criado_em desc);

-- conclusão: carimba quem/quando; não conclui com checklist pendente; recria tarefas recorrentes
create or replace function public.tarefa_ao_concluir() returns trigger
language plpgsql as $$
begin
  if new.status = 'concluida' and (tg_op = 'INSERT' or old.status is distinct from 'concluida') then
    if exists (select 1 from jsonb_array_elements(coalesce(new.checklist, '[]')) e where coalesce((e->>'feito')::boolean, false) = false) then
      raise exception 'Conclua todos os itens do checklist antes de concluir a tarefa.';
    end if;
    new.concluida_em := now(); new.concluida_por := auth.uid();
    if tg_op = 'UPDATE' and new.recorrencia in ('semanal','mensal','anual') and new.prazo is not null then
      insert into public.tarefas (titulo, grupo_id, cliente_id, contrato_id, processos_vinculados, prioridade, responsavel, status,
        inicio, prazo, prazo_fatal, descricao, participantes, etiquetas, checklist, recorrencia, fluxo_id, tarefa_pai_id)
      values (new.titulo, new.grupo_id, new.cliente_id, new.contrato_id, new.processos_vinculados, new.prioridade, new.responsavel, 'pendente',
        new.prazo, (new.prazo + case new.recorrencia when 'semanal' then interval '7 days' when 'mensal' then interval '1 month' else interval '1 year' end)::date,
        case when new.prazo_fatal is null then null else (new.prazo_fatal + case new.recorrencia when 'semanal' then interval '7 days' when 'mensal' then interval '1 month' else interval '1 year' end)::date end,
        new.descricao, new.participantes, new.etiquetas,
        (select coalesce(jsonb_agg(jsonb_set(e, '{feito}', 'false')), '[]') from jsonb_array_elements(coalesce(new.checklist, '[]')) e),
        new.recorrencia, new.fluxo_id, new.tarefa_pai_id);
    end if;
  elsif new.status <> 'concluida' then
    new.concluida_em := null; new.concluida_por := null;
  end if;
  return new;
end $$;
drop trigger if exists tarefa_ao_concluir on public.tarefas;
create trigger tarefa_ao_concluir before insert or update on public.tarefas
  for each row execute function public.tarefa_ao_concluir();

-- datas de alteração, histórico e regras de acesso das tabelas novas
do $$
declare t text;
begin
  foreach t in array array['contatos','enderecos','contas_bancarias','vinculos_societarios','etiquetas','interacoes','certidoes',
                           'documentos','modelos_fluxo','fluxos','comentarios'] loop
    execute format('drop trigger if exists atualizado_%1$s on public.%1$s', t);
    execute format('create trigger atualizado_%1$s before update on public.%1$s for each row execute function public.marcar_atualizacao()', t);
    execute format('drop trigger if exists hist_%1$s on public.%1$s', t);
    execute format('create trigger hist_%1$s after insert or update or delete on public.%1$s for each row execute function public.registrar_historico()', t);
  end loop;
  foreach t in array array['contatos','enderecos','contas_bancarias','vinculos_societarios','etiquetas','cliente_etiquetas','interacoes',
                           'certidoes','documentos','modelos_fluxo','fluxos','comentarios','feriados','notificacoes'] loop
    execute format('alter table public.%1$s enable row level security', t);
    execute format('revoke all on public.%1$s from anon', t);
    execute format('grant select, insert, update, delete on public.%1$s to authenticated', t);
  end loop;
  -- equipe lê e grava; exclusão: equipe nos detalhes do cliente e nas tarefas; admin em documentos e fluxos
  foreach t in array array['contatos','enderecos','contas_bancarias','vinculos_societarios','etiquetas','cliente_etiquetas','interacoes',
                           'certidoes','documentos','modelos_fluxo','fluxos','comentarios','feriados'] loop
    execute format('drop policy if exists %1$s_ver on public.%1$s', t);
    execute format('create policy %1$s_ver on public.%1$s for select to authenticated using (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_incluir on public.%1$s', t);
    execute format('create policy %1$s_incluir on public.%1$s for insert to authenticated with check (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_alterar on public.%1$s', t);
    execute format('create policy %1$s_alterar on public.%1$s for update to authenticated using (public.eh_equipe()) with check (public.eh_equipe())', t);
    execute format('drop policy if exists %1$s_excluir on public.%1$s', t);
    execute format('create policy %1$s_excluir on public.%1$s for delete to authenticated using (%2$s)', t,
                   case when t in ('documentos','fluxos','modelos_fluxo','feriados') then 'public.eh_admin()' else 'public.eh_equipe()' end);
  end loop;
end $$;
-- notificações: cada um vê e marca as suas; a equipe pode criar para colegas (ex.: tarefa atribuída, menção)
drop policy if exists notificacoes_ver on public.notificacoes;
create policy notificacoes_ver on public.notificacoes for select to authenticated using (usuario_id = auth.uid());
drop policy if exists notificacoes_incluir on public.notificacoes;
create policy notificacoes_incluir on public.notificacoes for insert to authenticated with check (public.eh_equipe());
drop policy if exists notificacoes_alterar on public.notificacoes;
create policy notificacoes_alterar on public.notificacoes for update to authenticated using (usuario_id = auth.uid()) with check (usuario_id = auth.uid());
drop policy if exists notificacoes_excluir on public.notificacoes;
create policy notificacoes_excluir on public.notificacoes for delete to authenticated using (usuario_id = auth.uid());
-- a equipe precisa ver os nomes dos colegas para atribuir tarefas e mencionar
create or replace function public.equipe_nomes() returns table (id uuid, nome text, email text)
language sql stable security definer set search_path = public as $$
  select p.id, p.nome, p.email from public.perfis p where public.eh_equipe() and p.papel in ('admin','equipe') order by p.nome;
$$;
revoke all on function public.equipe_nomes() from anon;
grant execute on function public.equipe_nomes() to authenticated;

-- feriados nacionais fixos (anos 2026 e 2027) e móveis principais; o admin pode acrescentar os de MG, municipais e de tribunal
insert into public.feriados (data, nome, abrangencia) values
  ('2026-01-01','Confraternização Universal','nacional'),('2026-02-16','Carnaval','nacional'),('2026-02-17','Carnaval','nacional'),
  ('2026-04-03','Sexta-feira Santa','nacional'),('2026-04-21','Tiradentes','nacional'),('2026-05-01','Dia do Trabalho','nacional'),
  ('2026-06-04','Corpus Christi','nacional'),('2026-09-07','Independência','nacional'),('2026-10-12','Nossa Senhora Aparecida','nacional'),
  ('2026-11-02','Finados','nacional'),('2026-11-15','Proclamação da República','nacional'),('2026-11-20','Consciência Negra','nacional'),
  ('2026-12-25','Natal','nacional'),
  ('2027-01-01','Confraternização Universal','nacional'),('2027-02-08','Carnaval','nacional'),('2027-02-09','Carnaval','nacional'),
  ('2027-03-26','Sexta-feira Santa','nacional'),('2027-04-21','Tiradentes','nacional'),('2027-05-01','Dia do Trabalho','nacional'),
  ('2027-05-27','Corpus Christi','nacional'),('2027-09-07','Independência','nacional'),('2027-10-12','Nossa Senhora Aparecida','nacional'),
  ('2027-11-02','Finados','nacional'),('2027-11-15','Proclamação da República','nacional'),('2027-11-20','Consciência Negra','nacional'),
  ('2027-12-25','Natal','nacional')
on conflict do nothing;

-- modelos de fluxo iniciais (o escritório pode editar na tela Tarefas → Modelos)
insert into public.modelos_fluxo (nome, descricao, itens)
select 'Onboarding de cliente', 'Do contrato assinado ao cliente com tudo em dia',
  '[{"titulo":"Boas-vindas e alinhamento","dias":10,"checklist":["Enviar mensagem de boas-vindas","Agendar reunião de alinhamento"]},
    {"titulo":"Solicitar documentos","dias":8,"subtarefas":[{"titulo":"Contrato social e alterações","dias":8},{"titulo":"Procuração assinada","dias":8},{"titulo":"Certificado digital / acesso e-CAC","dias":6}]},
    {"titulo":"Diagnóstico fiscal (e-CAC, PGFN, SEFAZ)","dias":4},
    {"titulo":"Relatório inicial ao cliente","dias":0}]'::jsonb
where not exists (select 1 from public.modelos_fluxo where nome = 'Onboarding de cliente');
insert into public.modelos_fluxo (nome, descricao, itens)
select 'Defesa em execução fiscal', 'Prazos contados para trás a partir do prazo fatal',
  '[{"titulo":"Analisar CDA e processo","dias":10,"checklist":["Baixar autos","Conferir prescrição e decadência","Levantar garantias"]},
    {"titulo":"Reunião de estratégia com o cliente","dias":7},
    {"titulo":"Minuta da defesa","dias":4,"subtarefas":[{"titulo":"Pesquisa de jurisprudência","dias":5},{"titulo":"Cálculos","dias":5}]},
    {"titulo":"Revisão do sócio","dias":2},
    {"titulo":"Protocolo","dias":0}]'::jsonb
where not exists (select 1 from public.modelos_fluxo where nome = 'Defesa em execução fiscal');
insert into public.modelos_fluxo (nome, descricao, itens)
select 'Parcelamento tributário', 'Adesão e acompanhamento',
  '[{"titulo":"Levantar débitos e modalidades","dias":6},{"titulo":"Simulação e aprovação do cliente","dias":4},
    {"titulo":"Adesão no portal","dias":1,"checklist":["Emitir 1ª guia","Enviar guia ao cliente"]},{"titulo":"Confirmar pagamento da 1ª parcela","dias":0}]'::jsonb
where not exists (select 1 from public.modelos_fluxo where nome = 'Parcelamento tributário');

-- Storage: bucket privado "documentos" (só existe no Supabase; o teste local ignora)
do $$
begin
  if exists (select 1 from information_schema.schemata where schema_name = 'storage') then
    insert into storage.buckets (id, name, public, file_size_limit)
    values ('documentos', 'documentos', false, 52428800) on conflict (id) do nothing;
    execute 'drop policy if exists documentos_ver on storage.objects';
    execute 'create policy documentos_ver on storage.objects for select to authenticated using (bucket_id = ''documentos'' and public.eh_equipe())';
    execute 'drop policy if exists documentos_enviar on storage.objects';
    execute 'create policy documentos_enviar on storage.objects for insert to authenticated with check (bucket_id = ''documentos'' and public.eh_equipe())';
    execute 'drop policy if exists documentos_alterar on storage.objects';
    execute 'create policy documentos_alterar on storage.objects for update to authenticated using (bucket_id = ''documentos'' and public.eh_equipe())';
    execute 'drop policy if exists documentos_apagar on storage.objects';
    execute 'create policy documentos_apagar on storage.objects for delete to authenticated using (bucket_id = ''documentos'' and public.eh_admin())';
  end if;
exception when insufficient_privilege then
  raise notice 'Sem permissão para criar a pasta de arquivos: crie o bucket privado "documentos" em Storage.';
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- v7 (2026-09-27) — FUNÇÕES DE ACESSO POR PESSOA
-- Além do papel (admin, equipe, cliente, inativo), cada pessoa da equipe
-- tem funções: {"financeiro_juridico":"editar","contratos":"ver",...}.
-- O admin tem tudo. A proteção vale no banco (RLS), não só na tela.
-- ═══════════════════════════════════════════════════════════════════
alter table public.perfis add column if not exists funcoes jsonb not null default '{}'::jsonb;

-- migração (uma vez só): quem já é equipe recebe todas as funções, para ninguém perder acesso
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'migracao_v7_funcoes') then
    update public.perfis set funcoes = '{"financeiro_juridico":"editar","financeiro_contab":"editar","contratos":"editar","clientes":"editar",
      "juridico":"editar","tarefas":"editar","documentos":"editar","crm":"editar","relatorios":"editar"}'::jsonb
     where papel = 'equipe' and funcoes = '{}'::jsonb;
    insert into public.configuracoes (chave, valor) values ('migracao_v7_funcoes', '{"feito":true}');
  end if;
end $$;

-- pode('financeiro_juridico') = pode ver; pode('contratos','editar') = pode gravar
create or replace function public.pode(f text, nivel text default 'ver') returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((
    select case when p.papel = 'admin' then true
                when p.papel <> 'equipe' then false
                when coalesce(p.funcoes->>f, '') = 'editar' then true
                when coalesce(p.funcoes->>f, '') = 'ver' then nivel = 'ver'
                else false end
      from public.perfis p where p.id = auth.uid()), false);
$$;
revoke all on function public.pode(text, text) from anon;
grant execute on function public.pode(text, text) to authenticated;

-- a tarefa é minha? (responsável ou participante, pelo primeiro nome do perfil)
create or replace function public.primeiro_nome(t text) returns text
language sql immutable as $$
  select lower(translate(split_part(btrim(coalesce(t, '')), ' ', 1), 'ÁÀÂÃÉÊÍÓÔÕÚÇáàâãéêíóôõúç', 'AAAAEEIOOOUCaaaaeeiooouc'));
$$;
create or replace function public.tarefa_minha(resp text, part text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.perfis p
    where p.id = auth.uid() and p.papel in ('admin','equipe') and public.primeiro_nome(p.nome) <> ''
      and (public.primeiro_nome(p.nome) = public.primeiro_nome(resp)
           or public.primeiro_nome(p.nome) in (select public.primeiro_nome(x) from unnest(string_to_array(coalesce(part, ''), ',')) x)));
$$;
revoke all on function public.tarefa_minha(text, text) from anon;
grant execute on function public.tarefa_minha(text, text) to authenticated;

-- contrato gera as parcelas mesmo para quem não tem a função Financeiro
alter function public.gerar_parcelas_contrato() security definer;
alter function public.gerar_parcelas_contrato() set search_path = public;

-- regras por tabela: ver / gravar (incluir e alterar) / excluir
do $$
declare
  r record;
begin
  for r in select * from (values
    -- tabela,               ver,                                  gravar,                                   excluir
    ('grupos',               'public.eh_equipe()',                 'public.eh_equipe()',                     'public.pode(''clientes'',''editar'')'),
    ('clientes',             'public.eh_equipe()',                 'public.pode(''clientes'',''editar'')',   'public.eh_admin()'),
    ('contratos',            'public.pode(''contratos'')',         'public.pode(''contratos'',''editar'')',  'public.eh_admin()'),
    ('lancamentos',          'public.pode(case when empresa = ''contabilidade'' then ''financeiro_contab'' else ''financeiro_juridico'' end)',
                             'public.pode(case when empresa = ''contabilidade'' then ''financeiro_contab'' else ''financeiro_juridico'' end, ''editar'')',
                             'public.pode(case when empresa = ''contabilidade'' then ''financeiro_contab'' else ''financeiro_juridico'' end, ''editar'')'),
    ('processos',            'public.pode(''juridico'')',          'public.pode(''juridico'',''editar'')',   'public.eh_admin()'),
    ('parcelamentos',        'public.pode(''juridico'')',          'public.pode(''juridico'',''editar'')',   'public.eh_admin()'),
    ('parcelas',             'public.pode(''juridico'')',          'public.pode(''juridico'',''editar'')',   'public.pode(''juridico'',''editar'')'),
    ('acordos',              'public.pode(''juridico'')',          'public.pode(''juridico'',''editar'')',   'public.eh_admin()'),
    ('tarefas',              'public.pode(''tarefas'') or public.tarefa_minha(responsavel, participantes)',
                             'public.pode(''tarefas'',''editar'') or public.tarefa_minha(responsavel, participantes)',
                             'public.pode(''tarefas'',''editar'')'),
    ('contatos',             'public.pode(''clientes'')',          'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('enderecos',            'public.pode(''clientes'')',          'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('contas_bancarias',     'public.pode(''clientes'')',          'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('vinculos_societarios', 'public.pode(''clientes'')',          'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('interacoes',           'public.pode(''clientes'')',          'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('certidoes',            'public.pode(''clientes'')',          'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('cliente_etiquetas',    'public.eh_equipe()',                 'public.pode(''clientes'',''editar'')',   'public.pode(''clientes'',''editar'')'),
    ('documentos',           'public.pode(''documentos'') and (lancamento_id is null or public.pode(''financeiro_juridico'') or public.pode(''financeiro_contab''))',
                             'public.pode(''documentos'',''editar'')', 'public.eh_admin()'),
    ('fluxos',               'public.eh_equipe()',                 'public.pode(''tarefas'',''editar'')',    'public.eh_admin()'),
    ('modelos_fluxo',        'public.eh_equipe()',                 'public.pode(''tarefas'',''editar'')',    'public.eh_admin()'),
    ('feriados',             'public.eh_equipe()',                 'public.pode(''tarefas'',''editar'')',    'public.eh_admin()')
  ) as t(tabela, ver, gravar, excluir) loop
    execute format('drop policy if exists %1$s_ver on public.%1$s', r.tabela);
    execute format('create policy %1$s_ver on public.%1$s for select to authenticated using (%2$s)', r.tabela, r.ver);
    execute format('drop policy if exists %1$s_incluir on public.%1$s', r.tabela);
    execute format('create policy %1$s_incluir on public.%1$s for insert to authenticated with check (%2$s)', r.tabela, r.gravar);
    execute format('drop policy if exists %1$s_alterar on public.%1$s', r.tabela);
    execute format('create policy %1$s_alterar on public.%1$s for update to authenticated using (%2$s) with check (%2$s)', r.tabela, r.gravar);
    execute format('drop policy if exists %1$s_excluir on public.%1$s', r.tabela);
    execute format('create policy %1$s_excluir on public.%1$s for delete to authenticated using (%2$s)', r.tabela, r.excluir);
  end loop;
end $$;

-- arquivos: mesma regra da função Documentos
do $$
begin
  if exists (select 1 from information_schema.schemata where schema_name = 'storage') then
    execute 'drop policy if exists documentos_ver on storage.objects';
    execute 'create policy documentos_ver on storage.objects for select to authenticated using (bucket_id = ''documentos'' and public.pode(''documentos''))';
    execute 'drop policy if exists documentos_enviar on storage.objects';
    execute 'create policy documentos_enviar on storage.objects for insert to authenticated with check (bucket_id = ''documentos'' and public.pode(''documentos'',''editar''))';
    execute 'drop policy if exists documentos_alterar on storage.objects';
    execute 'create policy documentos_alterar on storage.objects for update to authenticated using (bucket_id = ''documentos'' and public.pode(''documentos'',''editar''))';
  end if;
exception when insufficient_privilege then
  raise notice 'Sem permissão em storage.objects: as regras dos arquivos continuam as da v6.';
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- v8 (2026-09-27) — LÓGICA INTERNA DAS TAREFAS
-- Regras automáticas (sem duplicar), revisão antes de concluir, anexo
-- obrigatório, controle de horas, dias úteis e escalonamento de atrasos.
-- ═══════════════════════════════════════════════════════════════════
alter table public.tarefas add column if not exists chave_regra text;
alter table public.tarefas add column if not exists exige_anexo boolean not null default false;
alter table public.tarefas add column if not exists exige_revisao boolean not null default false;
alter table public.tarefas add column if not exists revisor text not null default '';
alter table public.tarefas add column if not exists escalada_em date;
create unique index if not exists tarefas_chave_regra on public.tarefas (chave_regra) where chave_regra is not null;

-- dias úteis (sábado, domingo e feriados cadastrados não contam)
create or replace function public.dia_util(d date) returns boolean
language sql stable set search_path = public as $$
  select extract(isodow from d) < 6 and not exists (select 1 from public.feriados f where f.data = d);
$$;
create or replace function public.somar_uteis(d date, n int) returns date
language plpgsql stable set search_path = public as $$
declare r date := d; passo int := case when n < 0 then -1 else 1 end; k int := abs(n);
begin
  while k > 0 loop
    r := r + passo;
    if public.dia_util(r) then k := k - 1; end if;
  end loop;
  return r;
end $$;
create or replace function public.uteis_entre(a date, b date) returns int
language sql stable set search_path = public as $$
  select count(*)::int from generate_series(least(a, b) + 1, greatest(a, b), interval '1 day') g where public.dia_util(g::date);
$$;

-- id do usuário pelo primeiro nome (responsável é texto: "Pedro", "Adriana")
create or replace function public.usuario_por_nome(nome text) returns uuid
language sql stable security definer set search_path = public as $$
  select p.id from public.perfis p
   where p.papel in ('admin','equipe') and public.primeiro_nome($1) <> ''   -- $1: o nome procurado (não a coluna perfis.nome)
     and (public.primeiro_nome(p.nome) = public.primeiro_nome($1) or public.primeiro_nome(split_part(p.email, '@', 1)) = public.primeiro_nome($1))
   order by p.criado_em limit 1;
$$;

-- concluir: checklist completo, anexo quando exigido, revisão quando exigida
create or replace function public.tarefa_ao_concluir() returns trigger
language plpgsql as $$
declare quem uuid;
begin
  if new.status = 'concluida' and (tg_op = 'INSERT' or old.status is distinct from 'concluida') then
    if exists (select 1 from jsonb_array_elements(coalesce(new.checklist, '[]')) e where coalesce((e->>'feito')::boolean, false) = false) then
      raise exception 'Conclua todos os itens do checklist antes de concluir a tarefa.';
    end if;
    -- Backup 26: "depende de" trava — o passo anterior precisa estar concluído (e aprovado, se tiver revisão)
    if new.depende_de is not null and exists (select 1 from public.tarefas d where d.id = new.depende_de and d.status not in ('concluida', 'cancelada')) then
      raise exception 'Esta tarefa depende de "%": conclua (ou aprove) aquela antes.', (select titulo from public.tarefas where id = new.depende_de);
    end if;
    if new.exige_anexo and tg_op = 'UPDATE' and not exists (select 1 from public.documentos d where d.tarefa_id = new.id and not d.arquivado) then
      raise exception 'Esta tarefa exige um documento anexado (ex.: protocolo) antes de ser concluída.';
    end if;
    -- em revisão: só o revisor (ou o administrador) conclui
    if new.exige_revisao and tg_op = 'UPDATE' and old.status = 'revisao' and auth.uid() is not null
       and not public.eh_admin() and public.usuario_por_nome(new.revisor) is distinct from auth.uid() then
      raise exception 'Esta tarefa está em revisão: só o revisor (%) pode concluir.', new.revisor;
    end if;
    -- com revisão: quem fez manda para o revisor; só sai de "revisão" para "concluída"
    if new.exige_revisao and tg_op = 'UPDATE' and old.status is distinct from 'revisao' then
      new.status := 'revisao';
      quem := public.usuario_por_nome(new.revisor);
      if quem is not null and quem is distinct from auth.uid() then
        insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link)
        values (quem, 'revisao', 'Revisar: ' || new.titulo, 'Enviada para sua revisão', 'tarefas');
      end if;
      return new;
    end if;
    new.concluida_em := now(); new.concluida_por := auth.uid();
    if tg_op = 'UPDATE' and new.recorrencia in ('semanal','mensal','anual') and new.prazo is not null then
      insert into public.tarefas (titulo, grupo_id, cliente_id, contrato_id, processos_vinculados, prioridade, responsavel, status,
        inicio, prazo, prazo_fatal, descricao, participantes, etiquetas, checklist, recorrencia, fluxo_id, tarefa_pai_id,
        exige_anexo, exige_revisao, revisor, estimativa_horas)
      values (new.titulo, new.grupo_id, new.cliente_id, new.contrato_id, new.processos_vinculados, new.prioridade, new.responsavel, 'pendente',
        new.prazo, (new.prazo + case new.recorrencia when 'semanal' then interval '7 days' when 'mensal' then interval '1 month' else interval '1 year' end)::date,
        case when new.prazo_fatal is null then null else (new.prazo_fatal + case new.recorrencia when 'semanal' then interval '7 days' when 'mensal' then interval '1 month' else interval '1 year' end)::date end,
        new.descricao, new.participantes, new.etiquetas,
        (select coalesce(jsonb_agg(jsonb_set(e, '{feito}', 'false')), '[]') from jsonb_array_elements(coalesce(new.checklist, '[]')) e),
        new.recorrencia, new.fluxo_id, new.tarefa_pai_id, new.exige_anexo, new.exige_revisao, new.revisor, new.estimativa_horas);
    end if;
  elsif new.status <> 'concluida' then
    new.concluida_em := null; new.concluida_por := null;
  end if;
  return new;
end $$;

-- horas gastas (botão ▶/■ na tarefa)
create table if not exists public.tarefa_tempos (
  id uuid primary key default gen_random_uuid(),
  tarefa_id uuid not null references public.tarefas(id) on delete cascade,
  usuario uuid default auth.uid(),
  inicio timestamptz not null default now(), fim timestamptz,
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
-- regras automáticas (Tarefas → Regras)
create table if not exists public.regras_tarefas (
  chave text primary key, nome text not null, descricao text not null default '',
  ligada boolean not null default true, dias int not null default 5, responsavel text not null default '',
  atualizado_em timestamptz not null default now()
);
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias) values
  ('contrato_onboarding', 'Contrato novo → onboarding do cliente', 'Cria a tarefa de boas-vindas com o checklist do modelo "Onboarding de cliente"; prazo em N dias úteis', true, 10),
  ('processo_novo', 'Processo cadastrado → conferir processo e prazos', 'Para o advogado do processo; prazo em N dias úteis', true, 2),
  ('certidao_vencendo', 'Certidão ou documento vencendo → renovar', 'N dias antes da validade, para o responsável do cliente', true, 15),
  ('parcela_parcelamento', 'Parcela de parcelamento do cliente → lembrete "Emitir guias"', 'N dias antes do vencimento aparece no card Lembretes do Início (não vira tarefa)', true, 5),
  ('parcela_acordo', 'Parcela de acordo do cliente → lembrar o cliente', 'N dias antes do vencimento (acompanhamento; não entra no financeiro)', true, 5),
  ('cobrar_honorario', 'Honorário vencido → cobrar', 'N dias depois do vencimento sem pagamento', false, 3),
  ('escalar_atraso', 'Tarefa atrasada → avisar o administrador', 'Depois de N dias úteis de atraso; com mais 2 dias a prioridade vira Alta', true, 3)
on conflict (chave) do nothing;

do $$
declare t text;
begin
  foreach t in array array['tarefa_tempos','regras_tarefas'] loop
    execute format('alter table public.%1$s enable row level security', t);
    execute format('revoke all on public.%1$s from anon', t);
    execute format('grant select, insert, update, delete on public.%1$s to authenticated', t);
    execute format('drop trigger if exists atualizado_%1$s on public.%1$s', t);
    execute format('create trigger atualizado_%1$s before update on public.%1$s for each row execute function public.marcar_atualizacao()', t);
  end loop;
end $$;
drop policy if exists tarefa_tempos_ver on public.tarefa_tempos;
create policy tarefa_tempos_ver on public.tarefa_tempos for select to authenticated using (public.eh_equipe());
drop policy if exists tarefa_tempos_gravar on public.tarefa_tempos;
create policy tarefa_tempos_gravar on public.tarefa_tempos for insert to authenticated with check (public.eh_equipe() and usuario = auth.uid());
drop policy if exists tarefa_tempos_alterar on public.tarefa_tempos;
create policy tarefa_tempos_alterar on public.tarefa_tempos for update to authenticated using (usuario = auth.uid()) with check (usuario = auth.uid());
drop policy if exists tarefa_tempos_excluir on public.tarefa_tempos;
create policy tarefa_tempos_excluir on public.tarefa_tempos for delete to authenticated using (usuario = auth.uid() or public.eh_admin());
drop policy if exists regras_tarefas_ver on public.regras_tarefas;
create policy regras_tarefas_ver on public.regras_tarefas for select to authenticated using (public.eh_equipe());
drop policy if exists regras_tarefas_admin on public.regras_tarefas;
create policy regras_tarefas_admin on public.regras_tarefas for update to authenticated using (public.eh_admin()) with check (public.eh_admin());

-- cria uma tarefa da regra (a chave impede duplicar)
create or replace function public.tarefa_da_regra(p_chave text, p_titulo text, p_resp text, p_prazo date,
  p_cliente uuid default null, p_grupo uuid default null, p_contrato uuid default null, p_checklist jsonb default '[]',
  p_descricao text default '', p_processo text default '', p_prioridade text default 'media') returns boolean
language plpgsql security definer set search_path = public as $$
declare n int; quem uuid;
begin
  insert into public.tarefas (chave_regra, titulo, responsavel, prazo, inicio, cliente_id, grupo_id, contrato_id, checklist, descricao,
                              processos_vinculados, prioridade, status)
  values (p_chave, p_titulo, coalesce(p_resp, ''), p_prazo, current_date, p_cliente, p_grupo, p_contrato, coalesce(p_checklist, '[]'),
          coalesce(p_descricao, ''), coalesce(p_processo, ''), p_prioridade, 'pendente')
  on conflict (chave_regra) where chave_regra is not null do nothing;
  get diagnostics n = row_count;
  if n > 0 then
    begin   -- registro da automação (Central de automações; tabela da v17)
      insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (split_part(p_chave, ':', 1), p_chave, p_titulo, p_cliente);
    exception when undefined_table then null;
    end;
    quem := public.usuario_por_nome(p_resp);
    if quem is not null then
      insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link)
      values (quem, 'tarefa', 'Nova tarefa automática: ' || p_titulo, coalesce('Prazo ' || to_char(p_prazo, 'DD/MM/YYYY'), ''), 'tarefas');
    end if;
  end if;
  return n > 0;
end $$;
revoke all on function public.tarefa_da_regra(text, text, text, date, uuid, uuid, uuid, jsonb, text, text, text) from anon, authenticated;

-- gatilhos na hora: contrato novo e processo novo
create or replace function public.regra_contrato_novo() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; cl record; ck jsonb;
begin
  select * into rg from public.regras_tarefas where chave = 'contrato_onboarding' and ligada;
  if not found then return null; end if;
  select * into cl from public.clientes where id = new.cliente_id;
  select coalesce(jsonb_agg(jsonb_build_object('texto', i->>'titulo', 'feito', false)), '[]') into ck
    from public.modelos_fluxo m, jsonb_array_elements(m.itens) i where m.nome = 'Onboarding de cliente';
  perform public.tarefa_da_regra('onb:' || new.id, 'Onboarding: ' || coalesce(cl.nome, new.descricao),
    coalesce(nullif(rg.responsavel, ''), nullif(new.responsavel, ''), cl.responsavel),
    public.somar_uteis(coalesce(new.data_contrato, current_date), rg.dias), new.cliente_id, cl.grupo_id, new.id, ck,
    'Contrato: ' || new.descricao);
  return null;
end $$;
drop trigger if exists regra_contrato_novo on public.contratos;
create trigger regra_contrato_novo after insert on public.contratos for each row execute function public.regra_contrato_novo();

create or replace function public.regra_processo_novo() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record;
begin
  select * into rg from public.regras_tarefas where chave = 'processo_novo' and ligada;
  if not found or new.chave_importacao is not null then return null; end if;   -- importação em massa não gera tarefa
  perform public.tarefa_da_regra('proc:' || new.id, 'Conferir processo ' || new.numero || ' e prazos',
    coalesce(nullif(rg.responsavel, ''), new.advogado), public.somar_uteis(current_date, rg.dias),
    null, new.grupo_id, null, '[{"texto":"Conferir partes e valor da causa","feito":false},{"texto":"Lançar prazos em aberto","feito":false}]',
    '', new.numero);
  return null;
end $$;
drop trigger if exists regra_processo_novo on public.processos;
create trigger regra_processo_novo after insert on public.processos for each row execute function public.regra_processo_novo();

-- rotina diária (e botão "Rodar agora"): vencimentos, cobranças e atrasos
create or replace function public.rodar_regras_tarefas() returns int
language plpgsql security definer set search_path = public as $$
declare rg record; x record; n int := 0; adm record;
begin
  if auth.uid() is not null and not public.eh_equipe() then raise exception 'Só a equipe roda as regras.'; end if;
  -- certidões e documentos com validade chegando
  select * into rg from public.regras_tarefas where chave = 'certidao_vencendo' and ligada;
  if found then
    for x in select c.id, c.orgao, c.validade, cl.id cli, cl.nome, cl.grupo_id, cl.responsavel from public.certidoes c join public.clientes cl on cl.id = c.cliente_id
              where c.validade is not null and c.validade <= current_date + rg.dias loop
      if public.tarefa_da_regra('cert:' || x.id || ':' || x.validade, 'Renovar certidão ' || x.orgao || ' — ' || x.nome,
           coalesce(nullif(rg.responsavel, ''), x.responsavel), least(x.validade, public.somar_uteis(current_date, 2)), x.cli, x.grupo_id) then n := n + 1; end if;
    end loop;
    for x in select d.id, d.nome doc, d.validade, cl.id cli, cl.nome, cl.grupo_id, cl.responsavel from public.documentos d left join public.clientes cl on cl.id = d.cliente_id
              where not d.arquivado and d.validade is not null and d.validade <= current_date + rg.dias loop
      if public.tarefa_da_regra('doc:' || x.id || ':' || x.validade, 'Renovar documento ' || x.doc || coalesce(' — ' || x.nome, ''),
           coalesce(nullif(rg.responsavel, ''), x.responsavel), least(x.validade, public.somar_uteis(current_date, 2)), x.cli, x.grupo_id) then n := n + 1; end if;
    end loop;
  end if;
  -- parcelas de parcelamentos: desde o Backup 16 viram LEMBRETE no Início ("Emitir guias de parcelamentos"),
  -- não tarefa. A regra continua guardando quantos dias antes o lembrete aparece.
  -- parcelas de acordos do cliente (acompanhamento; nada no financeiro)
  select * into rg from public.regras_tarefas where chave = 'parcela_acordo' and ligada;
  if found then
    for x in select a.id, a.credor, a.devedor, a.parcela, a.vencimento, a.grupo_id, a.responsavel from public.acordos a
              where not a.pago and a.vencimento between current_date and current_date + rg.dias loop
      if public.tarefa_da_regra('aco:' || x.id, 'Lembrar ' || coalesce(nullif(x.devedor, ''), 'o cliente') || ' do acordo com ' || coalesce(nullif(x.credor, ''), 'o credor') || ' (parc. ' || coalesce(x.parcela, '') || ')',
           coalesce(nullif(rg.responsavel, ''), x.responsavel), public.somar_uteis(x.vencimento, -1), null, x.grupo_id) then n := n + 1; end if;
    end loop;
  end if;
  -- honorários vencidos sem pagamento
  select * into rg from public.regras_tarefas where chave = 'cobrar_honorario' and ligada;
  if found then
    for x in select l.id, l.descricao, l.referencia, l.vencimento, l.cliente_id, l.grupo_id, l.responsavel, g.nome gnome from public.lancamentos l
              left join public.grupos g on g.id = l.grupo_id
              where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false) and l.vencimento <= current_date - rg.dias loop
      if public.tarefa_da_regra('cob:' || x.id, 'Cobrar honorário — ' || coalesce(x.gnome, x.descricao) || coalesce(' ' || nullif(x.referencia, ''), ''),
           coalesce(nullif(rg.responsavel, ''), x.responsavel), public.somar_uteis(current_date, 1), x.cliente_id, x.grupo_id) then n := n + 1; end if;
    end loop;
  end if;
  -- atrasos: avisa os administradores; mais 2 dias úteis, prioridade Alta
  select * into rg from public.regras_tarefas where chave = 'escalar_atraso' and ligada;
  if found then
    for x in select t.id, t.titulo, t.responsavel, t.prazo from public.tarefas t
              where t.status not in ('concluida','cancelada') and t.prazo is not null and t.prazo < current_date
                and public.uteis_entre(t.prazo, current_date) > rg.dias and t.escalada_em is null loop
      for adm in select id from public.perfis where papel = 'admin' loop
        insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link)
        values (adm.id, 'atraso', 'Atrasada: ' || x.titulo, coalesce(nullif(x.responsavel, ''), 'sem responsável') || ' · prazo ' || to_char(x.prazo, 'DD/MM/YYYY'), 'tarefas');
      end loop;
      update public.tarefas set escalada_em = current_date where id = x.id;
      n := n + 1;
    end loop;
    update public.tarefas set prioridade = 'alta'
     where status not in ('concluida','cancelada') and prazo is not null and prazo < current_date
       and public.uteis_entre(prazo, current_date) > rg.dias + 2 and prioridade <> 'alta';
  end if;
  -- e-mails automáticos ao cliente (v17; cada tipo começa desligado)
  begin n := n + public.rodar_emails_cliente_se_sem_hora(); exception when undefined_function then n := n + public.rodar_emails_cliente(); end;
  -- regras novas (v22+: CRM parado, follow-up de proposta, tarefas…) ficam em rodar_regras_extras
  begin n := n + public.rodar_regras_extras(); exception when undefined_function then null; end;
  insert into public.configuracoes (chave, valor) values ('regras_tarefas_ultima', jsonb_build_object('quando', now(), 'criadas', n))
  on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  return n;
end $$;
revoke all on function public.rodar_regras_tarefas() from anon;
grant execute on function public.rodar_regras_tarefas() to authenticated;

-- rotina automática todo dia útil às 7h (Brasília = 10h UTC), se o agendador existir no Supabase
do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_regras_tarefas';
  perform cron.schedule('erp_regras_tarefas', '0 10 * * 1-5', 'select public.rodar_regras_tarefas()');
exception when others then
  raise notice 'Agendador (pg_cron) indisponível: as regras rodam ao abrir o sistema e pelo botão "Rodar agora".';
end $$;

-- o revisor também enxerga e grava a tarefa que está com ele
drop policy if exists tarefas_ver on public.tarefas;
create policy tarefas_ver on public.tarefas for select to authenticated
  using (public.pode('tarefas') or public.tarefa_minha(responsavel, participantes) or public.tarefa_minha(revisor, ''));
drop policy if exists tarefas_alterar on public.tarefas;
create policy tarefas_alterar on public.tarefas for update to authenticated
  using (public.pode('tarefas','editar') or public.tarefa_minha(responsavel, participantes) or public.tarefa_minha(revisor, ''))
  with check (public.pode('tarefas','editar') or public.tarefa_minha(responsavel, participantes) or public.tarefa_minha(revisor, ''));

-- ═══════════════════════════════════════════════════════════════════
-- v9 (2026-09-27) — AVISOS POR E-MAIL (configurados na tela Administração → E-mail)
-- A tela e os gatilhos só põem e-mails na FILA; a função "erp-emails"
-- (Supabase → Edge Functions) envia pelo Gmail do escritório, outro SMTP ou Resend.
-- A senha do serviço fica em config_privada, que o site não consegue ler.
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.config_privada (
  chave text primary key, valor jsonb not null, atualizado_em timestamptz not null default now()
);
alter table public.config_privada enable row level security;       -- sem nenhuma regra: ninguém lê pelo site
revoke all on public.config_privada from anon, authenticated;
insert into public.config_privada (chave, valor) values ('segredo_funcoes', to_jsonb(gen_random_uuid()::text)) on conflict (chave) do nothing;
insert into public.config_privada (chave, valor) values ('url_projeto', to_jsonb('https://kukpiyqwtaeuvkvfrjjm.supabase.co'::text)) on conflict (chave) do nothing;

create table if not exists public.email_fila (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid references public.perfis(id) on delete set null,
  para text not null, assunto text not null, html text not null,
  tipo text not null default '', referencia text not null default '',
  status text not null default 'pendente' check (status in ('pendente','enviado','erro','cancelado')),
  tentativas int not null default 0, erro text not null default '',
  criado_em timestamptz not null default now(), enviado_em timestamptz
);
create unique index if not exists email_fila_ref on public.email_fila (usuario_id, referencia) where referencia <> '';
alter table public.email_fila enable row level security;
revoke all on public.email_fila from anon;
revoke insert, update, delete on public.email_fila from authenticated;
grant select on public.email_fila to authenticated;
drop policy if exists email_fila_ver on public.email_fila;
create policy email_fila_ver on public.email_fila for select to authenticated using (public.eh_admin() or usuario_id = auth.uid());

-- a função de envio (chave de serviço) precisa ler a configuração e a fila
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant select, insert, update on public.config_privada, public.email_fila to service_role';
  end if;
end $$;

-- o que cada pessoa quer receber
alter table public.perfis add column if not exists pref_email jsonb not null
  default '{"resumo":true,"tarefa":true,"mencao":true,"fatal":true,"vencimentos":true,"publicacao":true}'::jsonb;
create or replace function public.salvar_minhas_preferencias(p jsonb) returns void
language sql security definer set search_path = public as $$
  update public.perfis set pref_email = coalesce(p, '{}'::jsonb) where id = auth.uid();
$$;
revoke all on function public.salvar_minhas_preferencias(jsonb) from anon;
grant execute on function public.salvar_minhas_preferencias(jsonb) to authenticated;

-- configurar (só admin) e consultar sem expor a senha
create or replace function public.salvar_config_email(p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare atual jsonb;
begin
  if not public.eh_admin() then raise exception 'Só o administrador configura o e-mail.'; end if;
  select valor into atual from public.config_privada where chave = 'email';
  if coalesce(p->>'senha', '') = '' then p := p || jsonb_build_object('senha', coalesce(atual->>'senha', '')); end if;
  insert into public.config_privada (chave, valor)
  values ('email', p || jsonb_build_object('configurado_em', now(), 'configurado_por', auth.uid()))
  on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
end $$;
create or replace function public.status_config_email() returns jsonb
language plpgsql security definer set search_path = public as $$
declare c jsonb;
begin
  if not public.eh_admin() then raise exception 'Só o administrador vê a configuração do e-mail.'; end if;
  select valor into c from public.config_privada where chave = 'email';
  return coalesce(c - 'senha', '{}'::jsonb) || jsonb_build_object('tem_senha', coalesce(c->>'senha', '') <> '',
    'pendentes', (select count(*) from public.email_fila where status = 'pendente'),
    'erros', (select count(*) from public.email_fila where status = 'erro'),
    'enviados_7d', (select count(*) from public.email_fila where status = 'enviado' and enviado_em > now() - interval '7 days'));
end $$;
revoke all on function public.salvar_config_email(jsonb) from anon;
revoke all on function public.status_config_email() from anon;
grant execute on function public.salvar_config_email(jsonb), public.status_config_email() to authenticated;

-- modelo visual do e-mail (paleta do escritório)
create or replace function public.email_modelo(titulo text, corpo text) returns text
language sql immutable as $$
  select '<div style="font-family:Arial,Helvetica,sans-serif;background:#F0F2F7;padding:24px">'
    || '<div style="max-width:620px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #E5E7EB">'
    || '<div style="background:#1B2A4A;color:#fff;padding:16px 22px"><div style="color:#C9A84C;font-size:11px;letter-spacing:.12em;text-transform:uppercase;font-weight:bold">Araújo &amp; Castro · ERP</div>'
    || '<div style="font-size:18px;font-weight:bold;margin-top:4px">' || replace(replace(titulo, '<', '&lt;'), '>', '&gt;') || '</div></div>'
    || '<div style="padding:18px 22px;color:#1F2937;font-size:14px;line-height:1.55">' || corpo || '</div>'
    || '<div style="padding:12px 22px;border-top:1px solid #E5E7EB;color:#6B7280;font-size:11.5px">Você recebe este aviso pelo ERP do escritório. '
    || 'Para mudar, abra o ERP → ⋯ → Meus avisos por e-mail.</div></div></div>';
$$;
create or replace function public.esc_html(t text) returns text language sql immutable as $$
  select replace(replace(replace(coalesce(t, ''), '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
$$;

-- põe na fila um e-mail para uma pessoa da equipe, respeitando a preferência
create or replace function public.enfileirar_email(p_usuario uuid, p_pref text, p_assunto text, p_corpo text, p_tipo text, p_ref text default '')
returns boolean language plpgsql security definer set search_path = public as $$
declare pf record; n int;
begin
  select * into pf from public.perfis where id = p_usuario and papel in ('admin','equipe');
  if not found or coalesce(pf.email, '') = '' then return false; end if;
  if p_pref <> '' and coalesce((pf.pref_email->>p_pref)::boolean, true) = false then return false; end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (p_usuario, pf.email, p_assunto, public.email_modelo(p_assunto, p_corpo), p_tipo, coalesce(p_ref, ''))
  on conflict (usuario_id, referencia) where referencia <> '' do nothing;
  get diagnostics n = row_count;
  return n > 0;
end $$;
revoke all on function public.enfileirar_email(uuid, text, text, text, text, text) from anon, authenticated;

-- toda notificação (tarefa atribuída, menção, revisão, atraso, publicação) pode virar e-mail na hora
create or replace function public.email_da_notificacao() returns trigger
language plpgsql security definer set search_path = public as $$
declare pref text;
begin
  pref := case new.tipo when 'mencao' then 'mencao' when 'publicacao' then 'publicacao' when 'atraso' then 'fatal' else 'tarefa' end;
  perform public.enfileirar_email(new.usuario_id, pref, new.titulo,
    '<p>' || public.esc_html(new.titulo) || '</p>' || case when new.detalhe <> '' then '<p style="color:#4B5563">' || public.esc_html(new.detalhe) || '</p>' else '' end
    || coalesce('<p><a href="' || (select valor #>> '{}' from public.config_privada where chave = 'url_sistema') || '" style="background:#1B2A4A;color:#fff;padding:9px 16px;border-radius:8px;text-decoration:none;display:inline-block">Abrir no ERP</a></p>', ''),
    new.tipo, 'notif:' || new.id);
  return null;
end $$;
drop trigger if exists email_da_notificacao on public.notificacoes;
create trigger email_da_notificacao after insert on public.notificacoes for each row execute function public.email_da_notificacao();

-- resumo diário de cada pessoa (dias úteis, de manhã)
create or replace function public.montar_resumos_diarios() returns int
language plpgsql security definer set search_path = public as $$
declare pf record; x record; corpo text; bloco text; n int := 0; hoje date := current_date;
begin
  if auth.uid() is not null and not public.eh_admin() then raise exception 'Só o administrador dispara o resumo.'; end if;
  for pf in select * from public.perfis where papel in ('admin','equipe') and coalesce(email, '') <> ''
                and coalesce((pref_email->>'resumo')::boolean, true) loop
    corpo := '';
    -- minhas tarefas de hoje e atrasadas
    bloco := '';
    for x in select titulo, prazo, prazo_fatal from public.tarefas
              where status not in ('concluida','cancelada') and prazo is not null and prazo <= hoje
                and (public.primeiro_nome(responsavel) = public.primeiro_nome(pf.nome)) order by prazo limit 20 loop
      bloco := bloco || '<li>' || public.esc_html(x.titulo) || ' — ' || case when x.prazo < hoje then '<b style="color:#B91C1C">atrasada desde ' || to_char(x.prazo, 'DD/MM') || '</b>' else 'hoje' end || '</li>';
    end loop;
    if bloco <> '' then corpo := corpo || '<h3 style="font-size:14px;color:#1B2A4A">Seus prazos de hoje e atrasados</h3><ul>' || bloco || '</ul>'; end if;
    -- prazos fatais nos próximos 5 dias
    bloco := '';
    for x in select titulo, prazo_fatal from public.tarefas
              where status not in ('concluida','cancelada') and prazo_fatal between hoje and hoje + 5
                and public.primeiro_nome(responsavel) = public.primeiro_nome(pf.nome) and coalesce((pf.pref_email->>'fatal')::boolean, true)
              order by prazo_fatal limit 20 loop
      bloco := bloco || '<li><b>⚑ ' || to_char(x.prazo_fatal, 'DD/MM') || '</b> — ' || public.esc_html(x.titulo) || '</li>';
    end loop;
    if bloco <> '' then corpo := corpo || '<h3 style="font-size:14px;color:#1B2A4A">Prazos fatais em 5 dias</h3><ul>' || bloco || '</ul>'; end if;
    -- menções e revisões não lidas
    bloco := '';
    for x in select titulo from public.notificacoes where usuario_id = pf.id and not lida and tipo in ('mencao','revisao') order by criado_em desc limit 10 loop
      bloco := bloco || '<li>' || public.esc_html(x.titulo) || '</li>';
    end loop;
    if bloco <> '' then corpo := corpo || '<h3 style="font-size:14px;color:#1B2A4A">Menções e revisões</h3><ul>' || bloco || '</ul>'; end if;
    -- documentos e certidões vencendo (15 dias)
    if coalesce((pf.pref_email->>'vencimentos')::boolean, true) then
      bloco := '';
      for x in select 'Certidão ' || c.orgao || ' — ' || cl.nome t, c.validade v from public.certidoes c join public.clientes cl on cl.id = c.cliente_id
                where c.validade <= hoje + 15 and (pf.papel = 'admin' or public.primeiro_nome(cl.responsavel) = public.primeiro_nome(pf.nome))
               union all
               select 'Documento ' || d.nome, d.validade from public.documentos d left join public.clientes cl on cl.id = d.cliente_id
                where not d.arquivado and d.validade <= hoje + 15 and (pf.papel = 'admin' or public.primeiro_nome(cl.responsavel) = public.primeiro_nome(pf.nome))
               order by 2 limit 15 loop
        bloco := bloco || '<li>' || public.esc_html(x.t) || ' — ' || case when x.v < hoje then '<b style="color:#B91C1C">vencido em ' else 'vence em ' end || to_char(x.v, 'DD/MM/YYYY') || case when x.v < hoje then '</b>' else '' end || '</li>';
      end loop;
      if bloco <> '' then corpo := corpo || '<h3 style="font-size:14px;color:#1B2A4A">Documentos e certidões vencendo</h3><ul>' || bloco || '</ul>'; end if;
    end if;
    -- administrador: atrasos da equipe acima de 3 dias úteis
    if pf.papel = 'admin' then
      bloco := '';
      for x in select titulo, responsavel, prazo from public.tarefas
                where status not in ('concluida','cancelada') and prazo < hoje and public.uteis_entre(prazo, hoje) > 3 order by prazo limit 15 loop
        bloco := bloco || '<li>' || public.esc_html(x.titulo) || ' — ' || public.esc_html(coalesce(nullif(x.responsavel, ''), 'sem responsável')) || ', desde ' || to_char(x.prazo, 'DD/MM') || '</li>';
      end loop;
      if bloco <> '' then corpo := corpo || '<h3 style="font-size:14px;color:#1B2A4A">Equipe: atrasos acima de 3 dias úteis</h3><ul>' || bloco || '</ul>'; end if;
    end if;
    if corpo <> '' then
      if public.enfileirar_email(pf.id, 'resumo', 'Resumo do dia — ' || to_char(hoje, 'DD/MM/YYYY'),
           '<p>Bom dia, ' || public.esc_html(split_part(pf.nome, ' ', 1)) || '. Este é o seu resumo de hoje.</p>' || corpo, 'resumo', 'resumo:' || hoje) then
        n := n + 1;
      end if;
    end if;
  end loop;
  return n;
end $$;
revoke all on function public.montar_resumos_diarios() from anon;
grant execute on function public.montar_resumos_diarios() to authenticated;

-- endereço do sistema (para o botão "Abrir no ERP" dos e-mails); o admin grava pela tela
create or replace function public.salvar_url_sistema(p text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador.'; end if;
  insert into public.config_privada (chave, valor) values ('url_sistema', to_jsonb(p)) on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
end $$;
revoke all on function public.salvar_url_sistema(text) from anon;
grant execute on function public.salvar_url_sistema(text) to authenticated;

-- agendamentos: resumo às 7h45 (dias úteis) e envio da fila a cada 5 minutos
do $$
begin
  create extension if not exists pg_cron;
  perform cron.unschedule(jobid) from cron.job where jobname in ('erp_resumo_diario', 'erp_enviar_emails');
  perform cron.schedule('erp_resumo_diario', '45 10 * * 1-5', 'select public.montar_resumos_diarios()');
  create extension if not exists pg_net;
  perform cron.schedule('erp_enviar_emails', '*/5 * * * *', $cron$
    select net.http_post(
      url := (select valor #>> '{}' from public.config_privada where chave = 'url_projeto') || '/functions/v1/erp-emails',
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-erp-segredo', (select valor #>> '{}' from public.config_privada where chave = 'segredo_funcoes')),
      body := '{"acao":"enviar"}'::jsonb)
    where exists (select 1 from public.email_fila where status = 'pendente')
  $cron$);
exception when others then
  raise notice 'Agendador indisponível: use o botão "Enviar agora" em Administração → E-mail.';
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- v10 (2026-09-27) — CRM DO ZERO (dentro do sistema, sem serviço pago)
-- Oportunidade → atividades → proposta (modelo do escritório) → "Ganhou"
-- cria cliente, contrato, parcelas e o fluxo de onboarding numa vez só.
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.crm_etapas (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (btrim(nome) <> ''), ordem int not null default 0,
  probabilidade int not null default 0 check (probabilidade between 0 and 100),
  cor text not null default '#2E5EAA', final text not null default '' check (final in ('', 'ganho', 'perdido')),
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
insert into public.crm_etapas (nome, ordem, probabilidade, final)
select * from (values ('Novo contato', 1, 10, ''), ('Diagnóstico agendado', 2, 25, ''), ('Diagnóstico feito', 3, 40, ''),
                      ('Proposta enviada', 4, 60, ''), ('Negociação', 5, 80, ''), ('Ganhou', 6, 100, 'ganho'), ('Perdeu', 7, 0, 'perdido')) v(n, o, p, f)
where not exists (select 1 from public.crm_etapas);

create table if not exists public.crm_oportunidades (
  id uuid primary key default gen_random_uuid(),
  titulo text not null check (btrim(titulo) <> ''),
  cliente_id uuid references public.clientes(id) on delete set null,
  prospecto_nome text not null default '', prospecto_doc text not null default '', prospecto_email text not null default '',
  prospecto_telefone text not null default '', prospecto_empresa text not null default '',
  origem text not null default '', indicado_por text not null default '',
  etapa_id uuid references public.crm_etapas(id) on delete set null, etapa_desde timestamptz not null default now(),
  valor_estimado numeric(14,2) not null default 0, honorario_tipo text not null default '',
  probabilidade int not null default 10 check (probabilidade between 0 and 100),
  previsao_fechamento date, responsavel text not null default '',
  proxima_acao text not null default '', proxima_acao_em date,
  motivo_perda text not null default '', ganho_em timestamptz, perdido_em timestamptz, contrato_id uuid references public.contratos(id) on delete set null,
  obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create table if not exists public.crm_atividades (
  id uuid primary key default gen_random_uuid(),
  oportunidade_id uuid not null references public.crm_oportunidades(id) on delete cascade,
  tipo text not null default 'anotacao', quando timestamptz not null default now(),
  resumo text not null check (btrim(resumo) <> ''), feita boolean not null default true,
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create table if not exists public.crm_modelos_proposta (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (btrim(nome) <> ''), texto text not null default '', itens jsonb not null default '[]',
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create table if not exists public.crm_propostas (
  id uuid primary key default gen_random_uuid(),
  oportunidade_id uuid not null references public.crm_oportunidades(id) on delete cascade,
  versao int not null default 1, titulo text not null default '', texto text not null default '',
  itens jsonb not null default '[]',       -- [{servico, valor, forma}]
  validade date, status text not null default 'rascunho' check (status in ('rascunho','enviada','aceita','recusada')),
  enviada_em timestamptz, documento_id uuid references public.documentos(id) on delete set null,
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
alter table public.documentos add column if not exists oportunidade_id uuid references public.crm_oportunidades(id) on delete set null;

insert into public.crm_modelos_proposta (nome, texto, itens)
select n, t, i::jsonb from (values
  ('Consultoria tributária mensal',
   '<p>Prezado(a) {cliente},</p><p>Conforme conversamos, apresentamos proposta de <b>consultoria tributária mensal</b>, com acompanhamento das obrigações e do passivo fiscal, atendimento às dúvidas da empresa e relatório periódico da situação fiscal.</p><p>Os valores e a forma de pagamento estão na tabela abaixo. Esta proposta vale até {validade}.</p>',
   '[{"servico":"Consultoria tributária mensal","valor":0,"forma":"mensal, por boleto ou PIX"}]'),
  ('Defesa em execução fiscal',
   '<p>Prezado(a) {cliente},</p><p>Apresentamos proposta para a <b>defesa na execução fiscal</b>: análise da CDA e do processo, estratégia com o cliente, elaboração e protocolo da defesa e acompanhamento até a decisão de primeira instância.</p><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Honorários iniciais","valor":0,"forma":"à vista ou em até 3 parcelas"},{"servico":"Êxito sobre o valor reduzido","valor":0,"forma":"percentual no êxito"}]'),
  ('Parcelamento / transação tributária',
   '<p>Prezado(a) {cliente},</p><p>Apresentamos proposta para o <b>levantamento dos débitos, simulação das modalidades e adesão ao parcelamento/transação</b> mais vantajoso, com emissão das primeiras guias.</p><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Levantamento, simulação e adesão","valor":0,"forma":"à vista"}]'),
  ('Holding e planejamento patrimonial',
   '<p>Prezado(a) {cliente},</p><p>Apresentamos proposta para o <b>estudo, constituição e integralização da holding</b>, com o planejamento tributário e sucessório da estrutura.</p><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Estudo e planejamento","valor":0,"forma":"na assinatura"},{"servico":"Constituição e integralização","valor":0,"forma":"na conclusão"}]')
) v(n, t, i)
where not exists (select 1 from public.crm_modelos_proposta);

-- muda de etapa → reinicia o relógio "dias parado"
create or replace function public.crm_ao_mudar_etapa() returns trigger
language plpgsql as $$
begin
  if tg_op = 'UPDATE' and new.etapa_id is distinct from old.etapa_id then new.etapa_desde := now(); end if;
  return new;
end $$;
drop trigger if exists crm_ao_mudar_etapa on public.crm_oportunidades;
create trigger crm_ao_mudar_etapa before update on public.crm_oportunidades for each row execute function public.crm_ao_mudar_etapa();

do $$
declare t text;
begin
  foreach t in array array['crm_etapas','crm_oportunidades','crm_atividades','crm_modelos_proposta','crm_propostas'] loop
    execute format('alter table public.%1$s enable row level security', t);
    execute format('revoke all on public.%1$s from anon', t);
    execute format('grant select, insert, update, delete on public.%1$s to authenticated', t);
    execute format('drop trigger if exists atualizado_%1$s on public.%1$s', t);
    execute format('create trigger atualizado_%1$s before update on public.%1$s for each row execute function public.marcar_atualizacao()', t);
    execute format('drop trigger if exists hist_%1$s on public.%1$s', t);
    execute format('create trigger hist_%1$s after insert or update or delete on public.%1$s for each row execute function public.registrar_historico()', t);
    execute format('drop policy if exists %1$s_ver on public.%1$s', t);
    execute format('create policy %1$s_ver on public.%1$s for select to authenticated using (public.pode(''crm''))', t);
    execute format('drop policy if exists %1$s_incluir on public.%1$s', t);
    execute format('create policy %1$s_incluir on public.%1$s for insert to authenticated with check (public.pode(''crm'',''editar''))', t);
    execute format('drop policy if exists %1$s_alterar on public.%1$s', t);
    execute format('create policy %1$s_alterar on public.%1$s for update to authenticated using (public.pode(''crm'',''editar'')) with check (public.pode(''crm'',''editar''))', t);
    execute format('drop policy if exists %1$s_excluir on public.%1$s', t);
    execute format('create policy %1$s_excluir on public.%1$s for delete to authenticated using (%2$s)', t,
                   case when t in ('crm_atividades') then 'public.pode(''crm'',''editar'')' else 'public.eh_admin()' end);
  end loop;
end $$;
-- documentos da oportunidade: também quem tem a função CRM
drop policy if exists documentos_ver on public.documentos;
create policy documentos_ver on public.documentos for select to authenticated using (
  (public.pode('documentos') or (oportunidade_id is not null and public.pode('crm')))
  and (lancamento_id is null or public.pode('financeiro_juridico') or public.pode('financeiro_contab')));
drop policy if exists documentos_incluir on public.documentos;
create policy documentos_incluir on public.documentos for insert to authenticated with check (public.pode('documentos','editar') or (oportunidade_id is not null and public.pode('crm','editar')));
drop policy if exists documentos_alterar on public.documentos;
create policy documentos_alterar on public.documentos for update to authenticated using (public.pode('documentos','editar') or (oportunidade_id is not null and public.pode('crm','editar')))
  with check (public.pode('documentos','editar') or (oportunidade_id is not null and public.pode('crm','editar')));
do $$
begin
  if exists (select 1 from information_schema.schemata where schema_name = 'storage') then
    execute 'drop policy if exists documentos_ver on storage.objects';
    execute 'create policy documentos_ver on storage.objects for select to authenticated using (bucket_id = ''documentos'' and (public.pode(''documentos'') or public.pode(''crm'')))';
    execute 'drop policy if exists documentos_enviar on storage.objects';
    execute 'create policy documentos_enviar on storage.objects for insert to authenticated with check (bucket_id = ''documentos'' and (public.pode(''documentos'',''editar'') or public.pode(''crm'',''editar'')))';
  end if;
exception when insufficient_privilege then null;
end $$;

-- fluxo a partir de um modelo (prazos em dias úteis antes do prazo final), usado pelo "Ganhou"
create or replace function public.criar_fluxo_modelo(p_modelo text, p_fatal date, p_cliente uuid, p_grupo uuid, p_resp text, p_nome text)
returns uuid language plpgsql security definer set search_path = public as $$
declare m record; it jsonb; st jsonb; f uuid; pai uuid;
begin
  select * into m from public.modelos_fluxo where nome = p_modelo limit 1;
  if not found then return null; end if;
  insert into public.fluxos (nome, cliente_id, grupo_id, modelo_id, responsavel, inicio, prazo_fatal)
  values (coalesce(p_nome, m.nome), p_cliente, p_grupo, m.id, coalesce(p_resp, ''), current_date, p_fatal) returning id into f;
  for it in select * from jsonb_array_elements(m.itens) loop
    insert into public.tarefas (fluxo_id, cliente_id, grupo_id, titulo, responsavel, status, prioridade, inicio, prazo, prazo_fatal, checklist)
    values (f, p_cliente, p_grupo, it->>'titulo', coalesce(nullif(it->>'responsavel', ''), p_resp, ''), 'pendente', 'media', current_date,
            public.somar_uteis(p_fatal, -coalesce((it->>'dias')::int, 0)),
            case when coalesce((it->>'dias')::int, 0) = 0 then p_fatal end,
            coalesce((select jsonb_agg(jsonb_build_object('texto', c, 'feito', false)) from jsonb_array_elements_text(coalesce(it->'checklist', '[]')) c), '[]'))
    returning id into pai;
    for st in select * from jsonb_array_elements(coalesce(it->'subtarefas', '[]')) loop
      insert into public.tarefas (fluxo_id, tarefa_pai_id, cliente_id, grupo_id, titulo, responsavel, status, prioridade, inicio, prazo)
      values (f, pai, p_cliente, p_grupo, st->>'titulo', coalesce(p_resp, ''), 'pendente', 'media', current_date, public.somar_uteis(p_fatal, -coalesce((st->>'dias')::int, 0)));
    end loop;
  end loop;
  return f;
end $$;
revoke all on function public.criar_fluxo_modelo(text, date, uuid, uuid, text, text) from anon, authenticated;

-- "Ganhou": cliente (se novo), contrato + parcelas, fluxo de onboarding, linha do tempo, proposta aceita
create or replace function public.crm_ganhar(p_op uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o record; cli uuid; grp uuid; ctr uuid; flx uuid; resp text; etp uuid;
begin
  if not public.pode('crm', 'editar') then raise exception 'Sem a função CRM (editar).'; end if;
  select * into o from public.crm_oportunidades where id = p_op;
  if not found then raise exception 'Oportunidade não encontrada.'; end if;
  resp := coalesce(nullif(p->>'responsavel', ''), o.responsavel);
  cli := coalesce(nullif(p->>'cliente_id', '')::uuid, o.cliente_id);
  if cli is null then
    if coalesce(p->>'cliente_nome', '') = '' then raise exception 'Informe o nome do cliente.'; end if;
    if coalesce(p->>'grupo', '') <> '' then
      select id into grp from public.grupos where lower(nome) = lower(p->>'grupo') limit 1;
      if grp is null then insert into public.grupos (nome) values (p->>'grupo') returning id into grp; end if;
    end if;
    insert into public.clientes (nome, cpf_cnpj, email, telefone, grupo_id, responsavel, tipo, origem)
    values (p->>'cliente_nome', coalesce(p->>'cpf_cnpj', ''), coalesce(p->>'email', ''), coalesce(p->>'telefone', ''), grp, coalesce(resp, ''), 'Consultoria', 'CRM')
    returning id into cli;
  else
    select grupo_id into grp from public.clientes where id = cli;
  end if;
  if coalesce((p->>'valor_total')::numeric, 0) > 0 or coalesce(p->>'descricao', '') <> '' then
    perform set_config('erp.sem_regra_onboarding', case when coalesce((p->>'criar_fluxo')::boolean, true) then '1' else '' end, true);
    insert into public.contratos (cliente_id, descricao, valor_total, num_parcelas, primeiro_vencimento, percentual_exito, responsavel)
    values (cli, coalesce(nullif(p->>'descricao', ''), o.titulo), coalesce((p->>'valor_total')::numeric, 0), greatest(1, coalesce((p->>'num_parcelas')::int, 1)),
            nullif(p->>'primeiro_vencimento', '')::date, nullif(p->>'percentual_exito', '')::numeric, coalesce(resp, ''))
    returning id into ctr;
    perform set_config('erp.sem_regra_onboarding', '', true);
  end if;
  if coalesce((p->>'criar_fluxo')::boolean, true) then
    flx := public.criar_fluxo_modelo('Onboarding de cliente', public.somar_uteis(current_date, 15), cli, grp, resp,
                                     'Onboarding — ' || coalesce(p->>'cliente_nome', (select nome from public.clientes where id = cli)));
  end if;
  insert into public.interacoes (cliente_id, tipo, resumo) values (cli, 'anotacao', 'Contrato fechado pelo CRM: ' || o.titulo);
  update public.crm_propostas set status = 'aceita' where id = (select id from public.crm_propostas where oportunidade_id = p_op order by versao desc limit 1);
  update public.documentos set cliente_id = cli, grupo_id = grp, contrato_id = coalesce(ctr, contrato_id) where oportunidade_id = p_op;
  select id into etp from public.crm_etapas where final = 'ganho' order by ordem limit 1;
  update public.crm_oportunidades set etapa_id = etp, probabilidade = 100, ganho_em = now(), perdido_em = null, cliente_id = cli, contrato_id = ctr where id = p_op;
  return jsonb_build_object('cliente_id', cli, 'contrato_id', ctr, 'fluxo_id', flx);
end $$;
revoke all on function public.crm_ganhar(uuid, jsonb) from anon;
grant execute on function public.crm_ganhar(uuid, jsonb) to authenticated;

create or replace function public.crm_perder(p_op uuid, p_motivo text, p_reativar boolean) returns void
language plpgsql security definer set search_path = public as $$
declare o record; etp uuid;
begin
  if not public.pode('crm', 'editar') then raise exception 'Sem a função CRM (editar).'; end if;
  if coalesce(btrim(p_motivo), '') = '' then raise exception 'Informe o motivo da perda.'; end if;
  select * into o from public.crm_oportunidades where id = p_op;
  select id into etp from public.crm_etapas where final = 'perdido' order by ordem limit 1;
  update public.crm_oportunidades set etapa_id = etp, probabilidade = 0, perdido_em = now(), ganho_em = null, motivo_perda = p_motivo where id = p_op;
  if p_reativar then
    perform public.tarefa_da_regra('crm-reativar:' || p_op, 'Reativar contato: ' || o.titulo, o.responsavel, current_date + 180, o.cliente_id);
  end if;
end $$;
revoke all on function public.crm_perder(uuid, text, boolean) from anon;
grant execute on function public.crm_perder(uuid, text, boolean) to authenticated;

-- proposta por e-mail (vai pela mesma fila dos avisos)
create or replace function public.crm_enviar_proposta(p_proposta uuid, p_para text, p_html text) returns void
language plpgsql security definer set search_path = public as $$
declare pr record;
begin
  if not public.pode('crm', 'editar') then raise exception 'Sem a função CRM (editar).'; end if;
  if p_para !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'E-mail do destinatário inválido.'; end if;
  select * into pr from public.crm_propostas where id = p_proposta;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (auth.uid(), p_para, coalesce(nullif(pr.titulo, ''), 'Proposta de honorários'), p_html, 'proposta', 'proposta:' || p_proposta || ':' || pr.versao || ':' || md5(p_para))
  on conflict (usuario_id, referencia) where referencia <> '' do nothing;
  update public.crm_propostas set status = case when status = 'rascunho' then 'enviada' else status end, enviada_em = now() where id = p_proposta;
end $$;
revoke all on function public.crm_enviar_proposta(uuid, text, text) from anon;
grant execute on function public.crm_enviar_proposta(uuid, text, text) to authenticated;

-- o "Ganhou" já cria o fluxo completo: a regra de onboarding não duplica
create or replace function public.regra_contrato_novo() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; cl record; ck jsonb;
begin
  if current_setting('erp.sem_regra_onboarding', true) = '1' then return null; end if;
  select * into rg from public.regras_tarefas where chave = 'contrato_onboarding' and ligada;
  if not found then return null; end if;
  select * into cl from public.clientes where id = new.cliente_id;
  select coalesce(jsonb_agg(jsonb_build_object('texto', i->>'titulo', 'feito', false)), '[]') into ck
    from public.modelos_fluxo m, jsonb_array_elements(m.itens) i where m.nome = 'Onboarding de cliente';
  perform public.tarefa_da_regra('onb:' || new.id, 'Onboarding: ' || coalesce(cl.nome, new.descricao),
    coalesce(nullif(rg.responsavel, ''), nullif(new.responsavel, ''), cl.responsavel),
    public.somar_uteis(coalesce(new.data_contrato, current_date), rg.dias), new.cliente_id, cl.grupo_id, new.id, ck,
    'Contrato: ' || new.descricao);
  return null;
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- v11 (2026-09-27) — BUSCADOR DE PUBLICAÇÕES (Diário de Justiça Eletrônico Nacional)
-- A função "erp-publicacoes" consulta a API pública e gratuita do CNJ
-- (Comunica PJe) pelas OABs cadastradas e guarda aqui, sem duplicar.
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.oabs_monitoradas (
  id uuid primary key default gen_random_uuid(),
  numero text not null check (btrim(numero) <> ''), uf text not null default 'MG', advogado text not null default '',
  ativo boolean not null default true,
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now(),
  unique (numero, uf)
);
create table if not exists public.publicacoes (
  id uuid primary key default gen_random_uuid(),
  id_origem text not null unique,
  data_disponibilizacao date, tribunal text not null default '', orgao text not null default '', tipo text not null default '',
  processo text not null default '', processo_numero text not null default '', classe text not null default '',
  texto text not null default '', link text not null default '', destinatarios text not null default '', advogados text not null default '',
  oab_numero text not null default '', oab_uf text not null default '', advogado text not null default '',
  processo_id uuid references public.processos(id) on delete set null,
  status text not null default 'nova' check (status in ('nova','lida','tratada','descartada')),
  tarefa_id uuid references public.tarefas(id) on delete set null,
  bruto jsonb,
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists publicacoes_data on public.publicacoes (data_disponibilizacao desc);

-- nova publicação: liga ao processo cadastrado e avisa o advogado (sino e e-mail)
create or replace function public.publicacao_nova() returns trigger
language plpgsql security definer set search_path = public as $$
declare quem uuid;
begin
  if new.processo_id is null and new.processo_numero <> '' then
    update public.publicacoes set processo_id = (select id from public.processos where regexp_replace(numero, '\D', '', 'g') = new.processo_numero limit 1)
     where id = new.id;
  end if;
  quem := public.usuario_por_nome(new.advogado);
  if quem is not null then
    insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link)
    values (quem, 'publicacao', 'Publicação nova: ' || coalesce(nullif(new.tipo, ''), 'comunicação') || ' — ' || coalesce(nullif(new.processo, ''), new.tribunal),
            new.tribunal || coalesce(' · ' || to_char(new.data_disponibilizacao, 'DD/MM/YYYY'), ''), 'publicacoes');
  end if;
  return null;
end $$;
drop trigger if exists publicacao_nova on public.publicacoes;
create trigger publicacao_nova after insert on public.publicacoes for each row execute function public.publicacao_nova();

do $$
declare t text;
begin
  foreach t in array array['oabs_monitoradas','publicacoes'] loop
    execute format('alter table public.%1$s enable row level security', t);
    execute format('revoke all on public.%1$s from anon', t);
    execute format('grant select, insert, update, delete on public.%1$s to authenticated', t);
    execute format('drop trigger if exists atualizado_%1$s on public.%1$s', t);
    execute format('create trigger atualizado_%1$s before update on public.%1$s for each row execute function public.marcar_atualizacao()', t);
    execute format('drop policy if exists %1$s_ver on public.%1$s', t);
    execute format('create policy %1$s_ver on public.%1$s for select to authenticated using (public.pode(''juridico''))', t);
    execute format('drop policy if exists %1$s_incluir on public.%1$s', t);
    execute format('create policy %1$s_incluir on public.%1$s for insert to authenticated with check (public.pode(''juridico'',''editar''))', t);
    execute format('drop policy if exists %1$s_alterar on public.%1$s', t);
    execute format('create policy %1$s_alterar on public.%1$s for update to authenticated using (public.pode(''juridico'',''editar'')) with check (public.pode(''juridico'',''editar''))', t);
    execute format('drop policy if exists %1$s_excluir on public.%1$s', t);
    execute format('create policy %1$s_excluir on public.%1$s for delete to authenticated using (public.eh_admin())', t);
  end loop;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant select, insert, update on public.oabs_monitoradas, public.publicacoes, public.configuracoes to service_role';
  end if;
end $$;
insert into public.config_privada (chave, valor) values ('api_publicacoes', to_jsonb('https://comunicaapi.pje.jus.br/api/v1'::text)) on conflict (chave) do nothing;

-- busca automática: dias úteis às 7h e às 13h (Brasília)
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_publicacoes';
  perform cron.schedule('erp_publicacoes', '0 10,16 * * 1-5', $cron$
    select net.http_post(
      url := (select valor #>> '{}' from public.config_privada where chave = 'url_projeto') || '/functions/v1/erp-publicacoes',
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-erp-segredo', (select valor #>> '{}' from public.config_privada where chave = 'segredo_funcoes')),
      body := '{}'::jsonb)
    where exists (select 1 from public.oabs_monitoradas where ativo)
  $cron$);
exception when others then
  raise notice 'Agendador indisponível: use o botão "Buscar agora" em Jurídico → Publicações.';
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- v12 (2026-09-28) — reimportar substituindo, contratos recorrentes,
-- alertas, atualização diária do CNPJ
-- ═══════════════════════════════════════════════════════════════════
-- apaga o que veio de planilha (chave_importacao) de um tipo, para importar de novo do zero
create or replace function public.limpar_importados(p_tipo text) returns int
language plpgsql security definer set search_path = public as $$
declare n int := 0;
begin
  if not public.eh_admin() then raise exception 'Só o administrador substitui importações.'; end if;
  if p_tipo = 'financeiro' then delete from public.lancamentos where empresa = 'escritorio' and chave_importacao is not null;
  elsif p_tipo = 'contabilidade' then delete from public.lancamentos where empresa = 'contabilidade' and chave_importacao is not null;
  elsif p_tipo = 'acordos' then delete from public.acordos where chave_importacao is not null;
  elsif p_tipo = 'processos' then delete from public.processos where chave_importacao is not null;
  elsif p_tipo = 'parcelamentos' then delete from public.parcelamentos where chave_importacao is not null;   -- as parcelas vão junto
  elsif p_tipo = 'tarefas' then delete from public.tarefas where chave_importacao is not null;
  elsif p_tipo = 'base' then raise exception 'Clientes não são apagados na substituição (têm contratos e documentos ligados): use Atualizar.';
  else raise exception 'Tipo de planilha desconhecido: %', p_tipo;
  end if;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.limpar_importados(text) from anon;
grant execute on function public.limpar_importados(text) to authenticated;

-- ─────────── contratos: consultoria recorrente (valor fixo ou em salários mínimos) ───────────
-- Consultoria: 1 lançamento por mês de COMPETÊNCIA, pago no mês seguinte (dia escolhido), até a
-- rescisão. Em salários mínimos, cada competência usa o salário mínimo do ANO da competência;
-- ao cadastrar o salário mínimo novo, as mensalidades em aberto daquele ano são reajustadas sozinhas.
-- Serviço pontual: como antes (valor total dividido em parcelas).
alter table public.contratos add column if not exists modalidade text not null default 'pontual';
alter table public.contratos add column if not exists forma_valor text not null default 'fixo';
alter table public.contratos add column if not exists valor_mensal numeric(14,2);
alter table public.contratos add column if not exists qtd_salarios numeric(7,3);
alter table public.contratos add column if not exists dia_vencimento int not null default 10;
alter table public.contratos add column if not exists inicio_competencia date;
alter table public.contratos add column if not exists rescindido_em date;
alter table public.contratos drop constraint if exists contratos_modalidade_check;
alter table public.contratos add constraint contratos_modalidade_check check (modalidade in ('pontual','consultoria'));
alter table public.contratos drop constraint if exists contratos_forma_valor_check;
alter table public.contratos add constraint contratos_forma_valor_check check (forma_valor in ('fixo','salario_minimo'));
alter table public.contratos drop constraint if exists contratos_dia_vencimento_check;
alter table public.contratos add constraint contratos_dia_vencimento_check check (dia_vencimento between 1 and 28);
alter table public.lancamentos add column if not exists competencia date;
alter table public.lancamentos add column if not exists chave_recorrencia text;
create unique index if not exists lancamentos_chave_recorrencia on public.lancamentos (chave_recorrencia) where chave_recorrencia is not null;

create table if not exists public.salarios_minimos (
  ano int primary key check (ano between 2000 and 2100), valor numeric(10,2) not null check (valor > 0),
  atualizado_em timestamptz not null default now()
);
insert into public.salarios_minimos (ano, valor) values (2025, 1518.00), (2026, 1621.00) on conflict (ano) do nothing;
alter table public.salarios_minimos enable row level security;
revoke all on public.salarios_minimos from anon;
grant select, insert, update, delete on public.salarios_minimos to authenticated;
drop policy if exists salarios_minimos_ver on public.salarios_minimos;
create policy salarios_minimos_ver on public.salarios_minimos for select to authenticated using (public.eh_equipe());
drop policy if exists salarios_minimos_admin on public.salarios_minimos;
create policy salarios_minimos_admin on public.salarios_minimos for all to authenticated using (public.eh_admin()) with check (public.eh_admin());

-- salário mínimo do ano (se o ano ainda não foi cadastrado, o último conhecido)
create or replace function public.salario_minimo(p_ano int) returns numeric
language sql stable set search_path = public as $$
  select valor from public.salarios_minimos where ano <= p_ano order by ano desc limit 1;
$$;
create or replace function public.valor_competencia(c public.contratos, comp date) returns numeric
language sql stable set search_path = public as $$
  select case when c.forma_valor = 'salario_minimo'
              then round(coalesce(c.qtd_salarios, 0) * coalesce(public.salario_minimo(extract(year from comp)::int), 0), 2)
              else coalesce(c.valor_mensal, 0) end;
$$;

-- gera as mensalidades que faltam (até 2 meses à frente), reajusta as em aberto e aplica a rescisão
drop function if exists public.gerar_mensalidades(uuid);
create or replace function public.gerar_mensalidades(p_contrato uuid default null, p_ate date default null) returns int
language plpgsql security definer set search_path = public as $$
declare c public.contratos; comp date; fim date; venc date; g uuid; resp text; n int := 0; k int; sm_falta boolean;
begin
  for c in select * from public.contratos where modalidade = 'consultoria' and (p_contrato is null or id = p_contrato) loop
    select grupo_id, responsavel into g, resp from public.clientes where id = c.cliente_id;
    -- rescisão: nada a partir da competência do mês da rescisão (rescindido em set → cobra até a competência de ago)
    if c.rescindido_em is not null then
      delete from public.lancamentos where contrato_id = c.id and chave_recorrencia is not null and not pago
         and competencia >= date_trunc('month', c.rescindido_em)::date;
    end if;
    if c.status in ('Cancelado') then continue; end if;
    comp := date_trunc('month', coalesce(c.inicio_competencia, c.data_contrato))::date;
    fim := date_trunc('month', coalesce(p_ate, (current_date + interval '2 months')::date))::date;
    if c.rescindido_em is not null then fim := least(fim, (date_trunc('month', c.rescindido_em) - interval '1 month')::date); end if;
    while comp <= fim loop
      venc := make_date(extract(year from comp + interval '1 month')::int, extract(month from comp + interval '1 month')::int, c.dia_vencimento);
      sm_falta := c.forma_valor = 'salario_minimo' and not exists (select 1 from public.salarios_minimos where ano = extract(year from comp)::int);
      insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia,
                                      competencia, vencimento, valor, chave_recorrencia, obs)
      values ('escritorio', 'receita', c.descricao || ' — competência ' || to_char(comp, 'MM/YYYY'), 'Consultoria mensal', c.cliente_id, c.id, g,
              coalesce(nullif(c.responsavel, ''), resp, ''), to_char(comp, 'MM/YYYY'), comp, venc, greatest(public.valor_competencia(c, comp), 0.01),
              'rec:' || c.id || ':' || to_char(comp, 'YYYY-MM'),
              case when sm_falta then 'Salário mínimo de ' || extract(year from comp)::int || ' ainda não cadastrado: valor provisório, reajusta sozinho.' else '' end)
      on conflict (chave_recorrencia) where chave_recorrencia is not null do nothing;
      get diagnostics k = row_count; n := n + k;
      comp := (comp + interval '1 month')::date;
    end loop;
    -- reajuste das mensalidades em aberto (valor do contrato mudou ou saiu o salário mínimo do ano)
    update public.lancamentos l set valor = greatest(public.valor_competencia(c, l.competencia), 0.01),
           obs = case when c.forma_valor = 'salario_minimo' and not exists (select 1 from public.salarios_minimos where ano = extract(year from l.competencia)::int)
                      then l.obs else regexp_replace(l.obs, 'Salário mínimo de \d{4} ainda não cadastrado: valor provisório, reajusta sozinho\.', '') end
     where l.contrato_id = c.id and l.chave_recorrencia is not null and not l.pago
       and l.valor is distinct from greatest(public.valor_competencia(c, l.competencia), 0.01);
  end loop;
  return n;
end $$;
revoke all on function public.gerar_mensalidades(uuid, date) from anon;
grant execute on function public.gerar_mensalidades(uuid, date) to authenticated;

create or replace function public.contrato_recorrente() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.modalidade = 'consultoria' then perform public.gerar_mensalidades(new.id); end if;
  return null;
end $$;
drop trigger if exists contrato_recorrente on public.contratos;
create trigger contrato_recorrente after insert or update on public.contratos for each row execute function public.contrato_recorrente();

create or replace function public.salario_minimo_mudou() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.gerar_mensalidades(id) from public.contratos where modalidade = 'consultoria' and forma_valor = 'salario_minimo';
  return null;
end $$;
drop trigger if exists salario_minimo_mudou on public.salarios_minimos;
create trigger salario_minimo_mudou after insert or update or delete on public.salarios_minimos for each statement execute function public.salario_minimo_mudou();

-- contrato de consultoria não usa a divisão em parcelas do serviço pontual
create or replace function public.gerar_parcelas_contrato() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  i int; base numeric(14,2); v numeric(14,2); g uuid;
begin
  if new.modalidade = 'consultoria' then return new; end if;
  if new.valor_total > 0 and new.primeiro_vencimento is not null then
    select grupo_id into g from public.clientes where id = new.cliente_id;
    base := trunc(new.valor_total / new.num_parcelas, 2);
    for i in 1..new.num_parcelas loop
      v := case when i = new.num_parcelas
                then new.valor_total - base * (new.num_parcelas - 1) else base end;
      insert into public.lancamentos
        (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia,
         parcela, total_parcelas, vencimento, valor)
      values
        ('escritorio', 'receita', new.descricao || case when new.num_parcelas > 1
                                          then ' — parcela ' || i || '/' || new.num_parcelas else '' end,
         'Honorários', new.cliente_id, new.id, g, new.responsavel,
         case when new.num_parcelas > 1 then i || '/' || new.num_parcelas else '' end,
         i, new.num_parcelas, (new.primeiro_vencimento + make_interval(months => i - 1))::date, v);
    end loop;
  end if;
  return new;
end $$;

-- rotina diária: cria a mensalidade do próximo mês de cada consultoria ativa
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_mensalidades';
  perform cron.schedule('erp_mensalidades', '30 9 * * *', 'select public.gerar_mensalidades()');
exception when others then
  raise notice 'Agendador indisponível: as mensalidades são geradas ao salvar o contrato e ao abrir Contratos.';
end $$;

-- ─────────── cartão CNPJ: atualização diária (6h) com relatório ───────────
alter table public.clientes add column if not exists razao_social text not null default '';
alter table public.clientes add column if not exists nome_fantasia text not null default '';
alter table public.clientes add column if not exists cnae_principal text not null default '';
alter table public.clientes add column if not exists porte text not null default '';
alter table public.clientes add column if not exists data_abertura date;
alter table public.clientes add column if not exists data_situacao date;
alter table public.clientes add column if not exists cep text not null default '';
alter table public.clientes add column if not exists cnpj_atualizado_em timestamptz;
alter table public.clientes add column if not exists cnpj_dados jsonb;

create table if not exists public.cnpj_execucoes (
  id uuid primary key default gen_random_uuid(),
  inicio timestamptz not null default now(), fim timestamptz,
  status text not null default 'rodando' check (status in ('rodando','ok','parcial','erro')),
  origem text not null default 'rotina', provedor text not null default '',
  total int not null default 0, consultados int not null default 0, alterados int not null default 0, erros int not null default 0,
  relatorio jsonb not null default '[]',        -- [{cliente_id, nome, cnpj, mudancas:[{campo, antes, depois}], erro}]
  mensagem text not null default ''
);
alter table public.cnpj_execucoes enable row level security;
revoke all on public.cnpj_execucoes from anon;
grant select on public.cnpj_execucoes to authenticated;
drop policy if exists cnpj_execucoes_ver on public.cnpj_execucoes;
create policy cnpj_execucoes_ver on public.cnpj_execucoes for select to authenticated using (public.eh_equipe());
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant select, insert, update on public.cnpj_execucoes, public.clientes to service_role';
  end if;
end $$;
insert into public.config_privada (chave, valor) values ('api_cnpj', '{"provedor":"brasilapi","token":""}') on conflict (chave) do nothing;

-- escolher a API do cartão CNPJ (só admin; o token, se houver, não volta para a tela)
create or replace function public.salvar_config_cnpj(p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare atual jsonb;
begin
  if not public.eh_admin() then raise exception 'Só o administrador.'; end if;
  select valor into atual from public.config_privada where chave = 'api_cnpj';
  if coalesce(p->>'token', '') = '' then p := p || jsonb_build_object('token', coalesce(atual->>'token', '')); end if;
  insert into public.config_privada (chave, valor) values ('api_cnpj', p) on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
end $$;
create or replace function public.status_config_cnpj() returns jsonb
language sql security definer set search_path = public as $$
  select case when public.eh_equipe() then coalesce((select (valor - 'token') || jsonb_build_object('tem_token', coalesce(valor->>'token', '') <> '') from public.config_privada where chave = 'api_cnpj'), '{}') end;
$$;
revoke all on function public.salvar_config_cnpj(jsonb) from anon;
revoke all on function public.status_config_cnpj() from anon;
grant execute on function public.salvar_config_cnpj(jsonb), public.status_config_cnpj() to authenticated;

-- todo dia às 6h (Brasília = 9h UTC)
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_cnpj';
  perform cron.schedule('erp_cnpj', '0 9 * * *', $cron$
    select net.http_post(
      url := (select valor #>> '{}' from public.config_privada where chave = 'url_projeto') || '/functions/v1/erp-cnpj',
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-erp-segredo', (select valor #>> '{}' from public.config_privada where chave = 'segredo_funcoes')),
      body := '{"acao":"rodar"}'::jsonb)
  $cron$);
exception when others then
  raise notice 'Agendador indisponível: use o botão "Atualizar agora" em Alertas → Cartão CNPJ.';
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- v13 — Desempenho: índices dos filtros mais usados e totais prontos no banco
-- ═══════════════════════════════════════════════════════════════════
create index if not exists lanc_emp_pago_venc on public.lancamentos (empresa, pago, vencimento);
create index if not exists acordos_pago_venc on public.acordos (pago, vencimento);
create index if not exists tarefas_status_prazo on public.tarefas (status, prazo);
create index if not exists publicacoes_status on public.publicacoes (status);

-- Totais do mês por empresa (escritorio / contabilidade), já com a comissão como redutor.
-- Roda com as permissões de quem chama (RLS): cada pessoa soma só o que pode ver.
-- Resultado: {"escritorio": {"recebido":…, "n_recebido":…, "a_receber":…, "n_a_receber":…,
--             "em_atraso":…, "n_em_atraso":…, "a_pagar":…, "n_a_pagar":…}, "contabilidade": {…}}
create or replace function public.resumo_financeiro(p_empresa text default null, p_de date default null, p_ate date default null)
returns jsonb language sql stable security invoker set search_path = public as $$
  with per as (
    select coalesce(p_de, date_trunc('month', current_date)::date) as de,
           coalesce(p_ate, (date_trunc('month', current_date) + interval '1 month - 1 day')::date) as ate
  ), l as (
    select l.empresa, l.tipo, l.pago, l.perda, l.vencimento, l.data_pagamento,
           case when l.redutor then -l.valor else l.valor end as v
      from public.lancamentos l
     where p_empresa is null or l.empresa = p_empresa
  ), t as (
    select e.empresa,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and l.pago and l.data_pagamento between per.de and per.ate), 0) as recebido,
      count(*)          filter (where l.tipo = 'receita' and l.pago and l.data_pagamento between per.de and per.ate) as n_recebido,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento between per.de and per.ate), 0) as a_receber,
      count(*)          filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento between per.de and per.ate) as n_a_receber,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento < current_date), 0) as em_atraso,
      count(*)          filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento < current_date) as n_em_atraso,
      coalesce(sum(l.v) filter (where l.tipo = 'despesa' and not l.pago and not l.perda and l.vencimento between per.de and per.ate), 0) as a_pagar,
      count(*)          filter (where l.tipo = 'despesa' and not l.pago and not l.perda and l.vencimento between per.de and per.ate) as n_a_pagar
    from (select unnest(array['escritorio','contabilidade']) as empresa) e
    cross join per
    left join l on l.empresa = e.empresa
    where p_empresa is null or e.empresa = p_empresa
    group by e.empresa
  )
  select coalesce(jsonb_object_agg(empresa, to_jsonb(t) - 'empresa'), '{}'::jsonb) from t;
$$;
revoke all on function public.resumo_financeiro(text, date, date) from public, anon;
grant execute on function public.resumo_financeiro(text, date, date) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- v14 — Cartão CNPJ: empresa que fica INAPTA/SUSPENSA/BAIXADA/NULA vira tarefa + aviso (e-mail)
-- Vale para a atualização diária (erp-cnpj) e para edição manual. Não dispara no primeiro
-- preenchimento (situação anterior vazia) nem quando volta a ATIVA.
-- ═══════════════════════════════════════════════════════════════════
create or replace function public.cnpj_situacao_mudou() returns trigger
language plpgsql security definer set search_path = public as $$
declare quem uuid; titulo text; det text;
begin
  if coalesce(old.situacao_cadastral, '') = '' or upper(new.situacao_cadastral) = upper(old.situacao_cadastral)
     or upper(coalesce(new.situacao_cadastral, '')) not in ('INAPTA','SUSPENSA','BAIXADA','NULA') then
    return null;
  end if;
  titulo := new.nome || ' ficou ' || upper(new.situacao_cadastral) || ' na Receita Federal';
  det := 'Antes: ' || old.situacao_cadastral || coalesce(' · desde ' || to_char(new.data_situacao, 'DD/MM/YYYY'), '') || ' · CNPJ ' || new.cpf_cnpj;
  insert into public.tarefas (chave_regra, titulo, responsavel, prazo, inicio, cliente_id, grupo_id, prioridade, descricao)
  values ('cnpj:' || new.id || ':' || upper(new.situacao_cadastral) || ':' || current_date, 'Verificar: ' || titulo,
          coalesce(nullif(new.responsavel, ''), ''), current_date + 2, current_date, new.id, new.grupo_id, 'alta',
          det || '. Confira no cartão CNPJ (Alertas → Cartão CNPJ) e fale com o cliente.')
  on conflict do nothing;
  for quem in
    select distinct u from (
      select public.usuario_por_nome(new.responsavel) as u
      union all select id from public.perfis where papel = 'admin'
    ) x where u is not null
  loop
    insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link) values (quem, 'cnpj', titulo, det, 'alertas');
  end loop;
  return null;
end $$;
drop trigger if exists cnpj_situacao_mudou on public.clientes;
create trigger cnpj_situacao_mudou after update of situacao_cadastral on public.clientes
  for each row execute function public.cnpj_situacao_mudou();

-- ═══════════════════════════════════════════════════════════════════
-- v15 — Google Agenda: um link secreto por pessoa (função erp-agenda devolve os prazos em .ics)
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.agenda_links (
  token text primary key,
  usuario_id uuid not null unique references public.perfis(id) on delete cascade,
  criado_em timestamptz not null default now()
);
alter table public.agenda_links enable row level security;   -- sem policy: só a função (service role) lê
revoke all on public.agenda_links from anon, authenticated;

create or replace function public.meu_link_agenda(p_novo boolean default false) returns text
language plpgsql security definer set search_path = public as $$
declare t text;
begin
  if not public.eh_equipe() then raise exception 'Só a equipe do escritório tem agenda.'; end if;
  if p_novo then delete from public.agenda_links where usuario_id = auth.uid(); end if;
  select token into t from public.agenda_links where usuario_id = auth.uid();
  if t is null then
    t := replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '');
    insert into public.agenda_links (token, usuario_id) values (t, auth.uid());
  end if;
  return t;
end $$;
revoke all on function public.meu_link_agenda(boolean) from public, anon;
grant execute on function public.meu_link_agenda(boolean) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- v16 — Segurança e rotina: backup semanal automático, saúde do sistema e registro de acessos
-- ═══════════════════════════════════════════════════════════════════
-- tabelas que entram no backup (manual e automático): todas do sistema, menos segredos e filas técnicas
create or replace function public.listar_tabelas_backup() returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(table_name::text order by table_name), '{}')
    from information_schema.tables
   where table_schema = 'public' and table_type = 'BASE TABLE'
     and table_name not in ('config_privada', 'agenda_links', 'email_fila', 'acessos', 'backups_auto');
$$;
revoke all on function public.listar_tabelas_backup() from public, anon;
grant execute on function public.listar_tabelas_backup() to authenticated;

create table if not exists public.backups_auto (
  id uuid primary key default gen_random_uuid(),
  criado_em timestamptz not null default now(),
  origem text not null default 'rotina',          -- rotina (semanal) | manual
  caminho text not null,                          -- arquivo no bucket privado "backups"
  tamanho bigint not null default 0,
  resumo jsonb not null default '{}'::jsonb       -- registros por tabela
);
alter table public.backups_auto enable row level security;
revoke all on public.backups_auto from anon;
grant select on public.backups_auto to authenticated;
drop policy if exists backups_auto_ver on public.backups_auto;
create policy backups_auto_ver on public.backups_auto for select to authenticated using (public.eh_admin());

do $$
begin
  if exists (select 1 from information_schema.schemata where schema_name = 'storage') then
    insert into storage.buckets (id, name, public, file_size_limit)
    values ('backups', 'backups', false, 209715200) on conflict (id) do nothing;
    execute 'drop policy if exists backups_ver on storage.objects';
    execute 'create policy backups_ver on storage.objects for select to authenticated using (bucket_id = ''backups'' and public.eh_admin())';
  end if;
exception when others then raise notice 'Storage indisponível aqui (normal no teste local).';
end $$;

-- toda semana, domingo às 3h de Brasília (6h UTC)
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_backup';
  perform cron.schedule('erp_backup', '0 6 * * 0', $cron$
    select net.http_post(
      url := (select valor #>> '{}' from public.config_privada where chave = 'url_projeto') || '/functions/v1/erp-backup',
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-erp-segredo', (select valor #>> '{}' from public.config_privada where chave = 'segredo_funcoes')),
      body := '{"acao":"rodar"}'::jsonb)
  $cron$);
exception when others then
  raise notice 'Agendador indisponível: use "Fazer backup agora" em Administração → Backup.';
end $$;

-- saúde do sistema (admin): tamanho do banco e dos arquivos x limites do plano grátis do Supabase
create or replace function public.saude_sistema() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare arq bigint := 0; nobj int := 0;
begin
  if not public.eh_admin() then raise exception 'Só o administrador vê a saúde do sistema.'; end if;
  begin
    execute 'select coalesce(sum((metadata->>''size'')::bigint), 0), count(*) from storage.objects' into arq, nobj;
  exception when others then arq := 0; nobj := 0;
  end;
  return jsonb_build_object(
    'banco_bytes', pg_database_size(current_database()), 'banco_limite', 500 * 1024 * 1024,
    'arquivos_bytes', arq, 'arquivos_qtd', nobj, 'arquivos_limite', 1024 * 1024 * 1024,
    'ultimo_backup', (select max(criado_em) from public.backups_auto),
    'maiores', (select coalesce(jsonb_agg(x), '[]') from (
        select relname as tabela, pg_total_relation_size(c.oid) as bytes
          from pg_class c join pg_namespace n on n.oid = c.relnamespace
         where n.nspname = 'public' and c.relkind = 'r' order by 2 desc limit 6) x));
end $$;
revoke all on function public.saude_sistema() from public, anon;
grant execute on function public.saude_sistema() to authenticated;

-- registro de acessos: quem entrou, quando e de qual aparelho; aparelho novo avisa a própria pessoa
create table if not exists public.acessos (
  id bigint generated always as identity primary key,
  usuario_id uuid not null references public.perfis(id) on delete cascade,
  quando timestamptz not null default now(),
  dispositivo text not null default '',          -- identificador aleatório guardado no navegador
  navegador text not null default '',
  novo boolean not null default false
);
create index if not exists acessos_usuario on public.acessos (usuario_id, quando desc);
alter table public.acessos enable row level security;
revoke all on public.acessos from anon;
grant select on public.acessos to authenticated;
drop policy if exists acessos_ver on public.acessos;
create policy acessos_ver on public.acessos for select to authenticated using (public.eh_admin() or usuario_id = auth.uid());

create or replace function public.registrar_acesso(p_dispositivo text, p_navegador text) returns boolean
language plpgsql security definer set search_path = public as $$
declare ja_viu boolean; tem_antes boolean; nav text := left(coalesce(p_navegador, ''), 120);
begin
  if auth.uid() is null then return false; end if;
  perform pg_advisory_xact_lock(hashtext('acesso:' || auth.uid()::text));   -- duas abas ao mesmo tempo: uma espera a outra
  -- no máximo um registro por pessoa/aparelho a cada 30 min (recarregar a página não conta)
  if exists (select 1 from public.acessos where usuario_id = auth.uid() and dispositivo = coalesce(p_dispositivo, '') and quando > now() - interval '30 minutes') then
    return false;
  end if;
  select exists (select 1 from public.acessos where usuario_id = auth.uid() and dispositivo = coalesce(p_dispositivo, '')) into ja_viu;
  select exists (select 1 from public.acessos where usuario_id = auth.uid()) into tem_antes;
  insert into public.acessos (usuario_id, dispositivo, navegador, novo) values (auth.uid(), coalesce(p_dispositivo, ''), nav, tem_antes and not ja_viu);
  if tem_antes and not ja_viu then
    insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link)
    values (auth.uid(), 'acesso', 'Novo acesso ao ERP de um aparelho novo', nav || ' · ' || to_char(now() at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI') ||
            '. Se não foi você, troque sua senha e avise o administrador.', 'hoje');
  end if;
  delete from public.acessos where quando < now() - interval '180 days';
  return tem_antes and not ja_viu;
end $$;
revoke all on function public.registrar_acesso(text, text) from public, anon;
grant execute on function public.registrar_acesso(text, text) to authenticated;


-- ═══════════════════════════════════════════════════════════════════
-- v17 — Automações encadeadas: um lançamento dispara várias ações, tudo registrado
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.automacoes_log (
  id bigint generated always as identity primary key,
  quando timestamptz not null default now(),
  chave text not null,                 -- prefixo da regra (onb, anexo, procur, cob, email_lh…)
  ref text not null default '',        -- o que foi tratado (evita repetir e-mail/tarefa)
  descricao text not null default '',
  cliente_id uuid references public.clientes(id) on delete set null
);
create index if not exists automacoes_log_quando on public.automacoes_log (chave, quando desc);
create index if not exists automacoes_log_ref on public.automacoes_log (ref);
alter table public.automacoes_log enable row level security;
revoke all on public.automacoes_log from anon;
grant select on public.automacoes_log to authenticated;
drop policy if exists automacoes_log_ver on public.automacoes_log;
create policy automacoes_log_ver on public.automacoes_log for select to authenticated using (public.eh_equipe());

-- grupo de cada automação na Central (tarefas | cliente_email | integracao)
alter table public.regras_tarefas add column if not exists grupo text not null default 'tarefas';
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias, grupo) values
  ('contrato_anexo', 'Contrato novo → anexar o contrato assinado', 'Tarefa em N dias úteis; conclui sozinha quando o contrato ganha o anexo em Documentos', true, 5, 'tarefas'),
  ('processo_procuracao', 'Processo novo sem procuração → providenciar procuração', 'Quando nenhuma empresa do grupo tem procuração; conclui sozinha ao marcar "Procuração: Sim" no cadastro', true, 5, 'tarefas'),
  ('pagamento_conclui', 'Honorário recebido → conclui a tarefa de cobrança', 'Ao marcar o lançamento como pago, a tarefa "Cobrar honorário" dele é concluída sozinha', true, 0, 'tarefas'),
  ('publicacao_tarefa', 'Publicação nova ligada a processo → tarefa para analisar', 'Para o advogado da OAB, prazo em N dias úteis (confira o prazo legal na publicação)', false, 5, 'tarefas'),
  ('cliente_novo_cnpj', 'Cliente novo com CNPJ → busca os dados na Receita', 'Ao cadastrar (não na importação): razão social, endereço, situação… Empresa recém-aberta fica "aguardando" e é tentada todo dia', true, 0, 'integracao'),
  ('email_lembrete_honorario', 'E-mail ao cliente: lembrete de honorário', 'N dias antes do vencimento, para o contato financeiro (ou o e-mail do cadastro)', false, 3, 'cliente_email'),
  ('email_cobranca_honorario', 'E-mail ao cliente: cobrança educada', 'N dias depois do vencimento sem pagamento (uma vez por lançamento)', false, 3, 'cliente_email'),
  ('email_lembrete_acordo', 'E-mail ao cliente: lembrete de parcela de acordo', 'N dias antes do vencimento da parcela (dívida do cliente com terceiros)', false, 3, 'cliente_email'),
  ('email_pagamento_recebido', 'E-mail ao cliente: pagamento recebido', 'Assim que o honorário é marcado como pago', false, 0, 'cliente_email')
on conflict (chave) do nothing;
update public.regras_tarefas set grupo = 'tarefas' where grupo is null;

-- quem recebe e-mail do cliente: contato financeiro/cobrança/boletos; senão o e-mail do cadastro; senão outra empresa do grupo
create or replace function public.email_do_cliente(p_cliente uuid, p_grupo uuid) returns text
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select c.email from public.contatos c where c.cliente_id = p_cliente and c.email <> '' and (c.recebe_boletos or c.finalidade in ('financeiro','cobranca')) order by c.recebe_boletos desc limit 1),
    (select nullif(cl.email, '') from public.clientes cl where cl.id = p_cliente),
    (select c.email from public.contatos c join public.clientes cl on cl.id = c.cliente_id where p_cliente is null and cl.grupo_id = p_grupo and c.email <> ''
       and (c.recebe_boletos or c.finalidade in ('financeiro','cobranca')) order by c.recebe_boletos desc limit 1),
    (select cl.email from public.clientes cl where p_cliente is null and cl.grupo_id = p_grupo and cl.email <> '' and cl.tipo <> 'Inativo' order by cl.nome limit 1));
$$;
revoke all on function public.email_do_cliente(uuid, uuid) from public, anon, authenticated;

create or replace function public.brl_texto(v numeric) returns text language sql immutable as $$
  select 'R$ ' || replace(replace(replace(to_char(coalesce(v, 0), 'FM999G999G990D00'), ',', '#'), '.', ','), '#', '.');
$$;

-- manda um e-mail ao cliente uma vez só por "ref" (não repete a mesma cobrança)
create or replace function public.email_ao_cliente(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_assunto text, p_corpo text) returns boolean
language plpgsql security definer set search_path = public as $$
declare para text;
begin
  if exists (select 1 from public.automacoes_log where ref = p_ref) then return false; end if;
  para := public.email_do_cliente(p_cliente, p_grupo);
  if para is null or para = '' then return false; end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (null, para, p_assunto, public.email_modelo(p_assunto, p_corpo), 'cliente', p_ref);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, p_assunto || ' → ' || para, p_cliente);
  return true;
end $$;
revoke all on function public.email_ao_cliente(text, text, uuid, uuid, text, text) from public, anon, authenticated;

-- e-mails do passo diário (rodar_regras_tarefas chama)
create or replace function public.rodar_emails_cliente() returns int
language plpgsql security definer set search_path = public as $$
declare rg record; x record; n int := 0; esc text;
begin
  select * into rg from public.regras_tarefas where chave = 'email_lembrete_honorario' and ligada;
  if found then
    for x in select l.id, l.valor, l.vencimento, l.descricao, l.referencia, l.cliente_id, l.grupo_id from public.lancamentos l
              where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false) and l.vencimento = current_date + rg.dias loop
      if public.email_ao_cliente('email_lh', 'email_lh:' || x.id, x.cliente_id, x.grupo_id,
           'Lembrete: honorários com vencimento em ' || to_char(x.vencimento, 'DD/MM/YYYY'),
           '<p>Olá!</p><p>Lembramos que os honorários <b>' || public.esc_html(x.descricao || coalesce(' ' || nullif(x.referencia, ''), '')) || '</b>, no valor de <b>' ||
           public.brl_texto(x.valor) || '</b>, vencem em <b>' || to_char(x.vencimento, 'DD/MM/YYYY') || '</b>.</p><p>Se já pagou, desconsidere esta mensagem.</p><p>Araújo &amp; Castro Advocacia</p>') then n := n + 1; end if;
    end loop;
  end if;
  select * into rg from public.regras_tarefas where chave = 'email_cobranca_honorario' and ligada;
  if found then
    for x in select l.id, l.valor, l.vencimento, l.descricao, l.referencia, l.cliente_id, l.grupo_id from public.lancamentos l
              where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false) and l.vencimento = current_date - rg.dias loop
      if public.email_ao_cliente('email_ch', 'email_ch:' || x.id, x.cliente_id, x.grupo_id,
           'Honorários em aberto desde ' || to_char(x.vencimento, 'DD/MM/YYYY'),
           '<p>Olá!</p><p>Não identificamos o pagamento dos honorários <b>' || public.esc_html(x.descricao || coalesce(' ' || nullif(x.referencia, ''), '')) || '</b>, de <b>' ||
           public.brl_texto(x.valor) || '</b>, com vencimento em ' || to_char(x.vencimento, 'DD/MM/YYYY') || '.</p><p>Se já pagou, por favor nos envie o comprovante respondendo este e-mail. Qualquer dúvida, estamos à disposição.</p><p>Araújo &amp; Castro Advocacia</p>') then n := n + 1; end if;
    end loop;
  end if;
  select * into rg from public.regras_tarefas where chave = 'email_lembrete_acordo' and ligada;
  if found then
    for x in select a.id, a.valor, a.vencimento, a.credor, a.parcela, a.total_parcelas, a.processo, a.grupo_id,
                    (select cl.id from public.clientes cl where cl.grupo_id = a.grupo_id and public.primeiro_nome(cl.nome) = public.primeiro_nome(a.devedor) limit 1) cli
               from public.acordos a where not a.pago and a.vencimento = current_date + rg.dias loop
      if public.email_ao_cliente('email_la', 'email_la:' || x.id, x.cli, x.grupo_id,
           'Lembrete: parcela do acordo vence em ' || to_char(x.vencimento, 'DD/MM/YYYY'),
           '<p>Olá!</p><p>A parcela <b>' || coalesce(x.parcela, '') || coalesce('/' || x.total_parcelas, '') || '</b> do acordo com <b>' || public.esc_html(coalesce(x.credor, '')) ||
           '</b> (processo ' || public.esc_html(coalesce(x.processo, '')) || '), de <b>' || public.brl_texto(x.valor) || '</b>, vence em <b>' || to_char(x.vencimento, 'DD/MM/YYYY') ||
           '</b>.</p><p>Depois de pagar, nos envie o comprovante respondendo este e-mail.</p><p>Araújo &amp; Castro Advocacia</p>') then n := n + 1; end if;
    end loop;
  end if;
  return n;
end $$;
revoke all on function public.rodar_emails_cliente() from public, anon, authenticated;

-- contrato novo → tarefa "anexar contrato assinado"
create or replace function public.regra_contrato_anexo() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; cl record;
begin
  select * into rg from public.regras_tarefas where chave = 'contrato_anexo' and ligada;
  if not found or current_setting('erp.sem_regra_onboarding', true) = '1' then return null; end if;
  if exists (select 1 from public.documentos d where d.contrato_id = new.id) then return null; end if;
  select * into cl from public.clientes where id = new.cliente_id;
  perform public.tarefa_da_regra('anexo:' || new.id, 'Anexar o contrato assinado — ' || new.descricao || coalesce(' (' || cl.nome || ')', ''),
    coalesce(nullif(rg.responsavel, ''), nullif(new.responsavel, ''), cl.responsavel), public.somar_uteis(coalesce(new.data_contrato, current_date), rg.dias),
    new.cliente_id, cl.grupo_id, new.id, '[]', 'Envie o PDF assinado em Contratos → abrir o contrato → Documentos. A tarefa se conclui sozinha.');
  return null;
end $$;
drop trigger if exists regra_contrato_anexo on public.contratos;
create trigger regra_contrato_anexo after insert on public.contratos for each row execute function public.regra_contrato_anexo();

-- documento ligado ao contrato → conclui "anexar contrato"
create or replace function public.anexo_conclui_tarefa() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if new.contrato_id is null then return null; end if;
  update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(i || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) i)
   where chave_regra = 'anexo:' || new.contrato_id and status not in ('concluida','cancelada');
  get diagnostics n = row_count;
  if n > 0 then insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('anexo', 'anexo-ok:' || new.contrato_id, 'Contrato anexado: tarefa concluída sozinha', new.cliente_id); end if;
  return null;
end $$;
drop trigger if exists anexo_conclui_tarefa on public.documentos;
create trigger anexo_conclui_tarefa after insert or update of contrato_id on public.documentos for each row execute function public.anexo_conclui_tarefa();

-- processo novo de grupo sem nenhuma procuração → tarefa "providenciar procuração"
create or replace function public.regra_processo_procuracao() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; g record;
begin
  select * into rg from public.regras_tarefas where chave = 'processo_procuracao' and ligada;
  if not found or new.chave_importacao is not null or new.grupo_id is null or new.procuracao is true then return null; end if;
  if exists (select 1 from public.clientes where grupo_id = new.grupo_id and procuracao is true) then return null; end if;
  select * into g from public.grupos where id = new.grupo_id;
  perform public.tarefa_da_regra('procur:' || new.grupo_id, 'Providenciar procuração — ' || coalesce(g.nome, 'grupo'),
    coalesce(nullif(rg.responsavel, ''), new.advogado), public.somar_uteis(current_date, rg.dias), null, new.grupo_id, null,
    '[{"texto":"Gerar a procuração","feito":false},{"texto":"Colher assinatura","feito":false},{"texto":"Marcar Procuração: Sim no cadastro","feito":false}]',
    'Processo ' || new.numero || ' cadastrado e nenhuma empresa do grupo tem procuração.', new.numero);
  return null;
end $$;
drop trigger if exists regra_processo_procuracao on public.processos;
create trigger regra_processo_procuracao after insert on public.processos for each row execute function public.regra_processo_procuracao();

-- procuração marcada no cadastro → conclui a tarefa do grupo
create or replace function public.procuracao_conclui_tarefa() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if new.procuracao is not true or old.procuracao is true or new.grupo_id is null then return null; end if;
  update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(i || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) i)
   where chave_regra = 'procur:' || new.grupo_id and status not in ('concluida','cancelada');
  get diagnostics n = row_count;
  if n > 0 then insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('procur', 'procur-ok:' || new.id, 'Procuração marcada: tarefa concluída sozinha', new.id); end if;
  return null;
end $$;
drop trigger if exists procuracao_conclui_tarefa on public.clientes;
create trigger procuracao_conclui_tarefa after update of procuracao on public.clientes for each row execute function public.procuracao_conclui_tarefa();

-- honorário pago → conclui "cobrar honorário" + (opcional) e-mail de confirmação ao cliente
create or replace function public.pagamento_automacoes() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not new.pago or old.pago or new.tipo <> 'receita' or new.redutor then return null; end if;
  if exists (select 1 from public.regras_tarefas where chave = 'pagamento_conclui' and ligada) then
    update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(i || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) i) where chave_regra = 'cob:' || new.id and status not in ('concluida','cancelada');
    get diagnostics n = row_count;
    if n > 0 then insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('pagamento_conclui', 'pago:' || new.id, 'Honorário recebido: cobrança concluída sozinha — ' || new.descricao, new.cliente_id); end if;
  end if;
  if exists (select 1 from public.regras_tarefas where chave = 'email_pagamento_recebido' and ligada) then
    perform public.email_ao_cliente('email_pr', 'email_pr:' || new.id, new.cliente_id, new.grupo_id, 'Recebemos o seu pagamento',
      '<p>Olá!</p><p>Confirmamos o recebimento de <b>' || public.brl_texto(new.valor) || '</b> referente a <b>' || public.esc_html(new.descricao || coalesce(' ' || nullif(new.referencia, ''), '')) ||
      '</b>' || coalesce(', em ' || to_char(new.data_pagamento, 'DD/MM/YYYY'), '') || '. Obrigado!</p><p>Araújo &amp; Castro Advocacia</p>');
  end if;
  return null;
end $$;
drop trigger if exists pagamento_automacoes on public.lancamentos;
create trigger pagamento_automacoes after update of pago on public.lancamentos for each row execute function public.pagamento_automacoes();

-- publicação nova ligada a processo → tarefa (começa desligada: prazo legal precisa de conferência)
create or replace function public.publicacao_tarefa() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; pr record;
begin
  select * into rg from public.regras_tarefas where chave = 'publicacao_tarefa' and ligada;
  if not found or new.processo_id is null or new.tarefa_id is not null then return null; end if;
  select * into pr from public.processos where id = new.processo_id;
  perform public.tarefa_da_regra('pub:' || new.id, 'Analisar publicação — ' || coalesce(nullif(new.tipo, ''), 'comunicação') || ' · ' || coalesce(pr.numero, new.processo),
    coalesce(nullif(rg.responsavel, ''), nullif(new.advogado, ''), pr.advogado), public.somar_uteis(coalesce(new.data_disponibilizacao, current_date), rg.dias),
    null, pr.grupo_id, null, '[]', 'Prazo sugerido: confira o prazo legal no texto da publicação (Jurídico → Publicações).', coalesce(pr.numero, new.processo));
  update public.publicacoes set tarefa_id = (select id from public.tarefas where chave_regra = 'pub:' || new.id) where id = new.id and tarefa_id is null;
  return null;
end $$;
drop trigger if exists publicacao_tarefa on public.publicacoes;
create trigger publicacao_tarefa after update of processo_id on public.publicacoes for each row execute function public.publicacao_tarefa();

-- Central de automações: quantas vezes cada uma agiu nos últimos 30 dias
create or replace function public.resumo_automacoes() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(chave, n), '{}') from (
    select chave, count(*) n from public.automacoes_log where quando > now() - interval '30 days' and chave <> '_item' group by chave) x
  where public.eh_equipe();
$$;
revoke all on function public.resumo_automacoes() from public, anon;
grant execute on function public.resumo_automacoes() to authenticated;


-- ═══════════════════════════════════════════════════════════════════
-- v18 — Área do cliente (Jurídico / Contabilidade / Ambos) e quem vê cada área;
--       rascunho de estagiário (nível "Propor": só vale depois de aprovado);
--       êxito dos contratos (lança % × X quando acontece); comprovante do acordo.
-- ═══════════════════════════════════════════════════════════════════

-- ─────────── acordos: comprovante juntado ao processo ───────────
alter table public.acordos add column if not exists comprovante_processo boolean;
alter table public.acordos add column if not exists comprovante_id text not null default '';

-- ─────────── área do cliente e áreas que cada usuário vê ───────────
alter table public.clientes add column if not exists area text not null default 'ambos';
alter table public.perfis add column if not exists areas text not null default 'ambos';
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'clientes_area_check') then
    alter table public.clientes add constraint clientes_area_check check (area in ('juridico','contabil','ambos'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'perfis_areas_check') then
    alter table public.perfis add constraint perfis_areas_check check (areas in ('juridico','contabil','ambos'));
  end if;
end $$;
create index if not exists clientes_area on public.clientes (area);

-- migração (uma vez só): sugere a área pelo que o cliente já tem no sistema
--   só lançamentos da contabilidade → Contabilidade; só coisas do jurídico → Jurídico; os dois ou nada → Ambos
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'migracao_v18_area') then
    update public.clientes c set area = case
        when x.contab and not x.jur then 'contabil'
        when x.jur and not x.contab then 'juridico'
        else 'ambos' end
      from (select c2.id,
              exists (select 1 from public.lancamentos l where l.empresa = 'contabilidade' and (l.cliente_id = c2.id or (c2.grupo_id is not null and l.grupo_id = c2.grupo_id))) contab,
              exists (select 1 from public.lancamentos l where l.empresa = 'escritorio' and (l.cliente_id = c2.id or (c2.grupo_id is not null and l.grupo_id = c2.grupo_id)))
                or exists (select 1 from public.processos p where c2.grupo_id is not null and p.grupo_id = c2.grupo_id)
                or exists (select 1 from public.contratos k where k.cliente_id = c2.id) jur
            from public.clientes c2) x
     where x.id = c.id;
    insert into public.configuracoes (chave, valor) values ('migracao_v18_area', '{"feito":true}');
  end if;
end $$;

-- a pessoa logada vê clientes desta área? (admin e "ambas" veem tudo; cliente "ambos" todos veem)
create or replace function public.ve_area(a text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select p.papel = 'admin' or p.areas = 'ambos' or coalesce(a, 'ambos') = 'ambos' or a = p.areas
                     from public.perfis p where p.id = auth.uid()), false);
$$;
create or replace function public.ve_cliente(c uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select c is null or coalesce((select public.ve_area(area) from public.clientes where id = c), true);
$$;
revoke all on function public.ve_area(text) from anon;
revoke all on function public.ve_cliente(uuid) from anon;
grant execute on function public.ve_area(text) to authenticated;
grant execute on function public.ve_cliente(uuid) to authenticated;

-- regra RESTRITIVA: soma-se às regras de função (não substitui). Quem só vê Jurídico não lê,
-- nem grava, cliente só da Contabilidade — nem os contatos, contratos e documentos dele.
drop policy if exists clientes_area on public.clientes;
create policy clientes_area on public.clientes as restrictive for all to authenticated
  using (public.ve_area(area)) with check (public.ve_area(area));
do $$
declare t text;
begin
  foreach t in array array['contatos','enderecos','contas_bancarias','vinculos_societarios','cliente_etiquetas','interacoes','certidoes','documentos','contratos'] loop
    execute format('drop policy if exists %1$s_area on public.%1$s', t);
    execute format('create policy %1$s_area on public.%1$s as restrictive for all to authenticated using (public.ve_cliente(cliente_id)) with check (public.ve_cliente(cliente_id))', t);
  end loop;
end $$;

-- pode(f,'ver') = pode ver; pode(f,'editar') = grava. (Backup 41: o nível "Propor"/rascunho saiu.)
create or replace function public.pode(f text, nivel text default 'ver') returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((
    select case when p.papel = 'admin' then true
                when p.papel <> 'equipe' then false
                when coalesce(p.funcoes->>f, '') = 'editar' then true
                when coalesce(p.funcoes->>f, '') = 'ver' then nivel = 'ver'
                else false end
      from public.perfis p where p.id = auth.uid()), false);
$$;

-- ─────────── êxito: como foi combinado + registros (vira lançamento só quando acontece) ───────────
alter table public.contratos add column if not exists exito_base text;
alter table public.contratos add column if not exists exito_regra text not null default '';
create table if not exists public.exitos (
  id            uuid primary key default gen_random_uuid(),
  contrato_id   uuid not null references public.contratos(id) on delete cascade,
  cliente_id    uuid references public.clientes(id) on delete set null,
  data          date not null default current_date,
  base_valor    numeric(16,2) not null check (base_valor > 0),     -- o X (ex.: a economia obtida)
  percentual    numeric(5,2) not null,
  valor         numeric(14,2) not null,                             -- percentual × X
  descricao     text not null default '',
  lancamento_id uuid references public.lancamentos(id) on delete set null,
  criado_por    uuid default auth.uid(),
  criado_em     timestamptz not null default now()
);
create index if not exists exitos_contrato on public.exitos (contrato_id, data);
alter table public.exitos enable row level security;
revoke all on public.exitos from anon;
grant select on public.exitos to authenticated;
drop policy if exists exitos_ver on public.exitos;
create policy exitos_ver on public.exitos for select to authenticated using (public.pode('contratos') and public.ve_cliente(cliente_id));

create or replace function public.registrar_exito(p_contrato uuid, p_base numeric, p_data date, p_vencimento date, p_descricao text default '')
returns uuid language plpgsql security definer set search_path = public as $$
declare c record; v numeric(14,2); lanc uuid;
begin
  if not public.pode('contratos', 'editar') then raise exception 'permission denied: só quem edita Contratos registra êxito.'; end if;
  select k.*, cl.grupo_id, cl.responsavel resp_cliente into c from public.contratos k join public.clientes cl on cl.id = k.cliente_id where k.id = p_contrato;
  if c.id is null or not public.ve_cliente(c.cliente_id) then raise exception 'Contrato não encontrado.'; end if;
  if coalesce(c.percentual_exito, 0) <= 0 then raise exception 'Este contrato não tem %% de êxito.'; end if;
  if coalesce(p_base, 0) <= 0 then raise exception 'Informe o valor-base (X) maior que zero.'; end if;
  v := round(p_base * c.percentual_exito / 100, 2);
  insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia, vencimento, valor, obs)
  values ('escritorio', 'receita', c.descricao || ' — êxito', 'Êxito', c.cliente_id, c.id, c.grupo_id, coalesce(nullif(c.responsavel, ''), c.resp_cliente, ''),
          replace(c.percentual_exito::text, '.', ',') || '% de ' || public.brl_texto(p_base), coalesce(p_vencimento, p_data, current_date), v,
          coalesce(nullif(p_descricao, ''), 'Êxito registrado em ' || to_char(coalesce(p_data, current_date), 'DD/MM/YYYY')))
  returning id into lanc;
  insert into public.exitos (contrato_id, cliente_id, data, base_valor, percentual, valor, descricao, lancamento_id)
  values (c.id, c.cliente_id, coalesce(p_data, current_date), p_base, c.percentual_exito, v, coalesce(p_descricao, ''), lanc);
  return lanc;
end $$;
revoke all on function public.registrar_exito(uuid, numeric, date, date, text) from public, anon;
grant execute on function public.registrar_exito(uuid, numeric, date, date, text) to authenticated;
-- fim da v18


-- ═══════════════════════════════════════════════════════════════════
-- v19 — Início sem números sobrepostos, caixa de avisos, e-mails por finalidade
-- ═══════════════════════════════════════════════════════════════════

-- "A receber" e "A pagar" do mês = de hoje até o fim do período (o que já venceu fica só em "Em atraso")
create or replace function public.resumo_financeiro(p_empresa text default null, p_de date default null, p_ate date default null)
returns jsonb language sql stable security invoker set search_path = public as $$
  with per as (
    select coalesce(p_de, date_trunc('month', current_date)::date) as de,
           coalesce(p_ate, (date_trunc('month', current_date) + interval '1 month - 1 day')::date) as ate
  ), l as (
    select l.empresa, l.tipo, l.pago, l.perda, l.vencimento, l.data_pagamento,
           case when l.redutor then -l.valor else l.valor end as v
      from public.lancamentos l
     where p_empresa is null or l.empresa = p_empresa
  ), t as (
    select e.empresa,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and l.pago and l.data_pagamento between per.de and per.ate), 0) as recebido,
      count(*)          filter (where l.tipo = 'receita' and l.pago and l.data_pagamento between per.de and per.ate) as n_recebido,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate), 0) as a_receber,
      count(*)          filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate) as n_a_receber,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento < current_date), 0) as em_atraso,
      count(*)          filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento < current_date) as n_em_atraso,
      coalesce(sum(l.v) filter (where l.tipo = 'despesa' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate), 0) as a_pagar,
      count(*)          filter (where l.tipo = 'despesa' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate) as n_a_pagar
    from (select unnest(array['escritorio','contabilidade']) as empresa) e
    cross join per
    left join l on l.empresa = e.empresa
    where p_empresa is null or e.empresa = p_empresa
    group by e.empresa
  )
  select coalesce(jsonb_object_agg(empresa, to_jsonb(t) - 'empresa'), '{}'::jsonb) from t;
$$;

-- cada pessoa escolhe como quer ser chamada (barra superior e "Olá, …")
create or replace function public.salvar_meu_nome(p text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or btrim(coalesce(p, '')) = '' then raise exception 'Informe o nome.'; end if;
  update public.perfis set nome = left(btrim(p), 80) where id = auth.uid();
end $$;
revoke all on function public.salvar_meu_nome(text) from public, anon;
grant execute on function public.salvar_meu_nome(text) to authenticated;

-- caixa de avisos: o que cada pessoa já leu (por assunto + leva). Se o assunto continuar sem solução,
-- a próxima leva (amanhã para os urgentes, semana que vem para os demais) aparece de novo como não lida.
create table if not exists public.avisos_lidos (
  usuario_id uuid not null default auth.uid() references public.perfis(id) on delete cascade,
  chave      text not null,
  lido_em    timestamptz not null default now(),
  primary key (usuario_id, chave)
);
alter table public.avisos_lidos enable row level security;
revoke all on public.avisos_lidos from anon;
grant select, insert, delete on public.avisos_lidos to authenticated;
drop policy if exists avisos_lidos_meus on public.avisos_lidos;
create policy avisos_lidos_meus on public.avisos_lidos for all to authenticated
  using (usuario_id = auth.uid()) with check (usuario_id = auth.uid());
-- limpeza: leituras com mais de 60 dias e notificações lidas com mais de 90 dias
delete from public.avisos_lidos where lido_em < now() - interval '60 days';
delete from public.notificacoes where lida and criado_em < now() - interval '90 days';

-- ─────────── dados de DEMONSTRAÇÃO (fictícios, marcados "DEMO ·") ───────────
-- Administração → Importar → "🧪 Demonstração": carregar (apaga a anterior e cria de novo) ou apagar.
-- E-mails usam domínios example.com (reservados: não chegam a ninguém). CNPJs começam com 99 (fictícios).
create or replace function public.limpar_demonstracao() returns int
language plpgsql security definer set search_path = public as $$
declare n int := 0; k int; gs uuid[]; cs uuid[];
begin
  if not public.eh_admin() then raise exception 'permission denied: só o administrador.'; end if;
  select coalesce(array_agg(id), '{}') into gs from public.grupos where nome like 'DEMO · %';
  select coalesce(array_agg(id), '{}') into cs from public.clientes where grupo_id = any(gs) or chave_importacao like 'demo:%';
  -- e-mails e registros de automação dos exemplos (example.com nunca recebe nada)
  delete from public.automacoes_log where cliente_id = any(cs) or descricao like '%example.com%';
  delete from public.email_fila where para like '%example.com';
  delete from public.crm_oportunidades where cliente_id = any(cs) or prospecto_empresa like 'DEMO · %';
  delete from public.tarefas where cliente_id = any(cs) or grupo_id = any(gs) or chave_importacao like 'demo:%';
  delete from public.documentos where cliente_id = any(cs) or grupo_id = any(gs);
  delete from public.exitos where cliente_id = any(cs);
  delete from public.lancamentos where cliente_id = any(cs) or grupo_id = any(gs) or chave_importacao like 'demo:%';
  delete from public.contratos where cliente_id = any(cs);
  delete from public.acordos where grupo_id = any(gs) or chave_importacao like 'demo:%';
  delete from public.parcelamentos where grupo_id = any(gs) or chave_importacao like 'demo:%';
  delete from public.processos where grupo_id = any(gs) or chave_importacao like 'demo:%';
  delete from public.clientes where id = any(cs);
  get diagnostics k = row_count; n := n + k;
  delete from public.grupos where id = any(gs);
  return n;
end $$;
revoke all on function public.limpar_demonstracao() from public, anon;
grant execute on function public.limpar_demonstracao() to authenticated;

create or replace function public.carregar_demonstracao() returns int
language plpgsql security definer set search_path = public as $$
declare
  h date := current_date; m0 date := date_trunc('month', current_date)::date;
  gh uuid; gs uuid; gm uuid; ct uuid; cl uuid; sa uuid; sc uuid; cm uuid; mp uuid;
  k1 uuid; k2 uuid; k3 uuid; k4 uuid; pa uuid; e1 uuid; e2 uuid; e4 uuid; i int;
begin
  if not public.eh_admin() then raise exception 'permission denied: só o administrador.'; end if;
  perform public.limpar_demonstracao();
  insert into public.grupos (nome) values ('DEMO · Grupo Horizonte') returning id into gh;
  insert into public.grupos (nome) values ('DEMO · Grupo Serra Verde') returning id into gs;
  insert into public.grupos (nome) values ('DEMO · Família Moreira') returning id into gm;
  -- clientes (áreas diferentes para testar as permissões)
  insert into public.clientes (grupo_id, nome, cpf_cnpj, tipo, area, responsavel, email, telefone, cidade, estado, socio_admin, rfb, pgfn, pgfn_negociada, age_mg, age_mg_negociada,
      em_operacao, procuracao, certificado, cadastro_regular, capag, regime_tributario, situacao_cadastral, tipo_societario, chave_importacao)
    values (gh, 'Horizonte Transportes Ltda', '99111222000133', 'Consultoria', 'ambos', 'Pedro', 'contato@horizonte.example.com', '(31) 99999-0001', 'Belo Horizonte', 'MG', 'Ricardo Horizonte',
      180000, 420000, 150000, 90000, 30000, true, true, true, true, 'B', 'LP', 'ATIVA', 'LTDA', 'demo:c1') returning id into ct;
  insert into public.clientes (grupo_id, nome, cpf_cnpj, tipo, area, responsavel, email, pgfn, capag, regime_tributario, situacao_cadastral, tipo_societario, em_operacao, procuracao, chave_importacao)
    values (gh, 'Horizonte Logística Eireli', '99111222000214', 'Demanda', 'juridico', 'Emanuelle', 'adm@horizontelog.example.com', 60000, 'C', 'SN', 'INAPTA', 'EI', false, false, 'demo:c2') returning id into cl;
  insert into public.clientes (grupo_id, nome, cpf_cnpj, tipo, area, responsavel, email, telefone, cidade, estado, sefaz_mg, capag, regime_tributario, situacao_cadastral, tipo_societario, em_operacao, procuracao, certificado, chave_importacao)
    values (gs, 'Serra Verde Alimentos S.A.', '99333444000155', 'Consultoria', 'contabil', 'Adriana', 'financeiro@serraverde.example.com', '(31) 98888-0002', 'Contagem', 'MG', 35000, 'A', 'LR', 'ATIVA', 'S.A', true, true, true, 'demo:c3') returning id into sa;
  insert into public.clientes (grupo_id, nome, cpf_cnpj, tipo, area, responsavel, rfb, capag, regime_tributario, situacao_cadastral, tipo_societario, chave_importacao)
    values (gs, 'Serra Verde Comércio Ltda', '99333444000236', 'Consultoria', 'ambos', 'Adriana', 25000, 'Omisso', 'SN', 'ATIVA', 'LTDA', 'demo:c4') returning id into sc;
  insert into public.clientes (grupo_id, nome, cpf_cnpj, tipo, area, responsavel, email, pgfn, tipo_societario, procuracao, chave_importacao)
    values (gm, 'Carlos Moreira (DEMO)', '99988877766', 'Demanda', 'juridico', 'Pedro', 'carlos@moreira.example.com', 80000, 'PF', true, 'demo:c5') returning id into cm;
  insert into public.clientes (grupo_id, nome, cpf_cnpj, tipo, area, responsavel, regime_tributario, situacao_cadastral, tipo_societario, chave_importacao)
    values (gm, 'Moreira Participações Ltda', '99555666000177', 'Consultoria', 'ambos', 'Pedro', 'LP', 'ATIVA', 'LTDA', 'demo:c6') returning id into mp;
  -- contatos por finalidade (e-mail do financeiro diferente do contato geral)
  insert into public.contatos (cliente_id, nome, cargo, finalidade, email, telefone, whatsapp, recebe_boletos, recebe_notificacoes) values
    (ct, 'Marta (financeiro)', 'Gerente financeira', 'financeiro', 'financeiro@horizonte.example.com', '(31) 99999-1001', true, true, false),
    (ct, 'Ricardo Horizonte', 'Sócio', 'juridico', 'ricardo@horizonte.example.com', '(31) 99999-1002', true, false, true),
    (sa, 'Paula (contas a pagar)', 'Analista', 'financeiro', 'pagar@serraverde.example.com', '(31) 98888-1003', false, true, false),
    (mp, 'Carlos Moreira', 'Sócio', 'geral', 'carlos@moreira.example.com', '(31) 97777-1004', true, true, true);
  insert into public.interacoes (cliente_id, tipo, quando, resumo) values
    (ct, 'reuniao', now() - interval '6 days', 'Reunião mensal: revisão do parcelamento da PGFN e plano para a AGE/MG.'),
    (sa, 'email', now() - interval '2 days', 'Enviado o fechamento contábil do mês e a guia do DAS.');
  insert into public.certidoes (cliente_id, orgao, situacao, emissao, validade) values
    (ct, 'CND Federal', 'Positiva com efeitos de negativa', h - 170, h + 10),
    (sa, 'CND Estadual (MG)', 'Negativa', h - 200, h - 3);
  -- contratos (as mensalidades e parcelas saem sozinhas)
  insert into public.contratos (cliente_id, descricao, modalidade, forma_valor, valor_mensal, dia_vencimento, inicio_competencia, data_contrato, responsavel, valor_total, num_parcelas)
    values (ct, 'DEMO · Consultoria tributária mensal', 'consultoria', 'fixo', 4500, 10, (m0 - interval '3 months')::date, (m0 - interval '3 months')::date, 'Pedro', 0, 1) returning id into k1;
  insert into public.contratos (cliente_id, descricao, modalidade, forma_valor, qtd_salarios, dia_vencimento, inicio_competencia, data_contrato, responsavel, valor_total, num_parcelas)
    values (sc, 'DEMO · Assessoria em salários mínimos', 'consultoria', 'salario_minimo', 1.5, 5, (m0 - interval '2 months')::date, (m0 - interval '2 months')::date, 'Adriana', 0, 1) returning id into k2;
  insert into public.contratos (cliente_id, descricao, modalidade, valor_total, num_parcelas, primeiro_vencimento, data_contrato, responsavel)
    values (cl, 'DEMO · Defesa em execução fiscal', 'pontual', 12000, 4, (m0 - interval '1 month' + interval '14 days')::date, (m0 - interval '1 month')::date, 'Emanuelle') returning id into k3;
  insert into public.contratos (cliente_id, descricao, modalidade, valor_total, num_parcelas, percentual_exito, exito_base, exito_regra, data_contrato, responsavel)
    values (mp, 'DEMO · Transação tributária PGFN (êxito)', 'pontual', 0, 1, 20, 'economia', '20% do valor que a dívida reduzir, pago em até 10 dias', (m0 - interval '2 months')::date, 'Pedro') returning id into k4;
  perform public.gerar_mensalidades(k1); perform public.gerar_mensalidades(k2);
  update public.lancamentos set grupo_id = (select grupo_id from public.clientes where id = cliente_id) where contrato_id in (k1, k2, k3, k4) and grupo_id is null;
  -- o que já passou foi pago, menos uma mensalidade (fica em atraso) e a parcela de hoje
  update public.lancamentos set pago = true, data_pagamento = vencimento + 1, forma_pagamento = 'PIX'
   where contrato_id in (k1, k2, k3) and vencimento < h - 20;
  update public.lancamentos set vencimento = h where id = (select id from public.lancamentos where contrato_id = k3 and not pago order by vencimento limit 1);
  -- contabilidade: honorários mensais da Serra Verde (um em atraso, um vence hoje) e uma despesa
  for i in 0..3 loop
    insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, grupo_id, responsavel, referencia, vencimento, valor, pago, data_pagamento, chave_importacao)
    values ('contabilidade', 'receita', 'Honorários contábeis ' || to_char(m0 - (i || ' months')::interval, 'MM/YYYY'), 'Honorários contábeis', sa, gs, 'Adriana',
            to_char(m0 - (i || ' months')::interval, 'MM/YYYY'), case when i = 0 then h else (m0 - (i || ' months')::interval + interval '9 days')::date end, 1800,
            i >= 2, case when i >= 2 then (m0 - (i || ' months')::interval + interval '10 days')::date end, 'demo:lc' || i);
  end loop;
  insert into public.lancamentos (empresa, tipo, descricao, categoria, favorecido, vencimento, valor, chave_importacao)
    values ('contabilidade', 'despesa', 'DEMO · Sistema contábil (licença)', 'Software', 'Fornecedor Exemplo', h + 5, 390, 'demo:ld1');
  insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, grupo_id, responsavel, vencimento, valor, redutor, pago, data_pagamento, chave_importacao)
    values ('escritorio', 'receita', 'DEMO · Comissão de indicação', 'Comissão', ct, gh, 'Pedro', h - 15, 450, true, true, h - 15, 'demo:lr1');
  -- jurídico: processos, parcelamento com parcelas e acordo
  insert into public.processos (grupo_id, carteira, advogado, numero, competencia, natureza, autor, reu, data_distribuicao, valor, procuracao, status, chave_importacao) values
    (gh, 'Ativo', 'Pedro', '9000001-11.2025.4.01.3800', 'JF - BH', 'Execução fiscal', 'União (PGFN)', 'Horizonte Transportes Ltda', h - 400, 420000, true, 'Em andamento', 'demo:p1'),
    (gh, 'Ativo', 'Emanuelle', '9000002-22.2025.8.13.0024', 'TJMG - BH', 'Anulatória de débito', 'Horizonte Logística Eireli', 'Estado de Minas Gerais', h - 120, 60000, false, 'Aguardando Decisão', 'demo:p2'),
    (gm, 'Ativo', 'Pedro', '9000003-33.2024.5.03.0001', 'TRT3', 'Trabalhista', 'Ex-empregado (fictício)', 'Moreira Participações Ltda', h - 700, 35000, true, 'Arq. Provisoriamente', 'demo:p3'),
    (gs, 'Prospecção', 'Adriana', '9000004-44.2026.4.01.3800', 'JF - BH', 'Mandado de segurança', 'Serra Verde Alimentos S.A.', 'Delegado da Receita Federal', null, 150000, false, 'Em prospecção', 'demo:p4');
  insert into public.parcelamentos (grupo_id, aba, empresa, cnpj, local, natureza, numero, total_parcelas, valor_ultima_parcela, valor_residual, chave_importacao)
    values (gh, 'PGFN', 'Horizonte Transportes Ltda', '99111222000133', 'PGFN', 'Transação tributária', 'DEMO-2025-001', 60, 2500, 135000, 'demo:pa1') returning id into pa;
  for i in 1..12 loop
    insert into public.parcelas (parcelamento_id, numero, vencimento, pago, chave_importacao)
    values (pa, i::text, (m0 - interval '8 months' + (i || ' months')::interval + interval '19 days')::date, (m0 - interval '8 months' + (i || ' months')::interval + interval '19 days')::date < h - 35, 'demo:pp' || i);
  end loop;
  insert into public.parcelamentos (grupo_id, aba, empresa, cnpj, local, natureza, numero, total_parcelas, valor_ultima_parcela, valor_residual, chave_importacao)
    values (gs, 'SEFAZ', 'Serra Verde Alimentos S.A.', '99333444000155', 'SEFAZ/MG', 'ICMS', 'DEMO-MG-77', 24, 1450, 18000, 'demo:pa2');
  for i in 1..6 loop
    insert into public.acordos (grupo_id, responsavel, processo, devedor, credor, parcela, total_parcelas, valor, vencimento, pago, data_pagamento, comprovante_processo, comprovante_id, chave_importacao)
    values (gs, 'Adriana', '9000005-55.2025.8.13.0079', 'Serra Verde Comércio Ltda', 'Fornecedor Exemplo S.A.', i::text, '6', 3200,
            case i when 3 then h - 6 when 4 then h else (m0 + ((i - 3) || ' months')::interval + interval '14 days')::date end,
            i <= 2, case when i <= 2 then (m0 + ((i - 3) || ' months')::interval + interval '14 days')::date end,
            case when i = 1 then true when i = 2 then false end, case when i = 1 then '123456789' else '' end, 'demo:ac' || i);
  end loop;
  -- tarefas ligadas (cliente, contrato, processo)
  insert into public.tarefas (titulo, cliente_id, grupo_id, contrato_id, processos_vinculados, responsavel, prioridade, status, inicio, prazo, prazo_fatal, descricao, checklist, chave_importacao) values
    ('DEMO · Protocolar embargos à execução', cl, gh, k3, '9000001-11.2025.4.01.3800', 'Emanuelle', 'Alta', 'andamento', h - 5, h + 2, h + 4, 'Prazo de 30 dias da intimação.',
      '[{"texto":"Reunir documentos","feito":true},{"texto":"Minutar peça","feito":false},{"texto":"Revisão do Pedro","feito":false}]', 'demo:t1'),
    ('DEMO · Conferir parcela da transação PGFN', ct, gh, k1, '', 'Pedro', 'Média', 'pendente', h - 2, h, null, 'Confirmar o pagamento da parcela do mês no Regularize.', '[]', 'demo:t2'),
    ('DEMO · Cobrar mensalidade em atraso', ct, gh, k1, '', 'Adriana', 'Alta', 'pendente', h - 10, h - 3, null, 'Mandar lembrete ao financeiro (Marta).', '[]', 'demo:t3'),
    ('DEMO · Fechamento contábil do mês', sa, gs, null, '', 'Adriana', 'Média', 'pendente', h, (m0 + interval '1 month + 4 days')::date, null, '', '[{"texto":"Conciliação bancária","feito":false},{"texto":"Folha","feito":false}]', 'demo:t4'),
    ('DEMO · Levantar redução da dívida (êxito)', mp, gm, k4, '', 'Pedro', 'Média', 'pendente', h, h + 12, null, 'Quando a transação for homologada, registrar o êxito no contrato.', '[]', 'demo:t5');
  -- CRM
  select id into e1 from public.crm_etapas order by ordem limit 1;
  select id into e2 from public.crm_etapas where nome = 'Proposta enviada' limit 1;
  select id into e4 from public.crm_etapas where nome = 'Negociação' limit 1;
  insert into public.crm_oportunidades (titulo, cliente_id, prospecto_empresa, prospecto_nome, prospecto_email, origem, etapa_id, valor_estimado, honorario_tipo, probabilidade, previsao_fechamento, responsavel, proxima_acao, proxima_acao_em) values
    ('DEMO · Holding familiar Moreira', mp, '', '', '', 'Cliente atual', e2, 25000, 'fixo', 60, h + 20, 'Pedro', 'Ligar para fechar a proposta', h + 2),
    ('DEMO · Recuperação de créditos de PIS/COFINS', null, 'DEMO · Mercado Bom Preço', 'João Exemplo', 'joao@bompreco.example.com', 'Indicação', e1, 40000, 'exito', 20, h + 45, 'Emanuelle', 'Agendar diagnóstico', h + 1),
    ('DEMO · Contabilidade completa', null, 'DEMO · Clínica Vida', 'Ana Exemplo', 'ana@clinicavida.example.com', 'Site', e4, 2200, 'mensal', 70, h + 10, 'Adriana', 'Enviar contrato', h);
  -- documentos (só o registro, sem arquivo: servem para ver os vencimentos)
  insert into public.documentos (cliente_id, grupo_id, contrato_id, tipo, nome, caminho, validade, obs) values
    (ct, gh, k1, 'contrato', 'DEMO · Contrato de consultoria (exemplo).pdf', 'demo/contrato-horizonte.pdf', null, 'Exemplo sem arquivo'),
    (sa, gs, null, 'certidao', 'DEMO · Alvará de funcionamento (exemplo).pdf', 'demo/alvara-serraverde.pdf', h + 7, 'Exemplo sem arquivo');
  -- tarefas automáticas antigas dos contratos de exemplo ficam concluídas (senão a demonstração nasce "atrasada")
  update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(it || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) it)
   where chave_regra is not null and prazo < h - 7 and status not in ('concluida','cancelada') and (cliente_id in (ct, cl, sa, sc, cm, mp) or contrato_id in (k1, k2, k3, k4));
  return (select count(*) from public.clientes where grupo_id in (gh, gs, gm));
end $$;
revoke all on function public.carregar_demonstracao() from public, anon;
grant execute on function public.carregar_demonstracao() to authenticated;

-- ─────────── e-mails ao cliente: modelo novo (marca, itens, total, como pagar) ───────────
-- dados que aparecem no quadro "Como pagar" (Administração → E-mail → Dados para pagamento)
insert into public.configuracoes (chave, valor) values ('dados_pagamento', '{"pix":"","banco":"","titular":"Araújo & Castro","whatsapp":"","assinatura":"Equipe Araújo & Castro"}')
on conflict (chave) do nothing;

-- e-mail certo para cada assunto: contato com a FINALIDADE pedida (financeiro, juridico…), depois quem recebe boletos/avisos, depois o do cadastro
drop function if exists public.contato_do_cliente(uuid, uuid, text);  -- Backup 26 mudou o retorno (setor/origem)
create or replace function public.contato_do_cliente(p_cliente uuid, p_grupo uuid, p_finalidade text default 'financeiro')
returns table (email text, nome text)
language sql stable security definer set search_path = public as $$
  -- 1) finalidade certa + marcado para receber (boletos no financeiro; avisos nos demais)  2) marcado para receber
  -- 3) finalidade certa  4) contato "geral"  5) e-mail do cadastro  6/7) o mesmo no grupo, quando não há cliente
  select x.email, x.nome from (
    select c.email, nullif(split_part(btrim(c.nome), ' ', 1), '') nome,
           case when f.certa and marca then 1 when marca then 2 when f.certa then 3 else 4 end ord
      from public.contatos c
      cross join lateral (select case when p_finalidade in ('financeiro','cobranca') then c.recebe_boletos else c.recebe_notificacoes end marca,
                                 -- "cobrança" e "financeiro" valem como a mesma finalidade
                                 (c.finalidade = p_finalidade or (p_finalidade in ('financeiro','cobranca') and c.finalidade in ('financeiro','cobranca'))) certa) f
     where c.cliente_id = p_cliente and c.email <> '' and (f.certa or c.finalidade = 'geral' or f.marca)
    union all
    select cl.email, null, 5 from public.clientes cl where cl.id = p_cliente and cl.email <> ''
    union all
    select c.email, nullif(split_part(btrim(c.nome), ' ', 1), ''), 6 from public.contatos c join public.clientes cl on cl.id = c.cliente_id
     where p_cliente is null and cl.grupo_id = p_grupo and c.email <> '' and (c.finalidade = p_finalidade or c.recebe_boletos
           or (p_finalidade in ('financeiro','cobranca') and c.finalidade in ('financeiro','cobranca')))
    union all
    select cl.email, null, 7 from public.clientes cl where p_cliente is null and cl.grupo_id = p_grupo and cl.email <> '' and cl.tipo <> 'Inativo'
  ) x order by x.ord limit 1;
$$;
revoke all on function public.contato_do_cliente(uuid, uuid, text) from public, anon, authenticated;
create or replace function public.email_do_cliente(p_cliente uuid, p_grupo uuid) returns text
language sql stable security definer set search_path = public as $$
  select email from public.contato_do_cliente(p_cliente, p_grupo, 'financeiro');
$$;
revoke all on function public.email_do_cliente(uuid, uuid) from public, anon, authenticated;

-- modelo do e-mail ao cliente: cabeçalho da marca, saudação, texto, tabela de itens com total, "como pagar" e assinatura
create or replace function public.email_cliente_html(p_titulo text, p_nome text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_fecho text default '')
returns text language plpgsql stable security definer set search_path = public as $$
declare d jsonb; itens text := ''; tot numeric := 0; i jsonb; pag text := '';
begin
  select valor into d from public.configuracoes where chave = 'dados_pagamento';
  d := coalesce(d, '{}');
  for i in select * from jsonb_array_elements(coalesce(p_itens, '[]')) loop
    itens := itens || '<tr><td style="padding:10px 12px;border-bottom:1px solid #EEF0F5">' || public.esc_html(i->>'descricao') || '</td>'
      || '<td style="padding:10px 12px;border-bottom:1px solid #EEF0F5;white-space:nowrap">' || coalesce(to_char((i->>'vencimento')::date, 'DD/MM/YYYY'), '') || '</td>'
      || '<td style="padding:10px 12px;border-bottom:1px solid #EEF0F5;text-align:right;white-space:nowrap;font-weight:bold">' || public.brl_texto((i->>'valor')::numeric) || '</td></tr>';
    tot := tot + coalesce((i->>'valor')::numeric, 0);
  end loop;
  if itens <> '' then
    itens := '<table role="presentation" style="width:100%;border-collapse:collapse;margin:14px 0;font-size:14px;border:1px solid #E5E7EB;border-radius:10px">'
      || '<tr style="background:#F7F8FB;color:#5B6472;font-size:11px;text-transform:uppercase;letter-spacing:.06em"><td style="padding:9px 12px">Descrição</td><td style="padding:9px 12px">Vencimento</td><td style="padding:9px 12px;text-align:right">Valor</td></tr>'
      || itens || case when jsonb_array_length(p_itens) > 1 then '<tr><td colspan="2" style="padding:10px 12px;font-weight:bold">Total</td><td style="padding:10px 12px;text-align:right;font-weight:bold;color:#1B2A4A">' || public.brl_texto(tot) || '</td></tr>' else '' end
      || '</table>';
  end if;
  if p_pagar and (coalesce(d->>'pix', '') <> '' or coalesce(d->>'banco', '') <> '') then
    pag := '<div style="background:#F5EDD6;border-left:4px solid #C9A84C;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13.5px"><b style="color:#1B2A4A">Como pagar</b><br>'
      || case when coalesce(d->>'pix', '') <> '' then 'PIX: <b>' || public.esc_html(d->>'pix') || '</b>' || coalesce(' · ' || nullif(public.esc_html(d->>'titular'), ''), '') || '<br>' else '' end
      || case when coalesce(d->>'banco', '') <> '' then public.esc_html(d->>'banco') || '<br>' else '' end
      || 'Depois de pagar, responda este e-mail com o comprovante.</div>';
  end if;
  return '<div style="font-family:Arial,Helvetica,sans-serif;background:#F0F2F7;padding:24px 12px">'
    || '<div style="max-width:620px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #E5E7EB">'
    || '<div style="background:#1B2A4A;padding:20px 24px;border-bottom:3px solid #C9A84C">'
    ||   '<div style="color:#C9A84C;font-family:Georgia,serif;font-size:20px;font-weight:bold">Araújo &amp; Castro</div>'
    ||   '<div style="color:#CBD5E1;font-size:11px;letter-spacing:.14em;text-transform:uppercase;margin-top:2px">Advocacia · Contabilidade · Consultoria</div></div>'
    || '<div style="padding:22px 24px;color:#1F2937;font-size:14.5px;line-height:1.6">'
    ||   '<div style="font-size:18px;font-weight:bold;color:#1B2A4A;margin-bottom:10px">' || public.esc_html(p_titulo) || '</div>'
    ||   case when p_nome = '-' then '' else '<p style="margin:0 0 10px">Olá' || coalesce(', ' || public.esc_html(nullif(p_nome, '')), '') || '!</p>' end
    ||   p_texto || itens || pag
    ||   case when p_fecho = '-' then '' else
           coalesce(nullif(p_fecho, ''), '<p style="margin:14px 0 0">Qualquer dúvida, é só responder este e-mail' || case when coalesce(d->>'whatsapp', '') <> '' then ' ou chamar no WhatsApp ' || public.esc_html(d->>'whatsapp') else '' end || '.</p>')
           || '<p style="margin:16px 0 0">Atenciosamente,<br><b>' || public.esc_html(coalesce(nullif(d->>'assinatura', ''), 'Equipe Araújo & Castro')) || '</b></p>' end || '</div>'
    || '<div style="padding:12px 24px;background:#F7F8FB;border-top:1px solid #E5E7EB;color:#6B7280;font-size:11.5px">Mensagem automática do sistema do escritório. Se já resolveu, por favor desconsidere.</div>'
    || '</div></div>';
end $$;
revoke all on function public.email_cliente_html(text, text, text, jsonb, boolean, text) from public, anon, authenticated;

-- manda ao contato da finalidade certa, com o modelo novo, uma vez só por "ref"
-- (v22) o envio ganhou o parâmetro do anexo: a versão antiga sai antes de recriar
drop function if exists public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean);
create or replace function public.email_cliente_enviar(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_finalidade text,
  p_assunto text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_anexo jsonb default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare c record;
begin
  if exists (select 1 from public.automacoes_log where ref = p_ref) then return false; end if;
  select * into c from public.contato_do_cliente(p_cliente, p_grupo, p_finalidade);
  if c.email is null or c.email = '' then return false; end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (null, c.email, p_assunto, public.email_cliente_html(p_assunto, c.nome, p_texto, p_itens, p_pagar), 'cliente', p_ref);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, p_assunto || ' → ' || c.email, p_cliente);
  return true;
end $$;
revoke all on function public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean, jsonb) from public, anon, authenticated;
-- compatibilidade: chamadas antigas usam o modelo novo
create or replace function public.email_ao_cliente(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_assunto text, p_corpo text) returns boolean
language sql security definer set search_path = public as $$
  select public.email_cliente_enviar(p_regra, p_ref, p_cliente, p_grupo, 'financeiro', p_assunto, regexp_replace(p_corpo, '<p>Olá!</p>|<p>Araújo &amp; Castro Advocacia</p>', '', 'g'));
$$;
revoke all on function public.email_ao_cliente(text, text, uuid, uuid, text, text) from public, anon, authenticated;

-- nova automação: lembrete da parcela de parcelamento (guia) ao contato financeiro
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias, grupo) values
  ('email_lembrete_parcelamento', 'E-mail ao cliente: lembrete da parcela do parcelamento', 'N dias antes do vencimento da guia (PGFN, Receita, SEFAZ…), para o contato financeiro', true, 3, 'cliente_email')
on conflict (chave) do nothing;
-- migração (uma vez só): e-mails ao cliente LIGADOS — só saem para quem tem e-mail cadastrado
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'migracao_v19_emails') then
    update public.regras_tarefas set ligada = true where grupo = 'cliente_email';
    insert into public.configuracoes (chave, valor) values ('migracao_v19_emails', '{"feito":true}');
  end if;
end $$;

create or replace function public.rodar_emails_cliente() returns int
language plpgsql security definer set search_path = public as $$
declare rg record; x record; n int := 0;
begin
  -- honorários: um e-mail por cliente com TODOS os que vencem até N dias (faixa: a rotina só roda em dia útil,
  -- então o vencimento de sábado/domingo entra no lembrete de sexta). Cada lançamento só é lembrado uma vez.
  select * into rg from public.regras_tarefas where chave = 'email_lembrete_honorario' and ligada;
  if found then
    for x in select l.cliente_id, l.grupo_id, min(l.vencimento) venc, string_agg(l.id::text, ',' order by l.id) ids,
                    jsonb_agg(jsonb_build_object('descricao', l.descricao || coalesce(' (' || nullif(l.referencia, '') || ')', ''), 'vencimento', l.vencimento, 'valor', l.valor) order by l.vencimento) itens
               from public.lancamentos l where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false)
                and l.vencimento > current_date and l.vencimento <= current_date + rg.dias
                and not exists (select 1 from public.automacoes_log g where g.ref = 'email_lhi:' || l.id)
              group by l.cliente_id, l.grupo_id loop
      if public.email_cliente_enviar('email_lh', 'email_lh:' || md5(x.ids), x.cliente_id, x.grupo_id, 'financeiro',
           'Lembrete de honorários — vencimento em ' || to_char(x.venc, 'DD/MM/YYYY'),
           '<p style="margin:0">Passando para lembrar dos honorários abaixo, com vencimento a partir de <b>' || to_char(x.venc, 'DD/MM/YYYY') || '</b>.</p>', x.itens, true) then n := n + 1; end if;
      -- marca cada lançamento como lembrado (mesmo quando o perfil do cliente pulou o envio)
      insert into public.automacoes_log (chave, ref, descricao, cliente_id)
        select '_item', 'email_lhi:' || v, 'lembrete (item)', x.cliente_id from unnest(string_to_array(x.ids, ',')) v;
    end loop;
  end if;
  -- "vence hoje": só para clientes com o perfil "Só no vencimento" (ou personalizado com esse tipo)
  for x in select l.cliente_id, l.grupo_id, string_agg(l.id::text, ',' order by l.id) ids,
                  jsonb_agg(jsonb_build_object('descricao', l.descricao || coalesce(' (' || nullif(l.referencia, '') || ')', ''), 'vencimento', l.vencimento, 'valor', l.valor)) itens
             from public.lancamentos l where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false)
              and l.vencimento between current_date - 2 and current_date   -- segunda-feira alcança o fim de semana
              and not exists (select 1 from public.automacoes_log g where g.ref = 'email_vhi:' || l.id)
              and public.pode_email(l.cliente_id, l.grupo_id, 'vencimento') and public.perfil_email_de(l.cliente_id, l.grupo_id) <> 'padrao'
            group by l.cliente_id, l.grupo_id loop
    if public.email_cliente_enviar('email_vh', 'email_vh:' || md5(x.ids), x.cliente_id, x.grupo_id, 'financeiro',
         'Honorários com vencimento hoje',
         '<p style="margin:0">Os honorários abaixo vencem hoje.</p>', x.itens, true) then n := n + 1; end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
      select '_item', 'email_vhi:' || v, 'vencimento (item)', x.cliente_id from unnest(string_to_array(x.ids, ',')) v;
  end loop;
  -- cobrança: todos os honorários em aberto do cliente, uma vez por lançamento que completou N dias de atraso
  select * into rg from public.regras_tarefas where chave = 'email_cobranca_honorario' and ligada;
  if found then
    for x in select l.id, l.cliente_id, l.grupo_id, l.vencimento,
                    (select jsonb_agg(jsonb_build_object('descricao', o.descricao || coalesce(' (' || nullif(o.referencia, '') || ')', ''), 'vencimento', o.vencimento, 'valor', o.valor) order by o.vencimento)
                       from public.lancamentos o where o.tipo = 'receita' and not o.redutor and not o.pago and not coalesce(o.perda, false) and o.vencimento < current_date
                        and ((l.cliente_id is not null and o.cliente_id = l.cliente_id) or (l.cliente_id is null and o.grupo_id = l.grupo_id))) itens
               from public.lancamentos l where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false) and l.vencimento = current_date - rg.dias loop
      if public.email_cliente_enviar('email_ch', 'email_ch:' || x.id, x.cliente_id, x.grupo_id, 'financeiro',
           'Honorários em aberto',
           '<p style="margin:0">Não identificamos o pagamento dos honorários abaixo. Se já pagou, por favor responda com o comprovante para darmos baixa — obrigado!</p>', x.itens, true) then n := n + 1; end if;
    end loop;
  end if;
  -- acordo (dívida do cliente com terceiros): ao contato jurídico
  select * into rg from public.regras_tarefas where chave = 'email_lembrete_acordo' and ligada;
  if found then
    for x in select a.id, a.valor, a.vencimento, a.credor, a.parcela, a.total_parcelas, a.processo, a.grupo_id, a.pix, a.banco,
                    (select cl.id from public.clientes cl where cl.grupo_id = a.grupo_id and public.primeiro_nome(cl.nome) = public.primeiro_nome(a.devedor) limit 1) cli
               from public.acordos a where not a.pago and a.vencimento = current_date + rg.dias loop
      if public.email_cliente_enviar('email_la', 'email_la:' || x.id, x.cli, x.grupo_id, 'juridico',
           'Lembrete: parcela do acordo vence em ' || to_char(x.vencimento, 'DD/MM/YYYY'),
           '<p style="margin:0">A parcela do acordo com <b>' || public.esc_html(coalesce(x.credor, '')) || '</b> (processo ' || public.esc_html(coalesce(x.processo, '')) || ') vence em <b>' ||
           to_char(x.vencimento, 'DD/MM/YYYY') || '</b>. O pagamento é feito direto ao credor' ||
           case when coalesce(x.pix, '') <> '' then ' — PIX do credor: <b>' || public.esc_html(x.pix) || '</b>' else '' end ||
           case when coalesce(x.banco, '') <> '' then ' — ' || public.esc_html(x.banco) else '' end ||
           '.</p><p style="margin:10px 0 0">Depois de pagar, <b>responda este e-mail com o comprovante</b>: nós juntamos ao processo.</p>',
           jsonb_build_array(jsonb_build_object('descricao', 'Parcela ' || coalesce(x.parcela, '') || coalesce('/' || nullif(x.total_parcelas, ''), ''), 'vencimento', x.vencimento, 'valor', x.valor))) then n := n + 1; end if;
    end loop;
  end if;
  -- parcelamento (PGFN, Receita, SEFAZ…): guia do mês
  select * into rg from public.regras_tarefas where chave = 'email_lembrete_parcelamento' and ligada;
  if found then
    for x in select pa.id, pa.numero, pa.vencimento, p.empresa, p.natureza, p.local, p.numero parc_num, p.valor_ultima_parcela, p.grupo_id, p.total_parcelas,
                    (select cl.id from public.clientes cl where (soDig.d <> '' and regexp_replace(cl.cpf_cnpj, '\D', '', 'g') = soDig.d) or cl.nome = p.empresa limit 1) cli
               from public.parcelas pa join public.parcelamentos p on p.id = pa.parcelamento_id
               cross join lateral (select regexp_replace(coalesce(p.cnpj, ''), '\D', '', 'g') d) soDig
              where not pa.pago and pa.vencimento between current_date and current_date + rg.dias loop
      if public.email_cliente_enviar('email_lp', 'email_lp:' || x.id, x.cli, x.grupo_id, 'financeiro',
           'Lembrete: parcela do parcelamento vence em ' || to_char(x.vencimento, 'DD/MM/YYYY'),
           '<p style="margin:0">A parcela <b>' || coalesce(x.numero, '') || coalesce('/' || x.total_parcelas, '') || '</b> do parcelamento <b>' || public.esc_html(coalesce(x.natureza, '')) ||
           coalesce(' · ' || nullif(public.esc_html(x.local), ''), '') || '</b>' || coalesce(' (nº ' || nullif(public.esc_html(x.parc_num), '') || ')', '') || ' de <b>' || public.esc_html(coalesce(x.empresa, '')) ||
           '</b> vence em <b>' || to_char(x.vencimento, 'DD/MM/YYYY') || '</b>. Se ainda não recebeu a guia, responda este e-mail que enviamos.</p>' ||
           '<p style="margin:10px 0 0">Atenção: três parcelas em atraso podem cancelar o parcelamento.</p>',
           case when coalesce(x.valor_ultima_parcela, 0) > 0 then jsonb_build_array(jsonb_build_object('descricao', 'Parcela ' || coalesce(x.numero, ''), 'vencimento', x.vencimento, 'valor', x.valor_ultima_parcela)) else '[]'::jsonb end) then n := n + 1; end if;
    end loop;
  end if;
  return n;
end $$;
revoke all on function public.rodar_emails_cliente() from public, anon, authenticated;

create or replace function public.pagamento_automacoes() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not new.pago or old.pago or new.tipo <> 'receita' or new.redutor then return null; end if;
  if exists (select 1 from public.regras_tarefas where chave = 'pagamento_conclui' and ligada) then
    update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(i || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) i) where chave_regra = 'cob:' || new.id and status not in ('concluida','cancelada');
    get diagnostics n = row_count;
    if n > 0 then insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('pagamento_conclui', 'pago:' || new.id, 'Honorário recebido: cobrança concluída sozinha — ' || new.descricao, new.cliente_id); end if;
  end if;
  if exists (select 1 from public.regras_tarefas where chave = 'email_pagamento_recebido' and ligada) then
    perform public.email_cliente_enviar('email_pr', 'email_pr:' || new.id, new.cliente_id, new.grupo_id, 'financeiro', 'Recebemos o seu pagamento — obrigado!',
      '<p style="margin:0">Confirmamos o recebimento abaixo' || coalesce(', em <b>' || to_char(new.data_pagamento, 'DD/MM/YYYY') || '</b>', '') || '. Se precisar do recibo, é só responder este e-mail.</p>',
      jsonb_build_array(jsonb_build_object('descricao', new.descricao || coalesce(' (' || nullif(new.referencia, '') || ')', ''), 'vencimento', new.vencimento, 'valor', new.valor)));
  end if;
  return null;
end $$;

-- envio manual (Cobranças, avisos e recibos): o texto montado na tela sai pelo e-mail do escritório, no modelo da marca
create or replace function public.enviar_email_manual(p_para text, p_assunto text, p_texto text) returns void
language plpgsql security definer set search_path = public as $$
declare corpo text;
begin
  if not (public.pode('clientes', 'editar') or public.pode('financeiro_juridico', 'editar') or public.pode('financeiro_contab', 'editar') or public.pode('juridico', 'editar')) then
    raise exception 'permission denied: sem acesso para enviar e-mail a clientes.';
  end if;
  if coalesce(p_para, '') !~ '^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$' then raise exception 'Informe um e-mail válido (um só).'; end if;
  if btrim(coalesce(p_texto, '')) = '' then raise exception 'A mensagem está vazia.'; end if;
  corpo := '<p style="margin:0 0 10px">' || replace(replace(public.esc_html(btrim(p_texto)), E'\n\n', '</p><p style="margin:0 0 10px">'), E'\n', '<br>') || '</p>';
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (null, p_para, left(coalesce(nullif(btrim(p_assunto), ''), 'Mensagem do escritório'), 200), public.email_cliente_html(coalesce(nullif(btrim(p_assunto), ''), 'Mensagem do escritório'), '-', corpo, '[]', false, '-'), 'cliente', '');
  insert into public.automacoes_log (chave, ref, descricao) values ('email_manual', 'manual:' || gen_random_uuid(), 'E-mail enviado pela tela: ' || left(p_assunto, 120) || ' → ' || p_para);
end $$;
revoke all on function public.enviar_email_manual(text, text, text) from public, anon;
grant execute on function public.enviar_email_manual(text, text, text) to authenticated;

-- prévia dos modelos (Administração → E-mail): exemplo fictício de cada e-mail ao cliente
create or replace function public.previa_email_cliente(p_tipo text) returns text
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'permission denied'; end if;
  return case p_tipo
    when 'lembrete' then public.email_cliente_html('Lembrete de honorários — vencimento em 10/10/2026', 'Marta', '<p style="margin:0">Passando para lembrar dos honorários abaixo, com vencimento em <b>10/10/2026</b>.</p>',
      '[{"descricao":"Consultoria tributária mensal (09/2026)","vencimento":"2026-10-10","valor":4500}]', true)
    when 'cobranca' then public.email_cliente_html('Honorários em aberto', 'Marta', '<p style="margin:0">Não identificamos o pagamento dos honorários abaixo. Se já pagou, por favor responda com o comprovante para darmos baixa — obrigado!</p>',
      '[{"descricao":"Consultoria tributária mensal (08/2026)","vencimento":"2026-09-10","valor":4500},{"descricao":"Defesa em execução fiscal — parcela 2/4","vencimento":"2026-09-20","valor":3000}]', true)
    when 'acordo' then public.email_cliente_html('Lembrete: parcela do acordo vence em 12/10/2026', 'Ricardo', '<p style="margin:0">A parcela do acordo com <b>Fornecedor Exemplo S.A.</b> (processo 0000000-00.2025.8.13.0000) vence em <b>12/10/2026</b>. O pagamento é feito direto ao credor.</p><p style="margin:10px 0 0">Depois de pagar, <b>responda este e-mail com o comprovante</b>: nós juntamos ao processo.</p>',
      '[{"descricao":"Parcela 4/6","vencimento":"2026-10-12","valor":3200}]')
    when 'parcelamento' then public.email_cliente_html('Lembrete: parcela do parcelamento vence em 20/10/2026', 'Marta', '<p style="margin:0">A parcela <b>9/60</b> do parcelamento <b>Transação tributária · PGFN</b> vence em <b>20/10/2026</b>. Se ainda não recebeu a guia, responda este e-mail que enviamos.</p><p style="margin:10px 0 0">Atenção: três parcelas em atraso podem cancelar o parcelamento.</p>',
      '[{"descricao":"Parcela 9","vencimento":"2026-10-20","valor":2500}]')
    else public.email_cliente_html('Recebemos o seu pagamento — obrigado!', 'Marta', '<p style="margin:0">Confirmamos o recebimento abaixo, em <b>28/09/2026</b>. Se precisar do recibo, é só responder este e-mail.</p>',
      '[{"descricao":"Consultoria tributária mensal (08/2026)","vencimento":"2026-09-10","valor":4500}]')
  end;
end $$;
revoke all on function public.previa_email_cliente(text) from public, anon;
grant execute on function public.previa_email_cliente(text) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- v20 (Backup 14) — perfil de e-mail por cliente, usuários previstos, histórico mensal,
-- extrato OFX, PGFN (API SERPRO), processos com data da mudança de situação
-- ═══════════════════════════════════════════════════════════════════

-- ─────────── e-mails ao cliente: perfil por cliente ───────────
-- padrao: lembrete antes + cobrança depois do atraso + recibo · nunca: nada financeiro (clientes importantes)
-- vencimento: só "vence hoje" + recibo · personalizado: caixinhas por tipo (emails_tipos)
-- parcelamento e acordo (guias e parcelas do próprio cliente) não são cobrança do escritório: seguem ligados, salvo no personalizado
alter table public.clientes add column if not exists perfil_email text not null default 'padrao';
alter table public.clientes add column if not exists emails_tipos jsonb not null default '{}';
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'clientes_perfil_email_ck') then
    alter table public.clientes add constraint clientes_perfil_email_ck check (perfil_email in ('padrao','nunca','vencimento','personalizado'));
  end if;
end $$;

create or replace function public.perfil_email_de(p_cliente uuid, p_grupo uuid) returns text
language sql stable security definer set search_path = public as $$
  select coalesce((select perfil_email from public.clientes where id = p_cliente),
                  -- sem cliente (lançamento só do grupo): vale o perfil mais restritivo do grupo
                  (select perfil_email from public.clientes where grupo_id = p_grupo and perfil_email <> 'padrao'
                    order by case perfil_email when 'nunca' then 1 when 'vencimento' then 2 else 3 end limit 1), 'padrao');
$$;
revoke all on function public.perfil_email_de(uuid, uuid) from public, anon, authenticated;

create or replace function public.pode_email(p_cliente uuid, p_grupo uuid, p_tipo text) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare pf text := public.perfil_email_de(p_cliente, p_grupo); t jsonb;
begin
  if pf = 'nunca' then return p_tipo not in ('lembrete','vencimento','cobranca','recibo'); end if;
  if pf = 'vencimento' then return p_tipo not in ('lembrete','cobranca'); end if;
  if pf = 'personalizado' then
    select emails_tipos into t from public.clientes where id = p_cliente;
    if t is null then
      select emails_tipos into t from public.clientes where grupo_id = p_grupo and perfil_email = 'personalizado' limit 1;
    end if;
    return coalesce((t->>p_tipo)::boolean, p_tipo <> 'vencimento');
  end if;
  return p_tipo <> 'vencimento';
end $$;
revoke all on function public.pode_email(uuid, uuid, text) from public, anon, authenticated;

-- envio (redefinido): respeita o perfil do cliente e nunca manda para example.com (demonstração)
create or replace function public.email_cliente_enviar(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_finalidade text,
  p_assunto text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_anexo jsonb default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare c record; tipo text;
begin
  if exists (select 1 from public.automacoes_log where ref = p_ref) then return false; end if;
  tipo := case p_regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' when 'email_ch' then 'cobranca'
                       when 'email_pr' then 'recibo' when 'email_lp' then 'parcelamento' when 'email_la' then 'acordo' end;
  if tipo is not null and not public.pode_email(p_cliente, p_grupo, tipo) then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (p_regra, p_ref, 'Não enviado (perfil de e-mail do cliente): ' || p_assunto, p_cliente);
    return false;
  end if;
  select * into c from public.contato_do_cliente(p_cliente, p_grupo, p_finalidade);
  if c.email is null or c.email = '' then return false; end if;
  if c.email ~* '(@|\.)example\.com$' then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, 'Demonstração (não enviado): ' || p_assunto, p_cliente);
    return false;
  end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (null, c.email, p_assunto, public.email_cliente_html(p_assunto, c.nome, p_texto, p_itens, p_pagar), 'cliente', p_ref);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, p_assunto || ' → ' || c.email, p_cliente);
  return true;
end $$;
revoke all on function public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean, jsonb) from public, anon, authenticated;

-- tela "E-mails aos clientes": perfil em lote (quem edita Clientes)
create or replace function public.salvar_perfil_email(p_ids uuid[], p_perfil text, p_tipos jsonb default null) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.pode('clientes', 'editar') then raise exception 'permission denied: só quem edita Clientes muda o perfil de e-mail.'; end if;
  if p_perfil not in ('padrao','nunca','vencimento','personalizado') then raise exception 'Perfil inválido.'; end if;
  update public.clientes set perfil_email = p_perfil, emails_tipos = coalesce(p_tipos, emails_tipos)
   where id = any(p_ids) and public.ve_cliente(id);
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.salvar_perfil_email(uuid[], text, jsonb) from public, anon;
grant execute on function public.salvar_perfil_email(uuid[], text, jsonb) to authenticated;

-- último e-mail enviado a cada cliente (para a tabela da tela)
create or replace function public.ultimos_emails_clientes() returns table (cliente_id uuid, quando timestamptz, descricao text)
language sql stable security definer set search_path = public as $$
  select distinct on (l.cliente_id) l.cliente_id, l.quando, l.descricao
    from public.automacoes_log l
   where l.cliente_id is not null and l.chave like 'email%' and public.eh_equipe() and public.ve_cliente(l.cliente_id)
   order by l.cliente_id, l.quando desc;
$$;
revoke all on function public.ultimos_emails_clientes() from public, anon;
grant execute on function public.ultimos_emails_clientes() to authenticated;

-- ─────────── usuários previstos: quem o escritório já decidiu cadastrar ───────────
-- Ao criar a conta com esse e-mail (Administração → Usuários), a pessoa já nasce com o acesso certo.
create table if not exists public.usuarios_previstos (
  email   text primary key,
  nome    text not null default '',
  papel   text not null default 'equipe' check (papel in ('admin','equipe')),
  funcoes jsonb not null default '{}',
  areas   text not null default 'ambos',
  modelo  text not null default '',
  criado_em timestamptz not null default now()
);
alter table public.usuarios_previstos enable row level security;
revoke all on public.usuarios_previstos from anon;
grant select, delete on public.usuarios_previstos to authenticated;
drop policy if exists usuarios_previstos_admin on public.usuarios_previstos;
create policy usuarios_previstos_admin on public.usuarios_previstos for all to authenticated using (public.eh_admin()) with check (public.eh_admin());
insert into public.usuarios_previstos (email, nome, papel, funcoes, areas, modelo) values
  ('emanuellearaujoadvocacia@gmail.com', 'Emanuelle', 'admin', '{}', 'ambos', 'Administrador'),
  ('adriana_f_araujo@hotmail.com', 'Adriana', 'admin', '{}', 'ambos', 'Administrador'),
  ('joaovitordeoliveiramarques2007@gmail.com', 'João Vitor', 'equipe',
   '{"juridico":"editar","clientes":"editar","financeiro_contab":"ver","tarefas":"editar","documentos":"ver","contratos":"ver"}', 'ambos', 'Estagiário'),
  ('ederpsique@gmail.com', 'Éder', 'equipe',
   '{"financeiro_contab":"editar","clientes":"editar","contratos":"editar","documentos":"editar","tarefas":"editar","relatorios":"ver"}', 'contabil', 'Administrador da Contabilidade')
on conflict (email) do nothing;
-- quem já tem conta: se ainda está inativo, recebe o acesso previsto; e não fica como "previsto"
-- (rodar o SQL de novo não recria o convite)
update public.perfis p set papel = v.papel, funcoes = v.funcoes, areas = v.areas, nome = coalesce(nullif(p.nome, ''), v.nome)
  from public.usuarios_previstos v where lower(p.email) = lower(v.email) and p.papel = 'inativo';
delete from public.usuarios_previstos v where exists (select 1 from public.perfis p where lower(p.email) = lower(v.email));

create or replace function public.criar_perfil() returns trigger
language plpgsql security definer set search_path = public as $$
declare pv record;
begin
  select * into pv from public.usuarios_previstos where lower(email) = lower(coalesce(new.email, ''));
  insert into public.perfis (id, email, nome, papel)
  values (new.id, coalesce(new.email,''),
          coalesce(nullif(new.raw_user_meta_data->>'nome', ''), pv.nome, split_part(coalesce(new.email,''),'@',1)),
          case when not exists (select 1 from public.perfis) then 'admin' when pv.email is not null then pv.papel else 'inativo' end)
  on conflict (id) do nothing;
  if pv.email is not null then
    update public.perfis set funcoes = pv.funcoes, areas = pv.areas where id = new.id;
    delete from public.usuarios_previstos where email = pv.email;
  end if;
  return new;
end $$;

-- ─────────── processos: data em que mudou de situação (para "extintos no período") ───────────
alter table public.processos add column if not exists status_em date;
create or replace function public.processo_status_em() returns trigger
language plpgsql as $$
begin
  if tg_op = 'INSERT' or new.status is distinct from old.status then new.status_em := current_date; end if;
  return new;
end $$;
drop trigger if exists processo_status_em on public.processos;
create trigger processo_status_em before insert or update of status on public.processos for each row execute function public.processo_status_em();

create or replace function public.processo_encerrado(st text) returns boolean
language sql immutable as $$ select coalesce(st, '') ~* '(arquiv|extint|baixad|encerrad|transitad)'; $$;

-- passivo total de uma empresa (soma dos órgãos)
create or replace function public.passivo_do_cliente(c public.clientes) returns numeric
language sql immutable as $$
  select coalesce(c.rfb,0) + coalesce(c.rfb_negociada,0) + coalesce(c.pgfn,0) + coalesce(c.pgfn_negociada,0) + coalesce(c.sefaz_mg,0) + coalesce(c.age_mg,0) + coalesce(c.age_mg_negociada,0);
$$;


-- ═══════════════════════════════════════════════════════════════════
-- v21 (Backup 15) — preferências de tela por usuário, mural do Início,
-- área do serviço nos honorários e contratos
-- ═══════════════════════════════════════════════════════════════════

-- preferências de tela (ex.: fila do Início em lista ou calendário) — valem em qualquer computador
alter table public.perfis add column if not exists preferencias jsonb not null default '{}';
create or replace function public.salvar_preferencia(p_chave text, p_valor jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'permission denied'; end if;
  if coalesce(p_chave, '') !~ '^[a-z_]{1,40}$' then raise exception 'Preferência inválida.'; end if;
  update public.perfis set preferencias = coalesce(preferencias, '{}') || jsonb_build_object(p_chave, p_valor) where id = auth.uid();
end $$;
revoke all on function public.salvar_preferencia(text, jsonb) from public, anon;
grant execute on function public.salvar_preferencia(text, jsonb) to authenticated;

-- mural do Início: recados do escritório (qualquer pessoa da equipe publica; apaga quem publicou ou o admin)
create table if not exists public.mural (
  id         uuid primary key default gen_random_uuid(),
  texto      text not null check (btrim(texto) <> '' and length(texto) <= 1000),
  fixo       boolean not null default false,
  expira_em  date,
  autor      uuid default auth.uid() references public.perfis(id) on delete set null,
  autor_nome text not null default '',
  criado_em  timestamptz not null default now()
);
create index if not exists mural_criado on public.mural (criado_em desc);
alter table public.mural enable row level security;
revoke all on public.mural from anon;
grant select, insert, delete on public.mural to authenticated;
drop policy if exists mural_ver on public.mural;
create policy mural_ver on public.mural for select to authenticated using (public.eh_equipe());
drop policy if exists mural_publicar on public.mural;
create policy mural_publicar on public.mural for insert to authenticated with check (public.eh_equipe() and autor = auth.uid());
drop policy if exists mural_apagar on public.mural;
create policy mural_apagar on public.mural for delete to authenticated using (autor = auth.uid() or public.eh_admin());
create or replace function public.mural_autor() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.autor := auth.uid();
  new.autor_nome := coalesce((select nullif(split_part(btrim(nome), ' ', 1), '') from public.perfis where id = auth.uid()), '');
  if new.fixo and not public.eh_admin() then new.fixo := false; end if;   -- só o administrador fixa recado
  return new;
end $$;
drop trigger if exists mural_autor on public.mural;
create trigger mural_autor before insert on public.mural for each row execute function public.mural_autor();

-- área do serviço (gráfico "Recebido por tipo de serviço"): tributário, imobiliário, empresarial, sucessões, família,
-- criminal, trabalhista, contratual, cobrança, consultoria. A regra de consultoria mensal (recorrência) não muda.
alter table public.lancamentos add column if not exists servico text not null default '';
alter table public.contratos add column if not exists servico text not null default '';
create or replace function public.lancamento_servico() returns trigger
language plpgsql as $$
begin
  if coalesce(new.servico, '') = '' and new.contrato_id is not null then
    select servico into new.servico from public.contratos where id = new.contrato_id;
    new.servico := coalesce(new.servico, '');
  end if;
  return new;
end $$;
drop trigger if exists lancamento_servico on public.lancamentos;
create trigger lancamento_servico before insert on public.lancamentos for each row execute function public.lancamento_servico();
-- contrato ganhou/trocou a área: os honorários dele sem área passam a ter a mesma
create or replace function public.contrato_servico_propaga() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.servico, '') <> '' and new.servico is distinct from old.servico then
    update public.lancamentos set servico = new.servico where contrato_id = new.id and (servico = '' or servico = coalesce(old.servico, ''));
  end if;
  return null;
end $$;
drop trigger if exists contrato_servico_propaga on public.contratos;
create trigger contrato_servico_propaga after update of servico on public.contratos for each row execute function public.contrato_servico_propaga();

-- ═══════════════════════════════════════════════════════════════════════
-- v22 (Backup 16) — Lembretes (não são tarefas), guias de parcelamento como lembrete
-- ═══════════════════════════════════════════════════════════════════════
update public.regras_tarefas set nome = 'Parcela de parcelamento do cliente → lembrete "Emitir guias"',
  descricao = 'N dias antes do vencimento aparece no card Lembretes do Início (não vira tarefa)' where chave = 'parcela_parcelamento';
-- tarefas antigas "Emitir guia…" saem da fila (vão para Excluídas; dá para restaurar)
update public.tarefas set status = 'cancelada' where chave_regra like 'parc:%' and status not in ('concluida', 'cancelada');

create table if not exists public.lembretes (
  id uuid primary key default gen_random_uuid(),
  texto text not null check (btrim(texto) <> '' and length(texto) <= 300),
  dia date not null default current_date,
  repete text not null default '' check (repete in ('', 'semanal', 'mensal', 'anual')),
  pessoa text not null default '',              -- vazio = todo o escritório
  feito_em date,
  criado_por uuid default auth.uid(),
  criado_em timestamptz not null default now()
);
alter table public.lembretes enable row level security;
revoke all on public.lembretes from anon;
grant select, insert, update, delete on public.lembretes to authenticated;
drop policy if exists lembretes_equipe on public.lembretes;
create policy lembretes_equipe on public.lembretes for all to authenticated using (public.eh_equipe()) with check (public.eh_equipe());
create index if not exists lembretes_dia on public.lembretes (dia) where feito_em is null;

-- Publicações por PARTE (cliente): o Diário (DJEN) não busca por CNPJ, mas busca pelo nome da parte.
-- O cliente escolhido entra com a razão social; o CNPJ fica guardado para conferência.
create table if not exists public.partes_monitoradas (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (btrim(nome) <> ''),
  documento text not null default '',
  cliente_id uuid references public.clientes(id) on delete cascade,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now(),
  unique (nome)
);
alter table public.publicacoes add column if not exists parte_monitorada text not null default '';
do $$
begin
  alter table public.partes_monitoradas enable row level security;
  revoke all on public.partes_monitoradas from anon;
  grant select, insert, update, delete on public.partes_monitoradas to authenticated;
  drop trigger if exists atualizado_partes_monitoradas on public.partes_monitoradas;
  create trigger atualizado_partes_monitoradas before update on public.partes_monitoradas for each row execute function public.marcar_atualizacao();
  drop policy if exists partes_monitoradas_ver on public.partes_monitoradas;
  create policy partes_monitoradas_ver on public.partes_monitoradas for select to authenticated using (public.pode('juridico'));
  drop policy if exists partes_monitoradas_gravar on public.partes_monitoradas;
  create policy partes_monitoradas_gravar on public.partes_monitoradas for all to authenticated using (public.pode('juridico','editar')) with check (public.pode('juridico','editar'));
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant select on public.partes_monitoradas to service_role;
  end if;
end $$;

-- ═══════════════════════════════════════════════════════════════════════
-- v22 (Backup 16) — CRM: etapas novas, contrato fechado × assinado, área do serviço,
-- alerta de oportunidade parada, follow-up de proposta, motivo de perda em lista fixa
-- ═══════════════════════════════════════════════════════════════════════
update public.crm_etapas set nome = 'Contrato assinado', ordem = 9 where final = 'ganho' and nome in ('Ganhou', 'Contrato assinado');
update public.crm_etapas set nome = 'Lead perdido', ordem = 10 where final = 'perdido' and nome in ('Perdeu', 'Lead perdido');
insert into public.crm_etapas (nome, ordem, probabilidade, final)
select 'Contrato fechado', 6, 90, '' where not exists (select 1 from public.crm_etapas where nome = 'Contrato fechado');
insert into public.crm_etapas (nome, ordem, probabilidade, final)
select 'Aguardando assinatura', 7, 95, '' where not exists (select 1 from public.crm_etapas where nome = 'Aguardando assinatura');
alter table public.crm_etapas add column if not exists dias_alerta int;
alter table public.crm_etapas add column if not exists descricao text not null default '';
update public.crm_etapas e set dias_alerta = v.d, descricao = v.t from (values
  ('Novo contato', 3, 'Primeiro contato registrado; falta qualificar e marcar o diagnóstico.'),
  ('Diagnóstico agendado', 7, 'Reunião de diagnóstico marcada com o cliente.'),
  ('Diagnóstico feito', 5, 'Diagnóstico realizado; falta montar e enviar a proposta.'),
  ('Proposta enviada', 5, 'Proposta com o cliente, aguardando resposta.'),
  ('Negociação', 7, 'Cliente negociando valor, forma de pagamento ou escopo.'),
  ('Contrato fechado', 3, 'Cliente disse SIM: cadastro, contrato e onboarding criados; falta enviar o contrato.'),
  ('Aguardando assinatura', 5, 'Contrato enviado; aguardando a assinatura do cliente.'),
  ('Contrato assinado', null, 'Contrato assinado: sai do painel e vai para a aba "Contratos assinados".'),
  ('Lead perdido', null, 'Não fechou: sai do painel e vai para a aba "Leads perdidos".')) v(n, d, t)
where e.nome = v.n and e.descricao = '';
alter table public.crm_oportunidades add column if not exists servico text not null default '';
alter table public.crm_oportunidades add column if not exists assinado_em timestamptz;

-- "Contrato fechado" (cliente aceitou): cria cliente (herda os dados do prospecto), contrato com a área do serviço
-- e a forma da proposta (parcelas ou mensalidade), onboarding e a tarefa "Enviar contrato para assinatura".
create or replace function public.crm_ganhar(p_op uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o record; cli uuid; grp uuid; ctr uuid; flx uuid; resp text; etp uuid; consult boolean;
begin
  if not public.pode('crm', 'editar') then raise exception 'Sem a função CRM (editar).'; end if;
  select * into o from public.crm_oportunidades where id = p_op;
  if not found then raise exception 'Oportunidade não encontrada.'; end if;
  resp := coalesce(nullif(p->>'responsavel', ''), o.responsavel);
  cli := coalesce(nullif(p->>'cliente_id', '')::uuid, o.cliente_id);
  consult := coalesce(p->>'modalidade', '') = 'consultoria';
  if cli is null then
    if coalesce(p->>'cliente_nome', '') = '' then raise exception 'Informe o nome do cliente.'; end if;
    if coalesce(p->>'grupo', '') <> '' then
      select id into grp from public.grupos where lower(nome) = lower(p->>'grupo') limit 1;
      if grp is null then insert into public.grupos (nome) values (p->>'grupo') returning id into grp; end if;
    end if;
    insert into public.clientes (nome, cpf_cnpj, email, telefone, grupo_id, responsavel, tipo, origem)
    values (p->>'cliente_nome', coalesce(nullif(p->>'cpf_cnpj', ''), o.prospecto_doc, ''), coalesce(nullif(p->>'email', ''), o.prospecto_email, ''),
            coalesce(nullif(p->>'telefone', ''), o.prospecto_telefone, ''), grp, coalesce(resp, ''), case when consult then 'Consultoria' else 'Demanda' end, 'CRM')
    returning id into cli;
  else
    select grupo_id into grp from public.clientes where id = cli;
  end if;
  if consult or coalesce((p->>'valor_total')::numeric, 0) > 0 or coalesce(p->>'descricao', '') <> '' then
    perform set_config('erp.sem_regra_onboarding', case when coalesce((p->>'criar_fluxo')::boolean, true) then '1' else '' end, true);
    insert into public.contratos (cliente_id, descricao, valor_total, num_parcelas, primeiro_vencimento, percentual_exito, responsavel, servico,
                                  modalidade, valor_mensal, dia_vencimento, inicio_competencia)
    values (cli, coalesce(nullif(p->>'descricao', ''), o.titulo), case when consult then 0 else coalesce((p->>'valor_total')::numeric, 0) end,
            case when consult then 1 else greatest(1, coalesce((p->>'num_parcelas')::int, 1)) end,
            case when consult then null else nullif(p->>'primeiro_vencimento', '')::date end, nullif(p->>'percentual_exito', '')::numeric, coalesce(resp, ''),
            coalesce(nullif(p->>'servico', ''), o.servico, ''), case when consult then 'consultoria' else 'pontual' end,
            case when consult then nullif(p->>'valor_mensal', '')::numeric end, coalesce(nullif(p->>'dia_vencimento', '')::int, 10),
            case when consult then date_trunc('month', coalesce(nullif(p->>'inicio_competencia', '')::date, current_date))::date end)
    returning id into ctr;
    perform set_config('erp.sem_regra_onboarding', '', true);
    if consult then begin perform public.gerar_mensalidades(); exception when undefined_function then null; end; end if;
  end if;
  if coalesce((p->>'criar_fluxo')::boolean, true) then
    flx := public.criar_fluxo_modelo('Onboarding de cliente', public.somar_uteis(current_date, 15), cli, grp, resp,
                                     'Onboarding — ' || coalesce(p->>'cliente_nome', (select nome from public.clientes where id = cli)));
  end if;
  perform public.tarefa_da_regra('crm-contrato:' || p_op, 'Enviar contrato para assinatura — ' || coalesce(nullif(p->>'cliente_nome', ''), (select nome from public.clientes where id = cli)),
    resp, public.somar_uteis(current_date, 2), cli, grp, ctr, '[]'::jsonb, 'Oportunidade do CRM: ' || o.titulo, '', 'alta');
  insert into public.interacoes (cliente_id, tipo, resumo) values (cli, 'anotacao', 'Contrato fechado pelo CRM: ' || o.titulo);
  update public.crm_propostas set status = 'aceita' where id = (select id from public.crm_propostas where oportunidade_id = p_op order by versao desc limit 1);
  update public.documentos set cliente_id = cli, grupo_id = grp, contrato_id = coalesce(ctr, contrato_id) where oportunidade_id = p_op;
  select id into etp from public.crm_etapas where nome = 'Contrato fechado' limit 1;
  if etp is null then select id into etp from public.crm_etapas where final = 'ganho' order by ordem limit 1; end if;
  update public.crm_oportunidades set etapa_id = etp, probabilidade = 90, ganho_em = now(), perdido_em = null, cliente_id = cli, contrato_id = ctr,
         servico = coalesce(nullif(p->>'servico', ''), servico) where id = p_op;
  return jsonb_build_object('cliente_id', cli, 'contrato_id', ctr, 'fluxo_id', flx);
end $$;
revoke all on function public.crm_ganhar(uuid, jsonb) from anon;
grant execute on function public.crm_ganhar(uuid, jsonb) to authenticated;

-- entrar em "Contrato assinado" marca a data (e o contrato); sair limpa
create or replace function public.crm_ao_mudar_etapa() returns trigger
language plpgsql as $$
declare fim text;
begin
  if tg_op = 'UPDATE' and new.etapa_id is distinct from old.etapa_id then
    new.etapa_desde := now();
    select final into fim from public.crm_etapas where id = new.etapa_id;
    if fim = 'ganho' then new.assinado_em := coalesce(new.assinado_em, now()); new.probabilidade := 100; new.ganho_em := coalesce(new.ganho_em, now());
    elsif fim is distinct from 'ganho' then new.assinado_em := null; end if;
  end if;
  return new;
end $$;

-- regras automáticas do CRM (rodam com as demais, todo dia útil)
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias, grupo) values
  ('crm_parada', 'CRM: oportunidade parada na etapa → tarefa', 'Quando passa do prazo de cada etapa (CRM → ⚙ Etapas), cria tarefa para o responsável', true, 0, 'tarefas'),
  ('crm_followup', 'CRM: proposta sem resposta → follow-up', 'N dias depois do envio da proposta sem resposta, cria tarefa de follow-up (com e-mail pronto na ficha)', true, 5, 'tarefas')
on conflict (chave) do nothing;
create or replace function public.rodar_regras_extras() returns int
language plpgsql security definer set search_path = public as $$
declare rg record; x record; n int := 0;
begin
  select * into rg from public.regras_tarefas where chave = 'crm_parada' and ligada;
  if found then
    for x in select o.id, o.titulo, o.responsavel, o.cliente_id, o.etapa_id, e.nome etapa, e.dias_alerta
               from public.crm_oportunidades o join public.crm_etapas e on e.id = o.etapa_id
              where e.final = '' and e.dias_alerta is not null and o.etapa_desde < now() - make_interval(days => e.dias_alerta) loop
      if public.tarefa_da_regra('crm-parada:' || x.id || ':' || x.etapa_id, 'CRM parado há mais de ' || x.dias_alerta || ' dia(s) em "' || x.etapa || '" — ' || x.titulo,
           x.responsavel, public.somar_uteis(current_date, 1), x.cliente_id, null, null, '[]'::jsonb, 'Avance a oportunidade no CRM ou registre o próximo passo.') then n := n + 1; end if;
    end loop;
  end if;
  select * into rg from public.regras_tarefas where chave = 'crm_followup' and ligada;
  if found then
    for x in select pr.id, pr.titulo, pr.versao, o.titulo op, o.responsavel, o.cliente_id from public.crm_propostas pr join public.crm_oportunidades o on o.id = pr.oportunidade_id
               join public.crm_etapas e on e.id = o.etapa_id
              where pr.status = 'enviada' and pr.enviada_em < now() - make_interval(days => rg.dias) and e.final = '' loop
      if public.tarefa_da_regra('crm-follow:' || x.id, 'Follow-up da proposta — ' || x.op, x.responsavel, current_date, x.cliente_id, null, null, '[]'::jsonb,
           'Proposta v' || x.versao || ' enviada há mais de ' || rg.dias || ' dias sem resposta. Na ficha da oportunidade: "✉ Follow-up" envia o e-mail pronto.') then n := n + 1; end if;
    end loop;
  end if;
  return n;
end $$;
revoke all on function public.rodar_regras_extras() from public, anon, authenticated;
-- follow-up da proposta por e-mail (1 clique na ficha da oportunidade): modelo da marca + registro na linha do tempo
create or replace function public.crm_followup_email(p_op uuid, p_para text, p_assunto text, p_texto text) returns void
language plpgsql security definer set search_path = public as $$
declare corpo text;
begin
  if not public.pode('crm', 'editar') then raise exception 'Sem a função CRM (editar).'; end if;
  if coalesce(p_para, '') !~ '^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$' then raise exception 'Informe um e-mail válido (um só).'; end if;
  if p_para ilike '%@example.%' then raise exception 'E-mail de exemplo não recebe mensagens.'; end if;
  if btrim(coalesce(p_texto, '')) = '' then raise exception 'A mensagem está vazia.'; end if;
  corpo := '<p style="margin:0 0 10px">' || replace(replace(public.esc_html(btrim(p_texto)), E'\n\n', '</p><p style="margin:0 0 10px">'), E'\n', '<br>') || '</p>';
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (null, p_para, left(coalesce(nullif(btrim(p_assunto), ''), 'Nossa proposta'), 200),
          public.email_cliente_html(coalesce(nullif(btrim(p_assunto), ''), 'Nossa proposta'), '-', corpo, '[]', false, '-'), 'proposta', '');
  insert into public.crm_atividades (oportunidade_id, tipo, resumo) values (p_op, 'email', 'Follow-up enviado para ' || p_para || ': ' || left(p_texto, 300));
  update public.tarefas set status = 'concluida' where chave_regra like 'crm-follow:%' and status not in ('concluida', 'cancelada')
     and chave_regra in (select 'crm-follow:' || id from public.crm_propostas where oportunidade_id = p_op);
end $$;
revoke all on function public.crm_followup_email(uuid, text, text, text) from public, anon;
grant execute on function public.crm_followup_email(uuid, text, text, text) to authenticated;

-- modelos de proposta novos (o visual da proposta é o mesmo para todos: capa, apresentação, escopo, valores, aceite)
insert into public.crm_modelos_proposta (nome, texto, itens)
select v.n, v.t, v.i::jsonb from (values
  ('Planejamento tributário',
   '<p>Prezado(a) {cliente},</p><p>Agradecemos a confiança. Esta proposta trata do <b>planejamento tributário</b> da empresa: diagnóstico do regime atual, simulação dos cenários (Simples Nacional, Lucro Presumido e Lucro Real), indicação do caminho mais econômico e seguro e acompanhamento da implantação.</p><h3>O que está incluído</h3><ul><li>Levantamento de faturamento, folha e despesas dos últimos 12 meses</li><li>Comparativo dos regimes com a economia estimada</li><li>Relatório final com a recomendação e o passo a passo</li><li>Reunião de apresentação dos resultados</li></ul><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Diagnóstico e planejamento tributário","valor":0,"forma":"50% na assinatura e 50% na entrega"}]'),
  ('Inventário e planejamento sucessório',
   '<p>Prezado(a) {cliente},</p><p>Apresentamos proposta para a condução do <b>inventário</b> (judicial ou extrajudicial) e a orientação sucessória da família, com levantamento de bens, cálculo do ITCD, partilha e registro.</p><h3>O que está incluído</h3><ul><li>Levantamento de bens, dívidas e documentos</li><li>Cálculo e emissão das guias do ITCD</li><li>Minuta da partilha e acompanhamento no cartório ou no processo</li></ul><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Inventário e partilha","valor":0,"forma":"em até 3 parcelas"}]'),
  ('Defesa trabalhista',
   '<p>Prezado(a) {cliente},</p><p>Apresentamos proposta para a <b>defesa na reclamação trabalhista</b>: análise da inicial e dos documentos, contestação, audiências e recursos até a decisão de primeira instância.</p><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Honorários iniciais","valor":0,"forma":"à vista ou em até 3 parcelas"},{"servico":"Honorários por audiência","valor":0,"forma":"por ato"}]'),
  ('Abertura e regularização de empresa',
   '<p>Prezado(a) {cliente},</p><p>Apresentamos proposta para a <b>abertura (ou regularização) da empresa</b>: escolha do tipo societário e do regime tributário, contrato social, registros na Junta, Receita, Estado e Prefeitura e licenças.</p><p>Esta proposta vale até {validade}.</p>',
   '[{"servico":"Abertura / regularização","valor":0,"forma":"à vista"}]')
) v(n, t, i)
where not exists (select 1 from public.crm_modelos_proposta m where m.nome = v.n);

-- ═══════════════════════════════════════════════════════════════════════
-- v22 (Backup 16) — Central de e-mails ao cliente: honorários (lembrete, vence hoje, 1º/2º/3º aviso),
-- parcelamentos (guia do mês e atraso), acordos (lembrete e atraso) e recibo (PDF com valor por extenso).
-- Os modelos são editáveis (Administração → E-mails). A tela lista o que sai hoje, com prévia,
-- e permite "Enviar agora", "Pular este" e "Enviar selecionados".
-- ═══════════════════════════════════════════════════════════════════════
alter table public.email_fila add column if not exists anexo jsonb;

create table if not exists public.emails_modelos (
  chave text primary key, tipo text not null default '', nome text not null, assunto text not null, texto text not null,
  ordem int not null default 0, atualizado_em timestamptz not null default now()
);
alter table public.emails_modelos enable row level security;
revoke all on public.emails_modelos from anon;
grant select, insert, update on public.emails_modelos to authenticated;
drop policy if exists emails_modelos_ver on public.emails_modelos;
create policy emails_modelos_ver on public.emails_modelos for select to authenticated using (public.eh_equipe());
drop policy if exists emails_modelos_admin on public.emails_modelos;
create policy emails_modelos_admin on public.emails_modelos for update to authenticated using (public.eh_admin()) with check (public.eh_admin());
insert into public.emails_modelos (chave, tipo, nome, assunto, texto, ordem) values
  ('hon_lembrete', 'honorarios', 'Honorários — lembrete antes do vencimento', 'Lembrete de honorários — vencimento em {vencimento}',
   '<p style="margin:0">Passando para lembrar dos honorários abaixo, com vencimento a partir de <b>{vencimento}</b>.</p>', 1),
  ('hon_hoje', 'honorarios', 'Honorários — vence hoje', 'Honorários com vencimento hoje',
   '<p style="margin:0">Os honorários abaixo vencem hoje.</p>', 2),
  ('hon_atraso1', 'honorarios', 'Honorários em atraso — 1º aviso', 'Honorários em aberto',
   '<p style="margin:0">Não identificamos o pagamento dos honorários abaixo. Se já pagou, por favor responda com o comprovante para darmos baixa — obrigado!</p>', 3),
  ('hon_atraso2', 'honorarios', 'Honorários em atraso — 2º aviso', 'Honorários em aberto — 2º aviso',
   '<p style="margin:0">Ainda não identificamos o pagamento dos honorários abaixo. Se houver alguma dificuldade, responda este e-mail que combinamos a melhor forma de regularizar.</p>', 4),
  ('hon_atraso3', 'honorarios', 'Honorários em atraso — 3º aviso', 'Honorários em aberto — último aviso',
   '<p style="margin:0">Este é o nosso último aviso sobre os honorários abaixo, ainda em aberto. Pedimos que regularize ou entre em contato para combinarmos um acordo.</p>', 5),
  ('parc_guia', 'parcelamentos', 'Parcelamento — guia do mês', 'Guia do parcelamento — vence em {vencimento}',
   '<p style="margin:0">A parcela <b>{parcela}</b> do parcelamento <b>{natureza}</b>{numero} de <b>{empresa}</b> vence em <b>{vencimento}</b>. Se ainda não recebeu a guia, responda este e-mail que enviamos.</p><p style="margin:10px 0 0">Atenção: três parcelas em atraso podem cancelar o parcelamento.</p>', 6),
  ('parc_atraso', 'parcelamentos', 'Parcelamento — parcelas em atraso (risco de rescisão)', 'Atenção: {atrasadas} parcela(s) do parcelamento em atraso',
   '<p style="margin:0">O parcelamento <b>{natureza}</b>{numero} de <b>{empresa}</b> está com <b>{atrasadas} parcela(s) em atraso</b>. Com <b>3 parcelas em atraso</b> o parcelamento pode ser <b>cancelado (rescindido)</b> e a dívida volta a ser cobrada inteira.</p><p style="margin:10px 0 0">Responda este e-mail que enviamos as guias para regularizar.</p>', 7),
  ('aco_lembrete', 'acordos', 'Acordo — lembrete da parcela', 'Lembrete: parcela do acordo vence em {vencimento}',
   '<p style="margin:0">A parcela <b>{parcela}</b> do acordo com <b>{credor}</b> (processo {processo}) vence em <b>{vencimento}</b>. O pagamento é feito direto ao credor{pix}.</p><p style="margin:10px 0 0">Depois de pagar, <b>responda este e-mail com o comprovante</b>: nós juntamos ao processo.</p>', 8),
  ('aco_atraso', 'acordos', 'Acordo — parcela em atraso', 'Parcela do acordo em atraso',
   '<p style="margin:0">Não recebemos o comprovante da parcela <b>{parcela}</b> do acordo com <b>{credor}</b> (processo {processo}), vencida em <b>{vencimento}</b>.</p><p style="margin:10px 0 0">Pelo acordo, o atraso permite que o credor peça a <b>execução do saldo</b>, com multa. Se já pagou, responda com o comprovante; se não, pague o quanto antes e nos avise.</p>', 9),
  ('recibo', 'recibos', 'Recibo de pagamento', 'Recibo de pagamento — {valor}',
   '<p style="margin:0">Confirmamos o recebimento de <b>{valor}</b> ({extenso}) em <b>{data_pagamento}</b>. O recibo segue em anexo (PDF). Obrigado!</p>', 10)
on conflict (chave) do nothing;

-- troca {chave} pelos valores (os valores são escapados; o texto do modelo pode ter HTML simples)
create or replace function public.modelo_email(p_chave text, p_vars jsonb, out assunto text, out texto text)
language plpgsql stable security definer set search_path = public as $$
declare k text; v text;
begin
  select m.assunto, m.texto into assunto, texto from public.emails_modelos m where m.chave = p_chave;
  for k, v in select * from jsonb_each_text(coalesce(p_vars, '{}')) loop
    assunto := replace(assunto, '{' || k || '}', coalesce(v, ''));
    texto := replace(texto, '{' || k || '}', public.esc_html(coalesce(v, '')));
  end loop;
end $$;
revoke all on function public.modelo_email(text, jsonb) from public, anon, authenticated;

-- valor por extenso (reais e centavos), para o recibo
create or replace function public.valor_extenso(p numeric) returns text
language plpgsql immutable as $$
declare
  un text[] := array['um','dois','três','quatro','cinco','seis','sete','oito','nove','dez','onze','doze','treze','quatorze','quinze','dezesseis','dezessete','dezoito','dezenove'];
  dz text[] := array['','vinte','trinta','quarenta','cinquenta','sessenta','setenta','oitenta','noventa'];
  ct text[] := array['cento','duzentos','trezentos','quatrocentos','quinhentos','seiscentos','setecentos','oitocentos','novecentos'];
  reais bigint := floor(abs(coalesce(p, 0))); cent int := round((abs(coalesce(p, 0)) - floor(abs(coalesce(p, 0)))) * 100);
  r text := ''; partes text[] := '{}'; grupos int[] := '{}'; g int; n bigint; i int; esc text[] := array['', 'mil', 'milhão', 'bilhão']; escp text[] := array['', 'mil', 'milhões', 'bilhões'];
  function_txt text;
begin
  if reais = 0 and cent = 0 then return 'zero real'; end if;
  n := reais;
  while n > 0 loop grupos := grupos || (n % 1000)::int; n := n / 1000; end loop;
  for i in reverse coalesce(array_length(grupos, 1), 0)..1 loop
    g := grupos[i];
    if g = 0 then continue; end if;
    function_txt := case
      when g = 100 then 'cem'
      else trim(both ' ' from concat_ws(' e ',
        case when g >= 100 then ct[g / 100] end,
        case when g % 100 between 1 and 19 then un[g % 100] when g % 100 >= 20 then concat_ws(' e ', dz[(g % 100) / 10], case when g % 10 > 0 then un[g % 10] end) end))
    end;
    if i = 2 and g = 1 then function_txt := 'mil';
    elsif i > 1 then function_txt := function_txt || ' ' || case when g = 1 then esc[i] else escp[i] end; end if;
    partes := partes || function_txt;
  end loop;
  -- junta os grupos ("e" antes do último quando ele for menor que 100 ou redondo em centenas)
  for i in 1..coalesce(array_length(partes, 1), 0) loop
    if i = 1 then r := partes[i];
    elsif i = array_length(partes, 1) and (grupos[1] < 100 or grupos[1] % 100 = 0) then r := r || ' e ' || partes[i];
    else r := r || ' ' || partes[i]; end if;
  end loop;
  if reais > 0 then r := r || case when reais = 1 then ' real' when reais % 1000000 = 0 then ' de reais' else ' reais' end; end if;
  if cent > 0 then
    r := r || case when reais > 0 then ' e ' else '' end ||
         case when cent between 1 and 19 then un[cent] else concat_ws(' e ', dz[cent / 10], case when cent % 10 > 0 then un[cent % 10] end) end ||
         case when cent = 1 then ' centavo' else ' centavos' end;
  end if;
  return r;
end $$;

-- configuração da Central (automático por tipo, horário, intervalos dos avisos de atraso)
create or replace function public.config_emails() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'honorarios', coalesce((select ligada from public.regras_tarefas where chave = 'email_lembrete_honorario'), false) or coalesce((select ligada from public.regras_tarefas where chave = 'email_cobranca_honorario'), false),
    'parcelamentos', coalesce((select ligada from public.regras_tarefas where chave = 'email_lembrete_parcelamento'), false),
    'acordos', coalesce((select ligada from public.regras_tarefas where chave = 'email_lembrete_acordo'), false),
    'recibos', coalesce((select ligada from public.regras_tarefas where chave = 'email_pagamento_recebido'), false),
    'lembrete_dias', coalesce((select dias from public.regras_tarefas where chave = 'email_lembrete_honorario'), 5),
    'parc_dias', coalesce((select dias from public.regras_tarefas where chave = 'email_lembrete_parcelamento'), 3),
    'aco_dias', coalesce((select dias from public.regras_tarefas where chave = 'email_lembrete_acordo'), 3),
    'atraso', jsonb_build_array(coalesce((select dias from public.regras_tarefas where chave = 'email_cobranca_honorario'), 3),
                                coalesce(((select valor from public.configuracoes where chave = 'emails_central')->'atraso'->>1)::int, 10),
                                coalesce(((select valor from public.configuracoes where chave = 'emails_central')->'atraso'->>2)::int, 20)),
    'aco_atraso_dias', coalesce(((select valor from public.configuracoes where chave = 'emails_central')->>'aco_atraso_dias')::int, 2),
    'hora', (select valor->>'hora' from public.configuracoes where chave = 'emails_central'));
$$;
revoke all on function public.config_emails() from public, anon;
grant execute on function public.config_emails() to authenticated;

-- tudo o que a rotina mandaria hoje (sem enviar): a tela mostra e a rotina usa a mesma lista
create or replace function public.emails_pendentes()
returns table (tipo text, regra text, ref text, cliente_id uuid, grupo_id uuid, finalidade text, assunto text, texto text, itens jsonb, pagar boolean, marcas text[], vence date)
language plpgsql stable security definer set search_path = public as $$
declare cfg jsonb := public.config_emails(); t1 int; t2 int; t3 int; x record; m record; k int;
begin
  t1 := (cfg->'atraso'->>0)::int; t2 := (cfg->'atraso'->>1)::int; t3 := (cfg->'atraso'->>2)::int;
  -- honorários: lembrete (todos os que vencem até N dias; cada lançamento uma vez)
  for x in select l.cliente_id cli, l.grupo_id grp, min(l.vencimento) venc, array_agg('email_lhi:' || l.id order by l.id) mk, string_agg(l.id::text, ',' order by l.id) ids,
                  jsonb_agg(jsonb_build_object('descricao', l.descricao || coalesce(' (' || nullif(l.referencia, '') || ')', ''), 'vencimento', l.vencimento, 'valor', l.valor) order by l.vencimento) its
             from public.lancamentos l where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false)
              and l.vencimento > current_date and l.vencimento <= current_date + (cfg->>'lembrete_dias')::int
              and not exists (select 1 from public.automacoes_log g where g.ref = 'email_lhi:' || l.id)
            group by l.cliente_id, l.grupo_id loop
    select * into m from public.modelo_email('hon_lembrete', jsonb_build_object('vencimento', to_char(x.venc, 'DD/MM/YYYY')));
    return query select 'honorarios'::text, 'email_lh'::text, 'email_lh:' || md5(x.ids), x.cli, x.grp, 'cobranca'::text, m.assunto, m.texto, x.its, true, x.mk, x.venc;
  end loop;
  -- honorários: vence hoje (perfil "Só no vencimento")
  for x in select l.cliente_id cli, l.grupo_id grp, min(l.vencimento) venc, array_agg('email_vhi:' || l.id order by l.id) mk, string_agg(l.id::text, ',' order by l.id) ids,
                  jsonb_agg(jsonb_build_object('descricao', l.descricao || coalesce(' (' || nullif(l.referencia, '') || ')', ''), 'vencimento', l.vencimento, 'valor', l.valor)) its
             from public.lancamentos l where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false)
              and l.vencimento between current_date - 2 and current_date
              and not exists (select 1 from public.automacoes_log g where g.ref = 'email_vhi:' || l.id)
              and public.pode_email(l.cliente_id, l.grupo_id, 'vencimento') and public.perfil_email_de(l.cliente_id, l.grupo_id) <> 'padrao'
            group by l.cliente_id, l.grupo_id loop
    select * into m from public.modelo_email('hon_hoje', '{}');
    return query select 'honorarios'::text, 'email_vh'::text, 'email_vh:' || md5(x.ids), x.cli, x.grp, 'cobranca'::text, m.assunto, m.texto, x.its, true, x.mk, x.venc;
  end loop;
  -- honorários em atraso: 1º, 2º e 3º aviso (um e-mail por cliente e nível, com todos os que estão em aberto)
  for k in 1..3 loop
    for x in select l.cliente_id cli, l.grupo_id grp, min(l.vencimento) venc,
                    array_agg(case when k = 1 then 'email_ch:' else 'email_ch' || k || ':' end || l.id order by l.id) mk, string_agg(l.id::text, ',' order by l.id) ids
               from public.lancamentos l where l.tipo = 'receita' and not l.redutor and not l.pago and not coalesce(l.perda, false)
                and current_date - l.vencimento >= case k when 1 then t1 when 2 then t2 else t3 end
                -- Backup 26: um aviso por vez (1º → 2º → 3º), com o intervalo entre eles; quem nunca foi avisado recebe o 1º (não pula para o 2º)
                and not exists (select 1 from public.automacoes_log g where g.ref in (select pf || l.id from unnest(case k when 1 then array['email_ch:', 'email_ch2:', 'email_ch3:']
                                                                                                                  when 2 then array['email_ch2:', 'email_ch3:'] else array['email_ch3:'] end) pf))
                and (k = 1 or exists (select 1 from public.automacoes_log g where g.ref = case k when 2 then 'email_ch:' else 'email_ch2:' end || l.id
                                        and g.quando <= now() - make_interval(days => greatest(case k when 2 then t2 - t1 else t3 - t2 end, 1))))
              group by l.cliente_id, l.grupo_id loop
      select * into m from public.modelo_email('hon_atraso' || k, '{}');
      return query select 'honorarios'::text, 'email_ch'::text, 'email_ch' || k || 'c:' || md5(x.ids), x.cli, x.grp, 'cobranca'::text, m.assunto, m.texto,
        (select jsonb_agg(jsonb_build_object('descricao', o.descricao || coalesce(' (' || nullif(o.referencia, '') || ')', ''), 'vencimento', o.vencimento, 'valor', o.valor) order by o.vencimento)
           from public.lancamentos o where o.tipo = 'receita' and not o.redutor and not o.pago and not coalesce(o.perda, false) and o.vencimento < current_date
            and ((x.cli is not null and o.cliente_id = x.cli) or (x.cli is null and o.grupo_id = x.grp))), true, x.mk, x.venc;
    end loop;
  end loop;
  -- parcelamentos: guia do mês (N dias antes)
  for x in select pa.id, pa.numero, pa.vencimento, p.empresa, p.natureza, p.local, p.numero parc_num, p.valor_ultima_parcela, p.grupo_id, p.total_parcelas,
                  (select cl.id from public.clientes cl where (d.d <> '' and regexp_replace(cl.cpf_cnpj, '\D', '', 'g') = d.d) or cl.nome = p.empresa limit 1) cli
             from public.parcelas pa join public.parcelamentos p on p.id = pa.parcelamento_id
             cross join lateral (select regexp_replace(coalesce(p.cnpj, ''), '\D', '', 'g') d) d
            where not pa.pago and pa.vencimento between current_date and current_date + (cfg->>'parc_dias')::int
              and not exists (select 1 from public.automacoes_log g where g.ref = 'email_lp:' || pa.id) loop
    select * into m from public.modelo_email('parc_guia', jsonb_build_object('parcela', coalesce(x.numero, '') || coalesce('/' || x.total_parcelas, ''), 'natureza', trim(both ' ·' from coalesce(x.natureza, '') || coalesce(' · ' || nullif(x.local, ''), '')),
      'numero', coalesce(' (nº ' || nullif(x.parc_num, '') || ')', ''), 'empresa', coalesce(x.empresa, ''), 'vencimento', to_char(x.vencimento, 'DD/MM/YYYY')));
    return query select 'parcelamentos'::text, 'email_lp'::text, 'email_lp:' || x.id, x.cli, x.grupo_id, 'guia'::text, m.assunto, m.texto,
      case when coalesce(x.valor_ultima_parcela, 0) > 0 then jsonb_build_array(jsonb_build_object('descricao', 'Parcela ' || coalesce(x.numero, ''), 'vencimento', x.vencimento, 'valor', x.valor_ultima_parcela)) else '[]'::jsonb end,
      false, '{}'::text[], x.vencimento;
  end loop;
  -- parcelamentos em atraso (1 ou 2 parcelas: avisa antes da rescisão; muda o número, avisa de novo)
  if coalesce((select ligada from public.regras_tarefas where chave = 'email_atraso_parcelamento'), true) then
    for x in select * from (select p.id, p.empresa, p.natureza, p.local, p.numero parc_num, p.grupo_id, count(*) n, min(pa.vencimento) venc,
                    (select cl.id from public.clientes cl where (d.d <> '' and regexp_replace(cl.cpf_cnpj, '\D', '', 'g') = d.d) or cl.nome = p.empresa limit 1) cli
               from public.parcelas pa join public.parcelamentos p on p.id = pa.parcelamento_id
               cross join lateral (select regexp_replace(coalesce(p.cnpj, ''), '\D', '', 'g') d) d
              where not pa.pago and pa.vencimento < current_date
              group by p.id, p.empresa, p.natureza, p.local, p.numero, p.grupo_id, d.d) z
             where not exists (select 1 from public.automacoes_log g where g.ref = 'email_pa:' || z.id || ':' || z.n) loop
      select * into m from public.modelo_email('parc_atraso', jsonb_build_object('atrasadas', x.n, 'natureza', trim(both ' ·' from coalesce(x.natureza, '') || coalesce(' · ' || nullif(x.local, ''), '')),
        'numero', coalesce(' (nº ' || nullif(x.parc_num, '') || ')', ''), 'empresa', coalesce(x.empresa, '')));
      return query select 'parcelamentos'::text, 'email_lp'::text, 'email_pa:' || x.id || ':' || x.n, x.cli, x.grupo_id, 'guia'::text, m.assunto, m.texto, '[]'::jsonb, false, '{}'::text[], x.venc;
    end loop;
  end if;
  -- acordos: lembrete (até N dias antes; cada parcela uma vez) e atraso (N dias depois do vencimento)
  for x in select a.id, a.valor, a.vencimento, a.credor, a.parcela, a.total_parcelas, a.processo, a.grupo_id, a.pix, a.banco, a.vencimento < current_date atrasada,
                  (select cl.id from public.clientes cl where cl.grupo_id = a.grupo_id and public.primeiro_nome(cl.nome) = public.primeiro_nome(a.devedor) limit 1) cli
             from public.acordos a
            where not a.pago and ((a.vencimento between current_date and current_date + (cfg->>'aco_dias')::int and not exists (select 1 from public.automacoes_log g where g.ref = 'email_la:' || a.id))
               or (a.vencimento <= current_date - (cfg->>'aco_atraso_dias')::int and coalesce((select ligada from public.regras_tarefas where chave = 'email_atraso_acordo'), true)
                   and not exists (select 1 from public.automacoes_log g where g.ref = 'email_aa:' || a.id))) loop
    select * into m from public.modelo_email(case when x.atrasada then 'aco_atraso' else 'aco_lembrete' end, jsonb_build_object('parcela', coalesce(x.parcela, '') || coalesce('/' || nullif(x.total_parcelas, ''), ''),
      'credor', coalesce(x.credor, ''), 'processo', coalesce(x.processo, ''), 'vencimento', to_char(x.vencimento, 'DD/MM/YYYY'),
      'pix', case when coalesce(x.pix, '') <> '' then ' — PIX do credor: ' || x.pix else '' end || case when coalesce(x.banco, '') <> '' then ' — ' || x.banco else '' end));
    return query select 'acordos'::text, 'email_la'::text, case when x.atrasada then 'email_aa:' else 'email_la:' end || x.id, x.cli, x.grupo_id, 'acordo'::text, m.assunto, m.texto,
      jsonb_build_array(jsonb_build_object('descricao', 'Parcela ' || coalesce(x.parcela, '') || coalesce('/' || nullif(x.total_parcelas, ''), ''), 'vencimento', x.vencimento, 'valor', x.valor)), false, '{}'::text[], x.vencimento;
  end loop;
end $$;
revoke all on function public.emails_pendentes() from public, anon, authenticated;

-- regras novas (entram na Central de automações e no "automático" da Central de e-mails)
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias, grupo) values
  ('email_atraso_parcelamento', 'E-mail ao cliente: parcelamento com parcela em atraso', 'Avisa o risco de rescisão (3 parcelas em atraso) quando o número de parcelas atrasadas muda', true, 0, 'cliente_email'),
  ('email_atraso_acordo', 'E-mail ao cliente: parcela do acordo em atraso', 'N dias depois do vencimento sem baixa, avisa o cliente (o credor pode executar)', true, 2, 'cliente_email')
on conflict (chave) do nothing;

-- envio (redefinido): aceita anexo (recibo em PDF); respeita perfil, contato certo e nunca example.com
drop function if exists public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean);
create or replace function public.email_cliente_enviar(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_finalidade text,
  p_assunto text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_anexo jsonb default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare c record; tipo text;
begin
  if exists (select 1 from public.automacoes_log where ref = p_ref) then return false; end if;
  tipo := case p_regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' when 'email_ch' then 'cobranca'
                       when 'email_pr' then 'recibo' when 'email_lp' then 'parcelamento' when 'email_la' then 'acordo' end;
  if tipo is not null and not public.pode_email(p_cliente, p_grupo, tipo) then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (p_regra, p_ref, 'Não enviado (perfil de e-mail do cliente): ' || p_assunto, p_cliente);
    return false;
  end if;
  select * into c from public.contato_do_cliente(p_cliente, p_grupo, p_finalidade);
  if c.email is null or c.email = '' then return false; end if;
  if c.email ~* '(@|\.)example\.com$' then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, 'Demonstração (não enviado): ' || p_assunto, p_cliente);
    return false;
  end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo)
  values (null, c.email, p_assunto, public.email_cliente_html(p_assunto, c.nome, p_texto, p_itens, p_pagar), 'cliente', p_ref, p_anexo);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, p_assunto || ' → ' || c.email, p_cliente);
  return true;
end $$;
revoke all on function public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean, jsonb) from public, anon, authenticated;

-- tipo da Central ligado no automático?
create or replace function public.email_tipo_auto(p_tipo text) returns boolean
language sql stable security definer set search_path = public as $$ select coalesce((public.config_emails()->>p_tipo)::boolean, false) $$;
revoke all on function public.email_tipo_auto(text) from public, anon, authenticated;

-- a rotina: envia o que está na lista de hoje, só dos tipos ligados no automático
create or replace function public.rodar_emails_cliente() returns int
language plpgsql security definer set search_path = public as $$
declare x record; n int := 0;
begin
  for x in select * from public.emails_pendentes() loop
    if not public.email_tipo_auto(x.tipo) then continue; end if;
    if x.ref like 'email_ch%' and not coalesce((select ligada from public.regras_tarefas where chave = 'email_cobranca_honorario'), false) then continue; end if;
    if x.ref like 'email_lh:%' and not coalesce((select ligada from public.regras_tarefas where chave = 'email_lembrete_honorario'), false) then continue; end if;
    if public.email_cliente_enviar(x.regra, x.ref, x.cliente_id, x.grupo_id, x.finalidade, x.assunto, x.texto, x.itens, x.pagar) then n := n + 1; end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) select '_item', mk, 'marcador', x.cliente_id from unnest(x.marcas) mk
      where not exists (select 1 from public.automacoes_log g where g.ref = mk);
  end loop;
  return n;
end $$;
revoke all on function public.rodar_emails_cliente() from public, anon, authenticated;

-- dados do recibo: emitente (pela pessoa do lançamento), quem pagou, valor por extenso, data e local
create or replace function public.recibo_dados(p_lanc uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare l record; em jsonb; k_em text; quem text; doc text; cfg jsonb;
begin
  select * into l from public.lancamentos where id = p_lanc;
  if not found then return null; end if;
  cfg := coalesce((select valor from public.configuracoes where chave = 'recibo_emitentes'), '{}');
  k_em := lower(public.primeiro_nome(coalesce(l.responsavel, '')));
  k_em := translate(k_em, 'áàâãéêíóôõúç', 'aaaaeeiooouc');
  em := coalesce(cfg->k_em, cfg->'escritorio', jsonb_build_object('nome', 'ARAÚJO & CASTRO ADVOCACIA E CONSULTORIA', 'qualif', '', 'local', coalesce((select value->>'local' from jsonb_each(cfg) limit 1), '')));
  select coalesce(cl.nome, g.nome, l.favorecido, 'cliente'), coalesce(nullif(cl.cpf_cnpj, ''), '') into quem, doc
    from (select 1) z left join public.clientes cl on cl.id = l.cliente_id left join public.grupos g on g.id = l.grupo_id;
  return jsonb_build_object('emitente', em->>'nome', 'qualif', coalesce(em->>'qualif', ''), 'oab', coalesce(em->>'oab', ''), 'local', coalesce(em->>'local', ''),
    'pagador', quem, 'doc', doc, 'valor', l.valor, 'valor_txt', public.brl_texto(l.valor), 'extenso', public.valor_extenso(l.valor),
    'referente', l.descricao || coalesce(' (' || nullif(l.referencia, '') || ')', ''), 'data', to_char(coalesce(l.data_pagamento, current_date), 'DD/MM/YYYY'),
    'data_extenso', extract(day from coalesce(l.data_pagamento, current_date))::int || ' de ' ||
      (array['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'])[extract(month from coalesce(l.data_pagamento, current_date))::int] ||
      ' de ' || extract(year from coalesce(l.data_pagamento, current_date))::int, 'numero', upper(left(replace(l.id::text, '-', ''), 8)));
end $$;
revoke all on function public.recibo_dados(uuid) from public, anon;
grant execute on function public.recibo_dados(uuid) to authenticated;

-- "Recebido": recibo por e-mail com o PDF anexo (o PDF é montado pela função erp-emails na hora do envio)
create or replace function public.pagamento_automacoes() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int; r jsonb; m record;
begin
  if not new.pago or old.pago or new.tipo <> 'receita' or new.redutor then return null; end if;
  if exists (select 1 from public.regras_tarefas where chave = 'pagamento_conclui' and ligada) then
    update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(i || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) i) where chave_regra = 'cob:' || new.id and status not in ('concluida','cancelada');
    get diagnostics n = row_count;
    if n > 0 then insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('pagamento_conclui', 'pago:' || new.id, 'Honorário recebido: cobrança concluída sozinha — ' || new.descricao, new.cliente_id); end if;
  end if;
  if exists (select 1 from public.regras_tarefas where chave = 'email_pagamento_recebido' and ligada) then
    r := public.recibo_dados(new.id);
    select * into m from public.modelo_email('recibo', jsonb_build_object('valor', r->>'valor_txt', 'extenso', r->>'extenso', 'data_pagamento', r->>'data'));
    perform public.email_cliente_enviar('email_pr', 'email_pr:' || new.id, new.cliente_id, new.grupo_id, 'recibo', m.assunto, m.texto,
      jsonb_build_array(jsonb_build_object('descricao', new.descricao || coalesce(' (' || nullif(new.referencia, '') || ')', ''), 'vencimento', new.vencimento, 'valor', new.valor)), false,
      jsonb_build_object('tipo', 'recibo', 'arquivo', 'Recibo ' || (r->>'numero') || '.pdf', 'dados', r));
  end if;
  return null;
end $$;

-- ─────────── Central de e-mails (tela) ───────────
create or replace function public.pode_central_emails() returns boolean
language sql stable security definer set search_path = public as $$
  select public.eh_admin() or public.pode('financeiro_juridico', 'editar') or public.pode('financeiro_contab', 'editar') or public.pode('juridico', 'editar');
$$;
revoke all on function public.pode_central_emails() from public, anon;
grant execute on function public.pode_central_emails() to authenticated;

create or replace function public.emails_central(p_situacao text default 'hoje') returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.pode_central_emails() then raise exception 'permission denied: sem acesso à Central de e-mails.'; end if;
  if p_situacao = 'hoje' then
    select coalesce(jsonb_agg(jsonb_build_object('ref', x.ref, 'tipo', x.tipo, 'assunto', x.assunto, 'vence', x.vence, 'cliente', coalesce(cl.nome, g.nome, '—'), 'grupo', g.nome,
             'para', ct.email, 'auto', public.email_tipo_auto(x.tipo),
             'bloqueio', case when x.tipo <> 'honorarios' and x.tipo <> 'recibos' and not public.pode_email(x.cliente_id, x.grupo_id, case x.regra when 'email_lp' then 'parcelamento' else 'acordo' end) then 'perfil do cliente'
                              when x.tipo = 'honorarios' and not public.pode_email(x.cliente_id, x.grupo_id, case x.regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' else 'cobranca' end) then 'perfil do cliente'
                              when coalesce(ct.email, '') = '' then 'sem e-mail cadastrado'
                              when ct.email ~* '(@|\.)example\.com$' then 'demonstração' else '' end,
             'total', (select coalesce(sum((i->>'valor')::numeric), 0) from jsonb_array_elements(x.itens) i)) order by x.tipo, coalesce(cl.nome, g.nome)), '[]')
      into r
      from public.emails_pendentes() x left join public.clientes cl on cl.id = x.cliente_id left join public.grupos g on g.id = coalesce(x.grupo_id, cl.grupo_id)
      left join lateral (select email from public.contato_do_cliente(x.cliente_id, x.grupo_id, x.finalidade) limit 1) ct on true;
  else
    select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'para', f.para, 'assunto', f.assunto, 'status', f.status, 'erro', f.erro, 'quando', coalesce(f.enviado_em, f.criado_em),
             'ref', f.referencia, 'anexo', f.anexo is not null, 'tipo', case when f.referencia like 'email_pr:%' then 'recibos' when f.referencia ~ '^email_(lp|pa)' then 'parcelamentos'
             when f.referencia ~ '^email_(la|aa)' then 'acordos' when f.tipo = 'proposta' then 'propostas' else 'honorarios' end,
             'cliente', (select coalesce(cl.nome, '') from public.automacoes_log a left join public.clientes cl on cl.id = a.cliente_id where a.ref = f.referencia and f.referencia <> '' limit 1))
             order by coalesce(f.enviado_em, f.criado_em) desc), '[]') into r
      from (select * from public.email_fila where tipo in ('cliente', 'proposta') and criado_em > now() - interval '120 days'
               and (case when p_situacao = 'erro' then status = 'erro' else status in ('enviado', 'pendente') end) order by criado_em desc limit 300) f;
  end if;
  return r;
end $$;
revoke all on function public.emails_central(text) from public, anon;
grant execute on function public.emails_central(text) to authenticated;

create or replace function public.emails_central_previa(p_ref text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare x record; c record; f record;
begin
  if not public.pode_central_emails() then raise exception 'permission denied'; end if;
  select * into x from public.emails_pendentes() e where e.ref = p_ref;
  if found then
    select * into c from public.contato_do_cliente(x.cliente_id, x.grupo_id, x.finalidade);
    return jsonb_build_object('assunto', x.assunto, 'para', c.email, 'html', public.email_cliente_html(x.assunto, c.nome, x.texto, x.itens, x.pagar));
  end if;
  select * into f from public.email_fila where referencia = p_ref or id::text = p_ref order by criado_em desc limit 1;
  if found then return jsonb_build_object('assunto', f.assunto, 'para', f.para, 'html', f.html); end if;
  return null;
end $$;
revoke all on function public.emails_central_previa(text) from public, anon;
grant execute on function public.emails_central_previa(text) to authenticated;

create or replace function public.emails_central_enviar(p_refs text[]) returns int
language plpgsql security definer set search_path = public as $$
declare x record; n int := 0;
begin
  if not public.pode_central_emails() then raise exception 'permission denied'; end if;
  for x in select * from public.emails_pendentes() e where e.ref = any(p_refs) loop
    if public.email_cliente_enviar(x.regra, x.ref, x.cliente_id, x.grupo_id, x.finalidade, x.assunto, x.texto, x.itens, x.pagar) then n := n + 1; end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) select '_item', mk, 'marcador', x.cliente_id from unnest(x.marcas) mk
      where not exists (select 1 from public.automacoes_log g where g.ref = mk);
  end loop;
  return n;
end $$;
revoke all on function public.emails_central_enviar(text[]) from public, anon;
grant execute on function public.emails_central_enviar(text[]) to authenticated;

create or replace function public.emails_central_pular(p_refs text[]) returns int
language plpgsql security definer set search_path = public as $$
declare x record; n int := 0;
begin
  if not public.pode_central_emails() then raise exception 'permission denied'; end if;
  for x in select * from public.emails_pendentes() e where e.ref = any(p_refs) loop
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (x.regra, x.ref, 'Pulado na Central de e-mails: ' || x.assunto, x.cliente_id);
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) select '_item', mk, 'marcador (pulado)', x.cliente_id from unnest(x.marcas) mk
      where not exists (select 1 from public.automacoes_log g where g.ref = mk);
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.emails_central_pular(text[]) from public, anon;
grant execute on function public.emails_central_pular(text[]) to authenticated;

create or replace function public.email_reenviar(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.pode_central_emails() then raise exception 'permission denied'; end if;
  update public.email_fila set status = 'pendente', tentativas = 0, erro = '' where id = p_id and status = 'erro';
end $$;
revoke all on function public.email_reenviar(uuid) from public, anon;
grant execute on function public.email_reenviar(uuid) to authenticated;

-- automático por tipo + horário + intervalos (só o administrador)
create or replace function public.salvar_config_emails(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare hora text := nullif(p->>'hora', ''); h int; mi int;
begin
  if not public.eh_admin() then raise exception 'permission denied: só o administrador altera.'; end if;
  if p ? 'honorarios' then update public.regras_tarefas set ligada = (p->>'honorarios')::boolean where chave in ('email_lembrete_honorario', 'email_cobranca_honorario'); end if;
  if p ? 'parcelamentos' then update public.regras_tarefas set ligada = (p->>'parcelamentos')::boolean where chave in ('email_lembrete_parcelamento', 'email_atraso_parcelamento'); end if;
  if p ? 'acordos' then update public.regras_tarefas set ligada = (p->>'acordos')::boolean where chave in ('email_lembrete_acordo', 'email_atraso_acordo'); end if;
  if p ? 'recibos' then update public.regras_tarefas set ligada = (p->>'recibos')::boolean where chave = 'email_pagamento_recebido'; end if;
  if p ? 'lembrete_dias' then update public.regras_tarefas set dias = greatest(1, (p->>'lembrete_dias')::int) where chave = 'email_lembrete_honorario'; end if;
  if p ? 'parc_dias' then update public.regras_tarefas set dias = greatest(0, (p->>'parc_dias')::int) where chave = 'email_lembrete_parcelamento'; end if;
  if p ? 'aco_dias' then update public.regras_tarefas set dias = greatest(0, (p->>'aco_dias')::int) where chave = 'email_lembrete_acordo'; end if;
  if p ? 'atraso' then
    update public.regras_tarefas set dias = greatest(1, (p->'atraso'->>0)::int) where chave = 'email_cobranca_honorario';
    if (p->'atraso'->>1)::int <= (p->'atraso'->>0)::int or (p->'atraso'->>2)::int <= (p->'atraso'->>1)::int then raise exception 'Os avisos precisam estar em ordem (1º < 2º < 3º).'; end if;
  end if;
  if hora is not null and hora !~ '^([01]\d|2[0-3]):[0-5]\d$' then raise exception 'Horário inválido (use HH:MM).'; end if;
  insert into public.configuracoes (chave, valor) values ('emails_central', jsonb_build_object('hora', hora,
      'atraso', coalesce(p->'atraso', (public.config_emails())->'atraso'), 'aco_atraso_dias', coalesce((p->>'aco_atraso_dias')::int, ((public.config_emails())->>'aco_atraso_dias')::int)))
  on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  -- horário próprio (Brasília): rotina separada; sem horário, os e-mails saem junto das regras (7h)
  begin
    perform cron.unschedule(jobid) from cron.job where jobname = 'erp_emails_cliente';
    if hora is not null then
      h := (split_part(hora, ':', 1)::int + 3) % 24; mi := split_part(hora, ':', 2)::int;
      perform cron.schedule('erp_emails_cliente', mi || ' ' || h || ' * * 1-5', 'select public.rodar_emails_cliente()');
    end if;
  exception when others then null;
  end;
  return public.config_emails();
end $$;
revoke all on function public.salvar_config_emails(jsonb) from public, anon;
grant execute on function public.salvar_config_emails(jsonb) to authenticated;

-- com horário próprio, a rotina das 7h não manda os e-mails ao cliente (evita mandar duas vezes)
create or replace function public.rodar_emails_cliente_se_sem_hora() returns int
language plpgsql security definer set search_path = public as $$
begin
  if (select valor->>'hora' from public.configuracoes where chave = 'emails_central') is not null then return 0; end if;
  return public.rodar_emails_cliente();
end $$;
revoke all on function public.rodar_emails_cliente_se_sem_hora() from public, anon, authenticated;

-- histórico de e-mails na ficha do cliente
create or replace function public.emails_do_cliente(p_cliente uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare mails text[];
begin
  if not (public.eh_equipe() and public.pode('clientes')) then raise exception 'permission denied'; end if;
  select array_agg(distinct lower(e)) into mails from (select email e from public.clientes where id = p_cliente and email <> ''
    union select email from public.contatos where cliente_id = p_cliente and email <> '') z;
  return coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'quando', coalesce(f.enviado_em, f.criado_em), 'assunto', f.assunto, 'para', f.para, 'status', f.status, 'erro', f.erro,
      'anexo', f.anexo is not null, 'tipo', case when f.referencia like 'email_pr:%' then 'Recibo' when f.referencia ~ '^email_(lp|pa)' then 'Parcelamento' when f.referencia ~ '^email_(la|aa)' then 'Acordo'
      when f.referencia like 'email_bv:%' then 'Boas-vindas' when f.referencia like 'email_cv:%' then 'Convite de reunião'
      when f.tipo = 'proposta' then 'Proposta' when f.referencia like 'email_%' then 'Honorários' else 'Mensagem' end) order by f.criado_em desc)
    from public.email_fila f where f.tipo in ('cliente', 'proposta')
     and (f.referencia in (select ref from public.automacoes_log where cliente_id = p_cliente) or lower(f.para) = any(coalesce(mails, '{}')))), '[]');
end $$;
revoke all on function public.emails_do_cliente(uuid) from public, anon;
grant execute on function public.emails_do_cliente(uuid) to authenticated;

-- ═══════════════════════════════════════════════════════════════════════
-- v22 (Backup 16) — Tarefas: modelos por tipo de serviço, resumo diário às 8h, carga de trabalho
-- ═══════════════════════════════════════════════════════════════════════
alter table public.modelos_fluxo add column if not exists servico text not null default '';
insert into public.modelos_fluxo (nome, descricao, itens, servico)
select v.n, v.d, v.i::jsonb, v.s from (values
  ('Abertura de empresa', 'Da escolha do tipo societário às licenças (prazos em dias úteis antes da data final)',
   '[{"titulo":"Reunião inicial e lista de documentos","dias":15,"checklist":["Documentos dos sócios","Endereço e atividade (CNAE)","Capital social"]},{"titulo":"Contrato social e viabilidade","dias":10},{"titulo":"Registro na Junta e CNPJ","dias":6},{"titulo":"Inscrições estadual e municipal","dias":3},{"titulo":"Alvará e licenças; entrega ao cliente","dias":0}]', 'Empresarial'),
  ('Inventário', 'Inventário judicial ou extrajudicial com partilha',
   '[{"titulo":"Levantar bens, dívidas e herdeiros","dias":40,"checklist":["Certidão de óbito","Documentos dos herdeiros","Matrículas e extratos"]},{"titulo":"Cálculo e guias do ITCD","dias":25},{"titulo":"Minuta da partilha","dias":15},{"titulo":"Protocolo (cartório ou processo)","dias":8},{"titulo":"Registro e entrega aos herdeiros","dias":0}]', 'Sucessões'),
  ('Defesa trabalhista', 'Da citação à audiência',
   '[{"titulo":"Analisar a inicial e pedir documentos ao cliente","dias":10,"checklist":["Contrato de trabalho","Holerites e ponto","TRCT e guias"]},{"titulo":"Reunião de preparação com o cliente e testemunhas","dias":5},{"titulo":"Contestação e documentos","dias":2},{"titulo":"Audiência","dias":0}]', 'Trabalhista')
) v(n, d, i, s)
where not exists (select 1 from public.modelos_fluxo m where m.nome = v.n);

-- resumo do dia de cada pessoa às 8h de Brasília (11h UTC); cada um liga/desliga em "Meus avisos por e-mail"
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_resumo_diario';
  perform cron.schedule('erp_resumo_diario', '0 11 * * 1-5', 'select public.montar_resumos_diarios()');
exception when others then null;
end $$;


-- ═══════════════════════════════════════════════════════════════════
-- v23 (Backup 17) — CRM: 8 etapas em andamento (4 em cima, 4 embaixo) com "Follow-up da proposta"
-- entre "Proposta enviada" e "Negociação". Só roda uma vez (se a etapa ainda não existir).
-- ═══════════════════════════════════════════════════════════════════
do $$ begin
  if not exists (select 1 from public.crm_etapas where nome = 'Follow-up da proposta') then
    update public.crm_etapas set ordem = ordem + 1 where final = '' and ordem >= 5;
    insert into public.crm_etapas (nome, ordem, probabilidade, final, dias_alerta, descricao)
    values ('Follow-up da proposta', 5, 65, '', 4, 'Proposta sem resposta: cobrar retorno do cliente (✉ Follow-up no cartão).');
  end if;
end $$;

-- v23: a Central mostra para qual e-mail vai (e de qual contato: nome e finalidade), separado da situação
create or replace function public.emails_central(p_situacao text default 'hoje') returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.pode_central_emails() then raise exception 'permission denied: sem acesso à Central de e-mails.'; end if;
  if p_situacao = 'hoje' then
    select coalesce(jsonb_agg(jsonb_build_object('ref', x.ref, 'tipo', x.tipo, 'assunto', x.assunto, 'vence', x.vence, 'cliente', coalesce(cl.nome, g.nome, '—'), 'grupo', g.nome,
             'para', ct.email, 'contato', ct.nome, 'finalidade', x.finalidade, 'auto', public.email_tipo_auto(x.tipo),
             'bloqueio', case when x.tipo <> 'honorarios' and x.tipo <> 'recibos' and not public.pode_email(x.cliente_id, x.grupo_id, case x.regra when 'email_lp' then 'parcelamento' else 'acordo' end) then 'perfil do cliente'
                              when x.tipo = 'honorarios' and not public.pode_email(x.cliente_id, x.grupo_id, case x.regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' else 'cobranca' end) then 'perfil do cliente'
                              when coalesce(ct.email, '') = '' then 'sem e-mail cadastrado'
                              when ct.email ~* '(@|\.)example\.com$' then 'demonstração' else '' end,
             'total', (select coalesce(sum((i->>'valor')::numeric), 0) from jsonb_array_elements(x.itens) i)) order by x.tipo, coalesce(cl.nome, g.nome)), '[]')
      into r
      from public.emails_pendentes() x left join public.clientes cl on cl.id = x.cliente_id left join public.grupos g on g.id = coalesce(x.grupo_id, cl.grupo_id)
      left join lateral (select email, nome from public.contato_do_cliente(x.cliente_id, x.grupo_id, x.finalidade) limit 1) ct on true;
  else
    select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'para', f.para, 'assunto', f.assunto, 'status', f.status, 'erro', f.erro, 'quando', coalesce(f.enviado_em, f.criado_em),
             'ref', f.referencia, 'anexo', f.anexo is not null, 'tipo', case when f.referencia like 'email_pr:%' then 'recibos' when f.referencia ~ '^email_(lp|pa)' then 'parcelamentos'
             when f.referencia ~ '^email_(la|aa)' then 'acordos' when f.tipo = 'proposta' then 'propostas' else 'honorarios' end,
             'cliente', (select coalesce(cl.nome, '') from public.automacoes_log a left join public.clientes cl on cl.id = a.cliente_id where a.ref = f.referencia and f.referencia <> '' limit 1))
             order by coalesce(f.enviado_em, f.criado_em) desc), '[]') into r
      from (select * from public.email_fila where tipo in ('cliente', 'proposta') and criado_em > now() - interval '120 days'
               and (case when p_situacao = 'erro' then status = 'erro' else status in ('enviado', 'pendente') end) order by criado_em desc limit 300) f;
  end if;
  return r;
end $$;
revoke all on function public.emails_central(text) from public, anon;
grant execute on function public.emails_central(text) to authenticated;

-- v23: prévia do e-mail escrito à mão ("✉ Enviar e-mail ao cliente") no mesmo layout com a marca que ele vai sair
create or replace function public.previa_email_manual(p_assunto text, p_texto text) returns text
language plpgsql stable security definer set search_path = public as $$
declare corpo text;
begin
  if not (public.pode('clientes', 'editar') or public.pode('financeiro_juridico', 'editar') or public.pode('financeiro_contab', 'editar') or public.pode('juridico', 'editar')) then
    raise exception 'permission denied';
  end if;
  corpo := '<p style="margin:0 0 10px">' || replace(replace(public.esc_html(btrim(coalesce(p_texto, ''))), E'\n\n', '</p><p style="margin:0 0 10px">'), E'\n', '<br>') || '</p>';
  return public.email_cliente_html(coalesce(nullif(btrim(p_assunto), ''), 'Mensagem do escritório'), '-', corpo, '[]', false, '-');
end $$;
revoke all on function public.previa_email_manual(text, text) from public, anon;
grant execute on function public.previa_email_manual(text, text) to authenticated;
-- v23: prévia de um modelo da Central enquanto edita (texto do modelo já com exemplos no lugar das {chaves})
create or replace function public.previa_email_modelo(p_assunto text, p_html text) returns text
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.pode_central_emails() then raise exception 'permission denied'; end if;
  return public.email_cliente_html(coalesce(nullif(btrim(p_assunto), ''), 'Assunto'), 'Marta', coalesce(p_html, ''),
    '[{"descricao":"Consultoria tributária mensal (exemplo)","vencimento":"2026-10-10","valor":4500}]', true);
end $$;
revoke all on function public.previa_email_modelo(text, text) from public, anon;
grant execute on function public.previa_email_modelo(text, text) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- v23 (Backup 17) — Contratos: aditivos dentro do contrato
--   valor  → consultoria: novo valor mensal (ou nº de salários) a partir de uma competência; as mensalidades
--            anteriores continuam com o valor antigo. Serviço pontual: valor a mais, lançado em parcelas.
--   escopo / prazo / outro → só registra (com o documento no contrato).
-- Reajuste: só consultoria em salários mínimos (automático quando o salário mínimo do ano é cadastrado).
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.contratos_aditivos (
  id                 uuid primary key default gen_random_uuid(),
  contrato_id        uuid not null references public.contratos(id) on delete cascade,
  cliente_id         uuid references public.clientes(id) on delete set null,
  numero             int not null default 1,
  data               date not null default current_date,
  tipo               text not null default 'outro' check (tipo in ('valor','escopo','prazo','outro')),
  descricao          text not null default '',
  a_partir           date,                         -- competência (1º dia do mês) em que o valor novo começa
  forma_anterior     text, valor_mensal_anterior numeric(14,2), qtd_salarios_anterior numeric(8,2),
  forma_nova         text, valor_mensal_novo numeric(14,2), qtd_salarios_novo numeric(8,2),
  valor_adicional    numeric(14,2),                -- serviço pontual: valor a mais
  parcelas           int,
  criado_por         uuid default auth.uid(),
  criado_em          timestamptz not null default now()
);
create index if not exists contratos_aditivos_contrato on public.contratos_aditivos (contrato_id, a_partir);
alter table public.contratos_aditivos enable row level security;
revoke all on public.contratos_aditivos from anon;
grant select on public.contratos_aditivos to authenticated;
drop policy if exists aditivos_ver on public.contratos_aditivos;
create policy aditivos_ver on public.contratos_aditivos for select to authenticated using (public.pode('contratos') and public.ve_cliente(cliente_id));

-- valor de uma competência: antes de um aditivo de valor vale o valor anterior a ele; depois, o do contrato
create or replace function public.valor_competencia(c public.contratos, comp date) returns numeric
language sql stable set search_path = public as $$
  with a as (select * from public.contratos_aditivos where contrato_id = c.id and tipo = 'valor' and a_partir > comp order by a_partir limit 1)
  select case when exists (select 1 from a) then
           (select case when coalesce(a.forma_anterior, c.forma_valor) = 'salario_minimo'
                        then round(coalesce(a.qtd_salarios_anterior, 0) * coalesce(public.salario_minimo(extract(year from comp)::int), 0), 2)
                        else coalesce(a.valor_mensal_anterior, 0) end from a)
         when c.forma_valor = 'salario_minimo'
              then round(coalesce(c.qtd_salarios, 0) * coalesce(public.salario_minimo(extract(year from comp)::int), 0), 2)
         else coalesce(c.valor_mensal, 0) end;
$$;

create or replace function public.registrar_aditivo(p_contrato uuid, p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare c record; ad uuid; n int; tp text := coalesce(nullif(p->>'tipo', ''), 'outro'); ap date; i int; np int; vt numeric; base numeric; v numeric; pv date;
begin
  if not public.pode('contratos', 'editar') then raise exception 'permission denied: só quem edita Contratos registra aditivo.'; end if;
  select k.*, cl.grupo_id, cl.responsavel resp_cliente into c from public.contratos k join public.clientes cl on cl.id = k.cliente_id where k.id = p_contrato;
  if c.id is null or not public.ve_cliente(c.cliente_id) then raise exception 'Contrato não encontrado.'; end if;
  if btrim(coalesce(p->>'descricao', '')) = '' then raise exception 'Descreva o que o aditivo muda.'; end if;
  select coalesce(max(numero), 0) + 1 into n from public.contratos_aditivos where contrato_id = c.id;
  ap := date_trunc('month', coalesce(nullif(p->>'a_partir', '')::date, current_date))::date;
  insert into public.contratos_aditivos (contrato_id, cliente_id, numero, data, tipo, descricao, a_partir,
      forma_anterior, valor_mensal_anterior, qtd_salarios_anterior, forma_nova, valor_mensal_novo, qtd_salarios_novo, valor_adicional, parcelas)
  values (c.id, c.cliente_id, n, coalesce(nullif(p->>'data', '')::date, current_date), tp, btrim(p->>'descricao'),
      case when tp = 'valor' and c.modalidade = 'consultoria' then ap end,
      c.forma_valor, c.valor_mensal, c.qtd_salarios,
      case when tp = 'valor' and c.modalidade = 'consultoria' then coalesce(nullif(p->>'forma', ''), c.forma_valor) end,
      nullif(p->>'valor_mensal', '')::numeric, nullif(p->>'qtd_salarios', '')::numeric,
      nullif(p->>'valor_adicional', '')::numeric, nullif(p->>'parcelas', '')::int)
  returning id into ad;
  if tp = 'valor' and c.modalidade = 'consultoria' then
    if coalesce(nullif(p->>'forma', ''), c.forma_valor) = 'salario_minimo' then
      if coalesce(nullif(p->>'qtd_salarios', '')::numeric, 0) <= 0 then raise exception 'Informe quantos salários mínimos.'; end if;
      update public.contratos set forma_valor = 'salario_minimo', qtd_salarios = (p->>'qtd_salarios')::numeric where id = c.id;
    else
      if coalesce(nullif(p->>'valor_mensal', '')::numeric, 0) <= 0 then raise exception 'Informe o novo valor mensal.'; end if;
      update public.contratos set forma_valor = 'fixo', valor_mensal = (p->>'valor_mensal')::numeric where id = c.id;
    end if;
    perform public.gerar_mensalidades(c.id);   -- reajusta só as mensalidades em aberto a partir da competência do aditivo
  elsif tp = 'valor' then
    vt := coalesce(nullif(p->>'valor_adicional', '')::numeric, 0);
    if vt <= 0 then raise exception 'Informe o valor a mais do aditivo.'; end if;
    np := greatest(1, least(120, coalesce(nullif(p->>'parcelas', '')::int, 1)));
    pv := coalesce(nullif(p->>'primeiro_vencimento', '')::date, current_date + 30);
    base := trunc(vt / np, 2);
    for i in 1..np loop
      v := case when i = np then vt - base * (np - 1) else base end;
      insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia, parcela, total_parcelas, vencimento, valor, obs)
      values ('escritorio', 'receita', c.descricao || ' — aditivo ' || n || case when np > 1 then ' — parcela ' || i || '/' || np else '' end, 'Honorários',
              c.cliente_id, c.id, c.grupo_id, coalesce(nullif(c.responsavel, ''), c.resp_cliente, ''), case when np > 1 then i || '/' || np else '' end,
              i, np, (pv + make_interval(months => i - 1))::date, v, 'Aditivo nº ' || n || ': ' || btrim(p->>'descricao'));
    end loop;
    update public.contratos set valor_total = valor_total + vt where id = c.id;
  end if;
  return ad;
end $$;
revoke all on function public.registrar_aditivo(uuid, jsonb) from public, anon;
grant execute on function public.registrar_aditivo(uuid, jsonb) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 19 (2026-09-29) — ENVIO DE E-MAILS PAUSADO até o escritório liberar
-- Com a chave ligada, todo e-mail novo fica "retido" na fila (não sai); dá para ver,
-- liberar um a um ou descartar na Central de e-mails. O e-mail de teste do admin sai sempre.
-- E: confirmar o e-mail de um usuário criado pelo admin (entra sem o link de confirmação).
-- ═══════════════════════════════════════════════════════════════════
alter table public.email_fila drop constraint if exists email_fila_status_check;
alter table public.email_fila add constraint email_fila_status_check check (status in ('pendente','enviado','erro','cancelado','retido','rascunho','rascunho_salvo'));
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'emails_pausados') then
    insert into public.configuracoes (chave, valor) values ('emails_pausados', 'true'::jsonb);
    update public.email_fila set status = 'retido' where status = 'pendente';
  end if;
end $$;
create or replace function public.emails_pausados() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select valor = 'true'::jsonb from public.configuracoes where chave = 'emails_pausados'), false) $$;
grant execute on function public.emails_pausados() to authenticated;
create or replace function public.email_fila_reter() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'pendente' and coalesce(new.tipo, '') <> 'teste' and coalesce(current_setting('erp.liberar_email', true), '') <> '1'
     and (tg_op = 'INSERT' or old.status is distinct from 'pendente') and public.emails_pausados() then
    new.status := 'retido';
  end if;
  return new;
end $$;
drop trigger if exists email_fila_reter on public.email_fila;
create trigger email_fila_reter before insert or update of status on public.email_fila for each row execute function public.email_fila_reter();

create or replace function public.pausar_emails(p_pausar boolean) returns boolean language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador liga ou desliga o envio de e-mails.'; end if;
  insert into public.configuracoes (chave, valor, atualizado_em) values ('emails_pausados', to_jsonb(coalesce(p_pausar, true)), now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  if p_pausar then update public.email_fila set status = 'retido' where status = 'pendente' and tipo <> 'teste'; end if;
  return coalesce(p_pausar, true);
end $$;
revoke all on function public.pausar_emails(boolean) from public, anon;
grant execute on function public.pausar_emails(boolean) to authenticated;

-- liberar (envia de verdade, mesmo com a pausa) ou descartar os retidos escolhidos
create or replace function public.emails_retidos_acao(p_ids uuid[], p_acao text) returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.eh_admin() then raise exception 'Só o administrador libera ou descarta e-mails retidos.'; end if;
  if p_acao = 'liberar' then
    perform set_config('erp.liberar_email', '1', true);
    update public.email_fila set status = 'pendente', tentativas = 0, erro = '' where id = any(p_ids) and status = 'retido';
  elsif p_acao = 'descartar' then
    update public.email_fila set status = 'cancelado' where id = any(p_ids) and status = 'retido';
  else raise exception 'Ação inválida.'; end if;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.emails_retidos_acao(uuid[], text) from public, anon;
grant execute on function public.emails_retidos_acao(uuid[], text) to authenticated;

-- usuário criado pelo admin entra direto (sem depender do e-mail de confirmação do Supabase)
create or replace function public.confirmar_email_usuario(p_perfil uuid) returns boolean language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador confirma usuários.'; end if;
  begin
    execute 'update auth.users set email_confirmed_at = coalesce(email_confirmed_at, now()) where id = $1' using p_perfil;
  exception when undefined_column then return false;
  end;
  return true;
end $$;
revoke all on function public.confirmar_email_usuario(uuid) from public, anon;
grant execute on function public.confirmar_email_usuario(uuid) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 20 (2026-09-30) — LEMBRETES no lugar dos recados do mural
-- Lembrete pode ser SEM PRAZO (dia vazio = fica até marcar "Feito"), FIXO no topo e com DESTAQUE (cor).
-- Os recados do mural que ainda valem viram lembretes sem prazo (uma vez só; o mural sai da tela).
-- ═══════════════════════════════════════════════════════════════════
alter table public.lembretes alter column dia drop not null;
alter table public.lembretes add column if not exists fixo boolean not null default false;
alter table public.lembretes add column if not exists destaque text not null default '';
alter table public.lembretes add column if not exists origem text not null default '';
alter table public.lembretes drop constraint if exists lembretes_destaque_check;
alter table public.lembretes add constraint lembretes_destaque_check check (destaque in ('', 'vermelho', 'amarelo', 'verde', 'azul', 'roxo'));
insert into public.lembretes (texto, dia, fixo, pessoa, criado_por, criado_em, origem)
select left(btrim(m.texto), 300), null, m.fixo, '', m.autor, m.criado_em, 'mural:' || m.id
  from public.mural m
 where (m.expira_em is null or m.expira_em >= current_date)
   and not exists (select 1 from public.lembretes l where l.origem = 'mural:' || m.id);

-- Backup 22: o PIX copia e cola saiu (botão e e-mail); as funções do Backup 20 são apagadas
drop function if exists public.pix_copia_cola(text, text, text, numeric, text);
drop function if exists public.crc16_ccitt(text);

-- ═══ Backup 23: excluir usuário (Administração → Usuários → 🗑 Excluir) ═══
-- Só o administrador. Não exclui a si mesmo nem o último administrador. Apaga a conta de acesso (auth.users → perfis em cascata);
-- o que a pessoa lançou continua (as ligações com ela ficam vazias).
create or replace function public.excluir_usuario(p_perfil uuid) returns boolean language plpgsql security definer set search_path = public, auth as $$
declare v_papel text;
begin
  if not public.eh_admin() then raise exception 'Só o administrador exclui usuários.'; end if;
  if p_perfil = auth.uid() then raise exception 'Você não pode excluir o seu próprio usuário.'; end if;
  select papel into v_papel from public.perfis where id = p_perfil;
  if not found then raise exception 'Usuário não encontrado.'; end if;
  if v_papel = 'admin' and (select count(*) from public.perfis where papel = 'admin') <= 1 then raise exception 'Este é o único administrador: dê o acesso de administrador a outra pessoa antes.'; end if;
  delete from auth.users where id = p_perfil;
  delete from public.perfis where id = p_perfil;   -- se a conta já não existia no login
  return true;
end $$;
revoke all on function public.excluir_usuario(uuid) from public, anon;
grant execute on function public.excluir_usuario(uuid) to authenticated;

-- ═══ Backup 25: quem emite as guias de cada parcelamento ═══
-- true (padrão) = o escritório emite (entra no aviso "guias a emitir" do Início); false = o próprio cliente emite.
alter table public.parcelamentos add column if not exists emitimos_guia boolean not null default true;
-- ═══════════════════════════════════════════════════════════════════
-- Backup 26 — FLUXO CLIENTE → FINANCEIRO (etapa 0: correções)
--   · contrato novo pode nascer "Aguardando assinatura": não lança parcelas nem mensalidades
--   · ao virar "Ativo" (assinado): lança o financeiro, cria o onboarding, avisa a equipe, move o CRM
--     para "Contrato assinado", registra na linha do tempo e manda as boas-vindas (se ligado)
--   · o "Fechou" do CRM cria o contrato aguardando assinatura (financeiro e onboarding só na assinatura)
--   · recibo com valor no formato brasileiro (R$ 1.500,00) · "depende de" trava a conclusão
-- ═══════════════════════════════════════════════════════════════════
alter table public.contratos drop constraint if exists contratos_status_check;
alter table public.contratos add constraint contratos_status_check check (status in ('Aguardando assinatura','Ativo','Encerrado','Cancelado'));
alter table public.contratos add column if not exists assinado_em date;
alter table public.contratos add column if not exists onboarding_pendente boolean not null default false;
-- Backup 53: implantação — contrato antigo cujo financeiro JÁ está lançado: não gera parcelas nem mensalidades
alter table public.contratos add column if not exists sem_financeiro boolean not null default false;

-- lança as parcelas de um contrato pontual (uma vez só: se já tem parcela, não repete)
create or replace function public.lancar_parcelas_contrato(p_contrato uuid) returns int
language plpgsql security definer set search_path = public as $$
declare c public.contratos; i int; base numeric(14,2); v numeric(14,2); g uuid;
begin
  select * into c from public.contratos where id = p_contrato;
  if not found or c.valor_total <= 0 or c.primeiro_vencimento is null then return 0; end if;
  if coalesce(c.modalidade, 'pontual') = 'consultoria' or c.sem_financeiro then return 0; end if;   -- Backup 53: implantação não lança
  if exists (select 1 from public.lancamentos where contrato_id = c.id and chave_recorrencia is null and parcela is not null) then return 0; end if;
  select grupo_id into g from public.clientes where id = c.cliente_id;
  base := trunc(c.valor_total / c.num_parcelas, 2);
  for i in 1..c.num_parcelas loop
    v := case when i = c.num_parcelas then c.valor_total - base * (c.num_parcelas - 1) else base end;
    insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia,
                                    parcela, total_parcelas, vencimento, valor)
    values ('escritorio', 'receita', c.descricao || case when c.num_parcelas > 1 then ' — parcela ' || i || '/' || c.num_parcelas else '' end,
            'Honorários', c.cliente_id, c.id, g, c.responsavel, case when c.num_parcelas > 1 then i || '/' || c.num_parcelas else '' end,
            i, c.num_parcelas, (c.primeiro_vencimento + make_interval(months => i - 1))::date, v);
  end loop;
  return c.num_parcelas;
end $$;
revoke all on function public.lancar_parcelas_contrato(uuid) from public, anon, authenticated;

create or replace function public.gerar_parcelas_contrato() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'Aguardando assinatura' then return new; end if;
  perform public.lancar_parcelas_contrato(new.id);
  return new;
end $$;
drop trigger if exists gerar_parcelas on public.contratos;
create trigger gerar_parcelas after insert on public.contratos for each row execute function public.gerar_parcelas_contrato();

-- regras "na hora" do contrato novo: aguardando assinatura só ganha a tarefa de anexar (o resto vem na assinatura)
create or replace function public.regra_contrato_novo() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; cl record; ck jsonb;
begin
  if current_setting('erp.sem_regra_onboarding', true) = '1' or new.status = 'Aguardando assinatura' then return null; end if;
  select * into rg from public.regras_tarefas where chave = 'contrato_onboarding' and ligada;
  if not found then return null; end if;
  select * into cl from public.clientes where id = new.cliente_id;
  select coalesce(jsonb_agg(jsonb_build_object('texto', i->>'titulo', 'feito', false)), '[]') into ck
    from public.modelos_fluxo m, jsonb_array_elements(m.itens) i where m.nome = 'Onboarding de cliente';
  perform public.tarefa_da_regra('onb:' || new.id, 'Onboarding: ' || coalesce(cl.nome, new.descricao),
    coalesce(nullif(rg.responsavel, ''), nullif(new.responsavel, ''), cl.responsavel),
    public.somar_uteis(current_date, rg.dias), new.cliente_id, cl.grupo_id, new.id, ck, 'Contrato: ' || new.descricao);
  return null;
end $$;

-- "anexar o contrato assinado" também para o contrato que vem do CRM
create or replace function public.regra_contrato_anexo() returns trigger
language plpgsql security definer set search_path = public as $$
declare rg record; cl record;
begin
  select * into rg from public.regras_tarefas where chave = 'contrato_anexo' and ligada;
  if not found then return null; end if;
  if exists (select 1 from public.documentos d where d.contrato_id = new.id and d.tipo = 'contrato' and d.mime <> 'text/html') then return null; end if;
  select * into cl from public.clientes where id = new.cliente_id;
  perform public.tarefa_da_regra('anexo:' || new.id, 'Anexar o contrato assinado — ' || new.descricao || coalesce(' (' || cl.nome || ')', ''),
    coalesce(nullif(rg.responsavel, ''), nullif(new.responsavel, ''), cl.responsavel), public.somar_uteis(coalesce(new.data_contrato, current_date), rg.dias),
    new.cliente_id, cl.grupo_id, new.id, '[]',
    case when new.status = 'Aguardando assinatura'
         then 'Quando o cliente assinar: Contratos → abrir o contrato → "✓ Marcar como assinado" e anexe o PDF. O financeiro é lançado nessa hora.'
         else 'Envie o PDF assinado em Contratos → abrir o contrato → Documentos. A tarefa se conclui sozinha.' end);
  return null;
end $$;

-- documento ligado ao contrato → conclui "anexar contrato" (a minuta gerada pelo gerador, em HTML, não conta)
create or replace function public.anexo_conclui_tarefa() returns trigger
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if new.contrato_id is null or coalesce(new.mime, '') = 'text/html' then return null; end if;
  update public.tarefas set status = 'concluida', checklist = (select coalesce(jsonb_agg(i || '{"feito":true}'::jsonb), '[]'::jsonb) from jsonb_array_elements(checklist) i)
   where chave_regra = 'anexo:' || new.contrato_id and status not in ('concluida','cancelada');
  get diagnostics n = row_count;
  if n > 0 then insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('anexo', 'anexo-ok:' || new.contrato_id, 'Contrato anexado: tarefa concluída sozinha', new.cliente_id); end if;
  return null;
end $$;

-- mensalidades: contrato aguardando assinatura não gera nada
create or replace function public.gerar_mensalidades(p_contrato uuid default null, p_ate date default null) returns int
language plpgsql security definer set search_path = public as $$
declare c public.contratos; comp date; fim date; venc date; g uuid; resp text; n int := 0; k int; sm_falta boolean;
begin
  for c in select * from public.contratos where modalidade = 'consultoria' and status <> 'Aguardando assinatura' and (p_contrato is null or id = p_contrato) loop
    select grupo_id, responsavel into g, resp from public.clientes where id = c.cliente_id;
    if c.rescindido_em is not null then
      delete from public.lancamentos where contrato_id = c.id and chave_recorrencia is not null and not pago
         and competencia >= date_trunc('month', c.rescindido_em)::date;
    end if;
    if c.status in ('Cancelado') then continue; end if;
    comp := date_trunc('month', coalesce(c.inicio_competencia, c.data_contrato))::date;
    fim := date_trunc('month', coalesce(p_ate, (current_date + interval '2 months')::date))::date;
    if c.rescindido_em is not null then fim := least(fim, (date_trunc('month', c.rescindido_em) - interval '1 month')::date); end if;
    while comp <= fim loop
      venc := make_date(extract(year from comp + interval '1 month')::int, extract(month from comp + interval '1 month')::int, c.dia_vencimento);
      sm_falta := c.forma_valor = 'salario_minimo' and not exists (select 1 from public.salarios_minimos where ano = extract(year from comp)::int);
      insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia,
                                      competencia, vencimento, valor, chave_recorrencia, obs)
      values ('escritorio', 'receita', c.descricao || ' — competência ' || to_char(comp, 'MM/YYYY'), 'Consultoria mensal', c.cliente_id, c.id, g,
              coalesce(nullif(c.responsavel, ''), resp, ''), to_char(comp, 'MM/YYYY'), comp, venc, greatest(public.valor_competencia(c, comp), 0.01),
              'rec:' || c.id || ':' || to_char(comp, 'YYYY-MM'),
              case when sm_falta then 'Salário mínimo de ' || extract(year from comp)::int || ' ainda não cadastrado: valor provisório, reajusta sozinho.' else '' end)
      on conflict (chave_recorrencia) where chave_recorrencia is not null do nothing;
      get diagnostics k = row_count; n := n + k;
      comp := (comp + interval '1 month')::date;
    end loop;
    update public.lancamentos l set valor = greatest(public.valor_competencia(c, l.competencia), 0.01),
           obs = case when c.forma_valor = 'salario_minimo' and not exists (select 1 from public.salarios_minimos where ano = extract(year from l.competencia)::int)
                      then l.obs else regexp_replace(l.obs, 'Salário mínimo de \d{4} ainda não cadastrado: valor provisório, reajusta sozinho\.', '') end
     where l.contrato_id = c.id and l.chave_recorrencia is not null and not l.pago
       and l.valor is distinct from greatest(public.valor_competencia(c, l.competencia), 0.01);
  end loop;
  return n;
end $$;

-- boas-vindas (desligado de fábrica; só sai com a pausa desligada e a regra ligada)
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias, grupo) values
  ('email_boas_vindas', 'E-mail ao cliente: boas-vindas na assinatura', 'Quando o contrato é marcado como assinado, manda o e-mail de boas-vindas ao contato de "Contratos" do cliente', false, 0, 'cliente_email')
on conflict (chave) do nothing;
insert into public.emails_modelos (chave, tipo, nome, assunto, texto, ordem) values
  ('boas_vindas', 'contratos', 'Boas-vindas (contrato assinado)', 'Seja bem-vindo(a) ao Araújo & Castro',
   '<p style="margin:0">Seja bem-vindo(a)! Seu contrato de <b>{servico}</b> está ativo. Seu responsável aqui no escritório é <b>{responsavel}</b>.{vencimento}</p><p style="margin:10px 0 0">Em breve enviaremos a lista de documentos. Qualquer dúvida, é só responder este e-mail.</p>', 11)
on conflict (chave) do nothing;

-- contrato assinado: tudo o que depende da assinatura acontece aqui
create or replace function public.contrato_antes_status() returns trigger
language plpgsql as $$
begin
  if new.status = 'Ativo' and old.status = 'Aguardando assinatura' then new.assinado_em := coalesce(new.assinado_em, current_date); end if;
  if new.status = 'Aguardando assinatura' and old.status is distinct from 'Aguardando assinatura' then new.assinado_em := null; end if;
  return new;
end $$;
drop trigger if exists contrato_antes_status on public.contratos;
create trigger contrato_antes_status before update of status on public.contratos for each row execute function public.contrato_antes_status();

create or replace function public.contrato_assinado() returns trigger
language plpgsql security definer set search_path = public as $$
declare cl record; rg record; ck jsonb; m record; resp text; primeira date;
begin
  if not (new.status = 'Ativo' and old.status = 'Aguardando assinatura') then return null; end if;
  select * into cl from public.clientes where id = new.cliente_id;
  resp := coalesce(nullif(new.responsavel, ''), cl.responsavel, '');
  -- 1) financeiro (a consultoria gera as mensalidades pelo gatilho contrato_recorrente)
  perform public.lancar_parcelas_contrato(new.id);
  if new.modalidade = 'consultoria' then perform public.gerar_mensalidades(new.id); end if;
  -- 2) onboarding: fluxo completo (quando veio do CRM) ou a tarefa da regra
  if new.onboarding_pendente then
    perform public.criar_fluxo_modelo('Onboarding de cliente', public.somar_uteis(current_date, 15), new.cliente_id, cl.grupo_id, resp, 'Onboarding — ' || coalesce(cl.nome, new.descricao));
    update public.contratos set onboarding_pendente = false where id = new.id;
  else
    select * into rg from public.regras_tarefas where chave = 'contrato_onboarding' and ligada;
    if found then
      select coalesce(jsonb_agg(jsonb_build_object('texto', i->>'titulo', 'feito', false)), '[]') into ck
        from public.modelos_fluxo mf, jsonb_array_elements(mf.itens) i where mf.nome = 'Onboarding de cliente';
      perform public.tarefa_da_regra('onb:' || new.id, 'Onboarding: ' || coalesce(cl.nome, new.descricao), coalesce(nullif(rg.responsavel, ''), resp),
        public.somar_uteis(current_date, rg.dias), new.cliente_id, cl.grupo_id, new.id, ck, 'Contrato: ' || new.descricao);
    end if;
  end if;
  -- 3) avisa a equipe
  insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link)
  select p.id, 'financeiro', 'Contrato assinado: ' || coalesce(cl.nome, ''), new.descricao || ' — financeiro lançado', 'contratos'
    from public.perfis p where p.papel in ('admin', 'equipe') and p.id is distinct from auth.uid();
  -- 4) CRM e linha do tempo
  update public.crm_oportunidades set etapa_id = (select id from public.crm_etapas where final = 'ganho' order by ordem limit 1)
   where contrato_id = new.id and etapa_id is distinct from (select id from public.crm_etapas where final = 'ganho' order by ordem limit 1);
  insert into public.interacoes (cliente_id, tipo, resumo) values (new.cliente_id, 'anotacao', 'Contrato assinado: ' || new.descricao);
  -- 5) boas-vindas
  if coalesce((select ligada from public.regras_tarefas where chave = 'email_boas_vindas'), false) then
    select min(vencimento) into primeira from public.lancamentos where contrato_id = new.id and not pago;
    select * into m from public.modelo_email('boas_vindas', jsonb_build_object('servico', coalesce(nullif(new.servico, ''), new.descricao),
      'responsavel', coalesce(nullif(resp, ''), 'a nossa equipe'),
      'vencimento', case when primeira is not null then ' O primeiro vencimento é em <b>' || to_char(primeira, 'DD/MM/YYYY') || '</b>.' else '' end));
    perform public.email_cliente_enviar('email_bv', 'email_bv:' || new.id, new.cliente_id, cl.grupo_id, 'contrato', m.assunto, m.texto, '[]'::jsonb, false);
  end if;
  return null;
end $$;
drop trigger if exists contrato_assinado on public.contratos;
create trigger contrato_assinado after update of status on public.contratos for each row execute function public.contrato_assinado();

-- botão "✓ Marcar como assinado"
create or replace function public.contrato_assinar(p_contrato uuid, p_data date default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c public.contratos; n int;
begin
  if not public.pode('contratos', 'editar') then raise exception 'Sem a função Contratos (editar).'; end if;
  select * into c from public.contratos where id = p_contrato;
  if not found then raise exception 'Contrato não encontrado.'; end if;
  if c.status <> 'Aguardando assinatura' then raise exception 'Este contrato não está aguardando assinatura (situação: %).', c.status; end if;
  update public.contratos set status = 'Ativo', assinado_em = coalesce(p_data, current_date) where id = p_contrato;
  select count(*) into n from public.lancamentos where contrato_id = p_contrato;
  return jsonb_build_object('lancamentos', n);
end $$;
revoke all on function public.contrato_assinar(uuid, date) from public, anon;
grant execute on function public.contrato_assinar(uuid, date) to authenticated;

-- mover o lead para "Contrato assinado" assina o contrato ligado (se estiver aguardando)
create or replace function public.crm_assina_contrato() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.contrato_id is not null and new.etapa_id is distinct from old.etapa_id
     and exists (select 1 from public.crm_etapas where id = new.etapa_id and final = 'ganho') then
    update public.contratos set status = 'Ativo' where id = new.contrato_id and status = 'Aguardando assinatura';
  end if;
  return null;
end $$;
drop trigger if exists crm_assina_contrato on public.crm_oportunidades;
create trigger crm_assina_contrato after update of etapa_id on public.crm_oportunidades for each row execute function public.crm_assina_contrato();

-- "Fechou": cliente (se novo) + contrato AGUARDANDO ASSINATURA; financeiro e onboarding só na assinatura
create or replace function public.crm_ganhar(p_op uuid, p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o record; cli uuid; grp uuid; ctr uuid; resp text; etp uuid; consult boolean; nome_cli text;
begin
  if not public.pode('crm', 'editar') then raise exception 'Sem a função CRM (editar).'; end if;
  select * into o from public.crm_oportunidades where id = p_op;
  if not found then raise exception 'Oportunidade não encontrada.'; end if;
  resp := coalesce(nullif(p->>'responsavel', ''), o.responsavel);
  cli := coalesce(nullif(p->>'cliente_id', '')::uuid, o.cliente_id);
  consult := coalesce(p->>'modalidade', '') = 'consultoria';
  if cli is null then
    if coalesce(p->>'cliente_nome', '') = '' then raise exception 'Informe o nome do cliente.'; end if;
    if coalesce(p->>'grupo', '') <> '' then
      select id into grp from public.grupos where lower(nome) = lower(p->>'grupo') limit 1;
      if grp is null then insert into public.grupos (nome) values (p->>'grupo') returning id into grp; end if;
    end if;
    insert into public.clientes (nome, cpf_cnpj, email, telefone, grupo_id, responsavel, tipo, origem)
    values (p->>'cliente_nome', coalesce(nullif(p->>'cpf_cnpj', ''), o.prospecto_doc, ''), coalesce(nullif(p->>'email', ''), o.prospecto_email, ''),
            coalesce(nullif(p->>'telefone', ''), o.prospecto_telefone, ''), grp, coalesce(resp, ''), case when consult then 'Consultoria' else 'Demanda' end,
            coalesce(nullif(o.origem, ''), 'CRM'))
    returning id into cli;
    -- quem indicou (etapa 2); a coluna nasce mais abaixo no arquivo, por isso o update separado
    begin execute 'update public.clientes set indicado_por = $1 where id = $2' using coalesce(o.indicado_por, ''), cli; exception when undefined_column then null; end;
  else
    select grupo_id into grp from public.clientes where id = cli;
  end if;
  select nome into nome_cli from public.clientes where id = cli;
  if consult or coalesce((p->>'valor_total')::numeric, 0) > 0 or coalesce(p->>'descricao', '') <> '' then
    insert into public.contratos (cliente_id, descricao, valor_total, num_parcelas, primeiro_vencimento, percentual_exito, responsavel, servico,
                                  modalidade, valor_mensal, dia_vencimento, inicio_competencia, status, onboarding_pendente)
    values (cli, coalesce(nullif(p->>'descricao', ''), o.titulo), case when consult then 0 else coalesce((p->>'valor_total')::numeric, 0) end,
            case when consult then 1 else greatest(1, coalesce((p->>'num_parcelas')::int, 1)) end,
            case when consult then null else nullif(p->>'primeiro_vencimento', '')::date end, nullif(p->>'percentual_exito', '')::numeric, coalesce(resp, ''),
            coalesce(nullif(p->>'servico', ''), o.servico, ''), case when consult then 'consultoria' else 'pontual' end,
            case when consult then nullif(p->>'valor_mensal', '')::numeric end, coalesce(nullif(p->>'dia_vencimento', '')::int, 10),
            case when consult then date_trunc('month', coalesce(nullif(p->>'inicio_competencia', '')::date, current_date))::date end,
            'Aguardando assinatura', coalesce((p->>'criar_fluxo')::boolean, true))
    returning id into ctr;
  end if;
  perform public.tarefa_da_regra('crm-contrato:' || p_op, 'Enviar contrato para assinatura — ' || nome_cli,
    resp, public.somar_uteis(current_date, 2), cli, grp, ctr, '[]'::jsonb,
    'Oportunidade do CRM: ' || o.titulo || '. Gere o contrato (CRM → ficha → "📄 Gerar contrato") e envie ao cliente. Quando ele assinar, marque "✓ Assinado".', '', 'alta');
  insert into public.interacoes (cliente_id, tipo, resumo) values (cli, 'anotacao', 'Contrato fechado pelo CRM (aguardando assinatura): ' || o.titulo);
  update public.crm_propostas set status = 'aceita' where id = (select id from public.crm_propostas where oportunidade_id = p_op order by versao desc limit 1);
  update public.documentos set cliente_id = cli, grupo_id = grp, contrato_id = coalesce(ctr, contrato_id) where oportunidade_id = p_op;
  select id into etp from public.crm_etapas where nome = 'Contrato fechado' limit 1;
  if etp is null then select id into etp from public.crm_etapas where final = 'ganho' order by ordem limit 1; end if;
  update public.crm_oportunidades set etapa_id = etp, probabilidade = 90, ganho_em = now(), perdido_em = null, cliente_id = cli, contrato_id = ctr,
         servico = coalesce(nullif(p->>'servico', ''), servico) where id = p_op;
  return jsonb_build_object('cliente_id', cli, 'contrato_id', ctr, 'fluxo_id', null);
end $$;
revoke all on function public.crm_ganhar(uuid, jsonb) from anon;
grant execute on function public.crm_ganhar(uuid, jsonb) to authenticated;

-- recibo: valor no formato brasileiro, qualquer que seja o idioma do servidor
create or replace function public.brl_texto(v numeric) returns text language sql immutable as $$
  select 'R$ ' || replace(replace(replace(to_char(coalesce(v, 0), 'FM999,999,990.00'), ',', '#'), '.', ','), '#', '.');
$$;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 26 — etapa 1: CONTATOS POR SETOR e CONTROLE DOS E-MAILS
--   · setores: geral, financeiro, fiscal, rh, socio, juridico, contador ("cobrança" vira financeiro; "marketing" vira geral)
--   · "recebe o quê" por contato (contatos.recebe): cobranca, recibo, guia, acordo, contrato, convite
--   · para onde vai cada tipo quando ninguém está marcado: configuracoes.emails_destino (tipo → setor)
--   · vários contatos marcados para o mesmo tipo → o e-mail vai para todos (separados por vírgula)
--   · perfil novo "Não enviar nenhum e-mail" (nada)
-- ═══════════════════════════════════════════════════════════════════
alter table public.contatos add column if not exists recebe text[] not null default '{}';
update public.contatos set finalidade = 'financeiro' where finalidade = 'cobranca';
update public.contatos set finalidade = 'geral' where finalidade not in ('geral','financeiro','fiscal','rh','socio','juridico','contador');
do $$ begin
  if not exists (select 1 from public.configuracoes where chave = 'b25_recebe_migrado') then
    update public.contatos set recebe = (case when recebe_boletos then array['cobranca','recibo'] else '{}' end)
                                     || (case when recebe_notificacoes then array['guia','acordo'] else '{}' end)
     where recebe = '{}' and (recebe_boletos or recebe_notificacoes);
    insert into public.configuracoes (chave, valor) values ('b25_recebe_migrado', 'true'::jsonb) on conflict (chave) do nothing;
  end if;
end $$;
-- as caixinhas antigas continuam coerentes (telas e importações antigas ainda escrevem nelas)
create or replace function public.contato_recebe_sync() returns trigger language plpgsql as $$
begin
  if new.finalidade = 'cobranca' then new.finalidade := 'financeiro'; end if;
  if tg_op = 'INSERT' and new.recebe = '{}' and (new.recebe_boletos or new.recebe_notificacoes) then
    new.recebe := (case when new.recebe_boletos then array['cobranca','recibo'] else '{}' end) || (case when new.recebe_notificacoes then array['guia','acordo'] else '{}' end);
  elsif tg_op = 'UPDATE' and new.recebe is not distinct from old.recebe
        and (new.recebe_boletos is distinct from old.recebe_boletos or new.recebe_notificacoes is distinct from old.recebe_notificacoes) then
    new.recebe := array(select distinct x from unnest(new.recebe) x where x not in ('cobranca','recibo','guia','acordo'))
                  || (case when new.recebe_boletos then array['cobranca','recibo'] else '{}' end) || (case when new.recebe_notificacoes then array['guia','acordo'] else '{}' end);
  end if;
  new.recebe := array(select distinct x from unnest(coalesce(new.recebe, '{}')) x where x in ('cobranca','recibo','guia','acordo','contrato','convite') order by 1);
  new.recebe_boletos := new.recebe && array['cobranca','recibo'];
  new.recebe_notificacoes := new.recebe && array['guia','acordo','contrato','convite'];
  return new;
end $$;
drop trigger if exists contato_recebe_sync on public.contatos;
create trigger contato_recebe_sync before insert or update on public.contatos for each row execute function public.contato_recebe_sync();

insert into public.configuracoes (chave, valor) values
  ('emails_destino', '{"cobranca":"financeiro","recibo":"financeiro","guia":"fiscal","acordo":"financeiro","contrato":"socio","convite":"socio"}'::jsonb)
on conflict (chave) do nothing;
create or replace function public.salvar_destinos_email(p jsonb) returns jsonb language plpgsql security definer set search_path = public as $$
declare k text;
begin
  if not public.eh_admin() then raise exception 'Só o administrador muda para qual setor vai cada e-mail.'; end if;
  for k in select jsonb_object_keys(p) loop
    if k not in ('cobranca','recibo','guia','acordo','contrato','convite') or (p->>k) not in ('geral','financeiro','fiscal','rh','socio','juridico','contador') then
      raise exception 'Tipo ou setor inválido: % → %', k, p->>k;
    end if;
  end loop;
  insert into public.configuracoes (chave, valor, atualizado_em) values ('emails_destino', p, now())
    on conflict (chave) do update set valor = public.configuracoes.valor || excluded.valor, atualizado_em = now();
  return (select valor from public.configuracoes where chave = 'emails_destino');
end $$;
revoke all on function public.salvar_destinos_email(jsonb) from public, anon;
grant execute on function public.salvar_destinos_email(jsonb) to authenticated;

-- nome antigo (finalidade) → tipo de e-mail
create or replace function public.tipo_destino_email(p text) returns text language sql immutable as $$
  select case when p in ('financeiro','cobranca','lembrete','vencimento') then 'cobranca' when p in ('juridico','acordo') then 'acordo'
              when p in ('guia','parcelamento') then 'guia' when p in ('recibo') then 'recibo' when p in ('contrato','boas_vindas','proposta') then 'contrato'
              when p in ('convite','reuniao') then 'convite' else 'cobranca' end;
$$;

-- quem recebe: 1) contatos marcados para o tipo (todos)  2) contatos do setor do tipo  3) contato "geral"  4) e-mail do cadastro
--              (sem cliente: o mesmo nos clientes do grupo)
drop function if exists public.contato_do_cliente(uuid, uuid, text);
create or replace function public.contato_do_cliente(p_cliente uuid, p_grupo uuid, p_finalidade text default 'cobranca')
returns table (email text, nome text, setor text, origem text)
language plpgsql stable security definer set search_path = public as $$
declare t text := public.tipo_destino_email(p_finalidade);
        st text := coalesce((select valor->>public.tipo_destino_email(p_finalidade) from public.configuracoes where chave = 'emails_destino'), 'financeiro');
        ids uuid[];
begin
  ids := case when p_cliente is not null then array[p_cliente]
              else array(select id from public.clientes where grupo_id = p_grupo and tipo <> 'Inativo' order by criado_em) end;
  if ids is null or cardinality(ids) = 0 then return; end if;
  return query select string_agg(distinct lower(c.email), ', '), min(nullif(split_part(btrim(c.nome), ' ', 1), '')), min(c.finalidade), 'marcado'::text
    from public.contatos c where c.cliente_id = any(ids) and c.email <> '' and c.recebe @> array[t] having count(*) > 0;
  if found then return; end if;
  return query select string_agg(distinct lower(c.email), ', '), min(nullif(split_part(btrim(c.nome), ' ', 1), '')), st, 'setor'::text
    from public.contatos c where c.cliente_id = any(ids) and c.email <> '' and c.finalidade = st having count(*) > 0;
  if found then return; end if;
  return query select c.email, nullif(split_part(btrim(c.nome), ' ', 1), ''), 'geral'::text, 'geral'::text
    from public.contatos c where c.cliente_id = any(ids) and c.email <> '' and c.finalidade = 'geral' order by c.criado_em limit 1;
  if found then return; end if;
  return query select cl.email, null::text, ''::text, 'cadastro'::text from public.clientes cl where cl.id = any(ids) and cl.email <> '' order by cl.criado_em limit 1;
end $$;
revoke all on function public.contato_do_cliente(uuid, uuid, text) from public, anon, authenticated;
create or replace function public.email_do_cliente(p_cliente uuid, p_grupo uuid) returns text
language sql stable security definer set search_path = public as $$
  select email from public.contato_do_cliente(p_cliente, p_grupo, 'cobranca');
$$;
revoke all on function public.email_do_cliente(uuid, uuid) from public, anon, authenticated;

-- perfil "nada" + tipos novos (boas-vindas, convite, contrato)
alter table public.clientes drop constraint if exists clientes_perfil_email_ck;
alter table public.clientes add constraint clientes_perfil_email_ck check (perfil_email in ('padrao','nunca','vencimento','personalizado','nada'));
create or replace function public.pode_email(p_cliente uuid, p_grupo uuid, p_tipo text) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare pf text := public.perfil_email_de(p_cliente, p_grupo); t jsonb;
begin
  if pf = 'nada' then return false; end if;
  if pf = 'personalizado' then
    select emails_tipos into t from public.clientes where id = p_cliente;
    if t is null then select emails_tipos into t from public.clientes where grupo_id = p_grupo and perfil_email = 'personalizado' limit 1; end if;
    return coalesce((t->>p_tipo)::boolean, p_tipo <> 'vencimento');
  end if;
  if p_tipo in ('boas_vindas','convite','contrato') then return true; end if;
  if pf = 'nunca' then return p_tipo not in ('lembrete','vencimento','cobranca','recibo'); end if;
  if pf = 'vencimento' then return p_tipo not in ('lembrete','cobranca'); end if;
  return p_tipo <> 'vencimento';
end $$;
revoke all on function public.pode_email(uuid, uuid, text) from public, anon, authenticated;
create or replace function public.perfil_email_de(p_cliente uuid, p_grupo uuid) returns text
language sql stable security definer set search_path = public as $$
  select coalesce((select perfil_email from public.clientes where id = p_cliente),
                  (select perfil_email from public.clientes where grupo_id = p_grupo and perfil_email <> 'padrao'
                    order by case perfil_email when 'nada' then 0 when 'nunca' then 1 when 'vencimento' then 2 else 3 end limit 1), 'padrao');
$$;
revoke all on function public.perfil_email_de(uuid, uuid) from public, anon, authenticated;
create or replace function public.salvar_perfil_email(p_ids uuid[], p_perfil text, p_tipos jsonb default null) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.pode_central_emails() and not public.pode('clientes', 'editar') then raise exception 'permission denied'; end if;
  if p_perfil not in ('padrao','nunca','vencimento','personalizado','nada') then raise exception 'Perfil de e-mail inválido.'; end if;
  update public.clientes set perfil_email = p_perfil, emails_tipos = coalesce(p_tipos, emails_tipos) where id = any(p_ids);
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.salvar_perfil_email(uuid[], text, jsonb) from public, anon;
grant execute on function public.salvar_perfil_email(uuid[], text, jsonb) to authenticated;

-- envio: perfil do cliente, contato do tipo certo (um ou vários), nunca example.com, uma vez só por "ref"
create or replace function public.email_cliente_enviar(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_finalidade text,
  p_assunto text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_anexo jsonb default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare c record; tipo text;
begin
  if exists (select 1 from public.automacoes_log where ref = p_ref) then return false; end if;
  tipo := case p_regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' when 'email_ch' then 'cobranca'
                       when 'email_pr' then 'recibo' when 'email_lp' then 'parcelamento' when 'email_la' then 'acordo'
                       when 'email_bv' then 'boas_vindas' when 'email_cv' then 'convite' end;
  if tipo is not null and not public.pode_email(p_cliente, p_grupo, tipo) then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (p_regra, p_ref, 'Não enviado (perfil de e-mail do cliente): ' || p_assunto, p_cliente);
    return false;
  end if;
  select * into c from public.contato_do_cliente(p_cliente, p_grupo, p_finalidade);
  if c.email is null or c.email = '' then return false; end if;
  if c.email ~* '(@|\.)example\.com(,|$)' then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, 'Demonstração (não enviado): ' || p_assunto, p_cliente);
    return false;
  end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo)
  values (null, c.email, p_assunto, public.email_cliente_html(p_assunto, c.nome, p_texto, p_itens, p_pagar), 'cliente', p_ref, p_anexo);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, p_assunto || ' → ' || c.email, p_cliente);
  return true;
end $$;
revoke all on function public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean, jsonb) from public, anon, authenticated;

-- ── Controle por cliente: o que cada cliente recebe, para qual e-mail, quem é o responsável e o último envio ──
create or replace function public.emails_controle() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.pode_central_emails() then raise exception 'permission denied: sem acesso à Central de e-mails.'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id', cl.id, 'nome', cl.nome, 'grupo', g.nome, 'responsavel', cl.responsavel, 'perfil', cl.perfil_email, 'area', cl.area,
           'tipos', (select jsonb_object_agg(tt.k, jsonb_build_object('recebe', public.pode_email(cl.id, cl.grupo_id, tt.perm), 'para', ct.email, 'contato', ct.nome, 'setor', ct.setor, 'origem', ct.origem))
                       from (values ('cobranca', 'cobranca'), ('recibo', 'recibo'), ('guia', 'parcelamento'), ('acordo', 'acordo'), ('contrato', 'boas_vindas'), ('convite', 'convite')) tt(k, perm)
                       left join lateral (select * from public.contato_do_cliente(cl.id, cl.grupo_id, tt.k) limit 1) ct on true),
           'ultimo', (select jsonb_build_object('quando', a.quando, 'descricao', a.descricao) from public.automacoes_log a
                       where a.cliente_id = cl.id and a.chave like 'email_%' order by a.quando desc limit 1),
           'enviados30', (select count(*) from public.automacoes_log a where a.cliente_id = cl.id and a.chave like 'email_%' and a.descricao like '%→%' and a.quando > now() - interval '30 days'))
         order by coalesce(g.nome, cl.nome), cl.nome), '[]') into r
    from public.clientes cl left join public.grupos g on g.id = cl.grupo_id
   where cl.tipo <> 'Inativo';
  return r;
end $$;
revoke all on function public.emails_controle() from public, anon;
grant execute on function public.emails_controle() to authenticated;

-- marca/desmarca "recebe" de um contato (a partir da Central ou da ficha)
create or replace function public.contato_recebe(p_contato uuid, p_tipo text, p_recebe boolean) returns text[]
language plpgsql security definer set search_path = public as $$
declare r text[];
begin
  if not (public.pode('clientes', 'editar') or public.pode_central_emails()) then raise exception 'permission denied'; end if;
  if p_tipo not in ('cobranca','recibo','guia','acordo','contrato','convite') then raise exception 'Tipo de e-mail inválido.'; end if;
  update public.contatos set recebe = case when p_recebe then array(select distinct x from unnest(recebe || array[p_tipo]) x) else array_remove(recebe, p_tipo) end
   where id = p_contato returning recebe into r;
  return r;
end $$;
revoke all on function public.contato_recebe(uuid, text, boolean) from public, anon;
grant execute on function public.contato_recebe(uuid, text, boolean) to authenticated;

-- a fila mostra o responsável do cliente e de onde veio o destinatário (marcado, setor, geral, cadastro)
create or replace function public.emails_central(p_situacao text default 'hoje') returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.pode_central_emails() then raise exception 'permission denied: sem acesso à Central de e-mails.'; end if;
  if p_situacao = 'hoje' then
    select coalesce(jsonb_agg(jsonb_build_object('ref', x.ref, 'tipo', x.tipo, 'assunto', x.assunto, 'vence', x.vence, 'cliente', coalesce(cl.nome, g.nome, '—'), 'grupo', g.nome,
             'cliente_id', cl.id, 'responsavel', coalesce(cl.responsavel, ''),
             'para', ct.email, 'contato', ct.nome, 'finalidade', x.finalidade, 'setor', ct.setor, 'origem', ct.origem, 'auto', public.email_tipo_auto(x.tipo),
             'bloqueio', case when x.tipo <> 'honorarios' and x.tipo <> 'recibos' and not public.pode_email(x.cliente_id, x.grupo_id, case x.regra when 'email_lp' then 'parcelamento' else 'acordo' end) then 'perfil do cliente'
                              when x.tipo = 'honorarios' and not public.pode_email(x.cliente_id, x.grupo_id, case x.regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' else 'cobranca' end) then 'perfil do cliente'
                              when coalesce(ct.email, '') = '' then 'sem e-mail cadastrado'
                              when ct.email ~* '(@|\.)example\.com(,|$)' then 'demonstração' else '' end,
             'total', (select coalesce(sum((i->>'valor')::numeric), 0) from jsonb_array_elements(x.itens) i)) order by x.tipo, coalesce(cl.nome, g.nome)), '[]')
      into r
      from public.emails_pendentes() x left join public.clientes cl on cl.id = x.cliente_id left join public.grupos g on g.id = coalesce(x.grupo_id, cl.grupo_id)
      left join lateral (select * from public.contato_do_cliente(x.cliente_id, x.grupo_id, x.finalidade) limit 1) ct on true;
  else
    select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'para', f.para, 'assunto', f.assunto, 'status', f.status, 'erro', f.erro, 'quando', coalesce(f.enviado_em, f.criado_em),
             'ref', f.referencia, 'anexo', f.anexo is not null, 'tipo', case when f.referencia like 'email_pr:%' then 'recibos' when f.referencia ~ '^email_(lp|pa)' then 'parcelamentos'
             when f.referencia ~ '^email_(la|aa)' then 'acordos' when f.referencia like 'email_bv:%' then 'contratos' when f.referencia like 'email_cv:%' then 'convites'
             when f.tipo = 'proposta' then 'propostas' else 'honorarios' end,
             'cliente', a.nome, 'responsavel', a.responsavel)
             order by coalesce(f.enviado_em, f.criado_em) desc), '[]') into r
      from (select * from public.email_fila where tipo in ('cliente', 'proposta') and criado_em > now() - interval '120 days'
               and (case when p_situacao = 'erro' then status = 'erro' else status in ('enviado', 'pendente') end) order by criado_em desc limit 300) f
      left join lateral (select cl.nome, cl.responsavel from public.automacoes_log al join public.clientes cl on cl.id = al.cliente_id
                          where al.ref = f.referencia and f.referencia <> '' limit 1) a on true;
  end if;
  return r;
end $$;
revoke all on function public.emails_central(text) from public, anon;
grant execute on function public.emails_central(text) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 26 — etapa 2: CADASTRO ORGANIZADO
--   · "indicado por" (origem = Indicação) · aviso de CPF/CNPJ repetido · e-mail do cadastro vira o contato "Geral"
--   · sócios do cartão CNPJ entram sozinhos em "Sócios e vínculos" (sem apagar os que já existem)
-- ═══════════════════════════════════════════════════════════════════
alter table public.clientes add column if not exists indicado_por text not null default '';

-- clientes com o mesmo CPF/CNPJ (só os que a pessoa vê)
create or replace function public.clientes_mesmo_documento(p_doc text, p_ignorar uuid default null)
returns table (id uuid, nome text, grupo text, tipo text) language sql stable set search_path = public as $$
  select c.id, c.nome, g.nome, c.tipo from public.clientes c left join public.grupos g on g.id = c.grupo_id
   where length(regexp_replace(coalesce(p_doc, ''), '\D', '', 'g')) >= 11
     and regexp_replace(c.cpf_cnpj, '\D', '', 'g') = regexp_replace(p_doc, '\D', '', 'g')
     and c.id is distinct from p_ignorar
   order by c.criado_em limit 5;
$$;
revoke all on function public.clientes_mesmo_documento(text, uuid) from public, anon;
grant execute on function public.clientes_mesmo_documento(text, uuid) to authenticated;

-- e-mail/telefone do cadastro → contato "Geral" (um só; acompanha a troca do e-mail)
create or replace function public.cliente_contato_geral() returns trigger
language plpgsql security definer set search_path = public as $$
declare ct uuid;
begin
  if coalesce(btrim(new.email), '') = '' then return null; end if;
  if tg_op = 'UPDATE' and new.email is not distinct from old.email and new.telefone is not distinct from old.telefone then return null; end if;
  if exists (select 1 from public.contatos where cliente_id = new.id and lower(email) = lower(btrim(new.email))) then
    if tg_op = 'UPDATE' and new.telefone is distinct from old.telefone then
      update public.contatos set telefone = new.telefone where cliente_id = new.id and lower(email) = lower(btrim(new.email)) and origem_cadastro;
    end if;
    return null;
  end if;
  if tg_op = 'UPDATE' then
    select id into ct from public.contatos where cliente_id = new.id and origem_cadastro and lower(email) = lower(btrim(coalesce(old.email, ''))) limit 1;
  end if;
  if ct is not null then update public.contatos set email = btrim(new.email), telefone = new.telefone where id = ct;
  else insert into public.contatos (cliente_id, nome, cargo, finalidade, email, telefone, origem_cadastro)
       values (new.id, 'Contato principal', '', 'geral', btrim(new.email), coalesce(new.telefone, ''), true);
  end if;
  return null;
end $$;
alter table public.contatos add column if not exists origem_cadastro boolean not null default false;
drop trigger if exists cliente_contato_geral on public.clientes;
create trigger cliente_contato_geral after insert or update of email, telefone on public.clientes for each row execute function public.cliente_contato_geral();
-- uma vez: clientes que já têm e-mail no cadastro e nenhum contato com ele
insert into public.contatos (cliente_id, nome, finalidade, email, telefone, origem_cadastro)
select c.id, 'Contato principal', 'geral', btrim(c.email), coalesce(c.telefone, ''), true
  from public.clientes c
 where coalesce(btrim(c.email), '') <> '' and c.email !~* 'example\.com'
   and not exists (select 1 from public.contatos x where x.cliente_id = c.id and lower(x.email) = lower(btrim(c.email)));

-- sócios do cartão CNPJ → "Sócios e vínculos"
create or replace function public.cliente_socios_cnpj() returns trigger
language plpgsql security definer set search_path = public as $$
declare s jsonb;
begin
  if new.cnpj_dados is null or jsonb_typeof(new.cnpj_dados->'socios') <> 'array' then return null; end if;
  if tg_op = 'UPDATE' and new.cnpj_dados is not distinct from old.cnpj_dados then return null; end if;
  for s in select * from jsonb_array_elements(new.cnpj_dados->'socios') loop
    if coalesce(s->>'nome', '') <> '' and not exists (select 1 from public.vinculos_societarios v where v.cliente_id = new.id and lower(btrim(v.nome)) = lower(btrim(s->>'nome'))) then
      insert into public.vinculos_societarios (cliente_id, nome, cpf_cnpj, qualificacao, obs)
      values (new.id, s->>'nome', coalesce(s->>'doc', ''), coalesce(s->>'qualificacao', ''), 'Do cartão CNPJ (Receita)');
    end if;
  end loop;
  if coalesce(new.socio_admin, '') = '' then
    update public.clientes set socio_admin = (select s2->>'nome' from jsonb_array_elements(new.cnpj_dados->'socios') s2 where s2->>'qualificacao' ~* 'administr' limit 1)
     where id = new.id and exists (select 1 from jsonb_array_elements(new.cnpj_dados->'socios') s2 where s2->>'qualificacao' ~* 'administr');
  end if;
  return null;
end $$;
drop trigger if exists cliente_socios_cnpj on public.clientes;
create trigger cliente_socios_cnpj after insert or update of cnpj_dados on public.clientes for each row execute function public.cliente_socios_cnpj();

-- ═══════════════════════════════════════════════════════════════════
-- Backup 26 — etapa 3: REUNIÃO a partir do lead
--   · reunião com data, hora, duração, local/link e participantes (nomes da equipe)
--   · vira tarefa de cada participante, cai na agenda (erp-agenda), entra nas atividades do CRM e na linha do tempo
--   · convite por e-mail ao cliente SÓ quando marcado (e respeita a pausa dos e-mails), com o arquivo .ics para salvar na agenda
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.reunioes (
  id uuid primary key default gen_random_uuid(),
  oportunidade_id uuid references public.crm_oportunidades(id) on delete cascade,
  cliente_id uuid references public.clientes(id) on delete set null,
  titulo text not null check (btrim(titulo) <> ''),
  inicio timestamptz not null,
  duracao_min int not null default 60 check (duracao_min between 5 and 720),
  local text not null default '',
  participantes text not null default '',
  convite boolean not null default false,
  convite_para text not null default '',
  convite_enviado_em timestamptz,
  status text not null default 'agendada' check (status in ('agendada', 'realizada', 'cancelada')),
  obs text not null default '',
  criado_por uuid default auth.uid(), criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists reunioes_inicio on public.reunioes (inicio);
create index if not exists reunioes_cliente on public.reunioes (cliente_id);
alter table public.reunioes enable row level security;
revoke all on public.reunioes from anon;
grant select, insert, update, delete on public.reunioes to authenticated;
drop policy if exists reunioes_ver on public.reunioes;
create policy reunioes_ver on public.reunioes for select to authenticated using (public.eh_equipe());
drop policy if exists reunioes_gravar on public.reunioes;
create policy reunioes_gravar on public.reunioes for all to authenticated
  using (public.eh_equipe() and (public.pode('crm', 'editar') or public.pode('tarefas', 'editar') or public.pode('clientes', 'editar')))
  with check (public.eh_equipe() and (public.pode('crm', 'editar') or public.pode('tarefas', 'editar') or public.pode('clientes', 'editar')));
drop trigger if exists atualizado_reunioes on public.reunioes;
create trigger atualizado_reunioes before update on public.reunioes for each row execute function public.marcar_atualizacao();

insert into public.emails_modelos (chave, tipo, nome, assunto, texto, ordem) values
  ('convite', 'reunioes', 'Convite de reunião', 'Convite: {titulo} — {data}',
   '<p style="margin:0">Confirmamos a nossa reunião <b>{titulo}</b> em <b>{data}</b>{local}.</p><p style="margin:10px 0 0">O convite segue em anexo para você salvar na sua agenda. Se precisar remarcar, é só responder este e-mail.</p>', 12)
on conflict (chave) do nothing;

-- texto do .ics (convite para salvar na agenda)
create or replace function public.ics_texto(t text) returns text language sql immutable as $$
  select replace(replace(replace(replace(coalesce(t, ''), '\', '\\'), ';', '\;'), ',', '\,'), E'\n', '\n');
$$;
create or replace function public.reuniao_ics(r public.reunioes) returns text language sql stable as $$
  select concat_ws(E'\r\n', 'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Araujo e Castro//ERP//PT-BR', 'METHOD:PUBLISH', 'BEGIN:VEVENT',
    'UID:reuniao-' || r.id || '@erp-araujo-castro', 'DTSTAMP:' || to_char(now() at time zone 'UTC', 'YYYYMMDD"T"HH24MISS"Z"'),
    'DTSTART:' || to_char(r.inicio at time zone 'UTC', 'YYYYMMDD"T"HH24MISS"Z"'),
    'DTEND:' || to_char((r.inicio + make_interval(mins => r.duracao_min)) at time zone 'UTC', 'YYYYMMDD"T"HH24MISS"Z"'),
    'SUMMARY:' || public.ics_texto(r.titulo || ' — Araújo & Castro'), 'LOCATION:' || public.ics_texto(r.local), 'END:VEVENT', 'END:VCALENDAR') || E'\r\n';
$$;

-- manda o convite (uma vez por data/hora: remarcou → convite novo). Sem cliente cadastrado, usa o e-mail do lead.
create or replace function public.reuniao_enviar_convite(p_reuniao uuid) returns boolean
language plpgsql security definer set search_path = public as $$
declare r public.reunioes; o record; grp uuid; m record; v_ref text; v_para text; v_anexo jsonb; quando text;
begin
  select * into r from public.reunioes where id = p_reuniao;
  if not found or not r.convite or r.status <> 'agendada' then return false; end if;
  v_ref := 'email_cv:' || r.id || ':' || to_char(r.inicio at time zone 'UTC', 'YYYYMMDDHH24MI');
  if exists (select 1 from public.automacoes_log where automacoes_log.ref = v_ref) then return false; end if;
  select * into o from public.crm_oportunidades where id = r.oportunidade_id;
  select grupo_id into grp from public.clientes where id = r.cliente_id;
  quando := to_char(r.inicio at time zone 'America/Sao_Paulo', 'DD/MM/YYYY "às" HH24:MI');
  select * into m from public.modelo_email('convite', jsonb_build_object('titulo', r.titulo, 'data', quando,
    'local', case when btrim(r.local) <> '' then ' — ' || r.local else '' end));
  v_anexo := jsonb_build_object('tipo', 'ics', 'arquivo', 'Reunião ' || to_char(r.inicio at time zone 'America/Sao_Paulo', 'DD-MM-YYYY') || '.ics', 'conteudo', public.reuniao_ics(r));
  v_para := nullif(btrim(r.convite_para), '');
  if v_para is null and r.cliente_id is not null then
    if public.email_cliente_enviar('email_cv', v_ref, r.cliente_id, grp, 'convite', m.assunto, m.texto, '[]'::jsonb, false, v_anexo) then
      update public.reunioes set convite_enviado_em = now() where id = r.id; return true;
    end if;
    return false;
  end if;
  v_para := coalesce(v_para, nullif(btrim(o.prospecto_email), ''));
  if v_para is null then return false; end if;
  if r.cliente_id is not null and not public.pode_email(r.cliente_id, grp, 'convite') then return false; end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo)
  values (auth.uid(), v_para, m.assunto, public.email_cliente_html(m.assunto, nullif(split_part(btrim(coalesce(o.prospecto_nome, '')), ' ', 1), ''), m.texto, '[]', false), 'cliente', v_ref, v_anexo);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values ('email_cv', v_ref, m.assunto || ' → ' || v_para, r.cliente_id);
  update public.reunioes set convite_enviado_em = now() where id = r.id;
  return true;
end $$;
revoke all on function public.reuniao_enviar_convite(uuid) from public, anon, authenticated;

create or replace function public.reuniao_automacoes() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_nome text; grp uuid; v_titulo text; etp record; o record;
begin
  select grupo_id into grp from public.clientes where id = new.cliente_id;
  v_titulo := 'Reunião: ' || new.titulo || ' — ' || to_char(new.inicio at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI');
  if new.status = 'cancelada' then
    update public.tarefas set status = 'cancelada' where chave_regra like 'reuniao:' || new.id || ':%' and status not in ('concluida', 'cancelada');
    return null;
  end if;
  -- uma tarefa por participante (remarcou → a tarefa acompanha; saiu da lista → a tarefa dele é cancelada)
  for v_nome in select distinct btrim(x) from unnest(string_to_array(new.participantes, ',')) x where btrim(x) <> '' loop
    if exists (select 1 from public.tarefas where chave_regra = 'reuniao:' || new.id || ':' || lower(v_nome)) then
      update public.tarefas set titulo = v_titulo, prazo = (new.inicio at time zone 'America/Sao_Paulo')::date, cliente_id = new.cliente_id,
             descricao = 'Local/link: ' || coalesce(nullif(new.local, ''), '—') || E'\nParticipantes: ' || new.participantes || case when new.obs <> '' then E'\n' || new.obs else '' end
       where chave_regra = 'reuniao:' || new.id || ':' || lower(v_nome) and status not in ('concluida', 'cancelada');
    else
      perform public.tarefa_da_regra('reuniao:' || new.id || ':' || lower(v_nome), v_titulo, v_nome, (new.inicio at time zone 'America/Sao_Paulo')::date,
        new.cliente_id, grp, null, '[]'::jsonb,
        'Local/link: ' || coalesce(nullif(new.local, ''), '—') || E'\nParticipantes: ' || new.participantes || case when new.obs <> '' then E'\n' || new.obs else '' end, '', 'alta');
    end if;
  end loop;
  update public.tarefas set status = 'cancelada' where chave_regra like 'reuniao:' || new.id || ':%' and status not in ('concluida', 'cancelada')
     and substr(chave_regra, length('reuniao:' || new.id || ':') + 1) not in (select lower(btrim(x)) from unnest(string_to_array(new.participantes, ',')) x);
  if tg_op = 'INSERT' then
    if new.oportunidade_id is not null then
      insert into public.crm_atividades (oportunidade_id, tipo, quando, resumo, feita) values (new.oportunidade_id, 'reuniao', new.inicio, 'Reunião agendada: ' || new.titulo ||
        case when new.local <> '' then ' (' || new.local || ')' else '' end, false);
      -- lead nas primeiras etapas → "Diagnóstico agendado"
      select * into o from public.crm_oportunidades where id = new.oportunidade_id;
      select * into etp from public.crm_etapas where nome = 'Diagnóstico agendado' limit 1;
      if etp.id is not null and coalesce((select ordem from public.crm_etapas where id = o.etapa_id), 0) < etp.ordem
         and coalesce((select final from public.crm_etapas where id = o.etapa_id), '') = '' then
        update public.crm_oportunidades set etapa_id = etp.id where id = o.id;
      end if;
    end if;
    if new.cliente_id is not null then
      insert into public.interacoes (cliente_id, tipo, quando, resumo) values (new.cliente_id, 'reuniao', new.inicio,
        'Reunião agendada: ' || new.titulo || ' — ' || to_char(new.inicio at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'));
    end if;
  end if;
  if new.convite then perform public.reuniao_enviar_convite(new.id); end if;
  return null;
end $$;
drop trigger if exists reuniao_automacoes on public.reunioes;
create trigger reuniao_automacoes after insert or update of inicio, participantes, status, convite, local, titulo on public.reunioes
  for each row execute function public.reuniao_automacoes();

-- o lead virou cliente: as reuniões dele passam a ser do cliente (aparecem na ficha)
create or replace function public.crm_reunioes_do_cliente() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.cliente_id is not null and new.cliente_id is distinct from old.cliente_id then
    update public.reunioes set cliente_id = new.cliente_id where oportunidade_id = new.id and cliente_id is null;
  end if;
  return null;
end $$;
drop trigger if exists crm_reunioes_do_cliente on public.crm_oportunidades;
create trigger crm_reunioes_do_cliente after update of cliente_id on public.crm_oportunidades for each row execute function public.crm_reunioes_do_cliente();

-- ═══════════════════════════════════════════════════════════════════
-- Backup 26 — etapa 7: DELEGAR E VALIDAR
--   · sequência de passos para uma pessoa (modelo "Lead completo"): cada passo é uma tarefa com prazo;
--     o próximo só começa quando o anterior termina (e é aprovado, se o passo pedir validação)
--   · o passo com validação vai para "Aguardando revisão": quem valida aprova ou devolve com comentário
--   · Início: cartão "Aguardando minha validação"
-- ═══════════════════════════════════════════════════════════════════
alter table public.modelos_fluxo add column if not exists sequencial boolean not null default false;
insert into public.modelos_fluxo (nome, descricao, sequencial, itens)
select 'Lead completo', 'Delegar: cadastrar, agendar a reunião e preparar o contrato (o contrato só vai ao cliente depois da validação)', true,
  '[{"titulo":"Cadastrar o cliente (dados, sócios e contatos por setor)","dias":1},
    {"titulo":"Agendar a reunião com o cliente","dias":2},
    {"titulo":"Preparar o contrato (gerador) e guardar a minuta","dias":3,"validar":true},
    {"titulo":"Enviar o contrato ao cliente para assinatura","dias":1}]'::jsonb
where not exists (select 1 from public.modelos_fluxo where nome = 'Lead completo');

-- cria a sequência: cada passo depende do anterior; só o primeiro começa "pendente", os demais "aguardando"
create or replace function public.delegar_sequencia(p_modelo text, p_pessoa text, p_revisor text, p_cliente uuid default null,
  p_oportunidade uuid default null, p_nome text default null, p_obs text default '') returns uuid
language plpgsql security definer set search_path = public as $$
declare m record; it jsonb; f uuid; ant uuid; t uuid; prazo date := current_date; grp uuid; n int := 0; alvo text; rev text;
begin
  if not public.pode('tarefas', 'editar') then raise exception 'Sem a função Tarefas (editar).'; end if;
  if coalesce(btrim(p_pessoa), '') = '' then raise exception 'Escolha para quem delegar.'; end if;
  select * into m from public.modelos_fluxo where nome = p_modelo limit 1;
  if not found then raise exception 'Modelo "%" não encontrado.', p_modelo; end if;
  select grupo_id into grp from public.clientes where id = p_cliente;
  alvo := coalesce((select nome from public.clientes where id = p_cliente), (select coalesce(nullif(prospecto_empresa, ''), nullif(prospecto_nome, ''), titulo) from public.crm_oportunidades where id = p_oportunidade), '');
  rev := coalesce(nullif(btrim(p_revisor), ''), (select nome from public.perfis where id = auth.uid()), '');
  insert into public.fluxos (nome, cliente_id, grupo_id, modelo_id, responsavel, inicio, obs)
  values (coalesce(nullif(p_nome, ''), m.nome || case when alvo <> '' then ' — ' || alvo else '' end), p_cliente, grp, m.id, p_pessoa, current_date, coalesce(p_obs, ''))
  returning id into f;
  for it in select * from jsonb_array_elements(m.itens) loop
    n := n + 1;
    prazo := public.somar_uteis(prazo, greatest(coalesce((it->>'dias')::int, 1), 0));
    insert into public.tarefas (fluxo_id, cliente_id, grupo_id, titulo, responsavel, status, prioridade, inicio, prazo, descricao, depende_de, exige_revisao, revisor, ordem, chave_regra)
    values (f, p_cliente, grp, (it->>'titulo') || case when alvo <> '' then ' — ' || alvo else '' end, p_pessoa, case when ant is null then 'pendente' else 'aguardando' end, 'media',
            current_date, prazo, 'Passo ' || n || ' de ' || jsonb_array_length(m.itens) || ' (delegado).' || case when coalesce((it->>'validar')::boolean, false) then ' Ao terminar, vai para a validação de ' || rev || '.' else '' end ||
              case when coalesce(p_obs, '') <> '' then E'\n' || p_obs else '' end,
            ant, coalesce((it->>'validar')::boolean, false), case when coalesce((it->>'validar')::boolean, false) then rev else '' end, n,
            case when p_oportunidade is not null then 'deleg:' || p_oportunidade || ':' || n end)
    returning id into t;
    ant := t;
  end loop;
  perform public.notificar_pessoa(p_pessoa, 'tarefa', 'Nova sequência para você: ' || coalesce(nullif(p_nome, ''), m.nome), coalesce(alvo, ''), 'tarefas');
  return f;
end $$;
revoke all on function public.delegar_sequencia(text, text, text, uuid, uuid, text, text) from public, anon;
grant execute on function public.delegar_sequencia(text, text, text, uuid, uuid, text, text) to authenticated;

-- aviso a uma pessoa pelo nome (ignora quem não tem acesso)
create or replace function public.notificar_pessoa(p_nome text, p_tipo text, p_titulo text, p_detalhe text, p_link text) returns void
language plpgsql security definer set search_path = public as $$
declare u uuid := public.usuario_por_nome(p_nome);
begin
  if u is not null and u is distinct from auth.uid() then
    insert into public.notificacoes (usuario_id, tipo, titulo, detalhe, link) values (u, p_tipo, p_titulo, coalesce(p_detalhe, ''), coalesce(p_link, ''));
  end if;
end $$;
revoke all on function public.notificar_pessoa(text, text, text, text, text) from public, anon, authenticated;

-- passo concluído (aprovado) → libera o próximo e avisa quem faz
create or replace function public.tarefa_libera_proxima() returns trigger
language plpgsql security definer set search_path = public as $$
declare x record;
begin
  if new.status = 'concluida' and old.status is distinct from 'concluida' then
    for x in update public.tarefas set status = 'pendente', inicio = current_date where depende_de = new.id and status = 'aguardando' returning titulo, responsavel loop
      perform public.notificar_pessoa(x.responsavel, 'tarefa', 'Pode começar: ' || x.titulo, 'O passo anterior foi concluído' || case when new.exige_revisao then ' e aprovado' else '' end || '.', 'tarefas');
    end loop;
  end if;
  return null;
end $$;
drop trigger if exists tarefa_libera_proxima on public.tarefas;
create trigger tarefa_libera_proxima after update of status on public.tarefas for each row execute function public.tarefa_libera_proxima();

-- aprovar / devolver com comentário (só quem valida ou o administrador)
create or replace function public.tarefa_validar(p_tarefa uuid, p_aprovar boolean, p_comentario text default '') returns text
language plpgsql security definer set search_path = public as $$
declare t public.tarefas; eu text;
begin
  select * into t from public.tarefas where id = p_tarefa;
  if not found then raise exception 'Tarefa não encontrada.'; end if;
  if t.status <> 'revisao' then raise exception 'Esta tarefa não está aguardando validação.'; end if;
  if not public.eh_admin() and public.usuario_por_nome(t.revisor) is distinct from auth.uid() then raise exception 'Só quem valida (%) ou o administrador.', t.revisor; end if;
  select coalesce(nullif(nome, ''), email) into eu from public.perfis where id = auth.uid();
  if p_aprovar then
    update public.tarefas set status = 'concluida' where id = p_tarefa;
    if coalesce(btrim(p_comentario), '') <> '' then insert into public.comentarios (tarefa_id, texto) values (p_tarefa, '✓ Aprovado: ' || btrim(p_comentario)); end if;
    perform public.notificar_pessoa(t.responsavel, 'revisao', 'Aprovado: ' || t.titulo, coalesce(nullif(btrim(p_comentario), ''), 'Validado por ' || coalesce(eu, '')), 'tarefas');
    return 'aprovada';
  end if;
  if coalesce(btrim(p_comentario), '') = '' then raise exception 'Escreva o que precisa ser ajustado.'; end if;
  update public.tarefas set status = 'andamento' where id = p_tarefa;
  insert into public.comentarios (tarefa_id, texto) values (p_tarefa, '↩ Devolvido: ' || btrim(p_comentario));
  perform public.notificar_pessoa(t.responsavel, 'revisao', 'Devolvido para ajuste: ' || t.titulo, btrim(p_comentario), 'tarefas');
  return 'devolvida';
end $$;
revoke all on function public.tarefa_validar(uuid, boolean, text) from public, anon;
grant execute on function public.tarefa_validar(uuid, boolean, text) to authenticated;

-- Início: o que está esperando a MINHA validação (tarefas em revisão + alterações propostas no modo rascunho)
create or replace function public.minhas_validacoes() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.eh_equipe() then return '[]'::jsonb; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'titulo', t.titulo, 'responsavel', t.responsavel, 'prazo', t.prazo, 'cliente', c.nome,
             'desde', t.atualizado_em, 'fluxo', f.nome) order by t.atualizado_em)
    from public.tarefas t left join public.clientes c on c.id = t.cliente_id left join public.fluxos f on f.id = t.fluxo_id
   where t.status = 'revisao' and (public.usuario_por_nome(t.revisor) = auth.uid() or (public.eh_admin() and coalesce(btrim(t.revisor), '') = ''))), '[]'::jsonb);
end $$;
revoke all on function public.minhas_validacoes() from public, anon;
grant execute on function public.minhas_validacoes() to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 27 — EMISSÃO DAS GUIAS (parcelamentos) E DOS BOLETOS/PIX (acordos)
-- Para o estagiário: emitir → marcar "emitida" (data e quem) → guardar o PDF → mandar ao cliente → conferir o pagamento.
-- A coluna antiga "emissao" (texto da planilha) continua; "emitida_em" é a data certa.
-- ═══════════════════════════════════════════════════════════════════
alter table public.parcelas add column if not exists emitida_em date;
alter table public.parcelas add column if not exists emitida_por text not null default '';
alter table public.parcelas add column if not exists guia_doc uuid references public.documentos(id) on delete set null;
alter table public.acordos add column if not exists emitida_em date;
alter table public.acordos add column if not exists emitida_por text not null default '';
alter table public.acordos add column if not exists guia_doc uuid references public.documentos(id) on delete set null;
-- a planilha trazia "SIM" ou a data: vira data (quando é data) — só uma vez
update public.parcelas set emitida_em = to_date(substring(emissao from '(\d{2}/\d{2}/\d{4})'), 'DD/MM/YYYY')
 where emitida_em is null and emissao ~ '\d{2}/\d{2}/\d{4}';
update public.acordos set emitida_em = to_date(substring(emissao from '(\d{2}/\d{2}/\d{4})'), 'DD/MM/YYYY')
 where emitida_em is null and emissao ~ '\d{2}/\d{2}/\d{4}';

-- marca (ou desmarca) a emissão; com p_enviar, põe na fila o e-mail ao cliente com o PDF anexo (mesma referência do lembrete
-- automático, que então não repete). Devolve {emitida_em, emitida_por, email: 'enviado'|'sem e-mail'|'já enviado'|''}.
create or replace function public.registrar_emissao(p_tabela text, p_id uuid, p_emitida boolean default true, p_doc uuid default null, p_enviar boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare quem text; d record; cli uuid; grp uuid; v_ref text; assunto text; texto text; itens jsonb; anexo jsonb := null; ok boolean; res text := ''; m record;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para marcar a emissão.'; end if;
  if p_tabela not in ('parcelas', 'acordos') then raise exception 'Tabela inválida.'; end if;
  select coalesce(nullif(nome, ''), email) into quem from public.perfis where id = auth.uid();
  if p_tabela = 'parcelas' then
    update public.parcelas set emitida_em = case when p_emitida then coalesce(emitida_em, current_date) end,
           emitida_por = case when p_emitida then coalesce(nullif(emitida_por, ''), quem, '') else '' end,
           emissao = case when p_emitida then 'SIM' else '' end, guia_doc = coalesce(p_doc, case when p_emitida then guia_doc end)
     where id = p_id;
  else
    update public.acordos set emitida_em = case when p_emitida then coalesce(emitida_em, current_date) end,
           emitida_por = case when p_emitida then coalesce(nullif(emitida_por, ''), quem, '') else '' end,
           emissao = case when p_emitida then 'SIM' else '' end, guia_doc = coalesce(p_doc, case when p_emitida then guia_doc end)
     where id = p_id;
  end if;
  if not found then raise exception 'Parcela não encontrada.'; end if;
  if p_emitida and p_enviar then
    if p_doc is not null then
      select jsonb_build_object('tipo', 'arquivo', 'caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime) into anexo from public.documentos dc where dc.id = p_doc;
    end if;
    if p_tabela = 'parcelas' then
      select pa.id, pa.numero, pa.vencimento, p.empresa, p.natureza, p.local, p.numero parc_num, p.valor_ultima_parcela, p.grupo_id, p.total_parcelas,
             (select cl.id from public.clientes cl where (regexp_replace(coalesce(p.cnpj, ''), '\D', '', 'g') <> '' and regexp_replace(cl.cpf_cnpj, '\D', '', 'g') = regexp_replace(coalesce(p.cnpj, ''), '\D', '', 'g')) or cl.nome = p.empresa limit 1) cli
        into d from public.parcelas pa join public.parcelamentos p on p.id = pa.parcelamento_id where pa.id = p_id;
      select * into m from public.modelo_email('parc_guia', jsonb_build_object('parcela', coalesce(d.numero, '') || coalesce('/' || d.total_parcelas, ''), 'natureza', trim(both ' ·' from coalesce(d.natureza, '') || coalesce(' · ' || nullif(d.local, ''), '')),
        'numero', coalesce(' (nº ' || nullif(d.parc_num, '') || ')', ''), 'empresa', coalesce(d.empresa, ''), 'vencimento', to_char(d.vencimento, 'DD/MM/YYYY')));
      v_ref := 'email_lp:' || p_id; cli := d.cli; grp := d.grupo_id;
      assunto := m.assunto; texto := m.texto || case when anexo is not null then '<p style="margin:10px 0 0">A guia segue <b>anexa</b> a este e-mail.</p>' else '' end;
      itens := case when coalesce(d.valor_ultima_parcela, 0) > 0 then jsonb_build_array(jsonb_build_object('descricao', 'Parcela ' || coalesce(d.numero, ''), 'vencimento', d.vencimento, 'valor', d.valor_ultima_parcela)) else '[]'::jsonb end;
      if exists (select 1 from public.automacoes_log g where g.ref = 'email_lp:' || p_id) then res := 'já enviado';
      else ok := public.email_cliente_enviar('email_lp', v_ref, cli, grp, 'guia', assunto, texto, itens, false, anexo); res := case when ok then 'enviado' else 'sem e-mail' end; end if;
    else
      select a.id, a.valor, a.vencimento, a.credor, a.parcela, a.total_parcelas, a.processo, a.grupo_id, a.pix, a.banco,
             (select cl.id from public.clientes cl where cl.grupo_id = a.grupo_id and public.primeiro_nome(cl.nome) = public.primeiro_nome(a.devedor) limit 1) cli
        into d from public.acordos a where a.id = p_id;
      select * into m from public.modelo_email('aco_lembrete', jsonb_build_object('parcela', coalesce(d.parcela, '') || coalesce('/' || nullif(d.total_parcelas, ''), ''),
        'credor', coalesce(d.credor, ''), 'processo', coalesce(d.processo, ''), 'vencimento', to_char(d.vencimento, 'DD/MM/YYYY'),
        'pix', case when coalesce(d.pix, '') <> '' then ' — PIX do credor: ' || d.pix else '' end || case when coalesce(d.banco, '') <> '' then ' — ' || d.banco else '' end));
      v_ref := 'email_la:' || p_id;
      texto := m.texto || case when anexo is not null then '<p style="margin:10px 0 0">O boleto segue <b>anexo</b> a este e-mail.</p>' else '' end;
      if exists (select 1 from public.automacoes_log g where g.ref = 'email_la:' || p_id) then res := 'já enviado';
      else ok := public.email_cliente_enviar('email_la', v_ref, d.cli, d.grupo_id, 'acordo', m.assunto, texto,
             jsonb_build_array(jsonb_build_object('descricao', 'Parcela ' || coalesce(d.parcela, '') || coalesce('/' || nullif(d.total_parcelas, ''), ''), 'vencimento', d.vencimento, 'valor', d.valor)), false, anexo);
        res := case when ok then 'enviado' else 'sem e-mail' end; end if;
    end if;
  end if;
  return jsonb_build_object('email', res);
end $$;
revoke all on function public.registrar_emissao(text, uuid, boolean, uuid, boolean) from public, anon;
grant execute on function public.registrar_emissao(text, uuid, boolean, uuid, boolean) to authenticated;

-- quando cada parcela teve o e-mail ao cliente (lembrete/guia) — para a tela mostrar "✉ enviado em"
create or replace function public.emissao_emails(p_tabela text, p_ids uuid[]) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(split_part(g.ref, ':', 2), g.quando), '{}'::jsonb)
    from (select ref, max(quando) quando from public.automacoes_log
           where public.pode('juridico') and ref = any (select case when p_tabela = 'parcelas' then 'email_lp:' else 'email_la:' end || x::text from unnest(p_ids) x)
             and descricao like '%→%' group by ref) g;
$$;
revoke all on function public.emissao_emails(text, uuid[]) from public, anon;
grant execute on function public.emissao_emails(text, uuid[]) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 28 — Acompanhamento de processos (estagiário): última movimentação + histórico
-- ═══════════════════════════════════════════════════════════════════
alter table public.processos add column if not exists ultima_movimentacao text not null default '';
alter table public.processos add column if not exists ultima_movimentacao_em date;
create table if not exists public.processo_movimentacoes (
  id uuid primary key default gen_random_uuid(),
  processo_id uuid not null references public.processos(id) on delete cascade,
  data date not null default current_date,
  tipo text not null default 'movimentacao' check (tipo in ('movimentacao','decisao','valor','procuracao','sem_novidade')),
  descricao text not null default '',
  valor_novo numeric(16,2),
  quem text not null default '',
  criado_por uuid default auth.uid(),
  criado_em timestamptz not null default now()
);
create index if not exists processo_mov_proc on public.processo_movimentacoes (processo_id, data desc);
alter table public.processo_movimentacoes enable row level security;
revoke all on public.processo_movimentacoes from anon;
grant select, insert, delete on public.processo_movimentacoes to authenticated;
drop policy if exists pmov_ver on public.processo_movimentacoes;
create policy pmov_ver on public.processo_movimentacoes for select to authenticated using (public.pode('juridico'));
drop policy if exists pmov_criar on public.processo_movimentacoes;
create policy pmov_criar on public.processo_movimentacoes for insert to authenticated with check (public.pode('juridico', 'editar'));
drop policy if exists pmov_apagar on public.processo_movimentacoes;
create policy pmov_apagar on public.processo_movimentacoes for delete to authenticated using (public.eh_admin());
-- ao registrar: atualiza a "última movimentação" do processo (e o valor, quando é alteração de valor)
create or replace function public.processo_mov_aplica() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.quem, '') = '' then select coalesce(nullif(nome, ''), email) into new.quem from public.perfis where id = auth.uid(); new.quem := coalesce(new.quem, ''); end if;
  update public.processos set
    ultima_movimentacao = case when new.tipo = 'sem_novidade' then coalesce(nullif(ultima_movimentacao, ''), 'Conferido: sem novidade') else left(new.descricao, 500) end,
    ultima_movimentacao_em = greatest(coalesce(ultima_movimentacao_em, new.data), new.data),
    atualizacao = new.data,
    valor = case when new.tipo = 'valor' and new.valor_novo is not null then new.valor_novo else valor end,
    procuracao = case when new.tipo = 'procuracao' then true else procuracao end
   where id = new.processo_id;
  return new;
end $$;
drop trigger if exists processo_mov_aplica on public.processo_movimentacoes;
create trigger processo_mov_aplica before insert on public.processo_movimentacoes for each row execute function public.processo_mov_aplica();

-- Backup 28 — Certificado digital do cliente (validade e senha) — tabela separada, só quem EDITA clientes vê
create table if not exists public.cliente_certificado (
  cliente_id uuid primary key references public.clientes(id) on delete cascade,
  validade date,
  senha text not null default '',
  tipo text not null default 'A1',
  atualizado_por text not null default '',
  atualizado_em timestamptz not null default now()
);
alter table public.cliente_certificado enable row level security;
revoke all on public.cliente_certificado from anon;
grant select, insert, update, delete on public.cliente_certificado to authenticated;
drop policy if exists ccert_tudo on public.cliente_certificado;
create policy ccert_tudo on public.cliente_certificado for all to authenticated
  using (public.eh_equipe() and public.pode('clientes', 'editar')) with check (public.eh_equipe() and public.pode('clientes', 'editar'));
create or replace function public.cliente_certificado_quem() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select coalesce(nullif(nome, ''), email, '') into new.atualizado_por from public.perfis where id = auth.uid();
  new.atualizado_por := coalesce(new.atualizado_por, ''); new.atualizado_em := now();
  -- marca "Certificado: Sim" no cadastro quando há validade futura
  if new.validade is not null then update public.clientes set certificado = (new.validade >= current_date) where id = new.cliente_id; end if;
  return new;
end $$;
drop trigger if exists cliente_certificado_quem on public.cliente_certificado;
create trigger cliente_certificado_quem before insert or update on public.cliente_certificado for each row execute function public.cliente_certificado_quem();

-- Backup 28 — Contratos: início da vigência (ex.: fechado 28/07, trabalho começa 01/08, 1º pagamento 10/09) e quem fechou
alter table public.contratos add column if not exists inicio_vigencia date;
alter table public.contratos add column if not exists fechado_por text not null default '';
update public.contratos set inicio_vigencia = coalesce(inicio_competencia, data_contrato) where inicio_vigencia is null;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 28 — E-mail por empresa: quem cobra é quem aparece
--   • clientes do escritório (Pedro) → remetente e dados de pagamento do escritório;
--   • clientes da Contabilidade (área "contabil") e lançamentos da Contabilidade → remetente e dados da Contabilidade.
--   Conta da Contabilidade: config_privada 'email_contab' (senha fora do site); dados: configuracoes 'dados_pagamento_contab'.
-- ═══════════════════════════════════════════════════════════════════
alter table public.email_fila add column if not exists conta text not null default 'escritorio';
create or replace function public.conta_email(p_cliente uuid, p_ref text) returns text
language plpgsql stable security definer set search_path = public as $$
declare u uuid; e text; a text; m text;
begin
  m := substring(coalesce(p_ref, '') from '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}');
  if m is not null then u := m::uuid; select empresa into e from public.lancamentos where id = u;
    if e is not null then return case when e = 'contabilidade' then 'contabilidade' else 'escritorio' end; end if; end if;
  select area into a from public.clientes where id = p_cliente;
  return case when a = 'contabil' then 'contabilidade' else 'escritorio' end;
end $$;
revoke all on function public.conta_email(uuid, text) from public, anon, authenticated;

create or replace function public.email_cliente_html(p_titulo text, p_nome text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_fecho text default '')
returns text language plpgsql stable security definer set search_path = public as $$
declare d jsonb; itens text := ''; tot numeric := 0; i jsonb; pag text := '';
begin
  -- Backup 28: dados de quem cobra (Contabilidade ou escritório), escolhidos por email_cliente_enviar
  if coalesce(current_setting('erp.conta_email', true), '') = 'contabilidade' then
    select valor into d from public.configuracoes where chave = 'dados_pagamento_contab';
  end if;
  if d is null or d = '{}'::jsonb then select valor into d from public.configuracoes where chave = 'dados_pagamento'; end if;
  d := coalesce(d, '{}');
  for i in select * from jsonb_array_elements(coalesce(p_itens, '[]')) loop
    itens := itens || '<tr><td style="padding:10px 12px;border-bottom:1px solid #EEF0F5">' || public.esc_html(i->>'descricao') || '</td>'
      || '<td style="padding:10px 12px;border-bottom:1px solid #EEF0F5;white-space:nowrap">' || coalesce(to_char((i->>'vencimento')::date, 'DD/MM/YYYY'), '') || '</td>'
      || '<td style="padding:10px 12px;border-bottom:1px solid #EEF0F5;text-align:right;white-space:nowrap;font-weight:bold">' || public.brl_texto((i->>'valor')::numeric) || '</td></tr>';
    tot := tot + coalesce((i->>'valor')::numeric, 0);
  end loop;
  if itens <> '' then
    itens := '<table role="presentation" style="width:100%;border-collapse:collapse;margin:14px 0;font-size:14px;border:1px solid #E5E7EB;border-radius:10px">'
      || '<tr style="background:#F7F8FB;color:#5B6472;font-size:11px;text-transform:uppercase;letter-spacing:.06em"><td style="padding:9px 12px">Descrição</td><td style="padding:9px 12px">Vencimento</td><td style="padding:9px 12px;text-align:right">Valor</td></tr>'
      || itens || case when jsonb_array_length(p_itens) > 1 then '<tr><td colspan="2" style="padding:10px 12px;font-weight:bold">Total</td><td style="padding:10px 12px;text-align:right;font-weight:bold;color:#1B2A4A">' || public.brl_texto(tot) || '</td></tr>' else '' end
      || '</table>';
  end if;
  if p_pagar and (coalesce(d->>'pix', '') <> '' or coalesce(d->>'banco', '') <> '') then
    pag := '<div style="background:#F5EDD6;border-left:4px solid #C9A84C;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13.5px"><b style="color:#1B2A4A">Como pagar</b><br>'
      || case when coalesce(d->>'pix', '') <> '' then 'PIX: <b>' || public.esc_html(d->>'pix') || '</b>' || coalesce(' · ' || nullif(public.esc_html(d->>'titular'), ''), '') || '<br>' else '' end
      || case when coalesce(d->>'banco', '') <> '' then public.esc_html(d->>'banco') || '<br>' else '' end
      || 'Depois de pagar, responda este e-mail com o comprovante.</div>';
  end if;
  return '<div style="font-family:Arial,Helvetica,sans-serif;background:#F0F2F7;padding:24px 12px">'
    || '<div style="max-width:620px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #E5E7EB">'
    || '<div style="background:#1B2A4A;padding:20px 24px;border-bottom:3px solid #C9A84C">'
    ||   '<div style="color:#C9A84C;font-family:Georgia,serif;font-size:20px;font-weight:bold">Araújo &amp; Castro</div>'
    ||   '<div style="color:#CBD5E1;font-size:11px;letter-spacing:.14em;text-transform:uppercase;margin-top:2px">Advocacia · Contabilidade · Consultoria</div></div>'
    || '<div style="padding:22px 24px;color:#1F2937;font-size:14.5px;line-height:1.6">'
    ||   '<div style="font-size:18px;font-weight:bold;color:#1B2A4A;margin-bottom:10px">' || public.esc_html(p_titulo) || '</div>'
    ||   case when p_nome = '-' then '' else '<p style="margin:0 0 10px">Olá' || coalesce(', ' || public.esc_html(nullif(p_nome, '')), '') || '!</p>' end
    ||   p_texto || itens || pag
    ||   case when p_fecho = '-' then '' else
           coalesce(nullif(p_fecho, ''), '<p style="margin:14px 0 0">Qualquer dúvida, é só responder este e-mail' || case when coalesce(d->>'whatsapp', '') <> '' then ' ou chamar no WhatsApp ' || public.esc_html(d->>'whatsapp') else '' end || '.</p>')
           || '<p style="margin:16px 0 0">Atenciosamente,<br><b>' || public.esc_html(coalesce(nullif(d->>'assinatura', ''), 'Equipe Araújo & Castro')) || '</b></p>' end || '</div>'
    || '<div style="padding:12px 24px;background:#F7F8FB;border-top:1px solid #E5E7EB;color:#6B7280;font-size:11.5px">Mensagem automática do sistema do escritório. Se já resolveu, por favor desconsidere.</div>'
    || '</div></div>';
end $$;
revoke all on function public.email_cliente_html(text, text, text, jsonb, boolean, text) from public, anon, authenticated;

create or replace function public.email_cliente_enviar(p_regra text, p_ref text, p_cliente uuid, p_grupo uuid, p_finalidade text,
  p_assunto text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_anexo jsonb default null) returns boolean
language plpgsql security definer set search_path = public as $$
declare c record; tipo text; v_conta text;
begin
  if exists (select 1 from public.automacoes_log where ref = p_ref) then return false; end if;
  tipo := case p_regra when 'email_lh' then 'lembrete' when 'email_vh' then 'vencimento' when 'email_ch' then 'cobranca'
                       when 'email_pr' then 'recibo' when 'email_lp' then 'parcelamento' when 'email_la' then 'acordo'
                       when 'email_bv' then 'boas_vindas' when 'email_cv' then 'convite' end;
  if tipo is not null and not public.pode_email(p_cliente, p_grupo, tipo) then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (p_regra, p_ref, 'Não enviado (perfil de e-mail do cliente): ' || p_assunto, p_cliente);
    return false;
  end if;
  select * into c from public.contato_do_cliente(p_cliente, p_grupo, p_finalidade);
  if c.email is null or c.email = '' then return false; end if;
  if c.email ~* '(@|\.)example\.com(,|$)' then
    insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, 'Demonstração (não enviado): ' || p_assunto, p_cliente);
    return false;
  end if;
  v_conta := public.conta_email(p_cliente, p_ref);
  perform set_config('erp.conta_email', v_conta, true);
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (null, c.email, p_assunto, public.email_cliente_html(p_assunto, c.nome, p_texto, p_itens, p_pagar), 'cliente', p_ref, p_anexo, v_conta);
  perform set_config('erp.conta_email', '', true);
  insert into public.automacoes_log (chave, ref, descricao, cliente_id) values (p_regra, p_ref, p_assunto || ' → ' || c.email, p_cliente);
  return true;
end $$;
revoke all on function public.email_cliente_enviar(text, text, uuid, uuid, text, text, text, jsonb, boolean, jsonb) from public, anon, authenticated;

-- configuração da conta de e-mail por empresa (só admin; a senha nunca volta para o site)
create or replace function public.salvar_config_email_conta(p_conta text, p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare atual jsonb; k text;
begin
  if not public.eh_admin() then raise exception 'Só o administrador configura o e-mail.'; end if;
  if p_conta = 'escritorio' then perform public.salvar_config_email(p); return; end if;
  if p_conta <> 'contabilidade' then raise exception 'Conta inválida.'; end if;
  k := 'email_contab';
  select valor into atual from public.config_privada where chave = k;
  if coalesce(p->>'senha', '') = '' then p := p || jsonb_build_object('senha', coalesce(atual->>'senha', '')); end if;
  insert into public.config_privada (chave, valor) values (k, p || jsonb_build_object('configurado_em', now(), 'configurado_por', auth.uid()))
  on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
end $$;
create or replace function public.status_config_email_conta(p_conta text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c jsonb;
begin
  if not public.eh_admin() then raise exception 'Só o administrador vê a configuração do e-mail.'; end if;
  select valor into c from public.config_privada where chave = case when p_conta = 'contabilidade' then 'email_contab' else 'email' end;
  return coalesce(c - 'senha', '{}'::jsonb) || jsonb_build_object('tem_senha', coalesce(c->>'senha', '') <> '');
end $$;
revoke all on function public.salvar_config_email_conta(text, jsonb) from public, anon;
revoke all on function public.status_config_email_conta(text) from public, anon;
grant execute on function public.salvar_config_email_conta(text, jsonb), public.status_config_email_conta(text) to authenticated;
insert into public.configuracoes (chave, valor) values ('dados_pagamento_contab', '{}'::jsonb) on conflict (chave) do nothing;

-- Várias guias/boletos de UMA empresa num e-mail só, com o texto e os valores revisados na tela e as guias em PDF anexas
-- p_itens: [{tabela:'parcelas'|'acordos', id, descricao, vencimento, valor}] · p_docs: documentos (PDF) já enviados ao Storage
create or replace function public.enviar_guias_email(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c record; para text; nome text; anexo jsonb; it jsonb; html text; v_conta text; n int := 0; lista jsonb;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if coalesce(jsonb_array_length(p_itens), 0) = 0 then raise exception 'Escolha ao menos uma guia.'; end if;
  if coalesce(trim(p_para), '') <> '' then para := trim(p_para); nome := '';
  else select * into c from public.contato_do_cliente(p_cliente, p_grupo, 'guia'); para := c.email; nome := c.nome; end if;
  if coalesce(para, '') = '' then raise exception 'Este cliente não tem e-mail para guias: cadastre em Clientes → ficha → Contatos (ou informe o e-mail aqui).'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime)), '[]') into lista
    from public.documentos dc where dc.id = any (coalesce(p_docs, '{}'));
  anexo := case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'arquivos', 'lista', lista) end;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  html := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), coalesce(nome, ''),
    '<p style="margin:0 0 10px">' || replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>') || '</p>', p_itens, false);
  perform set_config('erp.conta_email', '', true);
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (auth.uid(), para, coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), html, 'cliente', 'guias:' || gen_random_uuid(), anexo, v_conta);
  for it in select * from jsonb_array_elements(p_itens) loop
    if it->>'tabela' not in ('parcelas', 'acordos') then continue; end if;
    perform public.registrar_emissao(it->>'tabela', (it->>'id')::uuid, true, null, false);
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (case when it->>'tabela' = 'parcelas' then 'email_lp' else 'email_la' end, case when it->>'tabela' = 'parcelas' then 'email_lp:' else 'email_la:' end || (it->>'id'),
            coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento') || ' → ' || para, p_cliente);
    n := n + 1;
  end loop;
  return jsonb_build_object('para', para, 'itens', n, 'anexos', jsonb_array_length(lista), 'conta', v_conta);
end $$;
revoke all on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text) from public, anon;
grant execute on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 29 — Início: cartão "Prejuízo" (créditos baixados como perda, todos os meses) nos Honorários
-- ═══════════════════════════════════════════════════════════════════
create or replace function public.resumo_financeiro(p_empresa text default null, p_de date default null, p_ate date default null)
returns jsonb language sql stable security invoker set search_path = public as $$
  with per as (
    select coalesce(p_de, date_trunc('month', current_date)::date) as de,
           coalesce(p_ate, (date_trunc('month', current_date) + interval '1 month - 1 day')::date) as ate
  ), l as (
    select l.empresa, l.tipo, l.pago, l.perda, l.vencimento, l.data_pagamento,
           case when l.redutor then -l.valor else l.valor end as v
      from public.lancamentos l
     where p_empresa is null or l.empresa = p_empresa
  ), t as (
    select e.empresa,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and l.pago and l.data_pagamento between per.de and per.ate), 0) as recebido,
      count(*)          filter (where l.tipo = 'receita' and l.pago and l.data_pagamento between per.de and per.ate) as n_recebido,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate), 0) as a_receber,
      count(*)          filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate) as n_a_receber,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento < current_date), 0) as em_atraso,
      count(*)          filter (where l.tipo = 'receita' and not l.pago and not l.perda and l.vencimento < current_date) as n_em_atraso,
      coalesce(sum(l.v) filter (where l.tipo = 'despesa' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate), 0) as a_pagar,
      count(*)          filter (where l.tipo = 'despesa' and not l.pago and not l.perda and l.vencimento between greatest(per.de, current_date) and per.ate) as n_a_pagar,
      coalesce(sum(l.v) filter (where l.tipo = 'receita' and l.perda), 0) as prejuizo,
      count(*)          filter (where l.tipo = 'receita' and l.perda) as n_prejuizo
    from (select unnest(array['escritorio','contabilidade']) as empresa) e
    cross join per
    left join l on l.empresa = e.empresa
    where p_empresa is null or e.empresa = p_empresa
    group by e.empresa
  )
  select coalesce(jsonb_object_agg(empresa, to_jsonb(t) - 'empresa'), '{}'::jsonb) from t;
$$;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 29 — Guias por empresa: PDFs anexados SEM guardar (vão só no e-mail) + e-mails de teste com a pausa ligada
-- ═══════════════════════════════════════════════════════════════════
drop function if exists public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text);
create or replace function public.enviar_guias_email(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c record; para text; nome text; anexo jsonb; it jsonb; html text; v_conta text; n int := 0; lista jsonb;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if coalesce(jsonb_array_length(p_itens), 0) = 0 then raise exception 'Escolha ao menos uma guia.'; end if;
  if coalesce(trim(p_para), '') <> '' then para := trim(p_para); nome := '';
  else select * into c from public.contato_do_cliente(p_cliente, p_grupo, 'guia'); para := c.email; nome := c.nome; end if;
  if coalesce(para, '') = '' then raise exception 'Este cliente não tem e-mail para guias: cadastre em Clientes → ficha → Contatos (ou informe o e-mail aqui).'; end if;
  -- Backup 29: os PDFs escolhidos na tela vêm aqui (p_arquivos: [{arquivo, mime, b64}]) e NÃO ficam guardados:
  -- a função de e-mail apaga o conteúdo do anexo assim que o e-mail sai (fica só no e-mail enviado)
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'arquivo', 'caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime)), '[]') into lista
    from public.documentos dc where dc.id = any (coalesce(p_docs, '{}'));
  select lista || coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  anexo := case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  html := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-',
    '<p style="margin:0 0 10px">' || replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>') || '</p>', p_itens, false);
  perform set_config('erp.conta_email', '', true);
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (auth.uid(), para, coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), html, 'cliente', 'guias:' || gen_random_uuid(), anexo, v_conta);
  for it in select * from jsonb_array_elements(p_itens) loop
    if it->>'tabela' not in ('parcelas', 'acordos') then continue; end if;
    perform public.registrar_emissao(it->>'tabela', (it->>'id')::uuid, true, null, false);
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (case when it->>'tabela' = 'parcelas' then 'email_lp' else 'email_la' end, case when it->>'tabela' = 'parcelas' then 'email_lp:' else 'email_la:' end || (it->>'id'),
            coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento') || ' → ' || para, p_cliente);
    n := n + 1;
  end loop;
  return jsonb_build_object('para', para, 'itens', n, 'anexos', jsonb_array_length(lista), 'conta', v_conta);
end $$;
revoke all on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) from public, anon;
grant execute on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) to authenticated;

-- e-mails de teste: saem mesmo com o envio pausado (para testar sem mandar nada aos clientes)
insert into public.configuracoes (chave, valor) values ('emails_teste', '"pedromgsam@gmail.com, advocaciapedrocastro@gmail.com"'::jsonb) on conflict (chave) do nothing;
create or replace function public.eh_email_teste(p_para text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(trim(p_para), '') <> '' and not exists (
    select 1 from regexp_split_to_table(lower(p_para), '\s*[,;]\s*') d
     where trim(d) <> '' and trim(d) <> all (select trim(x) from regexp_split_to_table(lower(coalesce((select valor #>> '{}' from public.configuracoes where chave = 'emails_teste'), '')), '\s*[,;]\s*') x));
$$;
create or replace function public.email_fila_reter() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'pendente' and coalesce(new.tipo, '') <> 'teste' and coalesce(current_setting('erp.liberar_email', true), '') <> '1'
     and (tg_op = 'INSERT' or old.status is distinct from 'pendente') and public.emails_pausados()
     and not public.eh_email_teste(new.para) then
    new.status := 'retido';
  end if;
  return new;
end $$;
create or replace function public.salvar_emails_teste(p text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador muda os e-mails de teste.'; end if;
  insert into public.configuracoes (chave, valor) values ('emails_teste', to_jsonb(coalesce(p, ''))) on conflict (chave) do update set valor = excluded.valor;
end $$;
revoke all on function public.salvar_emails_teste(text) from public, anon;
grant execute on function public.salvar_emails_teste(text) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 29 — Rotina: histórico de alterações do passivo das empresas (lido do histórico geral)
-- ═══════════════════════════════════════════════════════════════════
create or replace function public.historico_passivo(p_cliente uuid default null, p_limite int default 300)
returns table (quando timestamptz, quem text, cliente_id uuid, cliente text, campo text, antes text, depois text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.eh_equipe() and public.pode('clientes')) then raise exception 'permission denied: sem acesso aos clientes.'; end if;
  return query
  select h.quando, coalesce(nullif(pf.nome, ''), pf.email, ''), h.registro_id, coalesce(h.depois->>'nome', h.antes->>'nome', ''), k.campo,
         h.antes->>k.campo, h.depois->>k.campo
    from public.historico h
    cross join unnest(array['rfb','rfb_negociada','pgfn','pgfn_negociada','age_mg','age_mg_negociada','sefaz_mg','ceat_trt3','em_operacao','procuracao','certificado','capag']) as k(campo)
    left join public.perfis pf on pf.id = h.usuario
   where h.tabela = 'clientes' and h.acao = 'UPDATE' and (p_cliente is null or h.registro_id = p_cliente)
     and (h.antes->k.campo) is distinct from (h.depois->k.campo)
   order by h.quando desc
   limit greatest(coalesce(p_limite, 300), 1);
end $$;
revoke all on function public.historico_passivo(uuid, int) from public, anon;
grant execute on function public.historico_passivo(uuid, int) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 29 — dados para pagamento com banco, agência e conta separados; mensalidades geradas 6 meses à frente
-- ═══════════════════════════════════════════════════════════════════
create or replace function public.email_cliente_html(p_titulo text, p_nome text, p_texto text, p_itens jsonb default '[]', p_pagar boolean default false, p_fecho text default '')
returns text language plpgsql stable security definer set search_path = public as $$
declare d jsonb; itens text := ''; tot numeric := 0; i jsonb; pag text := '';
begin
  -- Backup 28: dados de quem cobra (Contabilidade ou escritório), escolhidos por email_cliente_enviar
  if coalesce(current_setting('erp.conta_email', true), '') = 'contabilidade' then
    select valor into d from public.configuracoes where chave = 'dados_pagamento_contab';
  end if;
  if d is null or d = '{}'::jsonb then select valor into d from public.configuracoes where chave = 'dados_pagamento'; end if;
  d := coalesce(d, '{}');
  for i in select * from jsonb_array_elements(coalesce(p_itens, '[]')) loop
    itens := itens || '<tr><td style="padding:10px 12px;border-bottom:1px solid #EEF0F5">' || public.esc_html(i->>'descricao') || '</td>'
      || '<td style="padding:10px 12px;border-bottom:1px solid #EEF0F5;white-space:nowrap">' || coalesce(to_char((i->>'vencimento')::date, 'DD/MM/YYYY'), '') || '</td>'
      || '<td style="padding:10px 12px;border-bottom:1px solid #EEF0F5;text-align:right;white-space:nowrap;font-weight:bold">' || public.brl_texto((i->>'valor')::numeric) || '</td></tr>';
    tot := tot + coalesce((i->>'valor')::numeric, 0);
  end loop;
  if itens <> '' then
    itens := '<table role="presentation" style="width:100%;border-collapse:collapse;margin:14px 0;font-size:14px;border:1px solid #E5E7EB;border-radius:10px">'
      || '<tr style="background:#F7F8FB;color:#5B6472;font-size:11px;text-transform:uppercase;letter-spacing:.06em"><td style="padding:9px 12px">Descrição</td><td style="padding:9px 12px">Vencimento</td><td style="padding:9px 12px;text-align:right">Valor</td></tr>'
      || itens || case when jsonb_array_length(p_itens) > 1 then '<tr><td colspan="2" style="padding:10px 12px;font-weight:bold">Total</td><td style="padding:10px 12px;text-align:right;font-weight:bold;color:#1B2A4A">' || public.brl_texto(tot) || '</td></tr>' else '' end
      || '</table>';
  end if;
  if p_pagar and (coalesce(d->>'pix', '') <> '' or coalesce(d->>'banco', '') <> '' or coalesce(d->>'conta', '') <> '') then
    pag := '<div style="background:#F5EDD6;border-left:4px solid #C9A84C;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13.5px"><b style="color:#1B2A4A">Como pagar</b><br>'
      || case when coalesce(d->>'pix', '') <> '' then 'PIX: <b>' || public.esc_html(d->>'pix') || '</b>' || coalesce(' · ' || nullif(public.esc_html(d->>'titular'), ''), '') || '<br>' else '' end
      || case when coalesce(d->>'banco', '') <> '' or coalesce(d->>'conta', '') <> '' then public.esc_html(concat_ws(' · ', nullif(d->>'banco', ''),
           'Agência ' || nullif(d->>'agencia', ''), 'Conta ' || nullif(d->>'conta', ''))) || '<br>' else '' end
      || 'Depois de pagar, responda este e-mail com o comprovante.</div>';
  end if;
  return '<div style="font-family:Arial,Helvetica,sans-serif;background:#F0F2F7;padding:24px 12px">'
    || '<div style="max-width:620px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;border:1px solid #E5E7EB">'
    || '<div style="background:#1B2A4A;padding:20px 24px;border-bottom:3px solid #C9A84C">'
    ||   '<div style="color:#C9A84C;font-family:Georgia,serif;font-size:20px;font-weight:bold">Araújo &amp; Castro</div>'
    ||   '<div style="color:#CBD5E1;font-size:11px;letter-spacing:.14em;text-transform:uppercase;margin-top:2px">Advocacia · Contabilidade · Consultoria</div></div>'
    || '<div style="padding:22px 24px;color:#1F2937;font-size:14.5px;line-height:1.6">'
    ||   '<div style="font-size:18px;font-weight:bold;color:#1B2A4A;margin-bottom:10px">' || public.esc_html(p_titulo) || '</div>'
    ||   case when p_nome = '-' then '' else '<p style="margin:0 0 10px">Olá' || coalesce(', ' || public.esc_html(nullif(p_nome, '')), '') || '!</p>' end
    ||   p_texto || itens || pag
    ||   case when p_fecho = '-' then '' else
           coalesce(nullif(p_fecho, ''), '<p style="margin:14px 0 0">Qualquer dúvida, é só responder este e-mail' || case when coalesce(d->>'whatsapp', '') <> '' then ' ou chamar no WhatsApp ' || public.esc_html(d->>'whatsapp') else '' end || '.</p>')
           || '<p style="margin:16px 0 0">Atenciosamente,<br><b>' || public.esc_html(coalesce(nullif(d->>'assinatura', ''), 'Equipe Araújo & Castro')) || '</b></p>' end || '</div>'
    || '<div style="padding:12px 24px;background:#F7F8FB;border-top:1px solid #E5E7EB;color:#6B7280;font-size:11.5px">Mensagem automática do sistema do escritório. Se já resolveu, por favor desconsidere.</div>'
    || '</div></div>';
end $$;
create or replace function public.gerar_mensalidades(p_contrato uuid default null, p_ate date default null) returns int
language plpgsql security definer set search_path = public as $$
declare c public.contratos; comp date; fim date; venc date; g uuid; resp text; n int := 0; k int; sm_falta boolean;
begin
  -- Backup 53: contrato de implantação (sem_financeiro) não gera mensalidades — o financeiro dele já existe
  for c in select * from public.contratos where modalidade = 'consultoria' and status <> 'Aguardando assinatura' and not sem_financeiro and (p_contrato is null or id = p_contrato) loop
    select grupo_id, responsavel into g, resp from public.clientes where id = c.cliente_id;
    if c.rescindido_em is not null then
      delete from public.lancamentos where contrato_id = c.id and chave_recorrencia is not null and not pago
         and competencia >= date_trunc('month', c.rescindido_em)::date;
    end if;
    if c.status in ('Cancelado') then continue; end if;
    comp := date_trunc('month', coalesce(c.inicio_competencia, c.data_contrato))::date;
    fim := date_trunc('month', coalesce(p_ate, (current_date + interval '6 months')::date))::date;
    if c.rescindido_em is not null then fim := least(fim, (date_trunc('month', c.rescindido_em) - interval '1 month')::date); end if;
    while comp <= fim loop
      venc := make_date(extract(year from comp + interval '1 month')::int, extract(month from comp + interval '1 month')::int, c.dia_vencimento);
      sm_falta := c.forma_valor = 'salario_minimo' and not exists (select 1 from public.salarios_minimos where ano = extract(year from comp)::int);
      insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, contrato_id, grupo_id, responsavel, referencia,
                                      competencia, vencimento, valor, chave_recorrencia, obs)
      values ('escritorio', 'receita', c.descricao || ' — competência ' || to_char(comp, 'MM/YYYY'), 'Consultoria mensal', c.cliente_id, c.id, g,
              coalesce(nullif(c.responsavel, ''), resp, ''), to_char(comp, 'MM/YYYY'), comp, venc, greatest(public.valor_competencia(c, comp), 0.01),
              'rec:' || c.id || ':' || to_char(comp, 'YYYY-MM'),
              case when sm_falta then 'Salário mínimo de ' || extract(year from comp)::int || ' ainda não cadastrado: valor provisório, reajusta sozinho.' else '' end)
      on conflict (chave_recorrencia) where chave_recorrencia is not null do nothing;
      get diagnostics k = row_count; n := n + k;
      comp := (comp + interval '1 month')::date;
    end loop;
    update public.lancamentos l set valor = greatest(public.valor_competencia(c, l.competencia), 0.01),
           obs = case when c.forma_valor = 'salario_minimo' and not exists (select 1 from public.salarios_minimos where ano = extract(year from l.competencia)::int)
                      then l.obs else regexp_replace(l.obs, 'Salário mínimo de \d{4} ainda não cadastrado: valor provisório, reajusta sozinho\.', '') end
     where l.contrato_id = c.id and l.chave_recorrencia is not null and not l.pago
       and l.valor is distinct from greatest(public.valor_competencia(c, l.competencia), 0.01);
  end loop;
  return n;
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 30 — Guias: a parcela guarda QUAL e-mail levou a guia (email_ref) e a tela mostra a situação real do e-mail
-- (na fila · retido pela pausa · enviado · erro). Destinatário igual na janela de emissão e no "Enviar por empresa".
-- ═══════════════════════════════════════════════════════════════════
alter table public.parcelas add column if not exists email_ref text not null default '';
alter table public.acordos add column if not exists email_ref text not null default '';

-- para quem vai o e-mail das guias deste cliente/grupo (a tela já mostra preenchido no campo "Para")
create or replace function public.guia_destino(p_cliente uuid, p_grupo uuid, p_tabela text default 'parcelas') returns text
language sql stable security definer set search_path = public as $$
  select case when public.pode('juridico') then
    (select email from public.contato_do_cliente(p_cliente, p_grupo, case when p_tabela = 'acordos' then 'acordo' else 'guia' end) limit 1) end;
$$;
revoke all on function public.guia_destino(uuid, uuid, text) from public, anon;
grant execute on function public.guia_destino(uuid, uuid, text) to authenticated;

create or replace function public.enviar_guias_email(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c record; para text; anexo jsonb; it jsonb; html text; v_conta text; n int := 0; lista jsonb; v_ref text; v_status text; tab text;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if coalesce(jsonb_array_length(p_itens), 0) = 0 then raise exception 'Escolha ao menos uma guia.'; end if;
  tab := coalesce(p_itens->0->>'tabela', 'parcelas');
  if coalesce(trim(p_para), '') <> '' then para := trim(p_para);
  else select * into c from public.contato_do_cliente(p_cliente, p_grupo, case when tab = 'acordos' then 'acordo' else 'guia' end); para := c.email; end if;
  if coalesce(para, '') = '' then raise exception 'Não há e-mail para enviar: digite o e-mail no campo "Para" (ou cadastre em Clientes → ficha → Contatos).'; end if;
  -- os PDFs escolhidos na tela (p_arquivos: [{arquivo, mime, b64}]) NÃO ficam guardados: a função de e-mail apaga o conteúdo assim que o e-mail sai
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'arquivo', 'caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime)), '[]') into lista
    from public.documentos dc where dc.id = any (coalesce(p_docs, '{}'));
  select lista || coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  anexo := case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  html := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-',
    '<p style="margin:0 0 10px">' || replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>') || '</p>', p_itens, false);
  perform set_config('erp.conta_email', '', true);
  v_ref := 'guias:' || gen_random_uuid();
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (auth.uid(), para, coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), html, 'cliente', v_ref, anexo, v_conta)
  returning status into v_status;
  for it in select * from jsonb_array_elements(p_itens) loop
    if it->>'tabela' not in ('parcelas', 'acordos') then continue; end if;
    perform public.registrar_emissao(it->>'tabela', (it->>'id')::uuid, true, null, false);
    if it->>'tabela' = 'parcelas' then update public.parcelas set email_ref = v_ref where id = (it->>'id')::uuid;
    else update public.acordos set email_ref = v_ref where id = (it->>'id')::uuid; end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (case when it->>'tabela' = 'parcelas' then 'email_lp' else 'email_la' end, case when it->>'tabela' = 'parcelas' then 'email_lp:' else 'email_la:' end || (it->>'id'),
            coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento') || ' → ' || para, p_cliente);
    n := n + 1;
  end loop;
  return jsonb_build_object('para', para, 'itens', n, 'anexos', jsonb_array_length(lista), 'conta', v_conta, 'status', v_status, 'ref', v_ref);
end $$;
revoke all on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) from public, anon;
grant execute on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) to authenticated;

-- situação do e-mail de cada parcela: {id: {em, status, para, erro}} — status vem da fila de e-mails
-- (pendente = na fila · retido = pausa ligada · enviado · erro · cancelado = descartado). Sem linha na fila: o registro antigo (enviado).
create or replace function public.emissao_emails(p_tabela text, p_ids uuid[]) returns jsonb
language sql stable security definer set search_path = public as $$
  with alvo as (
    select x.id, coalesce(nullif(case when p_tabela = 'parcelas' then (select email_ref from public.parcelas where id = x.id) else (select email_ref from public.acordos where id = x.id) end, ''),
                          case when p_tabela = 'parcelas' then 'email_lp:' else 'email_la:' end || x.id::text) ref,
           case when p_tabela = 'parcelas' then 'email_lp:' else 'email_la:' end || x.id::text ref_log
      from unnest(p_ids) x(id) where public.pode('juridico')
  ), sit as (
    select a.id, f.criado_em, f.enviado_em, f.status, f.para, f.erro,
           (select max(g.quando) from public.automacoes_log g where g.ref = a.ref_log and g.descricao like '%→%') log_em
      from alvo a left join lateral (select * from public.email_fila e where e.referencia = a.ref order by e.criado_em desc limit 1) f on true
  )
  select coalesce(jsonb_object_agg(id::text, jsonb_build_object('em', coalesce(enviado_em, criado_em, log_em), 'status', coalesce(status, 'enviado'), 'para', coalesce(para, ''), 'erro', coalesce(erro, ''))), '{}'::jsonb)
    from sit where status is not null or log_em is not null;
$$;
revoke all on function public.emissao_emails(text, uuid[]) from public, anon;
grant execute on function public.emissao_emails(text, uuid[]) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 31 — Rotina: "✓ Conferido" (mesmo sem alterar) + última alteração por empresa/parcelamento;
-- parcelamentos: marcar "nós emitimos a guia" por parcelamento ou pelo grupo inteiro
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.rotina_conferencias (
  id bigint generated always as identity primary key,
  area text not null check (area in ('passivo', 'parcelamentos')),
  registro_id uuid not null,
  alterou boolean not null default false,
  usuario_id uuid default auth.uid(),
  quem text not null default '',
  quando timestamptz not null default now()
);
create index if not exists rotina_conferencias_reg on public.rotina_conferencias (area, registro_id, quando desc);
alter table public.rotina_conferencias enable row level security;
revoke all on public.rotina_conferencias from anon;
revoke insert, update, delete on public.rotina_conferencias from authenticated;
grant select on public.rotina_conferencias to authenticated;
drop policy if exists rotina_conferencias_ver on public.rotina_conferencias;
create policy rotina_conferencias_ver on public.rotina_conferencias for select to authenticated using (public.eh_equipe());

-- registra que a pessoa foi até a linha (alterou = salvou mudança; false = conferiu e o dado continua certo)
create or replace function public.conferir_rotina(p_area text, p_ids uuid[], p_alterou boolean default false) returns int
language plpgsql security definer set search_path = public as $$
declare quem text; n int;
begin
  if p_area = 'passivo' and not public.pode('clientes', 'editar') then raise exception 'permission denied: sem acesso para conferir o passivo.'; end if;
  if p_area = 'parcelamentos' and not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para conferir parcelamentos.'; end if;
  if p_area not in ('passivo', 'parcelamentos') then raise exception 'Área inválida.'; end if;
  select coalesce(nullif(nome, ''), email, '') into quem from public.perfis where id = auth.uid();
  insert into public.rotina_conferencias (area, registro_id, alterou, quem)
  select p_area, x, coalesce(p_alterou, false), coalesce(quem, '') from unnest(coalesce(p_ids, '{}')) x;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.conferir_rotina(text, uuid[], boolean) from public, anon;
grant execute on function public.conferir_rotina(text, uuid[], boolean) to authenticated;

-- por linha: quando foi conferida por último (e por quem, e se mudou algo) e quando o dado mudou por último (histórico)
create or replace function public.rotina_situacao(p_area text)
returns table (registro_id uuid, conferido_em timestamptz, conferido_por text, conferido_alterou boolean, alterado_em timestamptz, alterado_por text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.eh_equipe() then raise exception 'permission denied'; end if;
  return query
  with conf as (
    select distinct on (c.registro_id) c.registro_id, c.quando, c.quem, c.alterou
      from public.rotina_conferencias c where c.area = p_area order by c.registro_id, c.quando desc
  ), alt as (
    select distinct on (h.registro_id) h.registro_id, h.quando, coalesce(nullif(pf.nome, ''), pf.email, '') quem
      from public.historico h left join public.perfis pf on pf.id = h.usuario
     where h.acao = 'UPDATE' and h.tabela = case when p_area = 'passivo' then 'clientes' else 'parcelamentos' end
       and (p_area <> 'passivo' or exists (select 1 from unnest(array['rfb','rfb_negociada','pgfn','pgfn_negociada','age_mg','age_mg_negociada','sefaz_mg','ceat_trt3','em_operacao','procuracao','certificado','capag']) k
                                            where (h.antes->k) is distinct from (h.depois->k)))
     order by h.registro_id, h.quando desc
  )
  select coalesce(conf.registro_id, alt.registro_id), conf.quando, conf.quem, conf.alterou, alt.quando, alt.quem
    from conf full join alt on alt.registro_id = conf.registro_id;
end $$;
revoke all on function public.rotina_situacao(text) from public, anon;
grant execute on function public.rotina_situacao(text) to authenticated;

-- "nós emitimos a guia?" para vários parcelamentos de uma vez (um parcelamento ou o grupo inteiro)
create or replace function public.parcelamentos_emitimos(p_ids uuid[], p_emitimos boolean) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para alterar parcelamentos.'; end if;
  update public.parcelamentos set emitimos_guia = coalesce(p_emitimos, true) where id = any (coalesce(p_ids, '{}')) and emitimos_guia is distinct from coalesce(p_emitimos, true);
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.parcelamentos_emitimos(uuid[], boolean) from public, anon;
grant execute on function public.parcelamentos_emitimos(uuid[], boolean) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 32 — Central de Documentos (sistema à parte em /documentos): procuração, substabelecimento, contrato de honorários,
-- recibo, declaração e acordo. Guarda o que foi preenchido (para reabrir/duplicar) e o texto final; numeração por tipo e ano.
-- ═══════════════════════════════════════════════════════════════════
create table if not exists public.documentos_gerados (
  id uuid primary key default gen_random_uuid(),
  modelo text not null,
  numero text not null default '',
  titulo text not null default '',
  cliente_id uuid references public.clientes(id) on delete set null,
  grupo_id uuid references public.grupos(id) on delete set null,
  dados jsonb not null default '{}',
  html text not null default '',
  editado boolean not null default false,
  criado_por uuid default auth.uid(),
  autor text not null default '',
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists documentos_gerados_cli on public.documentos_gerados (cliente_id, criado_em desc);
create index if not exists documentos_gerados_mod on public.documentos_gerados (modelo, criado_em desc);
alter table public.documentos_gerados enable row level security;
revoke all on public.documentos_gerados from anon;
grant select, insert, update, delete on public.documentos_gerados to authenticated;
drop policy if exists documentos_gerados_ver on public.documentos_gerados;
create policy documentos_gerados_ver on public.documentos_gerados for select to authenticated using (public.eh_equipe());
drop policy if exists documentos_gerados_criar on public.documentos_gerados;
create policy documentos_gerados_criar on public.documentos_gerados for insert to authenticated with check (public.eh_equipe());
drop policy if exists documentos_gerados_editar on public.documentos_gerados;
create policy documentos_gerados_editar on public.documentos_gerados for update to authenticated using (public.eh_equipe()) with check (public.eh_equipe());
drop policy if exists documentos_gerados_apagar on public.documentos_gerados;
create policy documentos_gerados_apagar on public.documentos_gerados for delete to authenticated using (public.eh_admin() or criado_por = auth.uid());
create or replace function public.documentos_gerados_carimbo() returns trigger language plpgsql set search_path = public as $$
begin
  new.atualizado_em := now();
  if tg_op = 'INSERT' and coalesce(new.autor, '') = '' then
    select coalesce(nullif(nome, ''), email, '') into new.autor from public.perfis where id = auth.uid();
  end if;
  return new;
end $$;
drop trigger if exists documentos_gerados_carimbo on public.documentos_gerados;
create trigger documentos_gerados_carimbo before insert or update on public.documentos_gerados for each row execute function public.documentos_gerados_carimbo();

-- numeração por tipo e ano (REC 2026/0001): só avança quando o documento é salvo
create table if not exists public.documentos_numeracao (
  modelo text not null, ano int not null, ultimo int not null default 0, primary key (modelo, ano));
alter table public.documentos_numeracao enable row level security;
revoke all on public.documentos_numeracao from anon, authenticated;
grant select on public.documentos_numeracao to authenticated;          -- leitura (o backup lê todas as tabelas); gravar, só pela função
drop policy if exists documentos_numeracao_ver on public.documentos_numeracao;
create policy documentos_numeracao_ver on public.documentos_numeracao for select to authenticated using (public.eh_equipe());
create or replace function public.proximo_numero_documento(p_modelo text) returns text
language plpgsql security definer set search_path = public as $$
declare a int := extract(year from now())::int; n int;
begin
  if not public.eh_equipe() then raise exception 'permission denied'; end if;
  insert into public.documentos_numeracao (modelo, ano, ultimo) values (p_modelo, a, 1)
  on conflict (modelo, ano) do update set ultimo = public.documentos_numeracao.ultimo + 1
  returning ultimo into n;
  return a || '/' || lpad(n::text, 4, '0');
end $$;
revoke all on function public.proximo_numero_documento(text) from public, anon;
grant execute on function public.proximo_numero_documento(text) to authenticated;

-- advogados e dados do escritório usados nos documentos (editáveis na Central de Documentos → Escritório)
insert into public.configuracoes (chave, valor) values ('documentos_escritorio', jsonb_build_object(
  'cidade', 'Santo Antônio do Monte/MG',
  'foro', 'Santo Antônio do Monte/MG',
  'email', 'araujocastroadvocacia@gmail.com',
  'advogados', jsonb_build_array(
    jsonb_build_object('id', 'pedro', 'nome', 'Pedro Henrique de Oliveira Castro', 'oab', 'OAB/MG 228.471', 'nacionalidade', 'brasileiro', 'estado_civil', '', 'genero', 'm',
      'endereco', 'Rua Araucária, n. 231, Coronel Luciano, Lagoa da Prata/MG, CEP 35.591-218', 'telefone', '(37) 99868-4323', 'email', 'araujocastroadvocacia@gmail.com', 'cpf', '', 'pix', '', 'banco', ''),
    jsonb_build_object('id', 'emanuelle', 'nome', 'Emanuelle Oliveira Araujo', 'oab', 'OAB/MG 240.369', 'nacionalidade', 'brasileira', 'estado_civil', '', 'genero', 'f',
      'endereco', 'Rua Sebastião Gontijo, n. 66, Centro, Santo Antônio do Monte/MG, CEP 35.560-000', 'telefone', '(37) 99856-4020', 'email', 'araujocastroadvocacia@gmail.com', 'cpf', '', 'pix', '', 'banco', ''),
    jsonb_build_object('id', 'adriana', 'nome', 'Adriana Fátima Araujo Borges', 'oab', 'OAB/MG 123.438', 'nacionalidade', 'brasileira', 'estado_civil', '', 'genero', 'f',
      'endereco', 'Rua Sebastião Gontijo, n. 66, Centro, Santo Antônio do Monte/MG, CEP 35.560-000', 'telefone', '(37) 99828-9996', 'email', 'araujocastroadvocacia@gmail.com', 'cpf', '', 'pix', '', 'banco', ''))))
on conflict (chave) do nothing;
create or replace function public.salvar_documentos_escritorio(p jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador altera os dados do escritório.'; end if;
  insert into public.configuracoes (chave, valor) values ('documentos_escritorio', p) on conflict (chave) do update set valor = excluded.valor;
end $$;
revoke all on function public.salvar_documentos_escritorio(jsonb) from public, anon;
grant execute on function public.salvar_documentos_escritorio(jsonb) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 33 — Guias vencidas: reenviar a mesma parcela com nova data e valor atualizado (SELIC do órgão) e guardar o histórico;
-- e-mails em modo de teste (uma vez); alertas de conferência da Rotina; evolução do passivo
-- ═══════════════════════════════════════════════════════════════════
alter table public.parcelas add column if not exists reenvio_em timestamptz;
alter table public.parcelas add column if not exists reenvio_venc date;
alter table public.parcelas add column if not exists reenvio_valor numeric(14,2);
alter table public.parcelas add column if not exists reenvios int not null default 0;
alter table public.acordos add column if not exists reenvio_em timestamptz;
alter table public.acordos add column if not exists reenvio_venc date;
alter table public.acordos add column if not exists reenvio_valor numeric(14,2);
alter table public.acordos add column if not exists reenvios int not null default 0;

create or replace function public.enviar_guias_email(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c record; para text; anexo jsonb; it jsonb; html text; v_conta text; n int := 0; lista jsonb; v_ref text; v_status text; tab text;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if coalesce(jsonb_array_length(p_itens), 0) = 0 then raise exception 'Escolha ao menos uma guia.'; end if;
  tab := coalesce(p_itens->0->>'tabela', 'parcelas');
  if coalesce(trim(p_para), '') <> '' then para := trim(p_para);
  else select * into c from public.contato_do_cliente(p_cliente, p_grupo, case when tab = 'acordos' then 'acordo' else 'guia' end); para := c.email; end if;
  if coalesce(para, '') = '' then raise exception 'Não há e-mail para enviar: digite o e-mail no campo "Para" (ou cadastre em Clientes → ficha → Contatos).'; end if;
  -- os PDFs escolhidos na tela (p_arquivos: [{arquivo, mime, b64}]) NÃO ficam guardados: a função de e-mail apaga o conteúdo assim que o e-mail sai
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'arquivo', 'caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime)), '[]') into lista
    from public.documentos dc where dc.id = any (coalesce(p_docs, '{}'));
  select lista || coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  anexo := case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  html := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-',
    '<p style="margin:0 0 10px">' || replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>') || '</p>', p_itens, false);
  perform set_config('erp.conta_email', '', true);
  v_ref := 'guias:' || gen_random_uuid();
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (auth.uid(), para, coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), html, 'cliente', v_ref, anexo, v_conta)
  returning status into v_status;
  for it in select * from jsonb_array_elements(p_itens) loop
    if it->>'tabela' not in ('parcelas', 'acordos') then continue; end if;
    perform public.registrar_emissao(it->>'tabela', (it->>'id')::uuid, true, null, false);
    if it->>'tabela' = 'parcelas' then update public.parcelas set email_ref = v_ref where id = (it->>'id')::uuid;
    else update public.acordos set email_ref = v_ref where id = (it->>'id')::uuid; end if;
    -- Backup 33: reenvio da guia de parcela vencida (nova data e valor atualizado pelo órgão, com SELIC)
    if coalesce(it->>'reenvio', '') = 'true' then
      if it->>'tabela' = 'parcelas' then
        update public.parcelas set reenvio_em = now(), reenvio_venc = nullif(it->>'vencimento', '')::date, reenvio_valor = nullif(it->>'valor', '')::numeric, reenvios = coalesce(reenvios, 0) + 1 where id = (it->>'id')::uuid;
      else
        update public.acordos set reenvio_em = now(), reenvio_venc = nullif(it->>'vencimento', '')::date, reenvio_valor = nullif(it->>'valor', '')::numeric, reenvios = coalesce(reenvios, 0) + 1 where id = (it->>'id')::uuid;
      end if;
    end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (case when it->>'tabela' = 'parcelas' then 'email_lp' else 'email_la' end, case when it->>'tabela' = 'parcelas' then 'email_lp:' else 'email_la:' end || (it->>'id'),
            coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento') || ' → ' || para, p_cliente);
    n := n + 1;
  end loop;
  return jsonb_build_object('para', para, 'itens', n, 'anexos', jsonb_array_length(lista), 'conta', v_conta, 'status', v_status, 'ref', v_ref);
end $$;
revoke all on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) from public, anon;
grant execute on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) to authenticated;

-- ── Backup 33: alertas da conferência da Rotina — lembra o estagiário (o que passou do prazo sem conferir) e o responsável por ele
-- (resumo da semana: quantas conferências, por quem, e o que segue atrasado). Uma tarefa por semana para cada um (a chave tem a semana).
insert into public.regras_tarefas (chave, nome, descricao, ligada, dias, grupo) values
  ('rotina_conferir', 'Rotina: lembrar de conferir', 'Toda semana, se houver empresa (passivo), processo ou parcelamento sem conferência há mais de N dias, cria tarefa para quem faz a Rotina (escolha a pessoa em "Responsável")', true, 15, 'tarefas'),
  ('rotina_supervisao', 'Rotina: responsável confere o estagiário', 'Toda semana cria uma tarefa para o responsável verificar a Rotina: quantas conferências foram feitas na semana, por quem, e o que segue atrasado (escolha a pessoa em "Responsável")', true, 7, 'tarefas')
on conflict (chave) do nothing;
create or replace function public.rodar_regras_rotina() returns int
language plpgsql security definer set search_path = public as $$
declare rg record; n int := 0; semana text := to_char(current_date, 'IYYY-IW'); c_pas int; c_par int; c_pro int; feitas int; quem text;
begin
  select * into rg from public.regras_tarefas where chave = 'rotina_conferir' and ligada;
  if found then
    select count(*) into c_pas from public.clientes cl where coalesce(cl.tipo, '') <> 'Inativo'
       and not exists (select 1 from public.rotina_conferencias r where r.area = 'passivo' and r.registro_id = cl.id and r.quando > now() - make_interval(days => rg.dias));
    select count(*) into c_par from public.parcelamentos pa where exists (select 1 from public.parcelas x where x.parcelamento_id = pa.id and not x.pago)
       and not exists (select 1 from public.rotina_conferencias r where r.area = 'parcelamentos' and r.registro_id = pa.id and r.quando > now() - make_interval(days => rg.dias));
    select count(*) into c_pro from public.processos pr where coalesce(pr.carteira, '') <> 'Prospecção' and coalesce(pr.status, '') !~* 'arquiv|extint|prescrit'
       and (pr.ultima_movimentacao_em is null or pr.ultima_movimentacao_em < current_date - rg.dias);
    if c_pas + c_par + c_pro > 0 and public.tarefa_da_regra('rot-conf:' || semana,
         'Conferir a Rotina: ' || concat_ws(' · ', case when c_pas > 0 then c_pas || ' empresa(s) do passivo' end, case when c_pro > 0 then c_pro || ' processo(s)' end,
           case when c_par > 0 then c_par || ' parcelamento(s)' end) || ' sem conferência há mais de ' || rg.dias || ' dias',
         rg.responsavel, public.somar_uteis(current_date, 2), null, null, null,
         jsonb_build_array(jsonb_build_object('texto', 'Passivo e cadastro: ' || c_pas || ' empresa(s) — clique ✓ em cada uma depois de conferir', 'feito', c_pas = 0),
                           jsonb_build_object('texto', 'Processos: ' || c_pro || ' — "✓ Sem novidade" ou "+ Registrar"', 'feito', c_pro = 0),
                           jsonb_build_object('texto', 'Controle dos parcelamentos: ' || c_par || ' — ✓ na coluna Conferência', 'feito', c_par = 0)),
         'Menu Rotina. O que passou de ' || rg.dias || ' dias sem conferir fica amarelo; mais de 30, vermelho.') then n := n + 1; end if;
  end if;
  select * into rg from public.regras_tarefas where chave = 'rotina_supervisao' and ligada;
  if found then
    select count(*), string_agg(distinct nullif(r.quem, ''), ', ') into feitas, quem from public.rotina_conferencias r where r.quando > now() - make_interval(days => rg.dias);
    select count(*) into c_pas from public.clientes cl where coalesce(cl.tipo, '') <> 'Inativo'
       and not exists (select 1 from public.rotina_conferencias r where r.area = 'passivo' and r.registro_id = cl.id and r.quando > now() - interval '30 days');
    if public.tarefa_da_regra('rot-sup:' || semana, 'Verificar a Rotina da semana: ' || feitas || ' conferência(s)' || coalesce(' por ' || quem, '') ||
           case when c_pas > 0 then ' · ' || c_pas || ' empresa(s) há mais de 30 dias sem conferir' else '' end,
         rg.responsavel, public.somar_uteis(current_date, 3), null, null, null, '[]'::jsonb,
         'Abra o menu Rotina: a coluna "Conferência" mostra quem conferiu e quando (✓ = conferiu sem mudar; ✎ = alterou). Vermelho = mais de 30 dias.') then n := n + 1; end if;
  end if;
  return n;
end $$;
revoke all on function public.rodar_regras_rotina() from public, anon, authenticated;
create or replace function public.rodar_regras_extras() returns int
language plpgsql security definer set search_path = public as $$
declare rg record; x record; n int := 0;
begin
  select * into rg from public.regras_tarefas where chave = 'crm_parada' and ligada;
  if found then
    for x in select o.id, o.titulo, o.responsavel, o.cliente_id, o.etapa_id, e.nome etapa, e.dias_alerta
               from public.crm_oportunidades o join public.crm_etapas e on e.id = o.etapa_id
              where e.final = '' and e.dias_alerta is not null and o.etapa_desde < now() - make_interval(days => e.dias_alerta) loop
      if public.tarefa_da_regra('crm-parada:' || x.id || ':' || x.etapa_id, 'CRM parado há mais de ' || x.dias_alerta || ' dia(s) em "' || x.etapa || '" — ' || x.titulo,
           x.responsavel, public.somar_uteis(current_date, 1), x.cliente_id, null, null, '[]'::jsonb, 'Avance a oportunidade no CRM ou registre o próximo passo.') then n := n + 1; end if;
    end loop;
  end if;
  select * into rg from public.regras_tarefas where chave = 'crm_followup' and ligada;
  if found then
    for x in select pr.id, pr.titulo, pr.versao, o.titulo op, o.responsavel, o.cliente_id from public.crm_propostas pr join public.crm_oportunidades o on o.id = pr.oportunidade_id
               join public.crm_etapas e on e.id = o.etapa_id
              where pr.status = 'enviada' and pr.enviada_em < now() - make_interval(days => rg.dias) and e.final = '' loop
      if public.tarefa_da_regra('crm-follow:' || x.id, 'Follow-up da proposta — ' || x.op, x.responsavel, current_date, x.cliente_id, null, null, '[]'::jsonb,
           'Proposta v' || x.versao || ' enviada há mais de ' || rg.dias || ' dias sem resposta. Na ficha da oportunidade: "✉ Follow-up" envia o e-mail pronto.') then n := n + 1; end if;
    end loop;
  end if;
  n := n + public.rodar_regras_rotina();   -- Backup 33: lembretes de conferência da Rotina
  return n;
end $$;
revoke all on function public.rodar_regras_extras() from public, anon, authenticated;

-- ── Backup 33: e-mails em MODO TESTE (uma vez só). Pausa todos os e-mails, deixa passar apenas pedromgsam@gmail.com e desliga as
-- rotinas de e-mail ao cliente. As regras que estavam ligadas ficam guardadas em configuracoes.b33_modo_teste_emails (para religar depois:
-- Automações → ligar uma a uma, ou rodar o update do comentário abaixo). Rodar o SQL de novo NÃO repete (a marca já existe).
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'b33_modo_teste_emails') then
    insert into public.configuracoes (chave, valor)
      select 'b33_modo_teste_emails', coalesce(jsonb_agg(chave), '[]'::jsonb) from public.regras_tarefas where grupo = 'cliente_email' and ligada;
    update public.regras_tarefas set ligada = false, atualizado_em = now() where grupo = 'cliente_email' and ligada;
    insert into public.configuracoes (chave, valor) values ('emails_pausados', 'true'::jsonb) on conflict (chave) do update set valor = 'true'::jsonb;
    insert into public.configuracoes (chave, valor) values ('emails_teste', '"pedromgsam@gmail.com"'::jsonb) on conflict (chave) do update set valor = excluded.valor;
  end if;
end $$;
-- Para voltar ao normal depois dos testes:
--   update public.regras_tarefas set ligada = true where chave in (select jsonb_array_elements_text(valor) from public.configuracoes where chave = 'b33_modo_teste_emails');
--   e em E-mails → desligar a pausa.

-- ── Backup 33: evolução do passivo mês a mês (gráfico de linhas do Painel). Reconstrói o valor de cada empresa no fim de cada mês
-- a partir do histórico de alterações: o valor no fim do mês = o "antes" da primeira alteração depois daquele dia (sem alteração = valor de hoje).
create or replace function public.passivo_json(j jsonb) returns numeric language sql immutable as $$
  select coalesce((j->>'rfb')::numeric,0) + coalesce((j->>'rfb_negociada')::numeric,0) + coalesce((j->>'pgfn')::numeric,0) + coalesce((j->>'pgfn_negociada')::numeric,0)
       + coalesce((j->>'sefaz_mg')::numeric,0) + coalesce((j->>'age_mg')::numeric,0) + coalesce((j->>'age_mg_negociada')::numeric,0) $$;
create or replace function public.evolucao_passivo(p_grupo uuid default null, p_meses int default 12)
returns table (mes date, cliente_id uuid, cliente text, grupo_id uuid, grupo text, total numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.eh_equipe() and (public.pode('clientes') or public.pode('relatorios') or public.pode('juridico'))) then
    raise exception 'permission denied: sem acesso ao passivo.'; end if;
  return query
  with meses as (
    select (date_trunc('month', current_date) - make_interval(months => k))::date as m,
           least(now(), (date_trunc('month', current_date) - make_interval(months => k - 1))) as corte
      from generate_series(0, least(greatest(coalesce(p_meses, 12), 2), 60) - 1) k
  )
  select ms.m, c.id, c.nome, g.id, g.nome,
         coalesce((select public.passivo_json(h.antes) from public.historico h
                              where h.tabela = 'clientes' and h.acao = 'UPDATE' and h.registro_id = c.id and h.quando > ms.corte
                                and public.passivo_json(h.antes) is distinct from public.passivo_json(h.depois)
                              order by h.quando limit 1), public.passivo_do_cliente(c))
    from public.clientes c
    join public.grupos g on g.id = c.grupo_id
    cross join meses ms
   where coalesce(c.tipo, '') <> 'Inativo' and (p_grupo is null or c.grupo_id = p_grupo)
   order by 1, 5, 3;
end $$;
revoke all on function public.evolucao_passivo(uuid, int) from public, anon;
grant execute on function public.evolucao_passivo(uuid, int) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 34 — guias saem de Parcelamentos/Acordos e passam a ser emitidas pela Rotina (controle por mês: emissão e pagamento).
-- parcelas.valor = valor lançado daquela parcela (vazio = vale o último lançado antes dela; sem nenhum = valor_ultima_parcela).
-- ═══════════════════════════════════════════════════════════════════
alter table public.parcelas add column if not exists valor numeric(14,2);
create or replace function public.enviar_guias_email(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c record; para text; anexo jsonb; it jsonb; html text; v_conta text; n int := 0; lista jsonb; v_ref text; v_status text; tab text;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if coalesce(jsonb_array_length(p_itens), 0) = 0 then raise exception 'Escolha ao menos uma guia.'; end if;
  tab := coalesce(p_itens->0->>'tabela', 'parcelas');
  if coalesce(trim(p_para), '') <> '' then para := trim(p_para);
  else select * into c from public.contato_do_cliente(p_cliente, p_grupo, case when tab = 'acordos' then 'acordo' else 'guia' end); para := c.email; end if;
  if coalesce(para, '') = '' then raise exception 'Não há e-mail para enviar: digite o e-mail no campo "Para" (ou cadastre em Clientes → ficha → Contatos).'; end if;
  -- os PDFs escolhidos na tela (p_arquivos: [{arquivo, mime, b64}]) NÃO ficam guardados: a função de e-mail apaga o conteúdo assim que o e-mail sai
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'arquivo', 'caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime)), '[]') into lista
    from public.documentos dc where dc.id = any (coalesce(p_docs, '{}'));
  select lista || coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  anexo := case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  html := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-',
    '<p style="margin:0 0 10px">' || replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>') || '</p>', p_itens, false);
  perform set_config('erp.conta_email', '', true);
  v_ref := 'guias:' || gen_random_uuid();
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (auth.uid(), para, coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), html, 'cliente', v_ref, anexo, v_conta)
  returning status into v_status;
  for it in select * from jsonb_array_elements(p_itens) loop
    if it->>'tabela' not in ('parcelas', 'acordos') then continue; end if;
    perform public.registrar_emissao(it->>'tabela', (it->>'id')::uuid, true, null, false);
    if it->>'tabela' = 'parcelas' then update public.parcelas set email_ref = v_ref where id = (it->>'id')::uuid;
    else update public.acordos set email_ref = v_ref where id = (it->>'id')::uuid; end if;
    -- Backup 34: o valor digitado no envio é o "valor lançado" da parcela (a Rotina e a Situação usam; os meses seguintes herdam o último lançado)
    if it->>'tabela' = 'parcelas' and coalesce(it->>'reenvio', '') <> 'true' and coalesce(nullif(it->>'valor', '')::numeric, 0) > 0 then
      update public.parcelas set valor = (it->>'valor')::numeric where id = (it->>'id')::uuid;
      update public.parcelamentos pa set valor_ultima_parcela = x.valor
        from (select p2.parcelamento_id, p2.valor from public.parcelas p2
               where p2.parcelamento_id = (select parcelamento_id from public.parcelas where id = (it->>'id')::uuid) and p2.valor is not null
               order by p2.vencimento desc nulls last limit 1) x
       where pa.id = x.parcelamento_id;
    end if;
    -- Backup 33: reenvio da guia de parcela vencida (nova data e valor atualizado pelo órgão, com SELIC)
    if coalesce(it->>'reenvio', '') = 'true' then
      if it->>'tabela' = 'parcelas' then
        update public.parcelas set reenvio_em = now(), reenvio_venc = nullif(it->>'vencimento', '')::date, reenvio_valor = nullif(it->>'valor', '')::numeric, reenvios = coalesce(reenvios, 0) + 1 where id = (it->>'id')::uuid;
      else
        update public.acordos set reenvio_em = now(), reenvio_venc = nullif(it->>'vencimento', '')::date, reenvio_valor = nullif(it->>'valor', '')::numeric, reenvios = coalesce(reenvios, 0) + 1 where id = (it->>'id')::uuid;
      end if;
    end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (case when it->>'tabela' = 'parcelas' then 'email_lp' else 'email_la' end, case when it->>'tabela' = 'parcelas' then 'email_lp:' else 'email_la:' end || (it->>'id'),
            coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento') || ' → ' || para, p_cliente);
    n := n + 1;
  end loop;
  return jsonb_build_object('para', para, 'itens', n, 'anexos', jsonb_array_length(lista), 'conta', v_conta, 'status', v_status, 'ref', v_ref);
end $$;
revoke all on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) from public, anon;
grant execute on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) to authenticated;

-- valor lançado direto na Rotina (sem enviar e-mail)
create or replace function public.lancar_valor_parcela(p_id uuid, p_valor numeric) returns void
language plpgsql security definer set search_path = public as $$
declare v_pa uuid;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para alterar parcelas.'; end if;
  update public.parcelas set valor = case when coalesce(p_valor, 0) > 0 then round(p_valor, 2) end, atualizado_em = now() where id = p_id returning parcelamento_id into v_pa;
  if v_pa is null then raise exception 'Parcela não encontrada.'; end if;
  update public.parcelamentos pa set valor_ultima_parcela = x.valor, atualizado_em = now()
    from (select valor from public.parcelas where parcelamento_id = v_pa and valor is not null order by vencimento desc nulls last limit 1) x
   where pa.id = v_pa;
end $$;
revoke all on function public.lancar_valor_parcela(uuid, numeric) from public, anon;
grant execute on function public.lancar_valor_parcela(uuid, numeric) to authenticated;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 35 — Processos: data da última atualização do VALOR DA CAUSA (diferente da última movimentação)
-- ═══════════════════════════════════════════════════════════════════
alter table public.processos add column if not exists valor_em date;
update public.processos p set valor_em = m.data
  from (select distinct on (processo_id) processo_id, data from public.processo_movimentacoes where tipo = 'valor' order by processo_id, data desc) m
 where m.processo_id = p.id and p.valor_em is null;
create or replace function public.processo_valor_em() returns trigger
language plpgsql as $$
begin
  if tg_op = 'INSERT' then
    if new.valor is not null and new.valor_em is null then new.valor_em := current_date; end if;
  elsif new.valor is distinct from old.valor and new.valor_em is not distinct from old.valor_em then
    new.valor_em := current_date;
  end if;
  return new;
end $$;
drop trigger if exists processo_valor_em on public.processos;
create trigger processo_valor_em before insert or update of valor on public.processos for each row execute function public.processo_valor_em();
-- a movimentação "Mudança de valor" grava a data dela como a data do valor
create or replace function public.processo_mov_aplica() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.quem, '') = '' then select coalesce(nullif(nome, ''), email) into new.quem from public.perfis where id = auth.uid(); new.quem := coalesce(new.quem, ''); end if;
  update public.processos set
    ultima_movimentacao = case when new.tipo = 'sem_novidade' then coalesce(nullif(ultima_movimentacao, ''), 'Conferido: sem novidade') else left(new.descricao, 500) end,
    ultima_movimentacao_em = greatest(coalesce(ultima_movimentacao_em, new.data), new.data),
    atualizacao = new.data,
    valor = case when new.tipo = 'valor' and new.valor_novo is not null then new.valor_novo else valor end,
    valor_em = case when new.tipo = 'valor' and new.valor_novo is not null then new.data else valor_em end,
    procuracao = case when new.tipo = 'procuracao' then true else procuracao end
   where id = new.processo_id;
  return new;
end $$;

-- ═══════════════════════════════════════════════════════════════════
-- Backup 36 — Evolução do passivo: antes de a empresa ter o passivo lançado pela primeira vez, o mês fica SEM VALOR (null) e não "zero"
-- (era isso que fazia a linha cair a 0 nos meses antigos: o cadastro existia, mas o passivo ainda não tinha sido digitado).
-- ═══════════════════════════════════════════════════════════════════
create or replace function public.evolucao_passivo(p_grupo uuid default null, p_meses int default 12)
returns table (mes date, cliente_id uuid, cliente text, grupo_id uuid, grupo text, total numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.eh_equipe() and (public.pode('clientes') or public.pode('relatorios') or public.pode('juridico'))) then
    raise exception 'permission denied: sem acesso ao passivo.'; end if;
  return query
  with meses as (
    select (date_trunc('month', current_date) - make_interval(months => k))::date as m,
           least(now(), (date_trunc('month', current_date) - make_interval(months => k - 1))) as corte
      from generate_series(0, least(greatest(coalesce(p_meses, 12), 2), 60) - 1) k
  ), primeiro as (
    -- quando o passivo apareceu pela primeira vez (inclusão já com valor ou a primeira alteração que deixou o total > 0)
    select h.registro_id, min(h.quando) as quando from public.historico h
     where h.tabela = 'clientes' and h.acao in ('INSERT', 'UPDATE') and public.passivo_json(h.depois) > 0
       and (h.acao = 'INSERT' or public.passivo_json(h.antes) = 0)
     group by h.registro_id
  )
  select ms.m, c.id, c.nome, g.id, g.nome,
         case when pr.quando is not null and pr.quando > ms.corte then null
              else coalesce((select public.passivo_json(h.antes) from public.historico h
                              where h.tabela = 'clientes' and h.acao = 'UPDATE' and h.registro_id = c.id and h.quando > ms.corte
                                and public.passivo_json(h.antes) is distinct from public.passivo_json(h.depois)
                              order by h.quando limit 1), public.passivo_do_cliente(c)) end
    from public.clientes c
    join public.grupos g on g.id = c.grupo_id
    cross join meses ms
    left join primeiro pr on pr.registro_id = c.id
   where coalesce(c.tipo, '') <> 'Inativo' and (p_grupo is null or c.grupo_id = p_grupo)
   order by 1, 5, 3;
end $$;
revoke all on function public.evolucao_passivo(uuid, int) from public, anon;
grant execute on function public.evolucao_passivo(uuid, int) to authenticated;
-- Backup 36: prévia do e-mail das guias/boletos exatamente como o cliente recebe (mesmo HTML do envio)
create or replace function public.previa_guias_email(p_cliente uuid, p_itens jsonb, p_assunto text, p_texto text) returns text
language plpgsql stable security definer set search_path = public as $$
declare h text; v_conta text;
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso.'; end if;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  h := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-',
    '<p style="margin:0 0 10px">' || replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>') || '</p>', p_itens, false);
  perform set_config('erp.conta_email', '', true);
  return h;
end $$;
revoke all on function public.previa_guias_email(uuid, jsonb, text, text) from public, anon;
grant execute on function public.previa_guias_email(uuid, jsonb, text, text) to authenticated;
-- Backup 36: compromissos na agenda do Início (reunião, audiência, compromisso, ligação) — ficam em tarefas, com tipo e hora
alter table public.tarefas add column if not exists tipo_agenda text not null default '';
alter table public.tarefas add column if not exists hora time;
alter table public.tarefas add column if not exists local text not null default '';

-- ═══════════════════════════════════════════════════════════════════
-- Backup 37 — acordos com forma de pagamento (boleto ou PIX), e-mail das guias no padrão "Honorários em aberto",
-- certificado digital (arquivo + senha + validade lida do arquivo) e a busca de publicações pela web registrada
-- ═══════════════════════════════════════════════════════════════════
alter table public.acordos add column if not exists forma_pagamento text not null default 'boleto';
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'acordos_forma_pagamento_check') then
    alter table public.acordos add constraint acordos_forma_pagamento_check check (forma_pagamento in ('boleto', 'pix'));
  end if;
end $$;
-- mudar a forma numa parcela muda o acordo inteiro (mesmo processo, devedor e credor); parcela nova herda a forma do acordo
create or replace function public.acordo_forma_propaga() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if pg_trigger_depth() > 1 then return new; end if;
  if tg_op = 'INSERT' then
    select a.forma_pagamento into new.forma_pagamento from public.acordos a
     where a.id <> new.id and coalesce(a.processo, '') = coalesce(new.processo, '') and coalesce(a.devedor, '') = coalesce(new.devedor, '') and coalesce(a.credor, '') = coalesce(new.credor, '')
       and a.forma_pagamento <> 'boleto' limit 1;
    new.forma_pagamento := coalesce(new.forma_pagamento, 'boleto');
  end if;
  return new;
end $$;
drop trigger if exists acordo_forma_propaga on public.acordos;
create trigger acordo_forma_propaga before insert on public.acordos for each row execute function public.acordo_forma_propaga();
create or replace function public.acordo_forma_propaga_depois() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if pg_trigger_depth() > 1 or new.forma_pagamento is not distinct from old.forma_pagamento then return null; end if;
  update public.acordos set forma_pagamento = new.forma_pagamento
   where id <> new.id and coalesce(processo, '') = coalesce(new.processo, '') and coalesce(devedor, '') = coalesce(new.devedor, '') and coalesce(credor, '') = coalesce(new.credor, '');
  return null;
end $$;
drop trigger if exists acordo_forma_propaga_depois on public.acordos;
create trigger acordo_forma_propaga_depois after update of forma_pagamento on public.acordos for each row execute function public.acordo_forma_propaga_depois();

-- texto do e-mail das guias: parágrafos (linha em branco = parágrafo novo) e, se algum item tem PIX, o quadro "Como pagar"
create or replace function public.guias_texto_html(p_texto text, p_itens jsonb) returns text
language plpgsql immutable set search_path = public as $$
declare h text; pix text;
begin
  h := '<p style="margin:0 0 10px">' || replace(replace(public.esc_html(btrim(coalesce(p_texto, ''))), E'\n\n', '</p><p style="margin:0 0 10px">'), E'\n', '<br>') || '</p>';
  select string_agg(distinct 'PIX: <b>' || public.esc_html(i->>'pix') || '</b>' || coalesce(' · ' || nullif(public.esc_html(i->>'banco'), ''), ''), '<br>') into pix
    from jsonb_array_elements(coalesce(p_itens, '[]')) i where coalesce(i->>'pix', '') <> '';
  if pix is not null then
    h := h || '<div style="background:#F5EDD6;border-left:4px solid #C9A84C;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13.5px"><b style="color:#1B2A4A">Como pagar</b><br>'
      || pix || '<br>Depois de pagar, responda este e-mail com o comprovante.</div>';
  end if;
  return h;
end $$;

create or replace function public.enviar_guias_email(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare c record; para text; anexo jsonb; it jsonb; html text; v_conta text; n int := 0; lista jsonb; v_ref text; v_status text; tab text;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if coalesce(jsonb_array_length(p_itens), 0) = 0 then raise exception 'Escolha ao menos uma guia.'; end if;
  tab := coalesce(p_itens->0->>'tabela', 'parcelas');
  if coalesce(trim(p_para), '') <> '' then para := trim(p_para);
  else select * into c from public.contato_do_cliente(p_cliente, p_grupo, case when tab = 'acordos' then 'acordo' else 'guia' end); para := c.email; end if;
  if coalesce(para, '') = '' then raise exception 'Não há e-mail para enviar: digite o e-mail no campo "Para" (ou cadastre em Clientes → ficha → Contatos).'; end if;
  -- os PDFs escolhidos na tela (p_arquivos: [{arquivo, mime, b64}]) NÃO ficam guardados: a função de e-mail apaga o conteúdo assim que o e-mail sai
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'arquivo', 'caminho', dc.caminho, 'arquivo', dc.nome, 'mime', dc.mime)), '[]') into lista
    from public.documentos dc where dc.id = any (coalesce(p_docs, '{}'));
  select lista || coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  anexo := case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  -- Backup 37: o mesmo desenho do e-mail "Honorários em aberto" (parágrafos, tabela e o quadro "Como pagar" quando há PIX)
  html := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-', public.guias_texto_html(p_texto, p_itens), p_itens, false);
  perform set_config('erp.conta_email', '', true);
  v_ref := 'guias:' || gen_random_uuid();
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta)
  values (auth.uid(), para, coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), html, 'cliente', v_ref, anexo, v_conta)
  returning status into v_status;
  for it in select * from jsonb_array_elements(p_itens) loop
    if it->>'tabela' not in ('parcelas', 'acordos') then continue; end if;
    perform public.registrar_emissao(it->>'tabela', (it->>'id')::uuid, true, null, false);
    if it->>'tabela' = 'parcelas' then update public.parcelas set email_ref = v_ref where id = (it->>'id')::uuid;
    else update public.acordos set email_ref = v_ref where id = (it->>'id')::uuid; end if;
    -- Backup 34: o valor digitado no envio é o "valor lançado" da parcela (a Rotina e a Situação usam; os meses seguintes herdam o último lançado)
    if it->>'tabela' = 'parcelas' and coalesce(it->>'reenvio', '') <> 'true' and coalesce(nullif(it->>'valor', '')::numeric, 0) > 0 then
      update public.parcelas set valor = (it->>'valor')::numeric where id = (it->>'id')::uuid;
      update public.parcelamentos pa set valor_ultima_parcela = x.valor
        from (select p2.parcelamento_id, p2.valor from public.parcelas p2
               where p2.parcelamento_id = (select parcelamento_id from public.parcelas where id = (it->>'id')::uuid) and p2.valor is not null
               order by p2.vencimento desc nulls last limit 1) x
       where pa.id = x.parcelamento_id;
    end if;
    -- Backup 33: reenvio da guia de parcela vencida (nova data e valor atualizado pelo órgão, com SELIC)
    if coalesce(it->>'reenvio', '') = 'true' then
      if it->>'tabela' = 'parcelas' then
        update public.parcelas set reenvio_em = now(), reenvio_venc = nullif(it->>'vencimento', '')::date, reenvio_valor = nullif(it->>'valor', '')::numeric, reenvios = coalesce(reenvios, 0) + 1 where id = (it->>'id')::uuid;
      else
        update public.acordos set reenvio_em = now(), reenvio_venc = nullif(it->>'vencimento', '')::date, reenvio_valor = nullif(it->>'valor', '')::numeric, reenvios = coalesce(reenvios, 0) + 1 where id = (it->>'id')::uuid;
      end if;
    end if;
    insert into public.automacoes_log (chave, ref, descricao, cliente_id)
    values (case when it->>'tabela' = 'parcelas' then 'email_lp' else 'email_la' end, case when it->>'tabela' = 'parcelas' then 'email_lp:' else 'email_la:' end || (it->>'id'),
            coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento') || ' → ' || para, p_cliente);
    n := n + 1;
  end loop;
  return jsonb_build_object('para', para, 'itens', n, 'anexos', jsonb_array_length(lista), 'conta', v_conta, 'status', v_status, 'ref', v_ref);
end $$;
revoke all on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) from public, anon;
grant execute on function public.enviar_guias_email(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) to authenticated;
create or replace function public.previa_guias_email(p_cliente uuid, p_itens jsonb, p_assunto text, p_texto text) returns text
language plpgsql stable security definer set search_path = public as $$
declare h text; v_conta text;
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso.'; end if;
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  h := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias para pagamento'), '-', public.guias_texto_html(p_texto, p_itens), p_itens, false);
  perform set_config('erp.conta_email', '', true);
  return h;
end $$;

-- certificado digital: o arquivo (.pfx) fica em Documentos (tipo "certificado"); a senha e a validade lida do arquivo ficam aqui
alter table public.cliente_certificado add column if not exists documento_id uuid references public.documentos(id) on delete set null;
alter table public.cliente_certificado add column if not exists titular text not null default '';
alter table public.cliente_certificado add column if not exists emissor text not null default '';

-- a busca de publicações feita pelo navegador (web) fica registrada como a do servidor (Alertas → Rotinas)
create or replace function public.registrar_busca_publicacoes(p_lidas int, p_novas int, p_erros jsonb default '[]') returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso.'; end if;
  insert into public.configuracoes (chave, valor) values ('publicacoes_ultima', jsonb_build_object('quando', now(), 'lidas', coalesce(p_lidas, 0), 'novas', coalesce(p_novas, 0),
    'erros', coalesce(p_erros, '[]'), 'via', 'web'))
  on conflict (chave) do update set valor = excluded.valor;
end $$;
revoke all on function public.registrar_busca_publicacoes(int, int, jsonb) from public, anon;
grant execute on function public.registrar_busca_publicacoes(int, int, jsonb) to authenticated;
-- data do pagamento da parcela do parcelamento (a planilha da Rotina mostra a data; a baixa preenche sozinha com hoje)
alter table public.parcelas add column if not exists data_pagamento date;
create or replace function public.parcela_data_pagamento() returns trigger
language plpgsql set search_path = public as $$
begin
  if new.pago and not coalesce(old.pago, false) and new.data_pagamento is null then new.data_pagamento := current_date; end if;
  if not new.pago then new.data_pagamento := null; end if;
  return new;
end $$;
drop trigger if exists parcela_data_pagamento on public.parcelas;
create trigger parcela_data_pagamento before update of pago on public.parcelas for each row execute function public.parcela_data_pagamento();

-- ═══════════════════════════════ Backup 38 ═══════════════════════════════
-- 1) Tarefas: só as que a equipe lança. Tarefa automática (com chave de regra: documento vencendo, publicação, CRM parado,
--    conferência da rotina…) não é mais criada. Reunião marcada pela própria equipe (chave "reuniao:") continua.
--    Para voltar: update configuracoes set valor = 'true' where chave = 'tarefas_automaticas';
insert into public.configuracoes (chave, valor) values ('tarefas_automaticas', 'false'::jsonb) on conflict (chave) do nothing;
create or replace function public.tarefa_so_manual() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.chave_regra is not null and new.chave_regra not like 'reuniao:%'
     and coalesce((select valor from public.configuracoes where chave = 'tarefas_automaticas'), 'false'::jsonb) <> 'true'::jsonb then
    return null;   -- não grava (sem erro): a regra segue rodando para e-mails e alertas, só não vira tarefa
  end if;
  return new;
end $$;
drop trigger if exists tarefa_so_manual on public.tarefas;
create trigger tarefa_so_manual before insert on public.tarefas for each row execute function public.tarefa_so_manual();
-- uma vez só: as tarefas automáticas que estavam abertas são canceladas (continuam no histórico; dá para reabrir)
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'b38_tarefas_auto') then
    update public.tarefas set status = 'cancelada'
     where chave_regra is not null and chave_regra not like 'reuniao:%' and status not in ('concluida', 'cancelada');
    insert into public.configuracoes (chave, valor) values ('b38_tarefas_auto', to_jsonb(now()));
  end if;
end $$;

-- 2) E-mails: módulo fora da tela; até segunda ordem TODO e-mail vai para um endereço só (configuracoes.email_redirecionar).
--    O destinatário original fica em email_fila.para_original e aparece no assunto: "[para fulano@cliente.com] …".
--    Para voltar ao normal: update configuracoes set valor = '""' where chave = 'email_redirecionar';
alter table public.email_fila add column if not exists para_original text not null default '';
insert into public.configuracoes (chave, valor) values ('email_redirecionar', '"pedromgsam@gmail.com"'::jsonb) on conflict (chave) do nothing;
create or replace function public.email_fila_redirecionar() returns trigger language plpgsql security definer set search_path = public as $$
declare alvo text := btrim(coalesce((select valor #>> '{}' from public.configuracoes where chave = 'email_redirecionar'), ''));
begin
  if alvo <> '' and lower(btrim(coalesce(new.para, ''))) <> lower(alvo) then
    new.para_original := coalesce(new.para, '');
    new.para := alvo;
    new.assunto := '[para ' || left(new.para_original, 120) || '] ' || coalesce(new.assunto, '');
  end if;
  return new;
end $$;
-- o nome começa com "d" para rodar ANTES do email_fila_reter (os gatilhos rodam em ordem alfabética): o endereço único é de teste, não fica retido
drop trigger if exists email_fila_redirecionar on public.email_fila;
drop trigger if exists email_fila_desviar on public.email_fila;
create trigger email_fila_desviar before insert on public.email_fila for each row execute function public.email_fila_redirecionar();

-- ═══════════════════════════════ Backup 39 ═══════════════════════════════
-- Agenda: "com quem" em texto livre quando a reunião não é com um cliente cadastrado
alter table public.tarefas add column if not exists com_quem text not null default '';

-- ═══════════════════════════════ Backup 40 ═══════════════════════════════
-- Agenda: horário de fim (sem sobreposição), aviso antes do compromisso e "Ligação" sai dos tipos
alter table public.tarefas add column if not exists hora_fim time;
alter table public.tarefas add column if not exists aviso_min int;
alter table public.tarefas add column if not exists aviso_em timestamptz;
update public.tarefas set tipo_agenda = 'compromisso' where tipo_agenda = 'ligacao';
-- aviso: notificação para o responsável e cada participante (a notificação já vira e-mail para a pessoa)
create or replace function public.avisos_agenda() returns int
language plpgsql security definer set search_path = public as $$
declare t record; pnome text; uid uuid; n int := 0; ini timestamptz; rot text;
begin
  for t in select * from public.tarefas
            where aviso_min is not null and aviso_em is null and prazo is not null
              and status not in ('concluida', 'cancelada') and prazo between current_date - 1 and current_date + 3 loop
    ini := ((t.prazo + coalesce(t.hora, time '08:00')) at time zone 'America/Sao_Paulo');
    continue when ini - make_interval(mins => t.aviso_min) > now() or ini < now() - interval '1 hour';
    rot := case t.tipo_agenda when 'reuniao' then 'Reunião' when 'audiencia' then 'Audiência' when 'compromisso' then 'Compromisso' else 'Tarefa' end;
    for pnome in select distinct lower(split_part(btrim(x), ' ', 1)) from unnest(array[t.responsavel] || string_to_array(coalesce(t.participantes, ''), ',')) x where btrim(coalesce(x, '')) <> '' loop
      uid := (select p.id from public.perfis p where p.papel in ('admin', 'equipe') and lower(split_part(btrim(p.nome), ' ', 1)) = pnome limit 1);
      if uid is not null then
        insert into public.notificacoes (usuario_id, tipo, titulo, detalhe)
        values (uid, 'agenda', '🔔 ' || rot || ' ' || to_char(t.prazo, 'DD/MM') || coalesce(' às ' || to_char(t.hora, 'HH24:MI'), '') || ': ' || t.titulo,
                concat_ws(' · ', nullif(coalesce(t.local, ''), ''), nullif(coalesce(t.processos_vinculados, ''), '')));
        n := n + 1;
      end if;
    end loop;
    update public.tarefas set aviso_em = now() where id = t.id;
  end loop;
  return n;
end $$;
revoke all on function public.avisos_agenda() from public, anon, authenticated;
-- se mudar dia, hora ou antecedência, o aviso volta a valer
create or replace function public.tarefa_aviso_reset() returns trigger language plpgsql as $$
begin
  if new.prazo is distinct from old.prazo or new.hora is distinct from old.hora or new.aviso_min is distinct from old.aviso_min then new.aviso_em := null; end if;
  return new;
end $$;
drop trigger if exists tarefa_aviso_reset on public.tarefas;
create trigger tarefa_aviso_reset before update on public.tarefas for each row execute function public.tarefa_aviso_reset();
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_avisos_agenda';
  perform cron.schedule('erp_avisos_agenda', '*/5 * * * *', 'select public.avisos_agenda()');
exception when others then
  raise notice 'Agendador indisponível: os avisos da agenda aparecem só na tela de quem está com o ERP aberto.';
end $$;
-- Conciliação de extrato (OFX) saiu do sistema: a tabela de controle dos créditos já tratados não é mais usada
drop table if exists public.extrato_itens;
-- Documentos: "Arquivar" virou "Excluir" (com confirmação na tela) — quem edita Documentos pode apagar o registro e o arquivo
drop policy if exists documentos_excluir on public.documentos;
create policy documentos_excluir on public.documentos for delete to authenticated
  using (public.pode('documentos','editar') or (oportunidade_id is not null and public.pode('crm','editar')));
do $$
begin
  if exists (select 1 from information_schema.schemata where schema_name = 'storage') then
    execute 'drop policy if exists documentos_apagar on storage.objects';
    execute 'create policy documentos_apagar on storage.objects for delete to authenticated using (bucket_id = ''documentos'' and public.pode(''documentos'',''editar''))';
  end if;
exception when others then
  raise notice 'Sem permissão em storage.objects: só o administrador apaga o arquivo; o registro sai da lista mesmo assim.';
end $$;
-- CRM: proposta "simplificada" (texto curto, como sempre foi) ou "completa" (detalha o serviço — escopo, fases, prazo, documentos)
alter table public.crm_modelos_proposta add column if not exists texto_completo text not null default '';
alter table public.crm_propostas add column if not exists texto_completo text not null default '';
alter table public.crm_propostas add column if not exists formato text not null default 'simplificada';
-- modelo de Holding: versão completa a partir do material de apresentação do escritório (só preenche se estiver vazio)
update public.crm_modelos_proposta set texto_completo = $h$
<h3>1. Por que uma holding</h3>
<p>Todo patrimônio enfrenta quatro problemas: o <b>inventário</b> (anos de processo, com ITCMD, custas e honorários de uma vez, no fim), o <b>imposto sobre a renda dos bens</b> (aluguel na pessoa física é tributado em até 27,5%), o <b>risco de perder o patrimônio</b> (dívida da operação alcança os bens do mesmo CNPJ) e a <b>falta de um comando</b> (patrimônio espalhado em vários nomes e empresas). A holding é uma empresa criada para ser, estrategicamente, a dona do patrimônio — e é essa titularidade que resolve os quatro.</p>
<h3>2. As quatro finalidades</h3>
<ul>
<li><b>Sucessão</b> — transferência das quotas aos herdeiros em vida, com os instituidores mantendo o controle e a renda (usufruto vitalício, administração reservada, incomunicabilidade e reversão).</li>
<li><b>Tributária</b> — o aluguel passa a ser recebido pela empresa, com carga de 11,33% a 14,53% sobre a receita, no lugar de até 27,5% do IRPF; e, para empresas do Lucro Real, vira despesa dedutível.</li>
<li><b>Proteção</b> — o que corre risco fica separado do que é patrimônio; o contrato traz cláusulas que impedem a venda ou a partilha indesejada.</li>
<li><b>Controle familiar</b> — uma controladora centraliza a decisão: um só contrato define quem administra e o que ninguém pode fazer sozinho.</li>
</ul>
<h3>3. O que está incluído — as cinco fases</h3>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:6px 0 14px">
<tr><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff;width:26%">Fase</th><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff">O que fazemos</th></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>1. Estudo</b><br><span style="color:#6B7280">sem custo</span></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Levantamento dos bens, do regime das empresas e do objetivo dos sócios; simulação da carga tributária e do custo de cada etapa; parecer dizendo se compensa.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>2. Constituição</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Contrato social com as regras acordadas; registro na Junta Comercial e CNPJ; indicação da contabilidade; abertura da conta bancária da holding.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>3. Patrimônio</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Integralização dos bens no capital social; recolhimento do ITBI ou pedido de imunidade; transferência nas matrículas (Cartório de Registro de Imóveis) e dos veículos e maquinário nos órgãos competentes.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>4. Operacionalização</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Contratos de locação de imóveis, veículos, maquinário, marca e propriedade industrial, a valor de mercado; controle contábil e fiscal das locações; distribuição de lucros e pró-labore.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>5. Manutenção</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Transferência das quotas aos beneficiários, com usufruto e cláusulas; atos societários do exercício; revisão periódica da estrutura e das regras.</td></tr>
</table>
<h3>4. O que não está incluído</h3>
<ul>
<li>ITBI, ITCMD, emolumentos de cartório, taxas da Junta Comercial e laudos de avaliação exigidos pelo Município — pagos diretamente pelo cliente.</li>
<li>Contabilidade mensal da holding (pode ser contratada à parte).</li>
<li>Defesa em processos ou execuções já existentes.</li>
</ul>
<h3>5. Prazo</h3>
<p>Cerca de <b>dez semanas</b>, do primeiro documento recebido até o último bem registrado em nome da holding: estudo (semanas 1–2), contrato e registro (3–5), transferência dos bens (5–9), quotas e ajustes (9–10). Os prazos variam conforme a entrega dos documentos, a exigência de laudo pelo Município e a fila dos cartórios.</p>
<h3>6. Documentos que vamos pedir</h3>
<ul>
<li><b>De cada pessoa:</b> identidade e CPF dos sócios; certidão de casamento e pacto antenupcial, se houver; comprovante de endereço; declarações de Imposto de Renda dos cinco últimos anos.</li>
<li><b>Do patrimônio:</b> matrículas atualizadas de cada imóvel; IPTU ou ITR com o valor venal; contrato social das empresas do grupo; relação dos demais bens a integralizar.</li>
<li><b>Da regularidade:</b> certidões negativas federal, estadual e municipal; certidões de distribuição cível e trabalhista dos sócios; certidão de ônus reais de cada matrícula.</li>
</ul>
<h3>7. Com franqueza</h3>
<p>A holding <b>não apaga dívida que já existe</b> (transferir bens para fugir de credor é fraude), <b>não isenta do ITCMD</b> (muda o momento e o planejamento), não compensa em todo caso (fora do Lucro Real a parte tributária costuma não fechar) e não é "montar e esquecer": é uma empresa, com contabilidade e obrigações mensais. Quando o caso não comporta holding, dizemos isso antes de qualquer contratação.</p>
<h3>8. Quem conduz</h3>
<p><b>Pedro Castro</b> (tributário) · <b>Emanuelle Araújo</b> (imobiliário e empresarial) · <b>Adriana Araújo</b> (sucessório) — áreas tributária, societária e imobiliária num único time, que é o que uma holding exige.</p>
$h$
where nome = 'Holding e planejamento patrimonial' and coalesce(texto_completo, '') = '';
update public.crm_modelos_proposta
   set itens = '[{"servico":"Estudo de viabilidade e planejamento","valor":0,"forma":"sem custo — antes da contratação"},{"servico":"Constituição da holding (contrato social, Junta e CNPJ)","valor":0,"forma":"na assinatura"},{"servico":"Integralização e transferência dos bens","valor":0,"forma":"por bem integralizado"},{"servico":"Operacionalização (contratos de locação) e doação de quotas","valor":0,"forma":"na conclusão"}]'::jsonb
 where nome = 'Holding e planejamento patrimonial'
   and itens = '[{"servico":"Estudo e planejamento","valor":0,"forma":"na assinatura"},{"servico":"Constituição e integralização","valor":0,"forma":"na conclusão"}]'::jsonb;

-- ═══════════════════════════════ Backup 41 ═══════════════════════════════
-- Aprovação de rascunho removida: quem estava em "Rascunho" passa a "Editar" (Jurídico/Clientes/Contratos/Tarefas) ou "Ver" (financeiro)
update public.perfis set funcoes = (select coalesce(jsonb_object_agg(k, case when v = '"propor"'::jsonb then (case when k like 'financeiro%' then '"ver"' else '"editar"' end)::jsonb else v end), '{}'::jsonb) from jsonb_each(funcoes) e(k, v))
 where funcoes::text like '%"propor"%';
update public.usuarios_previstos set funcoes = (select coalesce(jsonb_object_agg(k, case when v = '"propor"'::jsonb then (case when k like 'financeiro%' then '"ver"' else '"editar"' end)::jsonb else v end), '{}'::jsonb) from jsonb_each(funcoes) e(k, v)),
       modelo = replace(modelo, 'Estagiário (rascunho)', 'Estagiário')
 where funcoes::text like '%"propor"%';
drop function if exists public.propor_alteracao(text, text, jsonb, jsonb, text);
drop function if exists public.aprovar_rascunho(uuid);
drop function if exists public.recusar_rascunho(uuid, text);
drop function if exists public.rascunho_where(text, jsonb);
drop function if exists public.rascunho_na_area(text, jsonb, jsonb);
drop function if exists public.avisar_aprovadores(text, text, text);
drop function if exists public.funcao_da_tabela(text, text);
drop table if exists public.rascunhos;
-- PGFN pela API do SERPRO (e a importação dos dados abertos) removidas; os valores de PGFN do passivo continuam em clientes
do $$ begin perform cron.unschedule(jobid) from cron.job where jobname in ('erp_pgfn', 'erp_fotos_mensais'); exception when others then null; end $$;
drop function if exists public.salvar_config_pgfn(jsonb);
drop function if exists public.status_config_pgfn();
drop function if exists public.pgfn_importar_abertos(jsonb, text);
drop table if exists public.pgfn_inscricoes;
drop table if exists public.pgfn_execucoes;
delete from public.config_privada where chave = 'api_pgfn';
delete from public.configuracoes where chave = 'pgfn_abertos_ultima';
-- "Fotos mensais" removidas (eram cópias dos valores do passivo no dia 1 de cada mês); a evolução usa o histórico de alterações
drop function if exists public.tirar_fotos_mensais(date);
drop function if exists public.foto_do_grupo(uuid);
drop table if exists public.fotos_mensais;
-- CRM: todos os modelos de proposta com a versão "Completa" (só preenche quando o detalhamento está vazio — não apaga o que o escritório já escreveu)
update public.crm_modelos_proposta m set texto_completo = v.t
  from (values
  ('Consultoria tributária mensal', $c$
<h3>1. O objetivo</h3>
<p>Ter um time tributário acompanhando a empresa todo mês: o passivo fiscal sob controle, as obrigações em dia e uma resposta rápida sempre que surgir uma dúvida, uma notificação ou uma oportunidade de economia.</p>
<h3>2. O que está incluído</h3>
<ul>
<li><b>Acompanhamento do passivo</b> — conferência mensal dos débitos na Receita Federal, PGFN, Estado e Município, com o relatório da situação de cada empresa do grupo.</li>
<li><b>Parcelamentos em dia</b> — controle das parcelas e das guias, com aviso antes do vencimento.</li>
<li><b>Certidões</b> — emissão e acompanhamento das certidões negativas (ou positivas com efeito de negativa).</li>
<li><b>Dúvidas do dia a dia</b> — atendimento por e-mail, telefone ou WhatsApp sobre tributação de operações, notas, contratos e mudanças na lei.</li>
<li><b>Notificações e intimações</b> — análise e orientação sobre a resposta, com prazo.</li>
<li><b>Reunião periódica</b> — apresentação da situação fiscal e das oportunidades encontradas.</li>
</ul>
<h3>3. O que não está incluído</h3>
<ul>
<li>Defesa em processos administrativos ou judiciais e execuções fiscais (contratadas à parte, com proposta própria).</li>
<li>Contabilidade e folha de pagamento.</li>
<li>Taxas, tributos e custas, pagos diretamente pela empresa.</li>
</ul>
<h3>4. Prazo e vigência</h3>
<p>Contrato mensal, por prazo indeterminado, com reajuste anual. Pode ser encerrado por qualquer das partes com aviso prévio de 30 dias.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Procuração eletrônica (e-CAC) e acesso aos portais do Estado e do Município.</li>
<li>Contrato social atualizado e certificado digital da empresa.</li>
<li>Últimas declarações entregues e a relação dos parcelamentos em andamento.</li>
</ul>
<h3>6. Com franqueza</h3>
<p>Consultoria não substitui a contabilidade: depende das informações que a empresa e o contador nos passam. Quanto antes a dúvida chega, mais barata é a solução.</p>
$c$),
  ('Defesa em execução fiscal', $c$
<h3>1. O objetivo</h3>
<p>Defender a empresa (e os sócios, quando incluídos) na execução fiscal, buscando reduzir ou extinguir a cobrança e proteger o patrimônio e as contas contra bloqueios.</p>
<h3>2. O que está incluído</h3>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:6px 0 14px">
<tr><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff;width:26%">Etapa</th><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff">O que fazemos</th></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>1. Análise</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Leitura do processo e da CDA; conferência de prescrição, decadência, nulidades e erros de cálculo; estratégia definida com o cliente.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>2. Defesa</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Exceção de pré-executividade ou embargos à execução, conforme o caso; pedidos para liberar valores bloqueados quando cabível.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>3. Acompanhamento</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Manifestações, audiências e despachos até a decisão de primeira instância, com aviso ao cliente a cada movimentação importante.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>4. Alternativas</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Quando for melhor negociar, simulação de transação ou parcelamento para encerrar a cobrança.</td></tr>
</table>
<h3>3. O que não está incluído</h3>
<ul>
<li>Recursos ao Tribunal e aos Tribunais Superiores (proposta à parte, se necessários).</li>
<li>Custas, garantia do juízo (depósito, seguro ou fiança) e perícias.</li>
</ul>
<h3>4. Prazo</h3>
<p>A defesa é apresentada dentro do prazo legal contado da citação ou da garantia. A duração do processo depende do Judiciário e costuma levar de meses a alguns anos.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Cópia da citação ou do bloqueio e o número do processo.</li>
<li>Contrato social, documentos dos sócios e procuração.</li>
<li>Declarações e comprovantes de pagamento do período cobrado.</li>
</ul>
<h3>6. Com franqueza</h3>
<p>Nem toda execução tem defesa: quando o débito é devido e não há falha na cobrança, dizemos isso e indicamos o caminho mais barato para encerrar (transação ou parcelamento).</p>
$c$),
  ('Parcelamento / transação tributária', $c$
<h3>1. O objetivo</h3>
<p>Regularizar os débitos da empresa pela modalidade que mais reduz o valor e cabe no caixa, e voltar a ter certidão para operar, contratar e participar de licitações.</p>
<h3>2. O que está incluído</h3>
<ul>
<li><b>Levantamento</b> — todos os débitos na Receita Federal, PGFN, Estado e Município, por empresa do grupo.</li>
<li><b>Simulação</b> — comparativo das modalidades abertas (parcelamento comum, transação por adesão, transação individual), com descontos, entrada e valor das parcelas.</li>
<li><b>Adesão</b> — pedido no portal do órgão e emissão das primeiras guias.</li>
<li><b>Certidão</b> — emissão da certidão positiva com efeito de negativa depois da adesão.</li>
</ul>
<h3>3. O que não está incluído</h3>
<ul>
<li>Emissão mensal das guias depois da adesão (pode ser feita na consultoria mensal).</li>
<li>Defesa judicial ou administrativa dos débitos.</li>
</ul>
<h3>4. Prazo</h3>
<p>Cerca de <b>duas a três semanas</b> do recebimento dos acessos até a adesão, dependendo da abertura das modalidades e da quantidade de órgãos envolvidos.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Procuração eletrônica (e-CAC) e certificado digital.</li>
<li>Acesso aos portais do Estado e do Município.</li>
<li>Demonstrativos de faturamento recentes (exigidos em algumas transações).</li>
</ul>
<h3>6. Com franqueza</h3>
<p>Atrasar parcelas pode levar à exclusão do acordo e à volta da cobrança integral. O parcelamento só resolve se couber no caixa — por isso simulamos antes de aderir.</p>
$c$),
  ('Planejamento tributário', $c$
<h3>1. O objetivo</h3>
<p>Descobrir qual regime e qual organização da empresa pagam menos tributo dentro da lei, com segurança, e implantar a mudança sem sobressaltos.</p>
<h3>2. O que está incluído</h3>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:6px 0 14px">
<tr><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff;width:26%">Fase</th><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff">O que fazemos</th></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>1. Diagnóstico</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Levantamento do faturamento, folha, despesas e operações dos últimos 12 meses; leitura do regime atual.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>2. Simulação</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Comparativo entre Simples Nacional, Lucro Presumido e Lucro Real, com a economia estimada em reais e os riscos de cada um.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>3. Recomendação</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Relatório final com o caminho indicado e o passo a passo; reunião de apresentação dos resultados.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>4. Implantação</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Orientação ao contador e acompanhamento da mudança no início do exercício.</td></tr>
</table>
<h3>3. O que não está incluído</h3>
<ul>
<li>Contabilidade e entrega das obrigações mensais.</li>
<li>Alterações societárias, reorganizações e holding (proposta à parte, se recomendadas).</li>
</ul>
<h3>4. Prazo</h3>
<p>Cerca de <b>quatro semanas</b> a partir do recebimento dos dados. A troca de regime, em regra, só vale a partir de janeiro — por isso o ideal é começar no segundo semestre.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Balancetes ou DRE dos últimos 12 meses e as últimas declarações entregues.</li>
<li>Relatório de faturamento por produto/serviço e resumo da folha.</li>
<li>Contrato social atualizado.</li>
</ul>
<h3>6. Com franqueza</h3>
<p>Às vezes o regime atual já é o melhor — e isso também é resultado: a empresa passa a ter certeza de que não paga a mais.</p>
$c$),
  ('Inventário e planejamento sucessório', $c$
<h3>1. O objetivo</h3>
<p>Concluir a partilha dos bens com o menor custo e no menor prazo possível, e orientar a família para que a próxima sucessão seja mais simples.</p>
<h3>2. O que está incluído</h3>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:6px 0 14px">
<tr><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff;width:26%">Etapa</th><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff">O que fazemos</th></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>1. Levantamento</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Bens, dívidas, herdeiros e documentos; definição do caminho — extrajudicial (cartório, mais rápido, quando todos concordam) ou judicial.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>2. Imposto</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Declaração e cálculo do ITCD, emissão das guias e conferência dos valores atribuídos aos bens.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>3. Partilha</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Minuta da partilha, acompanhamento no cartório ou no processo até a escritura ou o formal de partilha.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>4. Registro</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Orientação para o registro dos imóveis, a transferência de veículos e a liberação de saldos bancários.</td></tr>
</table>
<h3>3. O que não está incluído</h3>
<ul>
<li>ITCD, emolumentos de cartório, custas judiciais, certidões e avaliações — pagos diretamente pelos herdeiros.</li>
<li>Disputas entre herdeiros que exijam ações próprias (proposta à parte).</li>
</ul>
<h3>4. Prazo</h3>
<p>No cartório, cerca de <b>dois a quatro meses</b> depois de reunidos os documentos; no Judiciário, depende do andamento do processo. Atenção à multa do ITCD quando o inventário não é aberto no prazo legal.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Certidão de óbito; documentos pessoais, certidões de casamento ou nascimento de todos os herdeiros.</li>
<li>Matrículas atualizadas dos imóveis, documentos dos veículos, extratos bancários e de investimentos na data do óbito.</li>
<li>Certidões negativas de débitos em nome do falecido.</li>
</ul>
<h3>6. Com franqueza</h3>
<p>O inventário extrajudicial só é possível quando todos os herdeiros concordam. Planejar a sucessão em vida (doação com reserva de usufruto ou holding) costuma sair mais barato do que o inventário.</p>
$c$),
  ('Defesa trabalhista', $c$
<h3>1. O objetivo</h3>
<p>Defender a empresa na reclamação trabalhista, reduzir o risco de condenação e, quando for vantajoso, buscar um acordo em bases justas.</p>
<h3>2. O que está incluído</h3>
<ul>
<li><b>Análise</b> — leitura da inicial, dos documentos do contrato de trabalho e estimativa do risco por pedido.</li>
<li><b>Contestação</b> — elaboração da defesa com os documentos e a indicação das testemunhas.</li>
<li><b>Audiências</b> — preparo do preposto e das testemunhas; participação nas audiências de conciliação e de instrução.</li>
<li><b>Acordo</b> — negociação quando o cálculo mostrar que é a melhor saída.</li>
<li><b>Acompanhamento</b> — até a sentença de primeira instância, com aviso a cada movimentação importante.</li>
</ul>
<h3>3. O que não está incluído</h3>
<ul>
<li>Recursos ao Tribunal Regional e ao TST (proposta à parte, se necessários).</li>
<li>Depósito recursal, custas, perícias e cálculos de liquidação por contador.</li>
</ul>
<h3>4. Prazo</h3>
<p>A defesa é entregue até a audiência inicial. Na primeira instância, o processo costuma durar de seis meses a um ano.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Contrato de trabalho, fichas de registro, holerites e recibos de férias e 13º.</li>
<li>Controles de ponto, termo de rescisão e comprovantes de pagamento.</li>
<li>Contrato social e carta de preposição.</li>
</ul>
<h3>6. Com franqueza</h3>
<p>Na Justiça do Trabalho, o documento que a empresa não tem costuma pesar contra ela. Quanto mais completa a documentação, melhor a defesa.</p>
$c$),
  ('Abertura e regularização de empresa', $c$
<h3>1. O objetivo</h3>
<p>Colocar a empresa para funcionar (ou deixá-la em ordem) com o tipo societário e o regime tributário certos desde o início, evitando custo e retrabalho depois.</p>
<h3>2. O que está incluído</h3>
<table style="width:100%;border-collapse:collapse;font-size:13px;margin:6px 0 14px">
<tr><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff;width:26%">Etapa</th><th style="text-align:left;padding:8px 10px;background:#1B2A4A;color:#fff">O que fazemos</th></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>1. Planejamento</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">Escolha do tipo societário, das atividades (CNAE) e do regime tributário; regras entre os sócios.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>2. Contrato</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Elaboração do contrato social (ou da alteração) e registro na Junta Comercial.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB"><b>3. Inscrições</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB">CNPJ, inscrição estadual e municipal, alvará e licenças necessárias à atividade.</td></tr>
<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC"><b>4. Regularização</b></td><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;background:#F8FAFC">Para empresas já abertas: conferência de pendências cadastrais e fiscais e o plano para resolvê-las.</td></tr>
</table>
<h3>3. O que não está incluído</h3>
<ul>
<li>Taxas da Junta, da Prefeitura e de licenças; certificado digital.</li>
<li>Contabilidade mensal e parcelamento de débitos antigos (propostas à parte).</li>
</ul>
<h3>4. Prazo</h3>
<p>Em geral, <b>duas a quatro semanas</b>, conforme a exigência de licenças e a fila dos órgãos.</p>
<h3>5. Documentos que vamos pedir</h3>
<ul>
<li>Documentos pessoais e comprovante de endereço dos sócios.</li>
<li>Endereço da empresa com o IPTU ou contrato de locação.</li>
<li>Para regularização: contrato social atual, CNPJ e acessos aos portais.</li>
</ul>
<h3>6. Com franqueza</h3>
<p>O regime escolhido na abertura define quanto a empresa vai pagar de tributo no primeiro ano — vale decidir com os números na mesa.</p>
$c$)
  ) v(n, t)
 where m.nome = v.n and coalesce(m.texto_completo, '') = '';

-- ═══════════════════════════════ Backup 42 ═══════════════════════════════
-- E-mails funcionando: todo e-mail já vai só para pedromgsam@gmail.com (email_redirecionar), então a pausa do Backup 19/33 sai.
-- Uma vez só: desliga a pausa e descarta os e-mails antigos que estavam retidos (não saem de uma vez para ninguém).
do $$
begin
  if not exists (select 1 from public.configuracoes where chave = 'b42_emails') then
    insert into public.configuracoes (chave, valor) values ('b42_emails', 'true'::jsonb);
    insert into public.configuracoes (chave, valor) values ('emails_pausados', 'false'::jsonb) on conflict (chave) do update set valor = 'false'::jsonb;
    update public.email_fila set status = 'cancelado', erro = 'Descartado no Backup 42 (estava retido pela pausa antiga).' where status = 'retido';
    insert into public.configuracoes (chave, valor) values ('email_redirecionar', '"pedromgsam@gmail.com"'::jsonb)
      on conflict (chave) do update set valor = '"pedromgsam@gmail.com"'::jsonb;
  end if;
end $$;
-- diagnóstico do e-mail (Administração → E-mail): o que falta para o e-mail sair, em linguagem simples
create or replace function public.diagnostico_email() returns jsonb
language plpgsql security definer set search_path = public as $$
declare c jsonb; v_cron boolean := false; v_net boolean; u record;
begin
  if not public.eh_admin() then raise exception 'Só o administrador.'; end if;
  select valor into c from public.config_privada where chave = 'email';
  v_net := exists (select 1 from pg_extension where extname = 'pg_net');
  begin execute 'select exists (select 1 from cron.job where jobname = ''erp_enviar_emails'' and active)' into v_cron; exception when others then v_cron := false; end;
  select status, erro, criado_em, para into u from public.email_fila where erro <> '' order by criado_em desc limit 1;
  return jsonb_build_object(
    'servico', coalesce(c->>'usuario', '') <> '' and coalesce(c->>'senha', '') <> '',
    'provedor', coalesce(c->>'provedor', ''), 'usuario', coalesce(c->>'usuario', ''),
    'rotina', v_cron and v_net,
    'pausado', public.emails_pausados(),
    'redirecionar', coalesce((select valor #>> '{}' from public.configuracoes where chave = 'email_redirecionar'), ''),
    'pendentes', (select count(*) from public.email_fila where status = 'pendente'),
    'retidos', (select count(*) from public.email_fila where status = 'retido'),
    'enviados', (select count(*) from public.email_fila where status = 'enviado'),
    'ultimo_envio', (select max(enviado_em) from public.email_fila where status = 'enviado'),
    'ultimo_erro', case when u.erro is null then null else jsonb_build_object('erro', u.erro, 'em', u.criado_em, 'status', u.status) end);
end $$;
revoke all on function public.diagnostico_email() from public, anon;
grant execute on function public.diagnostico_email() to authenticated;
-- Acordos (Backup 42): o quadro "Como pagar" do PIX sem o pedido de comprovante
create or replace function public.guias_texto_html(p_texto text, p_itens jsonb) returns text
language plpgsql immutable set search_path = public as $$
declare h text; pix text;
begin
  h := '<p style="margin:0 0 10px">' || replace(replace(public.esc_html(btrim(coalesce(p_texto, ''))), E'\n\n', '</p><p style="margin:0 0 10px">'), E'\n', '<br>') || '</p>';
  select string_agg(distinct 'PIX: <b>' || public.esc_html(i->>'pix') || '</b>' || coalesce(' · ' || nullif(public.esc_html(i->>'banco'), ''), ''), '<br>') into pix
    from jsonb_array_elements(coalesce(p_itens, '[]')) i where coalesce(i->>'pix', '') <> '';
  if pix is not null then
    h := h || '<div style="background:#F5EDD6;border-left:4px solid #C9A84C;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13.5px"><b style="color:#1B2A4A">Como pagar</b><br>' || pix || '</div>';
  end if;
  return h;
end $$;

-- ═══════════════════════════════ Backup 43 ═══════════════════════════════
-- E-mails: quando o navegador não alcança a função erp-emails, o próprio banco chama a função por dentro (pg_net, com o segredo das rotinas)
create or replace function public.disparar_envio_emails() returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_equipe() then raise exception 'Sem permissão.'; end if;
  begin
    execute $x$ select net.http_post(
      url := (select valor #>> '{}' from public.config_privada where chave = 'url_projeto') || '/functions/v1/erp-emails',
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-erp-segredo', (select valor #>> '{}' from public.config_privada where chave = 'segredo_funcoes')),
      body := '{"acao":"enviar"}'::jsonb) $x$;
    return true;
  exception when others then return false;   -- sem a extensão pg_net
  end;
end $$;
revoke all on function public.disparar_envio_emails() from public, anon;
grant execute on function public.disparar_envio_emails() to authenticated;

-- ═══════════════════════════════ Backup 44 ═══════════════════════════════
-- "Salvar rascunho no Gmail": o e-mail das guias é montado igual, mas em vez de sair fica com status 'rascunho';
-- a função erp-emails ({acao:'rascunho', ref}) grava na pasta Rascunhos do Gmail (IMAP) e marca 'rascunho_salvo'.
alter table public.email_fila drop constraint if exists email_fila_status_check;
alter table public.email_fila add constraint email_fila_status_check check (status in ('pendente','enviado','erro','cancelado','retido','rascunho','rascunho_salvo'));
create or replace function public.salvar_guias_rascunho(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r jsonb;
begin
  -- mesma transação: o e-mail nunca fica "pendente" (a rotina de 5 min não o envia)
  r := public.enviar_guias_email(p_cliente, p_grupo, p_itens, p_assunto, p_texto, p_docs, p_para, p_arquivos);
  update public.email_fila set status = 'rascunho' where referencia = r->>'ref' and status in ('pendente', 'retido');
  return r || jsonb_build_object('status', 'rascunho');
end $$;
revoke all on function public.salvar_guias_rascunho(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) from public, anon;
grant execute on function public.salvar_guias_rascunho(uuid, uuid, jsonb, text, text, uuid[], text, jsonb) to authenticated;

-- ═══════════════════════════════ Backup 45 ═══════════════════════════════
-- Rotina → "Enviar guias do mês" (igual às antigas Notificações): o botão "Enviar e-mail" salva um RASCUNHO no Gmail com o TEXTO da mensagem
-- (como o Apps Script fazia com GmailApp.createDraft) e os PDFs anexados na tela. O rascunho não sai sozinho, então vai com o e-mail
-- verdadeiro do cliente (o desvio do modo teste — email_redirecionar — não vale para rascunho).
create or replace function public.email_rascunho_destino_real(p_ref text) returns void
language sql security definer set search_path = public as $$
  update public.email_fila set para = para_original, assunto = regexp_replace(assunto, '^\[para [^]]*\] ', '')
   where referencia = p_ref and status = 'rascunho' and coalesce(para_original, '') <> '';
$$;
revoke all on function public.email_rascunho_destino_real(text) from public, anon, authenticated;
create or replace function public.rascunho_email_texto(p_cliente uuid, p_para text, p_assunto text, p_texto text, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_ref text := 'rasc:' || gen_random_uuid(); lista jsonb; v_conta text; html text;
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  v_conta := public.conta_email(p_cliente, null);
  html := '<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:#222">' ||
          replace(replace(replace(replace(coalesce(p_texto, ''), '&', '&amp;'), '<', '&lt;'), '>', '&gt;'), E'\n', '<br>') || '</div>';
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta, status)
  values (auth.uid(), coalesce(trim(p_para), ''), coalesce(nullif(trim(p_assunto), ''), 'Guias de Parcelamento'), html, 'cliente', v_ref,
          case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end, v_conta, 'rascunho');
  perform public.email_rascunho_destino_real(v_ref);
  return jsonb_build_object('ref', v_ref, 'para', p_para, 'status', 'rascunho', 'anexos', jsonb_array_length(lista));
end $$;
revoke all on function public.rascunho_email_texto(uuid, text, text, text, jsonb) from public, anon;
grant execute on function public.rascunho_email_texto(uuid, text, text, text, jsonb) to authenticated;
-- o rascunho das guias/acordos (janela "Emitir") também vai com o e-mail real do cliente
create or replace function public.salvar_guias_rascunho(p_cliente uuid, p_grupo uuid, p_itens jsonb, p_assunto text, p_texto text,
  p_docs uuid[] default '{}', p_para text default null, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r jsonb;
begin
  r := public.enviar_guias_email(p_cliente, p_grupo, p_itens, p_assunto, p_texto, p_docs, p_para, p_arquivos);
  update public.email_fila set status = 'rascunho' where referencia = r->>'ref' and status in ('pendente', 'retido');
  perform public.email_rascunho_destino_real(r->>'ref');
  return r || jsonb_build_object('status', 'rascunho');
end $$;
-- Usuários: cargo (hierarquia — quem está abaixo não vê a agenda de quem está acima) e revisor padrão (quem valida as tarefas da pessoa)
alter table public.perfis add column if not exists cargo text not null default '';
alter table public.perfis add column if not exists revisor_id uuid references public.perfis(id) on delete set null;
create or replace function public.nivel_cargo(p_cargo text, p_papel text) returns int language sql immutable as $$
  select case when p_papel = 'admin' and coalesce(p_cargo, '') = '' then 5
              else case coalesce(p_cargo, '') when 'socio' then 5 when 'coordenador' then 4 when 'advogado' then 3 when 'contador' then 3
                     when 'assistente' then 2 when 'estagiario' then 1 else 2 end end;
$$;
create or replace function public.equipe_hierarquia() returns table (id uuid, nome text, email text, papel text, cargo text, nivel int, revisor_id uuid)
language sql stable security definer set search_path = public as $$
  select p.id, p.nome, p.email, p.papel, p.cargo, public.nivel_cargo(p.cargo, p.papel), p.revisor_id
    from public.perfis p where public.eh_equipe() and p.papel in ('admin','equipe') order by p.nome;
$$;
revoke all on function public.equipe_hierarquia() from public, anon;
grant execute on function public.equipe_hierarquia() to authenticated;
-- tarefa com validação e sem revisor: vai para o revisor padrão de quem é responsável
create or replace function public.tarefa_revisor_padrao() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.exige_revisao, false) and coalesce(btrim(new.revisor), '') = '' and coalesce(btrim(new.responsavel), '') <> '' then
    new.revisor := coalesce((select r.nome from public.perfis p join public.perfis r on r.id = p.revisor_id
                              where p.papel in ('admin','equipe') and lower(split_part(btrim(p.nome), ' ', 1)) = lower(split_part(btrim(new.responsavel), ' ', 1)) limit 1), '');
  end if;
  return new;
end $$;
drop trigger if exists tarefa_revisor_padrao on public.tarefas;
create trigger tarefa_revisor_padrao before insert or update of exige_revisao, revisor, responsavel on public.tarefas for each row execute function public.tarefa_revisor_padrao();
-- Agenda: dois avisos (ex.: 1 dia antes + 30 min antes)
alter table public.tarefas add column if not exists aviso2_min int;
alter table public.tarefas add column if not exists aviso2_em timestamptz;
create or replace function public.avisos_agenda() returns int
language plpgsql security definer set search_path = public as $$
declare t record; pnome text; uid uuid; n int := 0; ini timestamptz; rot text; k int; mins int; ja timestamptz;
begin
  for t in select * from public.tarefas
            where ((aviso_min is not null and aviso_em is null) or (aviso2_min is not null and aviso2_em is null)) and prazo is not null
              and status not in ('concluida', 'cancelada') and prazo between current_date - 1 and current_date + 3 loop
    ini := ((t.prazo + coalesce(t.hora, time '08:00')) at time zone 'America/Sao_Paulo');
    rot := case t.tipo_agenda when 'reuniao' then 'Reunião' when 'audiencia' then 'Audiência' when 'compromisso' then 'Compromisso' else 'Tarefa' end;
    for k in 1..2 loop
      mins := case k when 1 then t.aviso_min else t.aviso2_min end;
      ja := case k when 1 then t.aviso_em else t.aviso2_em end;
      continue when mins is null or ja is not null;
      continue when ini - make_interval(mins => mins) > now() or ini < now() - interval '1 hour';
      for pnome in select distinct lower(split_part(btrim(x), ' ', 1)) from unnest(array[t.responsavel] || string_to_array(coalesce(t.participantes, ''), ',')) x where btrim(coalesce(x, '')) <> '' loop
        uid := (select p.id from public.perfis p where p.papel in ('admin', 'equipe') and lower(split_part(btrim(p.nome), ' ', 1)) = pnome limit 1);
        if uid is not null then
          insert into public.notificacoes (usuario_id, tipo, titulo, detalhe)
          values (uid, 'agenda', '🔔 ' || rot || ' ' || to_char(t.prazo, 'DD/MM') || coalesce(' às ' || to_char(t.hora, 'HH24:MI'), '') || ': ' || t.titulo,
                  concat_ws(' · ', nullif(coalesce(t.local, ''), ''), nullif(coalesce(t.processos_vinculados, ''), '')));
          n := n + 1;
        end if;
      end loop;
      if k = 1 then update public.tarefas set aviso_em = now() where id = t.id; else update public.tarefas set aviso2_em = now() where id = t.id; end if;
    end loop;
  end loop;
  return n;
end $$;
revoke all on function public.avisos_agenda() from public, anon, authenticated;
create or replace function public.tarefa_aviso_reset() returns trigger language plpgsql as $$
begin
  if new.prazo is distinct from old.prazo or new.hora is distinct from old.hora or new.aviso_min is distinct from old.aviso_min then new.aviso_em := null; end if;
  if new.prazo is distinct from old.prazo or new.hora is distinct from old.hora or new.aviso2_min is distinct from old.aviso2_min then new.aviso2_em := null; end if;
  return new;
end $$;
-- ═══ fim do Backup 45 ═══

-- ═══════════════════════════════ Backup 46 ═══════════════════════════════
-- Documentos: link da pasta no Google Drive, no grupo e em cada empresa (aparece ao lado do nome da pasta)
alter table public.grupos add column if not exists drive_url text not null default '';
alter table public.clientes add column if not exists drive_url text not null default '';
create or replace function public.salvar_link_drive(p_tipo text, p_id uuid, p_url text) returns void
language plpgsql security definer set search_path = public as $$
declare u text := btrim(coalesce(p_url, ''));
begin
  if not (public.pode('documentos', 'editar') or public.pode('clientes', 'editar')) then raise exception 'permission denied: sem acesso para editar Documentos.'; end if;
  if u <> '' and u !~* '^https?://' then u := 'https://' || u; end if;
  if p_tipo = 'grupo' then update public.grupos set drive_url = u where id = p_id;
  elsif p_tipo = 'cliente' then update public.clientes set drive_url = u where id = p_id;
  else raise exception 'Tipo inválido.'; end if;
end $$;
revoke all on function public.salvar_link_drive(text, uuid, text) from public, anon;
grant execute on function public.salvar_link_drive(text, uuid, text) to authenticated;
-- Automações: as regras que NUNCA foram usadas (nenhum registro no log, nenhuma tarefa e nenhum e-mail gerado por elas) saem da tela
-- e ficam desligadas (uma vez só; num banco novo, sem histórico nenhum, nada é escondido)
alter table public.regras_tarefas add column if not exists oculta boolean not null default false;
do $$
declare usados text[];
begin
  if exists (select 1 from public.configuracoes where chave = 'b46_automacoes') then return; end if;
  if exists (select 1 from public.automacoes_log) or exists (select 1 from public.tarefas where coalesce(chave_regra, '') <> '') then
    with mapa(prefixo, regra) as (values ('rot-conf','rotina_conferir'),('rot-sup','rotina_supervisao'),('onb','contrato_onboarding'),('proc','processo_novo'),
           ('cert','certidao_vencendo'),('doc','certidao_vencendo'),('parc','parcela_parcelamento'),('aco','parcela_acordo'),('cob','cobrar_honorario'),
           ('anexo','contrato_anexo'),('procur','processo_procuracao'),('pagamento_conclui','pagamento_conclui'),('pub','publicacao_tarefa'),
           ('cliente_novo_cnpj','cliente_novo_cnpj'),('email_lp','email_lembrete_parcelamento'),('email_lh','email_lembrete_honorario'),
           ('email_ch','email_cobranca_honorario'),('email_la','email_lembrete_acordo'),('email_pr','email_pagamento_recebido'),
           ('email_vh','email_lembrete_honorario'),('crm-parada','crm_parada'),('crm-follow','crm_followup'),('email_bv','email_boas_vindas'),
           ('email_ap','email_atraso_parcelamento'),('email_aa','email_atraso_acordo'),('escalar','escalar_atraso')),
    pref as (select distinct split_part(chave, ':', 1) p from public.automacoes_log
             union select distinct split_part(chave_regra, ':', 1) from public.tarefas where coalesce(chave_regra, '') <> ''
             union select distinct split_part(referencia, ':', 1) from public.email_fila where coalesce(referencia, '') <> '')
    select array_agg(distinct m.regra) into usados from mapa m join pref on pref.p = m.prefixo;
    update public.regras_tarefas set oculta = true, ligada = false where not (chave = any (coalesce(usados, '{}')));
  end if;
  insert into public.configuracoes (chave, valor) values ('b46_automacoes', to_jsonb(coalesce(usados, '{}')));
end $$;
-- ═══ fim do Backup 46 ═══

-- ═══════════════════════════════ Backup 49 ═══════════════════════════════
-- E-mails (1) — chave única por cliente: "Recebe e-mails do escritório: Sim / Não". Com "Não", NADA sai para ele
-- (lembrete, cobrança, guia, acordo, recibo, convite, rascunho). Os detalhes antigos (perfil, contatos, setor) continuam valendo para quem recebe.
alter table public.clientes add column if not exists recebe_email boolean not null default true;
do $$ begin
  if not exists (select 1 from public.configuracoes where chave = 'b49_recebe_email') then
    update public.clientes set recebe_email = false where perfil_email = 'nada';   -- "Não enviar nenhum e-mail" = a chave em Não
    insert into public.configuracoes (chave, valor) values ('b49_recebe_email', 'true');
  end if;
end $$;
alter table public.email_fila add column if not exists cliente_id uuid references public.clientes(id) on delete set null;
create index if not exists email_fila_cliente_idx on public.email_fila (cliente_id, criado_em desc);
-- de quem é este endereço? (e-mail do cadastro ou de um contato do cliente; vários endereços separados por vírgula ou ponto e vírgula)
create or replace function public.clientes_do_email(p_para text) returns uuid[]
language sql stable security definer set search_path = public as $$
  with e as (select distinct lower(btrim(x)) em from regexp_split_to_table(coalesce(p_para, ''), '[,;]') x where btrim(x) <> '')
  select coalesce(array_agg(distinct id), '{}') from (
    select c.id from public.clientes c join e on lower(btrim(c.email)) = e.em
    union select k.cliente_id from public.contatos k join e on lower(btrim(k.email)) = e.em where k.cliente_id is not null) z;
$$;
revoke all on function public.clientes_do_email(text) from public, anon, authenticated;
-- roda ANTES do desvio do modo teste ("a" < "d"): olha o endereço verdadeiro
create or replace function public.email_fila_recebe() returns trigger language plpgsql security definer set search_path = public as $$
declare ids uuid[]; bloq text;
begin
  if coalesce(new.tipo, '') <> 'cliente' then return new; end if;
  ids := public.clientes_do_email(new.para);
  if new.cliente_id is null and array_length(ids, 1) > 0 then new.cliente_id := ids[1]; end if;
  select string_agg(nome, ', ') into bloq from public.clientes where (id = any(ids) or id = new.cliente_id) and not recebe_email;
  if bloq is not null then
    if new.usuario_id is not null then
      raise exception 'Este cliente está marcado para NÃO receber e-mails (%). Para mandar, mude em Clientes → ✉ Recebe e-mails.', bloq;
    end if;
    new.status := 'cancelado'; new.erro := 'Cliente marcado para não receber e-mails';
  end if;
  return new;
end $$;
drop trigger if exists email_fila_a_recebe on public.email_fila;
create trigger email_fila_a_recebe before insert on public.email_fila for each row execute function public.email_fila_recebe();
-- as automações também perguntam antes de montar o e-mail
create or replace function public.pode_email(p_cliente uuid, p_grupo uuid, p_tipo text) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare pf text; t jsonb;
begin
  -- Backup 49: a chave "Recebe e-mails = Não" vence tudo (cliente, ou todos os clientes do grupo)
  if p_cliente is not null and exists (select 1 from public.clientes where id = p_cliente and not recebe_email) then return false; end if;
  if p_cliente is null and p_grupo is not null and exists (select 1 from public.clientes where grupo_id = p_grupo)
     and not exists (select 1 from public.clientes where grupo_id = p_grupo and recebe_email) then return false; end if;
  -- daqui para baixo, igual ao Backup 26 (perfil detalhado, em "Avançado")
  pf := public.perfil_email_de(p_cliente, p_grupo);
  if pf = 'nada' then return false; end if;
  if pf = 'personalizado' then
    select emails_tipos into t from public.clientes where id = p_cliente;
    if t is null then select emails_tipos into t from public.clientes where grupo_id = p_grupo and perfil_email = 'personalizado' limit 1; end if;
    return coalesce((t->>p_tipo)::boolean, p_tipo <> 'vencimento');
  end if;
  if p_tipo in ('boas_vindas','convite','contrato') then return true; end if;
  if pf = 'nunca' then return p_tipo not in ('lembrete','vencimento','cobranca','recibo'); end if;
  if pf = 'vencimento' then return p_tipo not in ('lembrete','cobranca'); end if;
  return p_tipo <> 'vencimento';
end $$;
revoke all on function public.pode_email(uuid, uuid, text) from public, anon, authenticated;
-- marcar vários clientes de uma vez (Clientes → selecionar → ✉ Sim / Não)
create or replace function public.clientes_recebe_email(p_ids uuid[], p_recebe boolean) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.pode('clientes', 'editar') then raise exception 'permission denied: sem acesso para editar clientes.'; end if;
  update public.clientes set recebe_email = p_recebe where id = any(coalesce(p_ids, '{}')) and recebe_email is distinct from p_recebe;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.clientes_recebe_email(uuid[], boolean) from public, anon;
grant execute on function public.clientes_recebe_email(uuid[], boolean) to authenticated;
-- E-mails (2) — "Quem recebe": uma linha por cliente com o destino, a chave e o último e-mail
create or replace function public.quem_recebe_emails() returns table (cliente_id uuid, grupo text, cliente text, area text, recebe boolean,
  destino text, ultimo_em timestamptz, ultimo_assunto text, ultimo_status text)
language sql stable security definer set search_path = public as $$
  select c.id, coalesce(g.nome, ''), c.nome, coalesce(c.area, ''), c.recebe_email,
         coalesce(nullif((select d.email from public.contato_do_cliente(c.id, c.grupo_id, 'cobranca') d limit 1), ''), nullif(btrim(c.email), ''), ''),
         u.criado_em, u.assunto, u.status
    from public.clientes c left join public.grupos g on g.id = c.grupo_id
    left join lateral (select f.criado_em, f.assunto, f.status from public.email_fila f where f.cliente_id = c.id order by f.criado_em desc limit 1) u on true
   where public.pode('clientes') and coalesce(c.tipo, '') <> 'Inativo'
   order by g.nome nulls last, c.nome;
$$;
revoke all on function public.quem_recebe_emails() from public, anon;
grant execute on function public.quem_recebe_emails() to authenticated;
-- E-mails (3) — "Para revisar": com a chave ligada, os e-mails AUTOMÁTICOS ao cliente (das rotinas; sem usuário) esperam um clique
insert into public.configuracoes (chave, valor) values ('emails_revisar', 'false'::jsonb) on conflict (chave) do nothing;
create or replace function public.emails_revisar() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select (valor #>> '{}')::boolean from public.configuracoes where chave = 'emails_revisar'), false);
$$;
grant execute on function public.emails_revisar() to authenticated;
create or replace function public.email_fila_reter() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'pendente' and coalesce(new.tipo, '') <> 'teste' and coalesce(current_setting('erp.liberar_email', true), '') <> '1'
     and (tg_op = 'INSERT' or old.status is distinct from 'pendente') then
    if public.emails_pausados() and not public.eh_email_teste(new.para) then new.status := 'retido';
    elsif new.tipo = 'cliente' and new.usuario_id is null and public.emails_revisar() then new.status := 'retido'; end if;
  end if;
  return new;
end $$;
create or replace function public.salvar_emails_revisar(p boolean) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador muda esta opção.'; end if;
  insert into public.configuracoes (chave, valor) values ('emails_revisar', to_jsonb(coalesce(p, false))) on conflict (chave) do update set valor = excluded.valor;
end $$;
revoke all on function public.salvar_emails_revisar(boolean) from public, anon;
grant execute on function public.salvar_emails_revisar(boolean) to authenticated;
-- E-mails (6) — modo teste: o administrador vê a faixa e desliga por aqui (vazio = e-mails vão para o endereço verdadeiro)
create or replace function public.modo_teste_email() returns text language sql stable security definer set search_path = public as $$
  select case when public.eh_admin() then btrim(coalesce((select valor #>> '{}' from public.configuracoes where chave = 'email_redirecionar'), '')) else '' end;
$$;
grant execute on function public.modo_teste_email() to authenticated;
create or replace function public.salvar_modo_teste_email(p text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.eh_admin() then raise exception 'Só o administrador muda o modo teste.'; end if;
  insert into public.configuracoes (chave, valor) values ('email_redirecionar', to_jsonb(btrim(coalesce(p, '')))) on conflict (chave) do update set valor = excluded.valor;
end $$;
revoke all on function public.salvar_modo_teste_email(text) from public, anon;
grant execute on function public.salvar_modo_teste_email(text) to authenticated;
-- E-mails (4) — "Enviar guias do mês" (Rotina) no mesmo modelo bonito dos outros e-mails: cabeçalho com a marca, cada guia num quadro e o rodapé
create or replace function public.texto_guias_rotina_html(p_texto text) returns text
language plpgsql immutable set search_path = public as $$
declare bl text; l text; caixa text; out text := '';
begin
  foreach bl in array regexp_split_to_array(btrim(coalesce(p_texto, '')), E'\n[ \t]*\n') loop
    if btrim(bl) = '' then continue; end if;
    if bl ~ '(Nº do Parcelamento|Parcela:|Nº da Guia:|Valor:)' then
      caixa := '';
      foreach l in array string_to_array(bl, E'\n') loop
        l := public.esc_html(btrim(l));
        if l = '' then continue; end if;
        if l ~ '^⚠' then caixa := caixa || '<div style="color:#B42318;font-weight:bold;font-size:12px;letter-spacing:.04em;margin-bottom:4px">' || l || '</div>';
        elsif l ~ '^Parcelamento ' then caixa := caixa || '<div style="font-weight:bold;color:#1B2A4A;font-size:15px;margin-bottom:6px">' || l || '</div>';
        elsif l ~ '^Valor:' then caixa := caixa || '<div style="margin-top:6px;font-size:15px"><span style="color:#5B6472">Valor:</span> <b style="color:#1B2A4A">' || btrim(substr(l, 7)) || '</b></div>';
        else caixa := caixa || '<div style="margin:2px 0">' || regexp_replace(l, '(Nº do Parcelamento:|Parcela:|Vencimento:|Nº da Guia:)', '<span style="color:#5B6472">\1</span>', 'g') || '</div>';
        end if;
      end loop;
      out := out || '<div style="background:#F7F8FB;border:1px solid #E5E7EB;border-left:4px solid #1B2A4A;border-radius:10px;padding:12px 14px;margin:12px 0;font-size:14px">' || caixa || '</div>';
    else
      out := out || '<p style="margin:0 0 10px">' || replace(public.esc_html(btrim(bl)), E'\n', '<br>') || '</p>';
    end if;
  end loop;
  return out;
end $$;
drop function if exists public.rascunho_email_texto(uuid, text, text, text, jsonb);
create or replace function public.rascunho_email_texto(p_cliente uuid, p_para text, p_assunto text, p_texto text, p_arquivos jsonb default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_ref text := 'rasc:' || gen_random_uuid(); lista jsonb; v_conta text; html text; v_ass text := coalesce(nullif(trim(p_assunto), ''), 'Guias de Parcelamento');
begin
  if not public.pode('juridico', 'editar') then raise exception 'permission denied: sem acesso para enviar guias.'; end if;
  if p_cliente is not null and exists (select 1 from public.clientes where id = p_cliente and not recebe_email) then
    raise exception 'Este cliente está marcado para NÃO receber e-mails. Para mandar, mude em Clientes → ✉ Recebe e-mails.';
  end if;
  select coalesce(jsonb_agg(jsonb_build_object('tipo', 'bin', 'arquivo', a->>'arquivo', 'mime', coalesce(a->>'mime', 'application/pdf'), 'b64', a->>'b64')), '[]') into lista
    from jsonb_array_elements(coalesce(p_arquivos, '[]')) a where coalesce(a->>'b64', '') <> '';
  v_conta := public.conta_email(p_cliente, null);
  perform set_config('erp.conta_email', v_conta, true);
  html := public.email_cliente_html(v_ass, '-', public.texto_guias_rotina_html(p_texto), '[]', false);
  perform set_config('erp.conta_email', '', true);
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, anexo, conta, status, cliente_id)
  values (auth.uid(), coalesce(trim(p_para), ''), v_ass, html, 'cliente', v_ref,
          case when jsonb_array_length(lista) > 0 then jsonb_build_object('tipo', 'lista', 'itens', lista) end, v_conta, 'rascunho', p_cliente);
  perform public.email_rascunho_destino_real(v_ref);
  return jsonb_build_object('ref', v_ref, 'para', p_para, 'status', 'rascunho', 'anexos', jsonb_array_length(lista));
end $$;
revoke all on function public.rascunho_email_texto(uuid, text, text, text, jsonb) from public, anon;
grant execute on function public.rascunho_email_texto(uuid, text, text, text, jsonb) to authenticated;
-- prévia do e-mail como o cliente vai ver (botão "👁 Prévia" do cartão)
create or replace function public.previa_rascunho_texto(p_cliente uuid, p_assunto text, p_texto text) returns text
language plpgsql stable security definer set search_path = public as $$
declare h text;
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso.'; end if;
  perform set_config('erp.conta_email', public.conta_email(p_cliente, null), true);
  h := public.email_cliente_html(coalesce(nullif(trim(p_assunto), ''), 'Guias de Parcelamento'), '-', public.texto_guias_rotina_html(p_texto), '[]', false);
  perform set_config('erp.conta_email', '', true);
  return h;
end $$;
revoke all on function public.previa_rascunho_texto(uuid, text, text) from public, anon;
grant execute on function public.previa_rascunho_texto(uuid, text, text) to authenticated;

-- ── Backup 49 (24): "Cobrar" também por e-mail, no modelo bonito, respeitando a chave "Recebe e-mails" do cliente ──
create or replace function public.cobranca_email_html(p_lanc uuid, p_texto text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare l record; c record; v_ass text; h text;
begin
  select * into l from public.lancamentos where id = p_lanc;
  if l.id is null then raise exception 'Lançamento não encontrado.'; end if;
  if not public.pode(case when l.empresa = 'contabilidade' then 'financeiro_contab' else 'financeiro_juridico' end, 'editar') then
    raise exception 'permission denied: sem acesso para cobrar este lançamento.'; end if;
  select * into c from public.contato_do_cliente(l.cliente_id, l.grupo_id, 'cobranca') limit 1;
  v_ass := 'Lembrete de pagamento — ' || l.descricao;
  perform set_config('erp.conta_email', case when l.empresa = 'contabilidade' then 'contabilidade' else '' end, true);
  h := public.email_cliente_html(v_ass, coalesce(c.nome, '-'), replace(public.esc_html(coalesce(p_texto, '')), E'\n', '<br>'),
         jsonb_build_array(jsonb_build_object('descricao', l.descricao, 'vencimento', l.vencimento, 'valor', l.valor)), true);
  perform set_config('erp.conta_email', '', true);
  return jsonb_build_object('para', coalesce(c.email, ''), 'assunto', v_ass, 'html', h,
    'recebe', coalesce((select recebe_email from public.clientes where id = l.cliente_id), true));
end $$;
revoke all on function public.cobranca_email_html(uuid, text) from public, anon;
grant execute on function public.cobranca_email_html(uuid, text) to authenticated;
create or replace function public.cobrar_por_email(p_lanc uuid, p_para text, p_texto text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare l record; m jsonb; v_ref text := 'email_cm:' || p_lanc || ':' || to_char(now(), 'YYYYMMDDHH24MISS');
begin
  select * into l from public.lancamentos where id = p_lanc;
  m := public.cobranca_email_html(p_lanc, p_texto);
  if l.cliente_id is not null and not (m->>'recebe')::boolean then
    raise exception 'Este cliente está marcado para NÃO receber e-mails. Para mandar, mude em Clientes → ✉ Recebe e-mails.';
  end if;
  if btrim(coalesce(p_para, '')) = '' then raise exception 'Informe o e-mail de destino.'; end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia, conta, cliente_id)
  values (auth.uid(), btrim(p_para), m->>'assunto', m->>'html', 'cliente', v_ref,
          public.conta_email(l.cliente_id, v_ref), l.cliente_id);
  update public.lancamentos set cobranca = 'Cobrado' where id = p_lanc;
  return jsonb_build_object('ref', v_ref, 'para', btrim(p_para));
end $$;
revoke all on function public.cobrar_por_email(uuid, text, text) from public, anon;
grant execute on function public.cobrar_por_email(uuid, text, text) to authenticated;
-- ═══ fim do Backup 49 ═══

-- ═══════════════════════════════ Backup 50 ═══════════════════════════════
-- E-mail → Quem recebe: trocar o e-mail de destino ali mesmo. Muda o endereço de onde ele vem hoje
-- (contato marcado "recebe cobrança", contato do setor, contato Geral ou o e-mail do cadastro).
create or replace function public.definir_email_destino(p_cliente uuid, p_email text) returns text
language plpgsql security definer set search_path = public as $$
declare o text; st text; cid uuid; v text := lower(btrim(coalesce(p_email, '')));
begin
  if not public.pode('clientes', 'editar') then raise exception 'permission denied: só quem edita Clientes troca o e-mail.'; end if;
  if v !~ '^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$' then raise exception 'E-mail inválido: %', p_email; end if;
  select origem into o from public.contato_do_cliente(p_cliente, null, 'cobranca') limit 1;
  st := coalesce((select valor->>public.tipo_destino_email('cobranca') from public.configuracoes where chave = 'emails_destino'), 'financeiro');
  if o = 'marcado' then
    select id into cid from public.contatos where cliente_id = p_cliente and email <> '' and recebe @> array[public.tipo_destino_email('cobranca')] order by criado_em limit 1;
  elsif o = 'setor' then
    select id into cid from public.contatos where cliente_id = p_cliente and email <> '' and finalidade = st order by criado_em limit 1;
  elsif o = 'geral' then
    select id into cid from public.contatos where cliente_id = p_cliente and email <> '' and finalidade = 'geral' order by criado_em limit 1;
  end if;
  if cid is not null then update public.contatos set email = v where id = cid;
  else update public.clientes set email = v where id = p_cliente; end if;
  return (select email from public.contato_do_cliente(p_cliente, null, 'cobranca') limit 1);
end $$;
revoke all on function public.definir_email_destino(uuid, text) from public, anon;
grant execute on function public.definir_email_destino(uuid, text) to authenticated;
-- ═══ fim do Backup 50 ═══

-- ═══════════════════════════════ Backup 51 ═══════════════════════════════
-- V1/V7 — Rotina rápida: "Guias do mês" e "Planilha" pedem tudo numa consulta só, enxuta.
-- Volta: os parcelamentos; as parcelas em aberto, as do mês e as dos últimos 3 meses (mais a última de cada parcelamento,
-- para a Planilha prever as próximas); e, por parcelamento, o resumo das antigas que ficaram de fora (quantas, quantas pagas,
-- o total pago e o último valor lançado nelas). O histórico inteiro de um parcelamento só é lido quando alguém pede ("ver").
create index if not exists parcelas_pa_pago_venc on public.parcelas (parcelamento_id, pago, vencimento);
create index if not exists parcelas_abertas_venc on public.parcelas (vencimento) where not pago;
create index if not exists parcelamentos_grupo on public.parcelamentos (grupo_id);
create or replace function public.rotina_parcelas_dados() returns jsonb
language sql stable security definer set search_path = public as $$
  -- janela: dos últimos 3 meses até 3 meses à frente, mais as em atraso (de qualquer data) e a última de cada parcelamento.
  -- Cada parcela vai como lista curta [id, número, vencimento, pago, data_pagamento, emitida_em, emissao, valor] dentro do parcelamento.
  with lim as (select (date_trunc('month', current_date) - interval '3 months')::date de,
                      (date_trunc('month', current_date) + interval '4 months - 1 day')::date ate),
  ult as (select distinct on (parcelamento_id) id from public.parcelas order by parcelamento_id, vencimento desc nulls last, id),
  marcadas as (
    select x.*, (x.vencimento is null or (x.vencimento between lim.de and lim.ate) or (not x.pago and x.vencimento < lim.ate) or x.id in (select id from ult)) vis,
           x.vencimento < lim.de antiga
      from public.parcelas x, lim
  ),
  fora as (
    select parcelamento_id,
           count(*) filter (where antiga) n, count(*) filter (where antiga and pago) pagas,
           coalesce(sum(valor) filter (where antiga and pago), 0) total_pago,
           (array_agg(valor order by vencimento desc) filter (where antiga and valor > 0))[1] ultimo_valor,
           count(*) filter (where not antiga) depois
      from marcadas where not vis group by parcelamento_id
  ),
  lista as (
    select parcelamento_id, jsonb_agg(jsonb_build_array(id, numero, vencimento, pago, data_pagamento, emitida_em, emissao, valor) order by vencimento nulls last, id) ps
      from marcadas where vis group by parcelamento_id
  )
  select jsonb_build_object(
    'hoje', current_date,
    'parcelamentos', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'empresa', p.empresa, 'cnpj', p.cnpj, 'local', p.local, 'natureza', p.natureza,
        'numero', p.numero, 'total_parcelas', p.total_parcelas, 'valor_ultima_parcela', p.valor_ultima_parcela, 'grupo_id', p.grupo_id,
        'emitimos_guia', p.emitimos_guia, 'obs', p.obs, 'grupo_nome', g.nome,
        'ps', coalesce(l.ps, '[]'::jsonb),
        'fora', case when f.parcelamento_id is not null then jsonb_build_object('n', f.n, 'pagas', f.pagas, 'total_pago', f.total_pago, 'ultimo_valor', f.ultimo_valor, 'depois', f.depois) end)
        order by p.id)
      from public.parcelamentos p left join public.grupos g on g.id = p.grupo_id left join lista l on l.parcelamento_id = p.id left join fora f on f.parcelamento_id = p.id), '[]'::jsonb));
$$;
revoke all on function public.rotina_parcelas_dados() from public, anon, authenticated;
-- a permissão é conferida UMA vez (antes: a regra de acesso rodava em cada uma das milhares de linhas)
create or replace function public.rotina_parcelas_json() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso ao Jurídico (parcelamentos).'; end if;
  return public.rotina_parcelas_dados();
end $$;
revoke all on function public.rotina_parcelas_json() from public, anon;
grant execute on function public.rotina_parcelas_json() to authenticated;

-- R1 — placar do mês da Rotina (quatro números, uma consulta)
create or replace function public.rotina_placar() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare ini date := date_trunc('month', current_date)::date; fim date := (date_trunc('month', current_date) + interval '1 month - 1 day')::date; r jsonb;
begin
  if not public.eh_equipe() then raise exception 'permission denied'; end if;
  with guias as (
    select x.* from public.parcelas x join public.parcelamentos p on p.id = x.parcelamento_id
     where p.emitimos_guia is distinct from false and ((x.vencimento between ini and fim) or (not x.pago and x.vencimento < ini))
  ), pags as (select x.* from public.parcelas x where x.vencimento between ini and current_date),
  conf as (select distinct on (registro_id) registro_id, quando from public.rotina_conferencias where area = 'passivo' order by registro_id, quando desc)
  select jsonb_build_object(
    'guias_total', (select count(*) from guias),
    'guias_feitas', (select count(*) from guias where pago or emitida_em is not null or emissao ~* 'sim|emitid'),
    'pag_total', (select count(*) from pags),
    'pag_feitos', (select count(*) from pags where pago),
    'passivo_total', (select count(*) from public.clientes),
    'passivo_feitos', (select count(*) from public.clientes c join conf on conf.registro_id = c.id where conf.quando >= ini),
    'proc_total', (select count(*) from public.processos),
    'proc_feitos', (select count(*) from public.processos where ultima_movimentacao_em >= current_date - 15)) into r;
  return r;
end $$;
revoke all on function public.rotina_placar() from public, anon;
grant execute on function public.rotina_placar() to authenticated;

-- R4 — Processos: "✓ Conferir o grupo todo (sem alteração)" registra "sem novidade" em cada processo do grupo, de uma vez
create or replace function public.conferir_processos_grupo(p_ids uuid[]) returns int
language plpgsql security invoker set search_path = public as $$
declare n int;
begin
  insert into public.processo_movimentacoes (processo_id, data, tipo, descricao)
  select x, current_date, 'sem_novidade', '✓ Sem novidade' from unnest(coalesce(p_ids, '{}')) x;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.conferir_processos_grupo(uuid[]) from public, anon;
grant execute on function public.conferir_processos_grupo(uuid[]) to authenticated;

-- T1 — regra de repetição completa (tarefas.recorrencia_regra, jsonb):
--   {"tipo":"semanal","dias":[1,4],"cada":1}         toda semana nos dias (1 = segunda … 7 = domingo); "cada":2 = a cada 2 semanas
--   {"tipo":"mensal_dias","dias":[5,20]}              2× ao mês nos dias escolhidos (dia 31 em mês curto = último dia)
--   {"tipo":"mensal","modo":"dia","dia":10}           todo mês no dia N
--   {"tipo":"mensal","modo":"util","n":5}             todo mês no N.º dia útil
--   {"tipo":"mensal","modo":"semana","ordem":-1,"dow":5}  toda última sexta (ordem 1..4 = 1ª..4ª; -1 = última)
--   {"tipo":"anual","mes":3,"dia":15}                 todo ano
--   e em todas: "inicio":"2026-10-13", "fim":"2027-06-30" (opcional), "util":true (feriado/fim de semana → próximo dia útil; usa a tabela feriados)
-- As tarefas de uma mesma regra formam uma "série" (recorrencia_serie). As antigas (semanal/mensal/anual sem regra) continuam como eram.
alter table public.tarefas add column if not exists recorrencia_regra jsonb;
alter table public.tarefas add column if not exists recorrencia_serie uuid;
create unique index if not exists tarefas_serie_prazo on public.tarefas (recorrencia_serie, prazo) where recorrencia_serie is not null;

create or replace function public.recorrencia_datas(r jsonb, p_de date, p_ate date) returns setof date
language plpgsql stable set search_path = public as $$
declare
  t text := coalesce(r->>'tipo', '');
  ini date := coalesce(nullif(r->>'inicio', '')::date, p_de);
  fim date := nullif(r->>'fim', '')::date;
  util boolean := coalesce((r->>'util')::boolean, false);
  cada int := greatest(1, coalesce(nullif(r->>'cada', '')::int, 1));
  dias int[] := coalesce((select array_agg(x::int) from jsonb_array_elements_text(case when jsonb_typeof(r->'dias') = 'array' then r->'dias' else '[]'::jsonb end) x), '{}');
  semana0 date := ini - (extract(isodow from ini)::int - 1);
  d date; m date; c date; ult int; k int; lista date[] := '{}';
begin
  if t = '' or p_ate < p_de then return; end if;
  if t = 'mensal' and coalesce(r->>'modo', 'dia') = 'util' then
    -- N.º dia útil de cada mês (já cai em dia útil: não precisa adiar)
    m := date_trunc('month', greatest(ini, p_de - 10))::date;
    while m <= p_ate loop
      select x::date into c from generate_series(m, (m + interval '1 month - 1 day')::date, '1 day') x
       where public.dia_util(x::date) order by x offset greatest(1, coalesce(nullif(r->>'n', '')::int, 1)) - 1 limit 1;
      if c is not null then lista := lista || c; end if;
      m := (m + interval '1 month')::date;
    end loop;
  else
    for d in select x::date from generate_series(greatest(ini, p_de - 10), p_ate, '1 day') x loop
      ult := extract(day from (date_trunc('month', d) + interval '1 month - 1 day'))::int;
      k := extract(day from d)::int;
      c := null;
      if t = 'semanal' then
        if extract(isodow from d)::int = any(dias) and ((d - semana0) / 7) % cada = 0 then c := d; end if;
      elsif t = 'mensal_dias' then
        if exists (select 1 from unnest(dias) z where least(z, ult) = k) then c := d; end if;
      elsif t = 'mensal' and coalesce(r->>'modo', 'dia') = 'dia' then
        if least(greatest(1, coalesce(nullif(r->>'dia', '')::int, 1)), ult) = k then c := d; end if;
      elsif t = 'mensal' and r->>'modo' = 'semana' then
        if extract(isodow from d)::int = coalesce(nullif(r->>'dow', '')::int, 5)
           and ((coalesce(nullif(r->>'ordem', '')::int, 1) = -1 and k + 7 > ult) or (k - 1) / 7 + 1 = coalesce(nullif(r->>'ordem', '')::int, 1)) then c := d; end if;
      elsif t = 'anual' then
        if extract(month from d)::int = coalesce(nullif(r->>'mes', '')::int, 1) and least(coalesce(nullif(r->>'dia', '')::int, 1), ult) = k then c := d; end if;
      end if;
      if c is not null and (fim is null or c <= fim) then
        if util then while not public.dia_util(c) loop c := c + 1; end loop; end if;
        lista := lista || c;
      end if;
    end loop;
  end if;
  return query select distinct z from unnest(lista) z where z >= greatest(p_de, ini) and z <= p_ate order by 1;
end $$;
grant execute on function public.recorrencia_datas(jsonb, date, date) to authenticated;

-- as próximas N datas depois de uma data (prévia do formulário e projeção da agenda)
create or replace function public.recorrencia_proximas(r jsonb, p_depois date, p_n int default 8) returns date[]
language sql stable set search_path = public as $$
  select coalesce((select array_agg(z order by z) from (select z from public.recorrencia_datas(r, p_depois + 1, p_depois + 800) z order by z limit greatest(1, least(coalesce(p_n, 8), 60))) s), '{}');
$$;
grant execute on function public.recorrencia_proximas(jsonb, date, int) to authenticated;

-- tarefa nova com regra: vira o começo de uma série; sem prazo, o prazo é a primeira data da regra
create or replace function public.tarefa_serie_inicio() returns trigger language plpgsql set search_path = public as $$
begin
  if new.recorrencia_regra is not null and jsonb_typeof(new.recorrencia_regra) = 'object' and coalesce(new.recorrencia_regra->>'tipo', '') <> '' then
    new.recorrencia := 'regra';
    if new.recorrencia_serie is null then new.recorrencia_serie := new.id; end if;
    if new.prazo is null then
      new.prazo := (public.recorrencia_proximas(new.recorrencia_regra, coalesce(nullif(new.recorrencia_regra->>'inicio', '')::date, current_date) - 1, 1))[1];
    end if;
  elsif tg_op = 'UPDATE' and old.recorrencia = 'regra' and new.recorrencia_regra is null then
    new.recorrencia := '';   -- tirou a repetição
  end if;
  return new;
end $$;
drop trigger if exists tarefa_serie_inicio on public.tarefas;
create trigger tarefa_serie_inicio before insert or update of recorrencia_regra on public.tarefas for each row execute function public.tarefa_serie_inicio();

-- T2 — garante as ocorrências da série: cria (sem repetir) as que caem até 7 dias à frente e, se nenhuma estiver aberta,
-- a próxima. Concluir uma não mexe nas outras; a ocorrência nasce na data dela mesmo que a anterior continue aberta.
create or replace function public.recorrencia_garantir(p_serie uuid) returns int
language plpgsql security definer set search_path = public as $$
declare m public.tarefas; ultimo date; d date; n int := 0; aberta boolean;
begin
  select * into m from public.tarefas where recorrencia_serie = p_serie and recorrencia_regra is not null order by prazo desc nulls last, criado_em desc limit 1;
  if not found or m.status = 'cancelada' and not exists (select 1 from public.tarefas where recorrencia_serie = p_serie and status <> 'cancelada') then return 0; end if;
  select max(prazo) into ultimo from public.tarefas where recorrencia_serie = p_serie;
  aberta := exists (select 1 from public.tarefas where recorrencia_serie = p_serie and status not in ('concluida', 'cancelada'));
  for d in select z from public.recorrencia_datas(m.recorrencia_regra, coalesce(ultimo, current_date - 1) + 1, greatest(coalesce(ultimo, current_date), current_date) + 800) z order by z loop
    exit when n >= 60 or (d > current_date + 7 and aberta);
    insert into public.tarefas (titulo, grupo_id, cliente_id, contrato_id, processos_vinculados, prioridade, responsavel, status, inicio, prazo,
      descricao, participantes, etiquetas, checklist, recorrencia, recorrencia_regra, recorrencia_serie, exige_anexo, exige_revisao, revisor, estimativa_horas,
      tipo_agenda, hora, hora_fim, local, com_quem, obs)
    values (m.titulo, m.grupo_id, m.cliente_id, m.contrato_id, m.processos_vinculados, m.prioridade, m.responsavel, 'pendente', d, d,
      m.descricao, m.participantes, m.etiquetas,
      (select coalesce(jsonb_agg(jsonb_set(e, '{feito}', 'false')), '[]') from jsonb_array_elements(coalesce(m.checklist, '[]')) e),
      'regra', m.recorrencia_regra, p_serie, m.exige_anexo, m.exige_revisao, m.revisor, m.estimativa_horas,
      m.tipo_agenda, m.hora, m.hora_fim, m.local, m.com_quem, m.obs)
    on conflict (recorrencia_serie, prazo) where recorrencia_serie is not null do nothing;
    n := n + 1; aberta := true;
  end loop;
  return n;
end $$;
revoke all on function public.recorrencia_garantir(uuid) from public, anon;
grant execute on function public.recorrencia_garantir(uuid) to authenticated;

create or replace function public.tarefa_serie_depois() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if pg_trigger_depth() = 1 and new.recorrencia_serie is not null and new.recorrencia_regra is not null then
    perform public.recorrencia_garantir(new.recorrencia_serie);
  end if;
  return null;
end $$;
drop trigger if exists tarefa_serie_depois on public.tarefas;
create trigger tarefa_serie_depois after insert or update of status, recorrencia_regra on public.tarefas for each row execute function public.tarefa_serie_depois();

-- todo dia: todas as séries em dia (a ocorrência da semana que vem já nasce, mesmo sem concluir a anterior)
create or replace function public.recorrencias_em_dia() returns int
language plpgsql security definer set search_path = public as $$
declare s uuid; n int := 0;
begin
  for s in select distinct recorrencia_serie from public.tarefas where recorrencia_serie is not null and recorrencia_regra is not null and status <> 'cancelada' loop
    n := n + public.recorrencia_garantir(s);
  end loop;
  return n;
end $$;
revoke all on function public.recorrencias_em_dia() from public, anon;
do $$
begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'erp_recorrencias';
  perform cron.schedule('erp_recorrencias', '5 9 * * *', 'select public.recorrencias_em_dia()');
exception when others then
  raise notice 'Agendador indisponível: as próximas ocorrências nascem quando a tarefa é concluída ou editada.';
end $$;

-- a regra "efetiva" de uma tarefa: a nova (recorrencia_regra) ou a antiga convertida (semanal / mensal / anual a partir do prazo)
create or replace function public.regra_da_tarefa(t public.tarefas) returns jsonb language sql immutable as $$
  select case
    when t.recorrencia_regra is not null then t.recorrencia_regra
    when t.prazo is null then null
    when t.recorrencia = 'semanal' then jsonb_build_object('tipo', 'semanal', 'dias', jsonb_build_array(extract(isodow from t.prazo)::int), 'inicio', t.prazo)
    when t.recorrencia = 'mensal' then jsonb_build_object('tipo', 'mensal', 'modo', 'dia', 'dia', extract(day from t.prazo)::int, 'inicio', t.prazo)
    when t.recorrencia = 'anual' then jsonb_build_object('tipo', 'anual', 'mes', extract(month from t.prazo)::int, 'dia', extract(day from t.prazo)::int, 'inicio', t.prazo)
  end;
$$;

-- T2 — próximas ocorrências (até 8 por série), depois da última que já existe: calendário do ERP e Google Agenda (erp-agenda).
-- Não duplica: começa depois da última tarefa real da série. A tarefa "modelo" é a aberta mais adiantada (clique abre ela).
create or replace function public.recorrencias_projecao(p_n int default 8) returns jsonb
language sql stable security invoker set search_path = public as $$
  with series as (
    select t as tr, public.regra_da_tarefa(t) regra,
           row_number() over (partition by coalesce(t.recorrencia_serie, t.id) order by (t.status in ('concluida', 'cancelada')), t.prazo desc nulls last) k,
           max(t.prazo) over (partition by coalesce(t.recorrencia_serie, t.id)) ultimo
      from public.tarefas t
     where (t.recorrencia_serie is not null and t.recorrencia_regra is not null) or (t.recorrencia in ('semanal', 'mensal', 'anual') and t.prazo is not null and t.status not in ('concluida', 'cancelada'))
  )
  select coalesce(jsonb_agg(jsonb_build_object('serie', coalesce((s.tr).recorrencia_serie, (s.tr).id), 'tarefa_id', (s.tr).id, 'titulo', (s.tr).titulo,
      'responsavel', (s.tr).responsavel, 'participantes', (s.tr).participantes, 'revisor', (s.tr).revisor, 'prioridade', (s.tr).prioridade,
      'tipo_agenda', (s.tr).tipo_agenda, 'hora', (s.tr).hora, 'hora_fim', (s.tr).hora_fim, 'local', (s.tr).local, 'cliente_id', (s.tr).cliente_id,
      'grupo_id', (s.tr).grupo_id, 'chave_regra', (s.tr).chave_regra, 'processos_vinculados', (s.tr).processos_vinculados, 'descricao', (s.tr).descricao,
      'regra', s.regra, 'datas', public.recorrencia_proximas(s.regra, s.ultimo, p_n))), '[]'::jsonb)
    from series s where s.k = 1 and (s.tr).status not in ('concluida', 'cancelada') and s.regra is not null;
$$;
grant execute on function public.recorrencias_projecao(int) to authenticated;

-- T3 — editar "esta e as próximas": aplica os campos nesta e nas abertas seguintes da série (cada uma mantém a própria data);
-- se a regra mudou, as próximas ainda não começadas saem e nascem de novo pela regra nova.
create or replace function public.tarefa_serie_editar(p_id uuid, p jsonb) returns int
language plpgsql security invoker set search_path = public as $$
declare t public.tarefas; d jsonb := coalesce(p, '{}'::jsonb) - 'id' - 'prazo' - 'prazo_fatal' - 'inicio' - 'status' - 'checklist' - 'recorrencia_serie' - 'recorrencia' - 'depende_de'; n int;
begin
  select * into t from public.tarefas where id = p_id;
  if not found then raise exception 'Tarefa não encontrada.'; end if;
  if t.recorrencia_serie is null then raise exception 'Esta tarefa não faz parte de uma série.'; end if;
  if d ? 'recorrencia_regra' and (d->'recorrencia_regra') is distinct from t.recorrencia_regra then
    delete from public.tarefas where recorrencia_serie = t.recorrencia_serie and id <> p_id and status = 'pendente' and prazo > t.prazo;
  end if;
  update public.tarefas x set (titulo, cliente_id, grupo_id, responsavel, participantes, prioridade, estimativa_horas, etiquetas, exige_anexo, exige_revisao,
      revisor, processos_vinculados, descricao, obs, recorrencia_regra, tipo_agenda, hora, hora_fim, local)
    = (select y.titulo, y.cliente_id, y.grupo_id, y.responsavel, y.participantes, y.prioridade, y.estimativa_horas, y.etiquetas, y.exige_anexo, y.exige_revisao,
              y.revisor, y.processos_vinculados, y.descricao, y.obs, y.recorrencia_regra, y.tipo_agenda, y.hora, y.hora_fim, y.local
         from jsonb_populate_record(x, d) y)
   where x.recorrencia_serie = t.recorrencia_serie and x.status not in ('concluida', 'cancelada') and x.prazo >= t.prazo;
  get diagnostics n = row_count;
  perform public.recorrencia_garantir(t.recorrencia_serie);
  return n;
end $$;
revoke all on function public.tarefa_serie_editar(uuid, jsonb) from public, anon;
grant execute on function public.tarefa_serie_editar(uuid, jsonb) to authenticated;
-- ═══ fim do Backup 51 ═══

-- ═══════════════════════════════ Backup 52 ═══════════════════════════════
-- C6 — código PIX (copia e cola) de cada parcela de acordo; sem ele, vale a chave PIX do acordo (acordos.pix)
alter table public.acordos add column if not exists pix_codigo text not null default '';
-- a caixa "Como pagar" do e-mail mostra o PIX de cada parcela (o código copia e cola fica num quadro fácil de selecionar e copiar)
create or replace function public.guias_texto_html(p_texto text, p_itens jsonb) returns text
language plpgsql immutable set search_path = public as $$
declare h text; pix text;
begin
  h := '<p style="margin:0 0 10px">' || replace(replace(public.esc_html(btrim(coalesce(p_texto, ''))), E'\n\n', '</p><p style="margin:0 0 10px">'), E'\n', '<br>') || '</p>';
  select string_agg(distinct
           case when coalesce((i->>'pix_codigo')::boolean, false)
             then 'PIX (copia e cola)' || coalesce(' — ' || nullif(public.esc_html(i->>'descricao'), ''), '') || ':<br><span style="display:block;font-family:Consolas,monospace;font-size:12.5px;word-break:break-all;background:#fff;border:1px solid #E2D6B5;border-radius:6px;padding:8px 10px;margin:4px 0 8px;user-select:all">' || public.esc_html(i->>'pix') || '</span>'
             else 'PIX: <b>' || public.esc_html(i->>'pix') || '</b>' || coalesce(' · ' || nullif(public.esc_html(i->>'banco'), ''), '') end, '<br>') into pix
    from jsonb_array_elements(coalesce(p_itens, '[]')) i where coalesce(i->>'pix', '') <> '';
  if pix is not null then
    h := h || '<div style="background:#F5EDD6;border-left:4px solid #C9A84C;border-radius:10px;padding:12px 14px;margin:14px 0;font-size:13.5px"><b style="color:#1B2A4A">Como pagar</b><br>' || pix || '</div>';
  end if;
  return h;
end $$;
-- O2 — Rotina → Processos: uma consulta só (os processos + a ÚLTIMA movimentação de cada um), em vez de baixar todas as movimentações
create index if not exists processo_mov_ultima on public.processo_movimentacoes (processo_id, criado_em desc);
create or replace function public.rotina_processos_dados() returns jsonb
language sql stable security definer set search_path = public as $$
  with ult as (
    select distinct on (m.processo_id) m.processo_id, m.tipo, m.quem, m.criado_em
      from public.processo_movimentacoes m order by m.processo_id, m.criado_em desc, m.id
  )
  select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'numero', p.numero, 'grupo_id', p.grupo_id, 'natureza', p.natureza, 'competencia', p.competencia,
      'autor', p.autor, 'reu', p.reu, 'valor', p.valor, 'procuracao', p.procuracao, 'obs', p.obs, 'atualizacao', p.atualizacao,
      'ultima_movimentacao', p.ultima_movimentacao, 'ultima_movimentacao_em', p.ultima_movimentacao_em,
      'grupos', case when g.id is null then null else jsonb_build_object('nome', g.nome) end,
      'ult', case when u.processo_id is null then null else jsonb_build_object('processo_id', u.processo_id, 'tipo', u.tipo, 'quem', u.quem, 'criado_em', u.criado_em) end)
      order by p.id), '[]'::jsonb)
    from public.processos p left join public.grupos g on g.id = p.grupo_id left join ult u on u.processo_id = p.id;
$$;
revoke all on function public.rotina_processos_dados() from public, anon, authenticated;
create or replace function public.rotina_processos_json() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso ao Jurídico (processos).'; end if;
  return public.rotina_processos_dados();
end $$;
revoke all on function public.rotina_processos_json() from public, anon;
grant execute on function public.rotina_processos_json() to authenticated;

-- O3 — Parcelamentos depois de um Pago: o ERP relê SÓ o parcelamento que mudou (o parcelamento e todas as parcelas dele, numa consulta)
create or replace function public.parcelamentos_json(p_ids uuid[]) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.pode('juridico') then raise exception 'permission denied: sem acesso ao Jurídico (parcelamentos).'; end if;
  return coalesce((select jsonb_agg(to_jsonb(pa) || jsonb_build_object('parcelas',
      coalesce((select jsonb_agg(to_jsonb(x) order by x.vencimento nulls last, x.id) from public.parcelas x where x.parcelamento_id = pa.id), '[]'::jsonb)))
    from public.parcelamentos pa where pa.id = any(coalesce(p_ids, '{}'))), '[]'::jsonb);
end $$;
revoke all on function public.parcelamentos_json(uuid[]) from public, anon;
grant execute on function public.parcelamentos_json(uuid[]) to authenticated;
-- ═══ fim do Backup 52 ═══

-- ═══════════════════════════════════════════════════════════════════
-- Backup 53 — Rotina (Planilha com 6 parcelas antes e 3 depois), Execuções, e-mails automáticos por tipo e por cliente
-- ═══════════════════════════════════════════════════════════════════
create or replace function public.rotina_parcelas_dados() returns jsonb
language sql stable security definer set search_path = public as $$
  -- janela: dos últimos 3 meses até 3 meses à frente, mais as em atraso (de qualquer data) e a última de cada parcelamento.
  -- Cada parcela vai como lista curta [id, número, vencimento, pago, data_pagamento, emitida_em, emissao, valor] dentro do parcelamento.
  with lim as (select (date_trunc('month', current_date) - interval '3 months')::date de,
                      (date_trunc('month', current_date) + interval '4 months - 1 day')::date ate),
  ult as (select distinct on (parcelamento_id) id from public.parcelas order by parcelamento_id, vencimento desc nulls last, id),
  -- Backup 53: sempre ao menos as 6 parcelas de ANTES do mês atual e as 3 de DEPOIS do mês atual (de cada parcelamento)
  perto as (select id from (select id, row_number() over (partition by parcelamento_id order by vencimento desc) rn from public.parcelas
                             where vencimento < date_trunc('month', current_date)::date) a where rn <= 6
            union all
            select id from (select id, row_number() over (partition by parcelamento_id order by vencimento) rn from public.parcelas
                             where vencimento > (date_trunc('month', current_date) + interval '1 month - 1 day')::date) d where rn <= 3),
  marcadas as (
    select x.*, (x.vencimento is null or (x.vencimento between lim.de and lim.ate) or (not x.pago and x.vencimento < lim.ate) or x.id in (select id from ult) or x.id in (select id from perto)) vis,
           x.vencimento < lim.de antiga
      from public.parcelas x, lim
  ),
  fora as (
    select parcelamento_id,
           count(*) filter (where antiga) n, count(*) filter (where antiga and pago) pagas,
           coalesce(sum(valor) filter (where antiga and pago), 0) total_pago,
           (array_agg(valor order by vencimento desc) filter (where antiga and valor > 0))[1] ultimo_valor,
           count(*) filter (where not antiga) depois
      from marcadas where not vis group by parcelamento_id
  ),
  lista as (
    select parcelamento_id, jsonb_agg(jsonb_build_array(id, numero, vencimento, pago, data_pagamento, emitida_em, emissao, valor) order by vencimento nulls last, id) ps
      from marcadas where vis group by parcelamento_id
  )
  select jsonb_build_object(
    'hoje', current_date,
    'parcelamentos', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'empresa', p.empresa, 'cnpj', p.cnpj, 'local', p.local, 'natureza', p.natureza,
        'numero', p.numero, 'total_parcelas', p.total_parcelas, 'valor_ultima_parcela', p.valor_ultima_parcela, 'grupo_id', p.grupo_id,
        'emitimos_guia', p.emitimos_guia, 'obs', p.obs, 'grupo_nome', g.nome,
        'ps', coalesce(l.ps, '[]'::jsonb),
        'fora', case when f.parcelamento_id is not null then jsonb_build_object('n', f.n, 'pagas', f.pagas, 'total_pago', f.total_pago, 'ultimo_valor', f.ultimo_valor, 'depois', f.depois) end)
        order by p.id)
      from public.parcelamentos p left join public.grupos g on g.id = p.grupo_id left join lista l on l.parcelamento_id = p.id left join fora f on f.parcelamento_id = p.id), '[]'::jsonb));
$$;
revoke all on function public.rotina_parcelas_dados() from public, anon, authenticated;

-- ── E-mails automáticos: quais tipos cada cliente recebe (grade cliente × tipo em Administração → E-mail → Quem recebe) ──
-- tipos: lembrete (antes de vencer) · vencimento (vence hoje) · cobranca (atraso) · recibo (pagamento recebido) · parcelamento · acordo
-- pode_email_tipo = só a parte do "perfil" (sem a chave Recebe Sim/Não, que a tela mostra à parte)
create or replace function public.pode_email_tipo(p_cliente uuid, p_grupo uuid, p_tipo text) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare pf text := public.perfil_email_de(p_cliente, p_grupo); t jsonb;
begin
  if pf = 'nada' then return false; end if;
  if pf = 'personalizado' then
    select emails_tipos into t from public.clientes where id = p_cliente;
    if t is null then select emails_tipos into t from public.clientes where grupo_id = p_grupo and perfil_email = 'personalizado' limit 1; end if;
    return coalesce((t->>p_tipo)::boolean, p_tipo <> 'vencimento');
  end if;
  if pf = 'nunca' then return p_tipo not in ('lembrete','vencimento','cobranca','recibo'); end if;
  if pf = 'vencimento' then return p_tipo not in ('lembrete','cobranca'); end if;
  return p_tipo <> 'vencimento';
end $$;
revoke all on function public.pode_email_tipo(uuid, uuid, text) from public, anon, authenticated;

create or replace function public.emails_matriz() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.pode('clientes') then raise exception 'permission denied: sem acesso a Clientes.'; end if;
  return coalesce((select jsonb_object_agg(c.id, (select jsonb_object_agg(k, public.pode_email_tipo(c.id, c.grupo_id, k))
            from unnest(array['lembrete','vencimento','cobranca','recibo','parcelamento','acordo']) k))
    from public.clientes c), '{}'::jsonb);
end $$;
revoke all on function public.emails_matriz() from public, anon;
grant execute on function public.emails_matriz() to authenticated;

-- liga/desliga UM tipo para UM cliente: o cliente passa a "personalizado", guardando como estava cada um dos outros tipos
create or replace function public.salvar_email_tipo(p_cliente uuid, p_tipo text, p_valor boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare g uuid; m jsonb;
begin
  if not public.pode('clientes', 'editar') then raise exception 'permission denied: só quem edita Clientes muda os e-mails do cliente.'; end if;
  if p_tipo not in ('lembrete','vencimento','cobranca','recibo','parcelamento','acordo') then raise exception 'Tipo de e-mail inválido.'; end if;
  select grupo_id into g from public.clientes where id = p_cliente;
  if not found then raise exception 'Cliente não encontrado.'; end if;
  select jsonb_object_agg(k, public.pode_email_tipo(p_cliente, g, k)) into m
    from unnest(array['lembrete','vencimento','cobranca','recibo','parcelamento','acordo']) k;
  m := m || jsonb_build_object(p_tipo, p_valor);
  update public.clientes set perfil_email = 'personalizado', emails_tipos = m where id = p_cliente;
  return m;
end $$;
revoke all on function public.salvar_email_tipo(uuid, text, boolean) from public, anon;
grant execute on function public.salvar_email_tipo(uuid, text, boolean) to authenticated;

-- Caixa de saída → "Da Rotina": os e-mails gerados na Rotina (rascunhos) podem ser AUTORIZADOS daqui (saem pelo envio normal) ou descartados
create or replace function public.emails_rotina_acao(p_ids uuid[], p_acao text) returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not (public.eh_admin() or public.pode('juridico', 'editar')) then raise exception 'permission denied: sem acesso para autorizar e-mails.'; end if;
  if p_acao not in ('enviar', 'descartar') then raise exception 'Ação inválida.'; end if;
  update public.email_fila set status = case when p_acao = 'enviar' then 'pendente' else 'cancelado' end,
         erro = case when p_acao = 'enviar' then null else 'Descartado na Caixa de saída' end
   where id = any(coalesce(p_ids, '{}')) and status in ('rascunho', 'rascunho_salvo');
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.emails_rotina_acao(uuid[], text) from public, anon;
grant execute on function public.emails_rotina_acao(uuid[], text) to authenticated;

-- ── Execuções (cobrança ajuizada): o processo, o que o CLIENTE recebe e o que fica para o ESCRITÓRIO (% do que foi recebido) ──
create table if not exists public.execucoes (
  id uuid primary key default gen_random_uuid(),
  cliente_id uuid references public.clientes(id) on delete set null,
  grupo_id uuid references public.grupos(id) on delete set null,
  processo_id uuid references public.processos(id) on delete set null,
  numero text not null default '',
  executado text not null default '',
  valor_execucao numeric(14,2) not null default 0,
  percentual numeric(5,2) not null default 0 check (percentual >= 0 and percentual <= 100),
  situacao text not null default 'ativa' check (situacao in ('ativa','acordo','suspensa','encerrada')),
  ajuizada_em date,
  responsavel text not null default '',
  obs text not null default '',
  criado_por uuid default auth.uid(),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists execucoes_cliente on public.execucoes (cliente_id);
create table if not exists public.execucao_recebimentos (
  id uuid primary key default gen_random_uuid(),
  execucao_id uuid not null references public.execucoes(id) on delete cascade,
  data date not null default current_date,
  valor numeric(14,2) not null check (valor > 0),
  forma text not null default '',
  repassado_em date,
  honorario numeric(14,2),
  lancamento_id uuid references public.lancamentos(id) on delete set null,
  obs text not null default '',
  criado_por uuid default auth.uid(),
  criado_em timestamptz not null default now()
);
create index if not exists exec_receb_exec on public.execucao_recebimentos (execucao_id, data desc);
drop trigger if exists atualizado_execucoes on public.execucoes;
create trigger atualizado_execucoes before update on public.execucoes for each row execute function public.marcar_atualizacao();
alter table public.execucoes enable row level security;
alter table public.execucao_recebimentos enable row level security;
revoke all on public.execucoes, public.execucao_recebimentos from anon;
grant select, insert, update, delete on public.execucoes, public.execucao_recebimentos to authenticated;
drop policy if exists exec_ver on public.execucoes;
create policy exec_ver on public.execucoes for select to authenticated using (public.pode('juridico'));
drop policy if exists exec_editar on public.execucoes;
create policy exec_editar on public.execucoes for all to authenticated using (public.pode('juridico', 'editar')) with check (public.pode('juridico', 'editar'));
drop policy if exists exrec_ver on public.execucao_recebimentos;
create policy exrec_ver on public.execucao_recebimentos for select to authenticated using (public.pode('juridico'));
drop policy if exists exrec_editar on public.execucao_recebimentos;
create policy exrec_editar on public.execucao_recebimentos for all to authenticated using (public.pode('juridico', 'editar')) with check (public.pode('juridico', 'editar'));
-- registrar um recebimento lança, no Financeiro Jurídico, o honorário do escritório (% da execução sobre o valor recebido)
create or replace function public.execucao_recebimento_lanca() returns trigger
language plpgsql security definer set search_path = public as $$
declare e public.execucoes; l uuid;
begin
  select * into e from public.execucoes where id = new.execucao_id;
  if new.honorario is null then new.honorario := round(new.valor * coalesce(e.percentual, 0) / 100, 2); end if;
  if new.honorario > 0 and new.lancamento_id is null then
    insert into public.lancamentos (empresa, tipo, descricao, categoria, cliente_id, grupo_id, responsavel, vencimento, valor, servico, obs)
    values ('escritorio', 'receita', 'Honorários da execução ' || coalesce(nullif(e.numero, ''), '') || case when e.executado <> '' then ' — ' || e.executado else '' end,
            'Honorários de êxito', e.cliente_id, coalesce(e.grupo_id, (select grupo_id from public.clientes where id = e.cliente_id)), e.responsavel, new.data, new.honorario, '',
            replace(rtrim(rtrim(e.percentual::text, '0'), '.'), '.', ',') || '% de R$ ' || translate(to_char(new.valor, 'FM999,999,990.00'), ',.', '.,') || ' recebido em ' || to_char(new.data, 'DD/MM/YYYY'))
    returning id into l;
    new.lancamento_id := l;
  end if;
  return new;
end $$;
drop trigger if exists execucao_recebimento_lanca on public.execucao_recebimentos;
create trigger execucao_recebimento_lanca before insert on public.execucao_recebimentos for each row execute function public.execucao_recebimento_lanca();
-- apagar o recebimento apaga o honorário lançado (se ainda não foi pago)
create or replace function public.execucao_recebimento_apaga() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.lancamento_id is not null then delete from public.lancamentos where id = old.lancamento_id and not pago; end if;
  return old;
end $$;
drop trigger if exists execucao_recebimento_apaga on public.execucao_recebimentos;
create trigger execucao_recebimento_apaga after delete on public.execucao_recebimentos for each row execute function public.execucao_recebimento_apaga();
-- ═══ fim do Backup 53 ═══

-- ═══════════════════════ Backup 54 ═══════════════════════
-- E-mails automáticos para a EQUIPE (avisos do ERP): uma chave por tipo, para o escritório todo (Administração → E-mail → Para a equipe).
-- Ex.: criar um fluxo ou "Lead completo" avisa por e-mail quem vai fazer — a chave "fluxo" desliga só esse e-mail (o aviso no ERP continua).
-- configuracoes.emails_equipe = {"fluxo": false, ...}; tipo ausente = ligado.
create or replace function public.email_equipe_ligado(p_tipo text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(((select valor from public.configuracoes where chave = 'emails_equipe') ->> p_tipo)::boolean, true);
$$;
revoke all on function public.email_equipe_ligado(text) from public, anon;
grant execute on function public.email_equipe_ligado(text) to authenticated;
create or replace function public.emails_equipe() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce((select valor from public.configuracoes where chave = 'emails_equipe'), '{}'::jsonb);
$$;
revoke all on function public.emails_equipe() from public, anon;
grant execute on function public.emails_equipe() to authenticated;
create or replace function public.salvar_email_equipe(p_tipo text, p_ligado boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.eh_admin() then raise exception 'Só o administrador muda os e-mails automáticos.'; end if;
  if coalesce(p_tipo, '') !~ '^[a-z_]{2,30}$' then raise exception 'Tipo inválido.'; end if;
  insert into public.configuracoes (chave, valor) values ('emails_equipe', jsonb_build_object(p_tipo, coalesce(p_ligado, true)))
  on conflict (chave) do update set valor = public.configuracoes.valor || excluded.valor, atualizado_em = now()
  returning valor into v;
  return v;
end $$;
revoke all on function public.salvar_email_equipe(text, boolean) from public, anon;
grant execute on function public.salvar_email_equipe(text, boolean) to authenticated;
-- a chave geral vale antes da preferência de cada pessoa (⋯ → Meus avisos por e-mail); o resumo do dia também passa por aqui
create or replace function public.enfileirar_email(p_usuario uuid, p_pref text, p_assunto text, p_corpo text, p_tipo text, p_ref text default '')
returns boolean language plpgsql security definer set search_path = public as $$
declare pf record; n int;
begin
  if p_pref <> '' and not public.email_equipe_ligado(p_pref) then return false; end if;
  select * into pf from public.perfis where id = p_usuario and papel in ('admin','equipe');
  if not found or coalesce(pf.email, '') = '' then return false; end if;
  if p_pref <> '' and coalesce((pf.pref_email->>p_pref)::boolean, true) = false then return false; end if;
  insert into public.email_fila (usuario_id, para, assunto, html, tipo, referencia)
  values (p_usuario, pf.email, p_assunto, public.email_modelo(p_assunto, p_corpo), p_tipo, coalesce(p_ref, ''))
  on conflict (usuario_id, referencia) where referencia <> '' do nothing;
  get diagnostics n = row_count;
  return n > 0;
end $$;
revoke all on function public.enfileirar_email(uuid, text, text, text, text, text) from anon, authenticated;
-- tipo do aviso → chave geral (fluxo/sequência separado das tarefas soltas)
create or replace function public.tipo_email_equipe(p_tipo text, p_titulo text) returns text language sql immutable as $$
  select case
    when coalesce(p_titulo, '') ~* '^(novo fluxo|nova sequência|pode começar)' then 'fluxo'
    when p_tipo in ('mencao','publicacao','revisao','agenda','financeiro','acesso','cnpj') then p_tipo
    when p_tipo = 'atraso' then 'atraso'
    else 'tarefa' end;
$$;
create or replace function public.email_da_notificacao() returns trigger
language plpgsql security definer set search_path = public as $$
declare pref text;
begin
  if not public.email_equipe_ligado(public.tipo_email_equipe(new.tipo, new.titulo)) then return null; end if;
  pref := case new.tipo when 'mencao' then 'mencao' when 'publicacao' then 'publicacao' when 'atraso' then 'fatal' else 'tarefa' end;
  perform public.enfileirar_email(new.usuario_id, pref, new.titulo,
    '<p>' || public.esc_html(new.titulo) || '</p>' || case when new.detalhe <> '' then '<p style="color:#4B5563">' || public.esc_html(new.detalhe) || '</p>' else '' end
    || coalesce('<p><a href="' || (select valor #>> '{}' from public.config_privada where chave = 'url_sistema') || '" style="background:#1B2A4A;color:#fff;padding:9px 16px;border-radius:8px;text-decoration:none;display:inline-block">Abrir no ERP</a></p>', ''),
    new.tipo, 'notif:' || new.id);
  return null;
end $$;
-- primeira vez: o aviso por e-mail de fluxo/sequência sai DESLIGADO (o dono pediu); os demais continuam como estavam
insert into public.configuracoes (chave, valor) values ('emails_equipe', '{"fluxo": false}'::jsonb) on conflict (chave) do nothing;

-- Execuções: contatos de quem NÃO é cliente (executado, advogado da outra parte, cartório, perito…) — telefone, e-mail, endereço
create table if not exists public.execucao_contatos (
  id          uuid primary key default gen_random_uuid(),
  execucao_id uuid not null references public.execucoes(id) on delete cascade,
  nome        text not null,
  papel       text not null default '',
  telefone    text not null default '',
  email       text not null default '',
  endereco    text not null default '',
  obs         text not null default '',
  criado_em   timestamptz not null default now()
);
create index if not exists execucao_contatos_exec on public.execucao_contatos (execucao_id);
alter table public.execucao_contatos enable row level security;
revoke all on public.execucao_contatos from anon;
grant select, insert, update, delete on public.execucao_contatos to authenticated;
drop policy if exists exct_ver on public.execucao_contatos;
create policy exct_ver on public.execucao_contatos for select to authenticated using (public.pode('juridico'));
drop policy if exists exct_editar on public.execucao_contatos;
create policy exct_editar on public.execucao_contatos for all to authenticated using (public.pode('juridico', 'editar')) with check (public.pode('juridico', 'editar'));
-- ═══ fim do Backup 54 ═══
