// ═══ Backup 25 — LISTA POR GRUPO (a mesma para Parcelamentos e Acordos) ═══
// Linha do GRUPO (clique abre) e, dentro dela, uma linha por parcelamento/acordo, bem recuada e em cartão próprio.
// Colunas: nome · "147 de 410 parcelas pagas" (embaixo "Quitado R$ · falta R$") · próxima parcela · situação.
// • Próxima parcela do GRUPO = soma de todas as parcelas que vencem no mês da próxima (ex.: 3 parcelas em out/2026).
// • Situação = nº de parcelas em atraso (o dia do vencimento já conta). "Risco de rescisão" só quando UM parcelamento/acordo
//   tem 2 ou mais parcelas em atraso (20 parcelas atrasadas, uma em cada parcelamento, não é risco).
// item: {k, grupo, titulo, sub, pagas, total, pago, falta, atr, abertas:[{d:Date, v:Number}], extra}
var _LG_MES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
function _lgFmtV(v){ return typeof _faFT==='function'?_faFT(v):fF(v); }
function _lgProx(abertas){
  var h=new Date(); h.setHours(0,0,0,0);
  var fut=abertas.filter(function(x){ return x.d&&x.d>h; }).sort(function(a,b){ return a.d-b.d; });
  if(!fut.length) return null;
  var m=fut[0].d.getMonth(), y=fut[0].d.getFullYear();
  var doMes=fut.filter(function(x){ return x.d.getMonth()===m&&x.d.getFullYear()===y; });
  return { d:fut[0].d, v:doMes.reduce(function(s,x){ return s+(Number(x.v)||0); },0), n:doMes.length, mes:_LG_MES[m]+'/'+y };
}
// Backup 27: uma pílula só — "2 em atraso" (rosa) ou, com risco, "2 em atraso — risco de rescisão" (a pílula toda vermelha)
function _lgSit(atr,risco,concluido){
  if(atr) return '<span class="lg-st '+(risco?'lg-st-risco':'lg-st-r')+'"'+(risco?' title="Um parcelamento/acordo com 2 ou mais parcelas em atraso"':'')+'>'+atr+' em atraso'+(risco?' — risco de rescisão':'')+'</span>';
  return concluido?'<span class="lg-st lg-st-x">Concluído</span>':'<span class="lg-st lg-st-g">Em dia</span>';
}
function _lgPag(pagas,total,pago,falta){
  return '<div class="lg-pag"><b class="lg-verde">'+pagas+' de '+(total||'?')+'</b> parcelas pagas</div><div class="lg-sub">Quitado <b>'+_lgFmtV(pago)+'</b> · falta <b>'+_lgFmtV(falta)+'</b></div>';
}
// Backup 28: guias a emitir — parcela sem pagamento, sem emissão, vencida ou vencendo em até 15 dias (mesmo prazo do quadro "Guias para emitir")
function _lgFaltaEmitir(lista, emitida, paga){
  var h=new Date(); h.setHours(0,0,0,0); var lim=new Date(h.getTime()+15*864e5);
  return (lista||[]).filter(function(pa){ var d=pDate(pa.vencimento); return !paga(pa) && !emitida(pa) && d && d<=lim; }).length;
}
// Backup 34: "Situação" só para enxergar — sem quem emite; guias a emitir num aviso discreto embaixo do nome
function _lgGuiaDiscreta(n, grupo){
  if(!n) return '';
  return ' <span class="lg-guia-d" title="'+(grupo?'Há parcelas deste grupo sem a guia emitida (vencem em até 15 dias) — emitir pela Rotina → Controle':'Parcela vencendo em até 15 dias sem a guia emitida — emitir pela Rotina → Controle')+'">· 🧾 '+(n>1?n+' guias a emitir':'1 guia a emitir')+'</span>';
}
function _lgEsc(t){ return String(t).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;'); }
// o: {itens, porGrupo, abertos (obj), fnGrupo, fnItem, rotulo ('parcelamento'|'acordo'), cab}
// Backup 34: a subdivisão natural é Grupo › itens; com um grupo só na tela (filtro de grupo), vira Empresa › itens (item.empresa).
// Linhas de mesma largura (sem recuo), colunas: nome · parcelas pagas (quitado/falta) · próxima parcela · situação.
function _lgRender(o){
  if(!o.itens.length) return '<div class="lg"><div class="pa-ok">Nada com esses filtros.</div></div>';
  // só quando há um grupo FILTRADO (o filtro do topo ou o da própria lista)
  var umGrupo=!!o.porEmpresa && o.itens.some(function(x){ return x.empresa; });
  var linhaItem=function(x){
    var p=_lgProx(x.abertas);
    return '<div class="lg-i lg-filho'+(x.atr?' lg-atr':'')+'" role="button" tabindex="0" onclick="'+o.fnItem+'(\''+_lgEsc(x.k)+'\')" onkeydown="if(event.key===\'Enter\')'+o.fnItem+'(\''+_lgEsc(x.k)+'\')" title="Abrir o detalhamento">'
      +'<div class="lg-c1"><div class="lg-nome">'+esc(umGrupo&&x.tituloEmp?x.tituloEmp:x.titulo)+'</div><div class="lg-sub">'+(umGrupo&&x.subEmp!=null?x.subEmp:x.sub)+_lgGuiaDiscreta(x.guias,false)+'</div></div>'
      +'<div class="lg-c2">'+_lgPag(x.pagas,x.total,x.pago,x.falta)+'</div>'
      +'<div class="lg-c3">'+(p?'<div class="lg-val">'+_lgFmtV(p.v)+'</div><div class="lg-sub">vence '+p.d.toLocaleDateString('pt-BR')+'</div>':'<div class="lg-val">—</div><div class="lg-sub">'+(x.atr?'só vencidas':'sem próxima')+'</div>')+'</div>'
      +'<div class="lg-c4">'+_lgSit(x.atr,x.atr>=2,x.concluido)+'</div><div class="lg-c5" aria-hidden="true">›</div></div>'; };
  var chave=umGrupo?function(x){ return x.empresa||x.titulo; }:function(x){ return x.grupo; };
  var G={}; o.itens.forEach(function(x){ (G[chave(x)]=G[chave(x)]||[]).push(x); });
  var atrG=function(g){ return G[g].reduce(function(s,x){ return s+x.atr; },0); };
  var gs=Object.keys(G).sort(function(a,b){ return (atrG(b)>0)-(atrG(a)>0) || a.localeCompare(b,'pt-BR'); });
  var corpo=gs.map(function(g){
    var l=G[g].slice().sort(function(a,b){ return b.atr-a.atr || String(a.titulo+a.sub).localeCompare(String(b.titulo+b.sub),'pt-BR'); }), ab=!!o.abertos[g];
    var soma=function(f){ return l.reduce(function(s,x){ return s+(Number(x[f])||0); },0); };
    var atr=soma('atr'), risco=l.some(function(x){ return x.atr>=2; });
    var p=_lgProx([].concat.apply([],l.map(function(x){ return x.abertas; })));
    return '<div class="lg-g'+(ab?' lg-g-aberto':'')+(atr?' lg-atr':'')+'">'
      +'<div class="lg-gl" role="button" tabindex="0" aria-expanded="'+ab+'" onclick="'+o.fnGrupo+'(\''+_lgEsc(g)+'\')" onkeydown="if(event.key===\'Enter\')'+o.fnGrupo+'(\''+_lgEsc(g)+'\')" title="'+(ab?'Recolher':'Ver os '+o.rotulo+'s')+'">'
      +'<div class="lg-c1"><div class="lg-gnome"><span class="lg-seta" aria-hidden="true">'+(ab?'▾':'▸')+'</span>'+esc(g)+'</div><div class="lg-sub">'+l.length+' '+o.rotulo+(l.length>1?'s':'')+_lgGuiaDiscreta(soma('guias'),true)+'</div></div>'
      +'<div class="lg-c2">'+_lgPag(soma('pagas'),soma('total'),soma('pago'),soma('falta'))+'</div>'
      +'<div class="lg-c3">'+(p?'<div class="lg-val">'+_lgFmtV(p.v)+'</div><div class="lg-sub">'+(p.n>1?p.n+' parcelas em '+p.mes:'vence '+p.d.toLocaleDateString('pt-BR'))+'</div>':'<div class="lg-val">—</div>')+'</div>'
      +'<div class="lg-c4">'+_lgSit(atr,risco,false)+'</div><div class="lg-c5" aria-hidden="true"></div></div>'
      +(ab?'<div class="lg-filhos">'+l.map(linhaItem).join('')+'</div>':'')+'</div>'; }).join('');
  return '<div class="lg lg-min"><div class="lg-hd"><span>'+(umGrupo?'Empresa / '+o.rotulo:o.cab)+'</span><span>Parcelas pagas</span><span>Próxima parcela</span><span>Situação</span><span></span></div>'+corpo+'</div>';
}
// Backup 34: parcelas do detalhamento (Parcelamentos e Acordos) em LISTA — igual a "Vencidos — URGENTE":
// Parcela · Vencimento · Valor · Situação (pagamento + guia emitida / não emitida / o cliente emite)
// l: [{id, rot, venc (dd/mm/aaaa), valor, lancado, pago, dataPag, emitida, emitidaEm, cliente}]
function _lgParcTabela(l, tabela){
  var h=new Date(); h.setHours(0,0,0,0);
  var nome=tabela==='parcelas'?'Guia':'Boleto';
  return '<div class="tw lg-parc-tw" data-sem-pagina><table class="lg-parc-tab"><thead><tr><th>Parcela</th><th>Vencimento</th><th>Valor</th><th>Situação</th><th></th></tr></thead><tbody>'
    +l.map(function(x){ var d=pDate(x.venc), n=d?Math.round((d-h)/864e5):null;
      var pag=x.pago?'<span class="pill pago">✓ Paga'+(x.dataPag?' em '+esc(x.dataPag):'')+'</span>'
        :(n!==null&&n<=0?'<span class="pill vencido">'+(n===0?'Vence hoje':'Vencida há '+Math.abs(n)+' d')+'</span>':'<span class="pill aberto">A vencer</span>');
      var em=x.cliente?'<span class="lg-em lg-em-cli" title="As guias deste parcelamento são emitidas pelo próprio cliente">Não emitimos</span>'
        :x.emitida?'<span class="lg-em lg-em-ok" title="'+esc(x.emitidaEm?nome+' emitid'+(nome==='Guia'?'a':'o')+' em '+x.emitidaEm:'')+'">✓ Emitid'+(nome==='Guia'?'a':'o')+(x.emitidaEm?' '+esc(String(x.emitidaEm).slice(0,5)):'')+'</span>'
        :(x.pago?'':'<span class="lg-em lg-em-nao">Não emitid'+(nome==='Guia'?'a':'o')+'</span>');
      return '<tr class="'+(x.pago?'lg-pt-pago':n!==null&&n<=0?'lg-pt-atr':'')+'"><td>'+esc(x.rot||'?')+'</td><td>'+esc(x.venc||'—')+'</td>'
        +'<td title="'+(x.lancado===false?'Valor não lançado nesta parcela: vale o último lançado':'')+'">'+_lgFmtV(Number(x.valor)||0)+(x.lancado===false?'<span class="lg-pt-est">*</span>':'')+'</td>'
        +'<td><div class="lg-pt-sit">'+pag+em+'</div></td>'
        +'<td class="lg-pt-ac">'+(x.pago?'':'<button type="button" class="btn-m ac-bt-pagar" data-lg-pagar="'+x.id+'" title="Lançar o pagamento desta parcela">✓ Pago</button>')+'</td></tr>'; }).join('')
    +'</tbody></table></div>'
    +(l.some(function(x){ return x.lancado===false; })?'<div class="lg-pt-nota">* valor ainda não lançado nesta parcela — vale o último valor lançado (o valor muda todo mês).</div>':'');
}
// cabeçalho do detalhamento com os dados da planilha (devedor, CPF/CNPJ, órgão, natureza, nº…)
function _lgFicha(campos){
  return '<div class="lg-ficha">'+campos.filter(function(c){ return c&&c[1]!==''&&c[1]!=null; }).map(function(c){ return '<div><span>'+c[0]+'</span><b>'+c[1]+'</b></div>'; }).join('')+'</div>';
}
